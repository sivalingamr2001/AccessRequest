export function LoginPage() {
  return (
    <>
      <div id="container">
        <div className="">
          <div className="">
            <div className="css-uwf2km css-fou3uo tailwind">
              <div className="flex min-h-screen w-full">
                <div
                  className="relative hidden w-[52%] flex-col justify-between overflow-hidden lg:flex"
                  style={{
                    background:
                      "linear-gradient(145deg, rgb(10, 31, 68) 0%, rgb(15, 42, 82) 40%, rgb(26, 58, 107) 70%, rgb(26, 95, 214) 100%)",
                  }}
                >
                  <div className="pointer-events-none absolute inset-0 overflow-hidden">
                    <div
                      className="absolute -top-32 -right-32 h-[500px] w-[500px] rounded-full opacity-10"
                      style={{
                        background:
                          "radial-gradient(circle, rgb(14, 165, 233) 0%, transparent 70%)",
                      }}
                    ></div>
                    <div
                      className="absolute bottom-0 -left-20 h-[400px] w-[400px] rounded-full opacity-10"
                      style={{
                        background:
                          "radial-gradient(circle, rgb(26, 95, 214) 0%, transparent 70%)",
                      }}
                    ></div>
                    <svg
                      className="absolute inset-0 h-full w-full opacity-[0.04]"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <defs>
                        <pattern
                          id="grid"
                          width="48"
                          height="48"
                          patternUnits="userSpaceOnUse"
                        >
                          <path
                            d="M 48 0 L 0 0 0 48"
                            fill="none"
                            stroke="white"
                            stroke-width="1"
                          ></path>
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#grid)"></rect>
                    </svg>
                  </div>
                  <div className="relative z-10 p-10">
                    <div className="flex items-center gap-3">
                      <div
                        className="flex h-10 w-10 items-center justify-center rounded-xl"
                        style={{
                          background:
                            "rgba(255, 255, 255, 0.12); border: 1px solid rgba(255, 255, 255, 0.2)",
                        }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          className="lucide lucide-factory text-white"
                        >
                          <path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path>
                          <path d="M17 18h1"></path>
                          <path d="M12 18h1"></path>
                          <path d="M7 18h1"></path>
                        </svg>
                      </div>
                      <div>
                        <div
                          className="text-4xl font-extrabold tracking-tight"
                          style={{
                            color: "rgb(96, 165, 250); letter-spacing: -0.02em",
                          }}
                        >
                          JANATICS
                        </div>
                        <div className="mt-1 text-xs tracking-widest text-blue-200 uppercase">
                          Unified Suite
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="relative z-10 flex flex-1 flex-col justify-center px-12 py-8">
                    <div
                      className="mb-6 inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium text-blue-200"
                      style={{
                        background:
                          "rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.12)",
                      }}
                    >
                      <div className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400"></div>
                      All systems operational
                    </div>
                    <h1
                      className="mb-4 text-4xl leading-tight font-bold text-white xl:text-5xl"
                      style={{ letterSpacing: "-0.02em" }}
                    >
                      Unified Control
                      <span style={{ color: "rgb(96, 165, 250)" }}>
                        for Every Process.
                      </span>
                    </h1>
                    <p className="max-w-sm text-base leading-relaxed text-blue-200">
                      One platform connecting production, supply chain,
                      documentation, and people — in real time.
                    </p>
                    <div className="mt-8 flex flex-wrap gap-2">
                      <span
                        className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold text-blue-100"
                        style={{
                          background:
                            "rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.12)",
                        }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          className="lucide lucide-layout-dashboard opacity-80"
                        >
                          <rect width="7" height="9" x="3" y="3" rx="1"></rect>
                          <rect width="7" height="5" x="14" y="3" rx="1"></rect>
                          <rect
                            width="7"
                            height="9"
                            x="14"
                            y="12"
                            rx="1"
                          ></rect>
                          <rect width="7" height="5" x="3" y="16" rx="1"></rect>
                        </svg>
                        Dashboards
                      </span>
                      <span
                        className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold text-blue-100"
                        style={{
                          background:
                            "rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.12)",
                        }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          className="lucide lucide-circle-alert opacity-80"
                        >
                          <circle cx="12" cy="12" r="10"></circle>
                          <line x1="12" x2="12" y1="8" y2="12"></line>
                          <line x1="12" x2="12.01" y1="16" y2="16"></line>
                        </svg>
                        Alerts
                      </span>
                      <span
                        className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold text-blue-100"
                        style={{
                          background:
                            "rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.12)",
                        }}
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          className="lucide lucide-chart-column opacity-80"
                        >
                          <path d="M3 3v16a2 2 0 0 0 2 2h16"></path>
                          <path d="M18 17V9"></path>
                          <path d="M13 17V5"></path>
                          <path d="M8 17v-3"></path>
                        </svg>
                        KPIs
                      </span>
                    </div>
                  </div>
                  <div
                    className="relative z-10 grid grid-cols-3 gap-4 border-t p-10"
                    style={{ borderColor: "rgba(255, 255, 255, 0.08)" }}
                  >
                    <div>
                      <div className="text-2xl font-bold text-white">7</div>
                      <div className="mt-0.5 text-xs text-blue-300">
                        Modules
                      </div>
                    </div>
                    <div>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        className="lucide lucide-layout-dashboard mb-0.5 text-blue-300"
                      >
                        <rect width="7" height="9" x="3" y="3" rx="1"></rect>
                        <rect width="7" height="5" x="14" y="3" rx="1"></rect>
                        <rect width="7" height="9" x="14" y="12" rx="1"></rect>
                        <rect width="7" height="5" x="3" y="16" rx="1"></rect>
                      </svg>
                      <div className="mt-0.5 text-xs text-blue-300">
                        Dashboards
                      </div>
                    </div>
                    <div>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        className="lucide lucide-chart-column mb-0.5 text-blue-300"
                      >
                        <path d="M3 3v16a2 2 0 0 0 2 2h16"></path>
                        <path d="M18 17V9"></path>
                        <path d="M13 17V5"></path>
                        <path d="M8 17v-3"></path>
                      </svg>
                      <div className="mt-0.5 text-xs text-blue-300">
                        KPI Metrics
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex flex-1 flex-col items-center justify-center bg-white p-8 lg:p-16">
                  <div className="mb-8 flex items-center gap-3 lg:hidden">
                    <div
                      className="flex h-10 w-10 items-center justify-center rounded-xl"
                      style={{ background: "rgb(26, 95, 214)" }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        className="lucide lucide-factory text-white"
                      >
                        <path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path>
                        <path d="M17 18h1"></path>
                        <path d="M12 18h1"></path>
                        <path d="M7 18h1"></path>
                      </svg>
                    </div>
                    <div>
                      <div
                        className="text-3xl font-extrabold"
                        style={{
                          color: "rgb(26, 95, 214); letter-spacing: -0.02em",
                        }}
                      >
                        JANATICS
                      </div>
                      <div className="mt-0.5 text-xs tracking-widest text-slate-400 uppercase">
                        Unified Suite
                      </div>
                    </div>
                  </div>
                  <div className="w-full max-w-sm">
                    <div className="mb-8">
                      <h2
                        className="mb-1 text-2xl font-bold text-slate-900"
                        style={{ letterSpacing: "-0.01em" }}
                      >
                        Janatics Unified Login
                      </h2>
                      <p className="text-sm text-slate-500">
                        Sign in to your workspace
                      </p>
                    </div>
                    <form className="flex flex-col gap-4">
                      <div>
                        <label className="mb-1.5 block text-xs font-semibold tracking-wider text-slate-600 uppercase">
                          Username
                        </label>
                        <div className="relative">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="15"
                            height="15"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            className="lucide lucide-users absolute top-1/2 left-3.5 -translate-y-1/2 text-slate-400"
                          >
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                            <circle cx="9" cy="7" r="4"></circle>
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                            <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                          </svg>
                          {/* <input type="text" placeholder="Enter username" className="w-full pl-10 pr-4 py-2.5 rounded-lg text-sm text-slate-800 outline-none transition-all" autoComplete="username" value="" style={{background: 'rgb(245, 247, 250); border: 1.5px solid rgb(226, 232, 240)'}} /> */}
                        </div>
                      </div>
                      <div>
                        <label className="mb-1.5 block text-xs font-semibold tracking-wider text-slate-600 uppercase">
                          Password
                        </label>
                        <div className="relative">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="15"
                            height="15"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            className="lucide lucide-lock absolute top-1/2 left-3.5 -translate-y-1/2 text-slate-400"
                          >
                            <rect
                              width="18"
                              height="11"
                              x="3"
                              y="11"
                              rx="2"
                              ry="2"
                            ></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                          </svg>
                          {/* <input type="text" placeholder="Enter password" className="w-full pl-10 pr-10 py-2.5 rounded-lg text-sm text-slate-800 outline-none transition-all" autoComplete="current-password" value="" style={{background: 'rgb(245, 247, 250); border: 1.5px solid rgb(226, 232, 240)'}} /> */}
                          <button
                            type="button"
                            className="absolute top-1/2 right-3.5 -translate-y-1/2 text-slate-400 transition-colors hover:text-slate-600"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="15"
                              height="15"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                              className="lucide lucide-eye-off"
                            >
                              <path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"></path>
                              <path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"></path>
                              <path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"></path>
                              <path d="m2 2 20 20"></path>
                            </svg>
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-xs">
                        <label className="flex cursor-pointer items-center gap-2 text-slate-500">
                          <input type="checkbox" className="rounded" />
                          Remember me
                        </label>
                        <button
                          type="button"
                          className="font-medium text-blue-600 hover:underline"
                        >
                          Forgot password?
                        </button>
                      </div>
                      <button
                        type="submit"
                        className="mt-1 flex w-full items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold text-white transition-all"
                        style={{
                          background:
                            "linear-gradient(135deg, rgb(26, 95, 214) 0%, rgb(14, 165, 233) 100%)",
                          boxShadow: "rgba(26, 95, 214, 0.35) 0px 4px 14px",
                        }}
                      >
                        Sign In
                      </button>
                    </form>
                    <div
                      className="mt-6 flex flex-col gap-1.5 rounded-lg p-3 text-xs text-slate-500"
                      style={{
                        background:
                          "rgb(240, 244, 248); border: 1px solid rgb(226, 232, 240)",
                      }}
                    >
                      <div className="flex items-center gap-2 font-medium text-slate-600">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="12"
                          height="12"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          className="lucide lucide-info shrink-0 text-blue-400"
                        >
                          <circle cx="12" cy="12" r="10"></circle>
                          <path d="M12 16v-4"></path>
                          <path d="M12 8h.01"></path>
                        </svg>{" "}
                        Demo credentials
                      </div>
                      <div className="flex items-center justify-between pl-1">
                        <span className="font-mono font-semibold text-slate-700">
                          admin / admin
                        </span>
                        <span className="text-slate-400">All modules</span>
                      </div>
                      <div className="flex items-center justify-between pl-1">
                        <span className="font-mono font-semibold text-slate-700">
                          skyfast / skyfast
                        </span>
                        <span className="text-slate-400">Finance · SCM</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-12 text-xs text-slate-400">
                    © 2026 EnterpriseOS · v4.2.1 ·{" "}
                    <span className="cursor-pointer hover:text-slate-600">
                      Privacy
                    </span>{" "}
                    ·{" "}
                    <span className="cursor-pointer hover:text-slate-600">
                      Terms
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default LoginPage
