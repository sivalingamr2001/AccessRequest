import DashboardPages from "./pages/DashboardPages"

export function App() {
  return (
    <>
      <DashboardPages />
    </>)
}

export default App
