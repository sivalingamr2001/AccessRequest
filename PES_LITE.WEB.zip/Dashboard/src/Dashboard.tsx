import { useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import { IndianRupee, Package, Warehouse, TrendingUp, ChartColumn, CheckSquare } from 'lucide-react';
import {
  REPORT_META,
  dateInfo,
  dynamic10DaySeries,
  kpiSummary,
  operatingUnits,
  groupTotals,
  salesOrdersMonthlyTrend,
  salesOrdersSummary,
  salesActualVsPriorByPeriod,
  unitFilterChips,
  type OperatingUnit,
  type SalesPeriod,
} from './data/data';

// ============================================================================
// Shared formatting helpers
// ============================================================================

const formatCr = (value: number | null | undefined, decimals = 2): string =>
  value === null || value === undefined ? '—' : `₹${value.toFixed(decimals)}`;

const formatPercent = (value: number): string => `${value.toFixed(2)}%`;

// ============================================================================
// Top Header Component
// ============================================================================

function HeaderSection({
  selectedFilter,
  setSelectedFilter,
  inclIntraSales,
  setInclIntraSales,
}: {
  selectedFilter: string;
  setSelectedFilter: (val: string) => void;
  inclIntraSales: boolean;
  setInclIntraSales: (val: boolean) => void;
}) {
  return (
    <header className="mb-6 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
      <div>
        <h1 className="text-3xl font-extrabold text-[#7C3AED] tracking-tight">
          Janatics Group Dashboard
        </h1>
        <p className="mt-1 text-sm font-semibold text-slate-800">
          Financial Year Comparison: {REPORT_META.currentFyLabel} vs {REPORT_META.priorFyLabel}
        </p>
        <p className="text-xs text-slate-500 font-normal mt-0.5">
          As on date: {REPORT_META.asOnDate} · All values in ₹ Crores (INR)
        </p>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => setSelectedFilter('All Units')}
          className={`rounded-lg px-4 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
            selectedFilter === 'All Units'
              ? 'bg-[#2563EB] text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          All Units
        </button>
        <button
          onClick={() => setSelectedFilter('Janatics')}
          className={`rounded-lg px-4 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
            selectedFilter === 'Janatics'
              ? 'bg-[#2563EB] text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          Janatics
        </button>
        <button
          onClick={() => setInclIntraSales(!inclIntraSales)}
          className={`rounded-lg px-4 py-1.5 text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
            inclIntraSales
              ? 'bg-[#2563EB] text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50'
          }`}
        >
          <CheckSquare className="h-4 w-4" />
          Incl Intra Sales
        </button>
      </div>
    </header>
  );
}

// ============================================================================
// KPI Cards Row
// ============================================================================

function KpiCardRow() {
  const { groupTurnover, pendingOrders, inventoryValue } = kpiSummary;

  return (
    <div className="mb-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
      {/* Group Turnover Card */}
      <div className="rounded-2xl border border-blue-200 bg-white p-5 shadow-xs">
        <div className="mb-4 flex items-center gap-3">
          <div className="rounded-full bg-blue-100 p-2.5 text-blue-600">
            <IndianRupee className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">{groupTurnover.label}</h3>
            <p className="text-xs text-slate-500">As on {groupTurnover.asOnDate}</p>
          </div>
        </div>

        <div className="mb-4 grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-blue-100 bg-[#EFF6FF] p-3 text-center">
            <p className="mb-1 text-xs font-medium text-slate-500">Current FY</p>
            <p className="text-2xl font-extrabold text-[#2563EB]">
              {formatCr(groupTurnover.currentValue)}
            </p>
            <p className="text-[11px] text-slate-400">{groupTurnover.unit}</p>
          </div>
          <div className="rounded-xl border border-slate-100 bg-[#F8FAFC] p-3 text-center">
            <p className="mb-1 text-xs font-medium text-slate-500">Previous FY</p>
            <p className="text-2xl font-bold text-slate-600">
              {formatCr(groupTurnover.previousValue)}
            </p>
            <p className="text-[11px] text-slate-400">{groupTurnover.unit}</p>
          </div>
        </div>

        <div className="text-center">
          <span className="inline-flex items-center rounded-full bg-[#10B981] px-4 py-1 text-xs font-bold text-white shadow-xs">
            <TrendingUp className="mr-1 h-3.5 w-3.5" />
            +{groupTurnover.growthPercent.toFixed(1)}% Growth
          </span>
        </div>
      </div>

      {/* Pending Orders Card */}
      <div className="rounded-2xl border-2 border-[#FCD34D] bg-[#FFFDF5] p-5 shadow-xs">
        <div className="mb-4 flex items-center gap-3">
          <div className="rounded-full bg-amber-100 p-2.5 text-amber-600">
            <Package className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">{pendingOrders.label}</h3>
            <p className="text-xs text-slate-500">{pendingOrders.asOnDate}</p>
          </div>
        </div>

        <div className="rounded-xl border border-amber-200 bg-[#FFFBEB] p-5 text-center">
          <p className="mb-1 text-xs font-semibold text-slate-600">{REPORT_META.currentFyLabel}</p>
          <p className="mb-1 text-4xl font-extrabold text-[#D97706]">
            {formatCr(pendingOrders.currentValue)}
          </p>
          <p className="text-xs text-slate-500">{pendingOrders.unit}</p>
        </div>
      </div>

      {/* Inventory Value Card */}
      <div className="rounded-2xl border-2 border-[#6EE7B7] bg-[#F0FDF4] p-5 shadow-xs">
        <div className="mb-4 flex items-center gap-3">
          <div className="rounded-full bg-emerald-100 p-2.5 text-emerald-600">
            <Warehouse className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">{inventoryValue.label}</h3>
            <p className="text-xs text-slate-500">{inventoryValue.asOnDate}</p>
          </div>
        </div>

        <div className="rounded-xl border border-emerald-200 bg-[#ECFDF5] p-5 text-center">
          <p className="mb-1 text-xs font-semibold text-slate-600">As on Date</p>
          <p className="mb-1 text-4xl font-extrabold text-[#059669]">
            {formatCr(inventoryValue.currentValue)}
          </p>
          <p className="text-xs text-slate-500">{inventoryValue.unit}</p>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// Operating Units Performance Comparison Table Component
// Replicates exact HTML structure, color codes, multi-level headers, and totals
// ============================================================================

function OperatingUnitsPerformanceTable({
  units,
  selectedIds,
  onToggleUnit,
  onToggleAll,
}: {
  units: OperatingUnit[];
  selectedIds: Record<string, boolean>;
  onToggleUnit: (id: string) => void;
  onToggleAll: () => void;
}) {
  const selectedUnits = useMemo(
    () => units.filter((u) => selectedIds[u.id]),
    [units, selectedIds],
  );

  const selectedCount = selectedUnits.length;
  const allChecked = selectedCount === units.length;

  // Compute live sums based on checked units
  const totals = useMemo(() => {
    return selectedUnits.reduce(
      (acc, u) => ({
        turnoverCurrentAsOnDate: acc.turnoverCurrentAsOnDate + u.turnoverCurrentAsOnDate,
        turnoverCurrentMonth: acc.turnoverCurrentMonth + u.turnoverCurrentMonth,
        turnoverPriorAsOnDate: acc.turnoverPriorAsOnDate + u.turnoverPriorAsOnDate,
        turnoverPriorMonth: acc.turnoverPriorMonth + u.turnoverPriorMonth,
        pendingOrdersAsOnDate: acc.pendingOrdersAsOnDate + u.pendingOrdersAsOnDate,
        pendingOrdersCurrentMonth: acc.pendingOrdersCurrentMonth + u.pendingOrdersCurrentMonth,
        inventoryAsOnDate: acc.inventoryAsOnDate + u.inventoryAsOnDate,
      }),
      {
        turnoverCurrentAsOnDate: 0,
        turnoverCurrentMonth: 0,
        turnoverPriorAsOnDate: 0,
        turnoverPriorMonth: 0,
        pendingOrdersAsOnDate: 0,
        pendingOrdersCurrentMonth: 0,
        inventoryAsOnDate: 0,
      },
    );
  }, [selectedUnits]);

  const totalYoyPercent =
    totals.turnoverPriorAsOnDate > 0
      ? ((totals.turnoverCurrentAsOnDate - totals.turnoverPriorAsOnDate) /
          totals.turnoverPriorAsOnDate) *
        100
      : groupTotals.turnoverYoyPercent;

  return (
    <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 mb-6">
      {/* Header bar matching exact user div */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 px-6 py-4 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">
            Operating Units Performance Comparison
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            As on {REPORT_META.asOnDate} · Values in ₹ Crores · {selectedCount} of {units.length} units selected
          </p>
        </div>
        <div className="flex gap-1 bg-white/10 rounded-lg p-1">
          <button
            onClick={onToggleAll}
            className={`px-3 py-1 rounded text-xs font-semibold transition-all cursor-pointer ${
              allChecked ? 'bg-white text-slate-900' : 'text-white/70 hover:bg-white/20'
            }`}
          >
            All Units
          </button>
          <button className="px-3 py-1 rounded text-xs font-semibold transition-all text-white/70 hover:bg-white/20 cursor-pointer">
            Janatics
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          {/* Multi-tier Header matching user's exact HTML code */}
          <thead className="bg-gradient-to-r from-slate-700 to-slate-800 text-white">
            <tr>
              <th className="px-4 py-4 text-center align-middle text-sm font-semibold w-12" rowSpan={3}>
                <input
                  type="checkbox"
                  checked={allChecked}
                  onChange={onToggleAll}
                  className="w-4 h-4 rounded cursor-pointer align-middle"
                />
              </th>
              <th className="px-4 py-4 text-left text-sm font-semibold align-middle" rowSpan={3}>
                Operating Unit
              </th>
              <th
                className="px-3 py-3 text-center text-sm font-semibold border-l border-slate-600"
                colSpan={5}
              >
                Turnover (₹ Cr)
              </th>
              <th
                className="px-3 py-3 text-center text-sm font-semibold border-l border-slate-600"
                colSpan={2}
              >
                Pending Orders (₹ Cr)
              </th>
              <th
                className="px-3 py-3 text-center text-sm font-semibold border-l border-slate-600 align-middle"
                rowSpan={3}
              >
                Inventory
                <br />
                (₹ Cr)
              </th>
            </tr>
            <tr>
              <th
                className="px-3 py-2 text-center text-xs font-medium bg-blue-600 border-l border-slate-600"
                colSpan={2}
              >
                {REPORT_META.currentFyLabel}
              </th>
              <th className="px-3 py-2 text-center text-xs font-medium bg-slate-600" colSpan={2}>
                {REPORT_META.priorFyLabel}
              </th>
              <th className="px-3 py-2 text-center text-xs font-medium bg-green-600">Trend</th>
              <th
                className="px-3 py-2 text-center text-xs font-medium bg-blue-600 border-l border-slate-600"
                colSpan={2}
              >
                {REPORT_META.currentFyLabel}
              </th>
            </tr>
            <tr>
              <th className="px-2 py-2 text-center text-xs font-medium bg-blue-500 border-l border-slate-600">
                As on Date
              </th>
              <th className="px-2 py-2 text-center text-xs font-medium bg-blue-500">Curr Month</th>
              <th className="px-2 py-2 text-center text-xs font-medium bg-slate-500">As on Date</th>
              <th className="px-2 py-2 text-center text-xs font-medium bg-slate-500">Curr Month</th>
              <th className="px-2 py-2 text-center text-xs font-medium bg-green-500">YoY %</th>
              <th className="px-2 py-2 text-center text-xs font-medium bg-blue-500 border-l border-slate-600">
                As on Date
              </th>
              <th className="px-2 py-2 text-center text-xs font-medium bg-blue-500">Curr Month</th>
            </tr>
          </thead>

          {/* Table Body */}
          <tbody className="divide-y divide-slate-100">
            {units.map((unit) => {
              const isChecked = selectedIds[unit.id] ?? true;
              return (
                <tr
                  key={unit.id}
                  onClick={() => onToggleUnit(unit.id)}
                  className="transition-all cursor-pointer hover:bg-blue-50/50"
                >
                  <td className="px-3 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => onToggleUnit(unit.id)}
                      className="w-4 h-4 text-blue-600 rounded cursor-pointer"
                    />
                  </td>
                  <td className="px-4 py-3 text-sm font-semibold text-slate-900">
                    <div>{unit.name}</div>
                    <div className="text-xs font-normal text-slate-400">{unit.code}</div>
                  </td>
                  <td className="px-3 py-3 text-center text-sm font-bold text-blue-700 bg-blue-50 border-l border-slate-200">
                    {formatCr(unit.turnoverCurrentAsOnDate)}
                  </td>
                  <td className="px-3 py-3 text-center text-sm font-bold text-blue-700 bg-blue-50">
                    {formatCr(unit.turnoverCurrentMonth)}
                  </td>
                  <td className="px-3 py-3 text-center text-sm text-slate-600">
                    {formatCr(unit.turnoverPriorAsOnDate)}
                  </td>
                  <td className="px-3 py-3 text-center text-sm text-slate-600">
                    {formatCr(unit.turnoverPriorMonth)}
                  </td>
                  <td className="px-3 py-3 text-center">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      {formatPercent(unit.turnoverYoyPercent)}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-center text-sm font-bold text-amber-700 bg-amber-50 border-l border-slate-200">
                    {formatCr(unit.pendingOrdersAsOnDate)}
                  </td>
                  <td className="px-3 py-3 text-center text-sm font-bold text-amber-700 bg-amber-50">
                    {formatCr(unit.pendingOrdersCurrentMonth)}
                  </td>
                  <td className="px-3 py-3 text-center text-sm font-bold text-green-700 bg-green-50 border-l border-slate-200">
                    {formatCr(unit.inventoryAsOnDate)}
                  </td>
                </tr>
              );
            })}

            {/* Selected Total Row matching user's exact HTML code */}
            <tr className="bg-slate-200 font-bold border-t-2 border-slate-400">
              <td className="px-3 py-4"></td>
              <td className="px-4 py-4 text-sm font-bold text-slate-900 uppercase">
                Selected Total
              </td>
              <td className="px-3 py-4 text-center text-sm font-bold text-blue-900 bg-blue-200 border-l border-slate-400">
                {formatCr(totals.turnoverCurrentAsOnDate)}
              </td>
              <td className="px-3 py-4 text-center text-sm font-bold text-blue-900 bg-blue-200">
                {formatCr(totals.turnoverCurrentMonth)}
              </td>
              <td className="px-3 py-4 text-center text-sm font-bold text-slate-700">
                {formatCr(totals.turnoverPriorAsOnDate)}
              </td>
              <td className="px-3 py-4 text-center text-sm font-bold text-slate-700">
                {formatCr(totals.turnoverPriorMonth)}
              </td>
              <td className="px-3 py-4 text-center">
                <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-bold text-white bg-green-600">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {formatPercent(totalYoyPercent)}
                </span>
              </td>
              <td className="px-3 py-4 text-center text-sm font-bold text-amber-900 bg-amber-200 border-l border-slate-400">
                {formatCr(totals.pendingOrdersAsOnDate)}
              </td>
              <td className="px-3 py-4 text-center text-sm font-bold text-amber-900 bg-amber-200">
                {formatCr(totals.pendingOrdersCurrentMonth)}
              </td>
              <td className="px-3 py-4 text-center text-sm font-bold text-green-900 bg-green-200 border-l border-slate-400">
                {formatCr(totals.inventoryAsOnDate)}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============================================================================
// Custom Tooltip Component matching user image
// ============================================================================

function CustomChartTooltip({ active, payload, label, isEmerald = false }: any) {
  if (!active || !payload || !payload.length) return null;

  const fy2627Point = payload.find((p: any) => p.dataKey === 'fy2627');
  const fy2526Point = payload.find((p: any) => p.dataKey === 'fy2526');

  const val2627 = fy2627Point?.value ?? null;
  const val2526 = fy2526Point?.value ?? null;

  let diff = 0;
  let percent = 0;
  if (val2627 !== null && val2526 !== null && val2526 > 0) {
    diff = val2627 - val2526;
    percent = (diff / val2526) * 100;
  }

  const valueColor = isEmerald ? 'text-[#10B981]' : 'text-[#6366F1]';

  return (
    <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-xl min-w-[220px]">
      <div className="mb-2 border-b border-slate-100 pb-2">
        <h4 className="text-base font-extrabold text-slate-900">{label}</h4>
      </div>

      <div className="space-y-2 mb-3">
        <div className="flex items-center justify-between gap-6">
          <span className="text-sm font-medium text-slate-500">FY 2026-27</span>
          <span className={`text-base font-extrabold ${valueColor}`}>
            {formatCr(val2627)} Cr
          </span>
        </div>

        <div className="flex items-center justify-between gap-6">
          <span className="text-sm font-medium text-slate-500">FY 2025-26</span>
          <span className="text-base font-bold text-slate-600">
            {formatCr(val2526)} Cr
          </span>
        </div>
      </div>

      {val2627 !== null && val2526 !== null && (
        <div className="flex items-center justify-between rounded-xl bg-[#F0FDF4] px-3 py-2 text-xs font-bold text-[#15803D]">
          <span className="flex items-center gap-1">
            <span>▲</span> {percent >= 0 ? `${percent.toFixed(1)}% YoY` : `${percent.toFixed(1)}% YoY`}
          </span>
          <span>
            {diff >= 0 ? `+₹${diff.toFixed(2)} Cr` : `-₹${Math.abs(diff).toFixed(2)} Cr`}
          </span>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// Chart 1 — Sales Orders, Month-wise Trend
// ============================================================================

function SalesOrdersTrendChart({
  activeUnit,
  setActiveUnit,
}: {
  activeUnit: string;
  setActiveUnit: (unit: string) => void;
}) {
  return (
    <div className="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
      {/* Deep Purple Header */}
      <div className="bg-[#581C87] px-6 py-4">
        <div className="mb-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ChartColumn className="h-5 w-5 text-purple-200" />
            <h2 className="text-lg font-bold text-white">Sales Orders — Month-wise Trend</h2>
          </div>
        </div>
        <p className="mb-3 text-xs text-purple-200">
          {REPORT_META.currentFyLabel} vs {REPORT_META.priorFyLabel} · ₹ Crores · Actuals through{' '}
          {dateInfo.currentMonthName}
        </p>

        {/* Operating Unit Filter Chips inside purple header */}
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setActiveUnit('All Units')}
            className={`rounded-full px-3 py-1 text-xs font-semibold transition-all cursor-pointer ${
              activeUnit === 'All Units'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            All Units
          </button>
          {unitFilterChips.map((chip) => (
            <button
              key={chip.code}
              onClick={() => setActiveUnit(chip.code)}
              className={`rounded-full px-3 py-1 text-xs font-semibold transition-all cursor-pointer ${
                activeUnit === chip.code
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'bg-white/10 text-white/80 hover:bg-white/20'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary stats bar (3 columns) */}
      <div className="grid grid-cols-1 divide-x divide-slate-100 border-b border-slate-200 sm:grid-cols-3">
        <div className="px-6 py-4">
          <p className="mb-1 text-xs font-semibold tracking-wide text-slate-400 uppercase">
            {salesOrdersSummary.currentLabel}
          </p>
          <p className="text-2xl font-extrabold text-[#6D28D9]">
            {formatCr(salesOrdersSummary.currentValue)}{' '}
            <span className="text-sm font-normal text-slate-400">Cr</span>
          </p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-[#6D28D9]" style={{ width: '100%' }} />
          </div>
        </div>

        <div className="px-6 py-4">
          <p className="mb-1 text-xs font-semibold tracking-wide text-slate-400 uppercase">
            {salesOrdersSummary.priorLabel}
          </p>
          <p className="text-2xl font-bold text-slate-600">
            {formatCr(salesOrdersSummary.priorValue)}{' '}
            <span className="text-sm font-normal text-slate-400">Cr</span>
          </p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full rounded-full bg-slate-400"
              style={{ width: `${salesOrdersSummary.priorProgressPercent}%` }}
            />
          </div>
        </div>

        <div className="px-6 py-4">
          <p className="mb-1 text-xs font-semibold tracking-wide text-slate-400 uppercase">
            YoY Growth
          </p>
          <p className="flex items-center gap-1 text-2xl font-extrabold text-[#10B981]">
            <TrendingUp className="h-5 w-5" />+{salesOrdersSummary.yoyGrowthPercent.toFixed(1)}%
          </p>
          <p className="mt-1 text-xs text-slate-400">
            +₹{salesOrdersSummary.aheadByValue.toFixed(2)} Cr ahead
          </p>
        </div>
      </div>

      {/* Chart */}
      <div className="p-6 min-w-0" style={{ height: 320, minWidth: 0 }}>
        <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
          <BarChart
            data={salesOrdersMonthlyTrend}
            margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
            <XAxis
              dataKey="month"
              tick={{ fontSize: 11, fill: '#94a3b8' }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomChartTooltip />} />
            <Bar
              dataKey="fy2526"
              name={REPORT_META.priorFyLabel}
              fill="#94a3b8"
              radius={[4, 4, 0, 0]}
              barSize={14}
            />
            <Bar
              dataKey="fy2627"
              name={REPORT_META.currentFyLabel}
              fill="#6366f1"
              radius={[4, 4, 0, 0]}
              barSize={14}
            />
            <ReferenceLine
              x="May"
              stroke="#f59e0b"
              strokeWidth={2}
              label={{
                value: '◆ Today',
                position: 'insideTopRight',
                fill: '#f59e0b',
                fontSize: 10,
                fontWeight: 800,
              }}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Custom Legend */}
      <div className="flex items-center justify-center gap-6 border-t border-slate-100 py-3 text-xs text-slate-500">
        <div className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#6366f1]" />
          <span>{REPORT_META.currentFyLabel} actual</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#94a3b8]" />
          <span>{REPORT_META.priorFyLabel} reference</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[#f59e0b] font-bold">◆</span>
          <span>Today cutoff</span>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// Chart 2 — Sales: Actual vs Prior Year (Area / Line Chart & Dual Bar)
// Replicates exact Image 1 design when Year-to-Date / Cumulative is selected
// ============================================================================

function SalesVsPriorYearChart({
  activeUnit,
  setActiveUnit,
}: {
  activeUnit: string;
  setActiveUnit: (unit: string) => void;
}) {
  const [period, setPeriod] = useState<SalesPeriod>('cumulative');
  const view = salesActualVsPriorByPeriod[period];

  return (
    <div className="mb-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
      {/* Dark Emerald Header matching Image 1 */}
      <div className="bg-[#04503E] px-6 py-4">
        <div className="mb-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="mb-1 flex items-center gap-2">
              <ChartColumn className="h-5 w-5 text-emerald-200" />
              <h2 className="text-xl font-bold text-white">Sales — Actual vs Prior Year</h2>
            </div>
            <p className="text-xs text-emerald-200">
              {REPORT_META.currentFyLabel} vs {REPORT_META.priorFyLabel} · ₹ Crores
            </p>
          </div>

          {/* Right side period toggle buttons matching Image 1 */}
          <div className="flex items-center gap-1 rounded-lg bg-emerald-950/40 p-1">
            <button
              onClick={() => setPeriod('10day')}
              className={`rounded px-3 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
                period === '10day'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-white/80 hover:bg-white/10'
              }`}
            >
              Day-wise
            </button>
            <button
              onClick={() => setPeriod('ytd')}
              className={`rounded px-3 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
                period === 'ytd'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-white/80 hover:bg-white/10'
              }`}
            >
              Month-wise
            </button>
            <button
              onClick={() => setPeriod('cumulative')}
              className={`rounded px-3 py-1.5 text-xs font-semibold transition-all cursor-pointer ${
                period === 'cumulative'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-white/80 hover:bg-white/10'
              }`}
            >
              Year-to-Date
            </button>
          </div>
        </div>

        {/* Operating Unit Filter Chips inside emerald header */}
        <div className="mt-3 flex flex-wrap gap-1.5">
          <button
            onClick={() => setActiveUnit('All Units')}
            className={`rounded-full px-3 py-1 text-xs font-semibold transition-all cursor-pointer ${
              activeUnit === 'All Units'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'bg-white/10 text-white/80 hover:bg-white/20'
            }`}
          >
            All Units
          </button>
          {unitFilterChips.map((chip) => (
            <button
              key={chip.code}
              onClick={() => setActiveUnit(chip.code)}
              className={`rounded-full px-3 py-1 text-xs font-semibold transition-all cursor-pointer ${
                activeUnit === chip.code
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'bg-white/10 text-white/80 hover:bg-white/20'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary stats bar (3 columns) matching Image 1 */}
      <div className="grid grid-cols-1 divide-x divide-slate-100 border-b border-slate-200 sm:grid-cols-3">
        <div className="px-6 py-4">
          <p className="mb-1 text-xs font-semibold tracking-wide text-slate-400 uppercase">
            {view.currentLabel}
          </p>
          <p className="text-3xl font-extrabold text-[#10B981]">
            {formatCr(view.currentValue)}{' '}
            <span className="text-sm font-normal text-slate-400">Cr</span>
          </p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-[#10B981]" style={{ width: '100%' }} />
          </div>
        </div>

        <div className="px-6 py-4">
          <p className="mb-1 text-xs font-semibold tracking-wide text-slate-400 uppercase">
            {view.priorLabel}
          </p>
          <p className="text-3xl font-bold text-slate-600">
            {formatCr(view.priorValue)}{' '}
            <span className="text-sm font-normal text-slate-400">Cr</span>
          </p>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full rounded-full bg-slate-400"
              style={{ width: `${view.priorProgressPercent}%` }}
            />
          </div>
        </div>

        <div className="px-6 py-4">
          <p className="mb-1 text-xs font-semibold tracking-wide text-slate-400 uppercase">
            Growth vs Prev FY
          </p>
          <p className="flex items-center gap-1 text-3xl font-extrabold text-[#10B981]">
            <TrendingUp className="h-6 w-6" />+8.5%
          </p>
          <p className="mt-1 text-xs text-slate-400">
            +₹{(view.currentValue - view.priorValue).toFixed(2)} Cr surplus
          </p>
        </div>
      </div>

      {/* Chart Section */}
      <div className="p-6 min-w-0" style={{ height: 340, minWidth: 0 }}>
        <ResponsiveContainer width="100%" height="100%" minWidth={0} minHeight={0}>
          {period === 'cumulative' ? (
            /* Area / Line chart matching Image 1 exactly */
            <AreaChart data={view.series} margin={{ top: 20, right: 10, left: 10, bottom: 0 }}>
              <defs>
                <linearGradient id="areaGreen" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis
                dataKey="month"
                tick={{ fontSize: 11, fill: '#94a3b8' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: '#94a3b8' }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => `₹${v}`}
              />
              <Tooltip content={<CustomChartTooltip isEmerald />} />
              {/* Dashed reference line for FY 2025-26 cumulative */}
              <Area
                type="monotone"
                dataKey="fy2526"
                name="FY 2025-26 (Cumulative)"
                stroke="#64748b"
                strokeDasharray="4 4"
                fill="none"
                strokeWidth={2}
              />
              {/* Green solid line & gradient fill for FY 2026-27 actual */}
              <Area
                type="monotone"
                dataKey="fy2627"
                name="FY 2026-27 (Cumulative)"
                stroke="#10b981"
                fill="url(#areaGreen)"
                strokeWidth={3}
                connectNulls={false}
                dot={{ r: 4, fill: '#10b981', strokeWidth: 2, stroke: '#fff' }}
              />
              <ReferenceLine
                x="May"
                stroke="#f59e0b"
                strokeWidth={2}
                label={{
                  value: '◆ Today',
                  position: 'insideTopLeft',
                  fill: '#f59e0b',
                  fontSize: 11,
                  fontWeight: 800,
                }}
              />
            </AreaChart>
          ) : (
            /* Dual Bar chart for Day-wise / Month-wise */
            <BarChart data={view.series} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis
                dataKey="month"
                tick={{ fontSize: 11, fill: '#94a3b8' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomChartTooltip isEmerald />} />
              <Bar
                dataKey="fy2526"
                name={REPORT_META.priorFyLabel}
                fill="#94a3b8"
                radius={[4, 4, 0, 0]}
                barSize={14}
              />
              <Bar
                dataKey="fy2627"
                name={REPORT_META.currentFyLabel}
                fill="#10b981"
                radius={[4, 4, 0, 0]}
                barSize={14}
              />
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Legend & Subtext matching Image 1 */}
      <div className="flex flex-col items-center justify-center gap-1.5 border-t border-slate-100 py-3 text-xs text-slate-500">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full border border-slate-500 bg-white" />
            <span className="font-semibold text-slate-600">{REPORT_META.priorFyLabel} (Cumulative)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full border border-emerald-500 bg-white" />
            <span className="font-semibold text-slate-600">{REPORT_META.currentFyLabel} (Cumulative)</span>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-[#10b981]" />
            <span>{REPORT_META.currentFyLabel} actual</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-[#64748b]" />
            <span>{REPORT_META.priorFyLabel} reference</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[#f59e0b] font-bold">◆</span>
            <span>Today cutoff</span>
          </div>
        </div>
        <p className="text-[11px] text-slate-400">
          {period === '10day'
            ? `Last 10 working days : ${dynamic10DaySeries[0]?.month} – ${dynamic10DaySeries[dynamic10DaySeries.length - 1]?.month} vs same days ${REPORT_META.priorFyLabel}`
            : `Cumulative YTD running total · ${REPORT_META.currentFyLabel} vs ${REPORT_META.priorFyLabel}`}
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// Main Dashboard Container
// ============================================================================

export function Dashboard() {
  const [selectedHeaderFilter, setSelectedHeaderFilter] = useState<string>('All Units');
  const [inclIntraSales, setInclIntraSales] = useState<boolean>(true);
  const [activeChartUnit, setActiveChartUnit] = useState<string>('All Units');

  // Track unit selection for rows
  const [selectedRowIds, setSelectedRowIds] = useState<Record<string, boolean>>(() =>
    operatingUnits.reduce((acc, u) => ({ ...acc, [u.id]: true }), {}),
  );

  const toggleUnit = (id: string) => {
    setSelectedRowIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleAll = () => {
    const isAllSelected = Object.values(selectedRowIds).every(Boolean);
    const nextState = !isAllSelected;
    setSelectedRowIds(
      operatingUnits.reduce((acc, u) => ({ ...acc, [u.id]: nextState }), {}),
    );
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] p-4 md:p-8 text-slate-800">
      <div className="mx-auto max-w-7xl">
        {/* Top Header */}
        <HeaderSection
          selectedFilter={selectedHeaderFilter}
          setSelectedFilter={setSelectedHeaderFilter}
          inclIntraSales={inclIntraSales}
          setInclIntraSales={setInclIntraSales}
        />

        {/* 3 KPI Cards */}
        <KpiCardRow />

        {/* Operating Units Performance Comparison Table */}
        <OperatingUnitsPerformanceTable
          units={operatingUnits}
          selectedIds={selectedRowIds}
          onToggleUnit={toggleUnit}
          onToggleAll={toggleAll}
        />

        {/* Charts Grid: Month-wise Trend & Sales Actual vs Prior */}
        <div className="space-y-6">
          <SalesOrdersTrendChart
            activeUnit={activeChartUnit}
            setActiveUnit={setActiveChartUnit}
          />
          <SalesVsPriorYearChart
            activeUnit={activeChartUnit}
            setActiveUnit={setActiveChartUnit}
          />
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
