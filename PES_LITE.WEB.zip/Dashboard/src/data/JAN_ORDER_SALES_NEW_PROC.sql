CREATE OR REPLACE PROCEDURE JAN_ORDER_SALES_NEW_PROC (
    p_stk_tfr_flg         IN  VARCHAR2 DEFAULT 'Y',
    p_ou_performance_cv   OUT SYS_REFCURSOR, -- 1. OU_PERFORMANCE DATA
    p_group_totals_cv     OUT SYS_REFCURSOR, -- 2. GROUP_TOTALS
    p_order_trend_cv      OUT SYS_REFCURSOR, -- 3. ORDER_TREND (Monthly Order)
    p_sales_trend_cv      OUT SYS_REFCURSOR, -- 4. SALES_TREND (Monthly Sales)
    p_rolling_10d_cv      OUT SYS_REFCURSOR, -- 5. 10Days_Sales
    p_cum_sales_cv        OUT SYS_REFCURSOR  -- 6. CUM_SALES (Cumulative YTD Sales)
) AS
    /* =========================================================================
       PROCEDURE  : JAN_ORDER_SALES_NEW_PROC
       PURPOSE    : Master Stored Procedure for Janatics Group Financial Dashboard.
                    Consolidates OU Performance, Group Totals, Monthly Order Trends,
                    Monthly Sales Trends, 10-Day Daily Sales, and Cumulative YTD Sales
                    with side-by-side Current FY (CY) and Previous FY (PY) values.
       
       OUTPUT CURSORS:
         1. p_ou_performance_cv : Operating Units Performance comparison table
         2. p_group_totals_cv   : Consolidated Group-level KPI summary totals
         3. p_order_trend_cv    : Month-wise Order Trend (CY vs PY Order Value in ₹ Cr)
         4. p_sales_trend_cv    : Month-wise Sales Trend (CY vs PY Sales Value in ₹ Cr)
         5. p_rolling_10d_cv    : Rolling 10-Working-Day Sales (CY vs PY Daily Sales in ₹ Cr)
         6. p_cum_sales_cv      : Cumulative YTD Sales (CY vs PY Cumulative Sales in ₹ Cr)
       
       PARAMETERS:
         p_stk_tfr_flg : 'Y' = All Sales/Orders (Internal Transfers + External)
                         'N' = External Sales/Orders Only
       ========================================================================= */

    v_curr_fy_start    DATE;
    v_curr_fy_end      DATE;
    v_prev_fy_start    DATE;
    v_prev_fy_end      DATE;
    
    -- Month start boundaries (1st of current month and same month last year)
    v_curr_month_start DATE;
    v_prev_month_start DATE;

    -- Rolling 10-day window boundaries
    v_window_start     DATE;
    v_window_end       DATE;
    v_ly_window_start  DATE;
    v_ly_window_end    DATE;

BEGIN
    -- =========================================================================
    -- 0. DYNAMIC FISCAL YEAR & DATE CALCULATIONS (April 1 to March 31)
    -- =========================================================================
    IF EXTRACT(MONTH FROM SYSDATE) >= 4 THEN
        v_curr_fy_start := TO_DATE('01-APR-' || TO_CHAR(SYSDATE, 'YYYY'), 'DD-MON-YYYY');
    ELSE
        v_curr_fy_start := TO_DATE('01-APR-' || TO_CHAR(ADD_MONTHS(SYSDATE, -12), 'YYYY'), 'DD-MON-YYYY');
    END IF;

    -- As On date ranges (up to current date)
    v_curr_fy_end      := TRUNC(SYSDATE) + 1;  -- Exclusive upper bound
    v_prev_fy_start    := ADD_MONTHS(v_curr_fy_start, -12);
    v_prev_fy_end      := ADD_MONTHS(v_curr_fy_end, -12);

    -- 1st day of current month and same month last year
    v_curr_month_start := TRUNC(SYSDATE, 'MM');
    v_prev_month_start := ADD_MONTHS(v_curr_month_start, -12);

    -- 10-day rolling window dates
    v_window_end       := TRUNC(SYSDATE);
    v_window_start     := TRUNC(SYSDATE) - 10;
    v_ly_window_end    := ADD_MONTHS(TRUNC(SYSDATE), -12);
    v_ly_window_start  := ADD_MONTHS(TRUNC(SYSDATE), -12) - 10;

    -- =========================================================================
    -- 1. OU_PERFORMANCE DATA (FEEDS OPERATING UNITS TABLE IN DATA.TS)
    -- =========================================================================
    OPEN p_ou_performance_cv FOR
        SELECT
            ORG_ID,
            OU_NAME,
            ROUND(SUM(CURR_FY_SALE_AS_ON) / 10000000, 2)       AS TURNOVER_CURR_AS_ON_DATE,
            ROUND(SUM(CURR_FY_SALE_CURRNT_MNTH) / 10000000, 2)  AS TURNOVER_CURR_MONTH,
            ROUND(SUM(PREV_FY_SALE_AS_ON) / 10000000, 2)       AS TURNOVER_PRIOR_AS_ON_DATE,
            ROUND(SUM(PREV_FY_SALE_CURRNT_MNTH) / 10000000, 2)  AS TURNOVER_PRIOR_MONTH,
            CASE
                WHEN SUM(PREV_FY_SALE_AS_ON) > 0 THEN
                    ROUND(((SUM(CURR_FY_SALE_AS_ON) - SUM(PREV_FY_SALE_AS_ON)) / SUM(PREV_FY_SALE_AS_ON)) * 100, 2)
                ELSE 0
            END AS TURNOVER_YOY_PERCENT,
            ROUND(SUM(CURR_FY_PEND_AS_ON) / 10000000, 2)       AS PENDING_ORDERS_CURR_AS_ON_DATE,
            ROUND(SUM(CURR_FY_PEND_CURRNT_MNTH) / 10000000, 2)  AS PENDING_ORDERS_CURR_MONTH,
            ROUND(SUM(PREV_FY_PEND_AS_ON) / 10000000, 2)       AS PENDING_ORDERS_PRIOR_AS_ON_DATE,
            ROUND(SUM(PREV_FY_PEND_CURRNT_MNTH) / 10000000, 2)  AS PENDING_ORDERS_PRIOR_MONTH,
            ROUND(SUM(INV_AMT) / 10000000, 2)                  AS INVENTORY_AS_ON_DATE,
            SORT_BY
        FROM (
            -- Sales & Orders Raw Values
            SELECT
                ORG_ID,
                OU_NAME,
                SUM(PREV_FY_SALE_AS_ON)       AS PREV_FY_SALE_AS_ON,
                SUM(PREV_FY_SALE_CURRNT_MNTH) AS PREV_FY_SALE_CURRNT_MNTH,
                SUM(CURR_FY_SALE_AS_ON)        AS CURR_FY_SALE_AS_ON,
                SUM(CURR_FY_SALE_CURRNT_MNTH)  AS CURR_FY_SALE_CURRNT_MNTH,
                SUM(PREV_FY_PEND_AS_ON)        AS PREV_FY_PEND_AS_ON,
                SUM(PREV_FY_PEND_CURRNT_MNTH)  AS PREV_FY_PEND_CURRNT_MNTH,
                SUM(CURR_FY_PEND_AS_ON)        AS CURR_FY_PEND_AS_ON,
                SUM(CURR_FY_PEND_CURRNT_MNTH)  AS CURR_FY_PEND_CURRNT_MNTH,
                CAST(0 AS NUMBER)              AS INV_AMT,
                SORT_BY
            FROM (
                SELECT
                    m.ORG_ID,
                    (SELECT alias_name FROM jan_ou_alias_name n WHERE n.org_id = m.org_id) AS OU_NAME,
                    -- Previous FY Sales As On
                    NVL(SUM(CASE WHEN TRX_DATE >= v_prev_fy_start AND TRX_DATE < v_prev_fy_end AND SOURCE_NAME = 'SALES'
                                 THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS PREV_FY_SALE_AS_ON,
                    -- Previous FY Sales Current Month
                    NVL(SUM(CASE WHEN TRX_DATE >= v_prev_month_start AND TRX_DATE < v_prev_fy_end AND SOURCE_NAME = 'SALES'
                                 THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS PREV_FY_SALE_CURRNT_MNTH,
                    -- Current FY Sales As On
                    NVL(SUM(CASE WHEN TRX_DATE >= v_curr_fy_start AND TRX_DATE < v_curr_fy_end AND SOURCE_NAME = 'SALES'
                                 THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_SALE_AS_ON,
                    -- Current FY Sales Current Month
                    NVL(SUM(CASE WHEN TRX_DATE >= v_curr_month_start AND TRX_DATE < v_curr_fy_end AND SOURCE_NAME = 'SALES'
                                 THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_SALE_CURRNT_MNTH,
                    -- Previous FY Pending Orders As On
                    NVL(SUM(CASE WHEN ORDERED_DATE >= v_prev_fy_start AND ORDERED_DATE < v_prev_fy_end AND SOURCE_NAME = 'ORDER'
                                 THEN NVL(PEND_QUANTITY, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS PREV_FY_PEND_AS_ON,
                    -- Previous FY Pending Orders Current Month
                    NVL(SUM(CASE WHEN ORDERED_DATE >= v_prev_month_start AND ORDERED_DATE < v_prev_fy_end AND SOURCE_NAME = 'ORDER'
                                 THEN NVL(PEND_QUANTITY, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS PREV_FY_PEND_CURRNT_MNTH,
                    -- Current FY Pending Orders As On
                    NVL(SUM(CASE WHEN ORDERED_DATE >= v_curr_fy_start AND ORDERED_DATE < v_curr_fy_end AND SOURCE_NAME = 'ORDER'
                                 THEN NVL(PEND_QUANTITY, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_PEND_AS_ON,
                    -- Current FY Pending Orders Current Month
                    NVL(SUM(CASE WHEN ORDERED_DATE >= v_curr_month_start AND ORDERED_DATE < v_curr_fy_end AND SOURCE_NAME = 'ORDER'
                                 THEN NVL(PEND_QUANTITY, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_PEND_CURRNT_MNTH,
                    (SELECT sort_by FROM jan_ou_alias_name k WHERE k.org_id = m.org_id) AS SORT_BY,
                    CASE
                        WHEN p_stk_tfr_flg = 'Y' AND m.org_id = 103 AND (m.ORD_EMPT_STATUS = 'Y' OR m.BILL_TO_CUST_NAME LIKE 'JANATICS INDIA PVT. LTD - UNIT%') THEN 'N'
                        ELSE 'Y'
                    END AS oa_flag
                FROM JAN_ALL_OU_ORD_SALES_V m
                WHERE (p_stk_tfr_flg = 'Y' OR m.STK_TFR_FLG = 'N')
                  AND m.ORD_EMPT_STATUS = 'N'
                  AND ((TRX_DATE >= v_prev_fy_start AND TRX_DATE < v_curr_fy_end)
                    OR (ORDERED_DATE >= v_prev_fy_start AND ORDERED_DATE < v_curr_fy_end))
                GROUP BY m.ORG_ID, m.ORD_EMPT_STATUS, m.BILL_TO_CUST_NAME
            )
            WHERE oa_flag = 'Y'
            GROUP BY ORG_ID, OU_NAME, SORT_BY

            UNION ALL

            -- Inventory Values
            SELECT
                ORG_ID,
                OU_NAME,
                0, 0, 0, 0, 0, 0, 0, 0,
                SUM(amount) AS INV_AMT,
                SORT_BY
            FROM (
                SELECT
                    (SELECT operating_unit FROM org_organization_definitions m WHERE m.organization_id = a.organization_id) AS ORG_ID,
                    (SELECT alias_name FROM jan_ou_alias_name n WHERE n.org_id = (SELECT operating_unit FROM org_organization_definitions m WHERE m.organization_id = a.organization_id)) AS OU_NAME,
                    NVL(TRANSACTION_QUANTITY, 0) * NVL(ITEM_COST, 0) AS amount,
                    (SELECT sort_by FROM jan_ou_alias_name k WHERE k.org_id = (SELECT operating_unit FROM org_organization_definitions m WHERE m.organization_id = a.organization_id)) AS SORT_BY
                FROM Jan_all_ou_inventory_details a
                WHERE INVENTORY_OTHERS = 'Planning Asset Sub-Inventories'
                  AND organization_id NOT IN (564, 565)
            )
            GROUP BY ORG_ID, OU_NAME, SORT_BY
        )
        GROUP BY ORG_ID, OU_NAME, SORT_BY
        ORDER BY SORT_BY ASC, ORG_ID ASC;

    -- =========================================================================
    -- 2. GROUP_TOTALS (CONSOLIDATED GROUP KPI CARDS SUMMARY)
    -- =========================================================================
    OPEN p_group_totals_cv FOR
        SELECT
            ROUND(SUM(CURR_FY_SALE_AS_ON) / 10000000, 2)       AS GROUP_TURNOVER_CURR_AS_ON,
            ROUND(SUM(CURR_FY_SALE_CURRNT_MNTH) / 10000000, 2)  AS GROUP_TURNOVER_CURR_MNTH,
            ROUND(SUM(PREV_FY_SALE_AS_ON) / 10000000, 2)       AS GROUP_TURNOVER_PREV_AS_ON,
            ROUND(SUM(PREV_FY_SALE_CURRNT_MNTH) / 10000000, 2)  AS GROUP_TURNOVER_PREV_MNTH,
            CASE
                WHEN SUM(PREV_FY_SALE_AS_ON) > 0 THEN
                    ROUND(((SUM(CURR_FY_SALE_AS_ON) - SUM(PREV_FY_SALE_AS_ON)) / SUM(PREV_FY_SALE_AS_ON)) * 100, 2)
                ELSE 0
            END AS GROUP_TURNOVER_YOY_PCT,
            ROUND(SUM(CURR_FY_PEND_AS_ON) / 10000000, 2)       AS GROUP_PENDING_CURR_AS_ON,
            ROUND(SUM(CURR_FY_PEND_CURRNT_MNTH) / 10000000, 2)  AS GROUP_PENDING_CURR_MNTH,
            ROUND(SUM(INV_AMT) / 10000000, 2)                  AS GROUP_INVENTORY_AS_ON
        FROM (
            SELECT
                NVL(SUM(CASE WHEN TRX_DATE >= v_curr_fy_start AND TRX_DATE < v_curr_fy_end AND SOURCE_NAME = 'SALES' THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_SALE_AS_ON,
                NVL(SUM(CASE WHEN TRX_DATE >= v_curr_month_start AND TRX_DATE < v_curr_fy_end AND SOURCE_NAME = 'SALES' THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_SALE_CURRNT_MNTH,
                NVL(SUM(CASE WHEN TRX_DATE >= v_prev_fy_start AND TRX_DATE < v_prev_fy_end AND SOURCE_NAME = 'SALES' THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS PREV_FY_SALE_AS_ON,
                NVL(SUM(CASE WHEN TRX_DATE >= v_prev_month_start AND TRX_DATE < v_prev_fy_end AND SOURCE_NAME = 'SALES' THEN NVL(QUANTITY_INVOICED, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS PREV_FY_SALE_CURRNT_MNTH,
                NVL(SUM(CASE WHEN ORDERED_DATE >= v_curr_fy_start AND ORDERED_DATE < v_curr_fy_end AND SOURCE_NAME = 'ORDER' THEN NVL(PEND_QUANTITY, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_PEND_AS_ON,
                NVL(SUM(CASE WHEN ORDERED_DATE >= v_curr_month_start AND ORDERED_DATE < v_curr_fy_end AND SOURCE_NAME = 'ORDER' THEN NVL(PEND_QUANTITY, 0) * NVL(UNIT_SELLING_PRICE, 0) * NVL(TO_NUMBER(REGEXP_REPLACE(Ou_Currency_Conv_Rate, '[^0-9.\-]')), 1) END), 0) AS CURR_FY_PEND_CURRNT_MNTH,
                0 AS INV_AMT
            FROM JAN_ALL_OU_ORD_SALES_V m
            WHERE (p_stk_tfr_flg = 'Y' OR m.STK_TFR_FLG = 'N')
              AND m.ORD_EMPT_STATUS = 'N'
              AND ((TRX_DATE >= v_prev_fy_start AND TRX_DATE < v_curr_fy_end) OR (ORDERED_DATE >= v_prev_fy_start AND ORDERED_DATE < v_curr_fy_end))

            UNION ALL

            SELECT 0, 0, 0, 0, 0, 0, SUM(NVL(TRANSACTION_QUANTITY, 0) * NVL(ITEM_COST, 0)) AS INV_AMT
            FROM Jan_all_ou_inventory_details a
            WHERE INVENTORY_OTHERS = 'Planning Asset Sub-Inventories'
              AND organization_id NOT IN (564, 565)
        );

    -- =========================================================================
    -- 3. ORDER_TREND (MONTHLY ORDER VALUE: CURRENT FY VS PREVIOUS FY)
    -- =========================================================================
    OPEN p_order_trend_cv FOR
        SELECT
            os.org_id,
            n.alias_name AS ou_name,
            TO_CHAR(os.ordered_date, 'MON') AS month_name,
            CASE 
                WHEN EXTRACT(MONTH FROM os.ordered_date) >= 4 THEN EXTRACT(MONTH FROM os.ordered_date) - 3
                ELSE EXTRACT(MONTH FROM os.ordered_date) + 9
            END AS fy_month_seq,
            ROUND(
                SUM(
                    CASE 
                        WHEN os.ordered_date >= v_curr_fy_start AND os.ordered_date < v_curr_fy_end 
                        THEN os.ordered_quantity * os.unit_selling_price * os.ou_currency_conv_rate 
                        ELSE 0 
                    END
                ) / 10000000, 
                2
            ) AS cy_order_val,
            ROUND(
                SUM(
                    CASE 
                        WHEN os.ordered_date >= v_prev_fy_start AND os.ordered_date < v_prev_fy_end 
                        THEN os.ordered_quantity * os.unit_selling_price * os.ou_currency_conv_rate 
                        ELSE 0 
                    END
                ) / 10000000, 
                2
            ) AS py_order_val
        FROM jan_all_ou_ord_sales_v os
        JOIN (
            SELECT m.operating_unit AS valid_org_id
            FROM jan_all_ou_inventory_details a
            JOIN org_organization_definitions m ON m.organization_id = a.organization_id
            WHERE a.inventory_others = 'Planning Asset Sub-Inventories'
              AND a.organization_id NOT IN (564, 565)
            GROUP BY m.operating_unit
        ) filter_ou ON os.org_id = filter_ou.valid_org_id
        JOIN jan_ou_alias_name n ON n.org_id = os.org_id
        WHERE os.source_name = 'ORDER'
          AND os.ord_empt_status = 'N'
          AND (p_stk_tfr_flg = 'Y' OR os.stk_tfr_flg = 'N')
          AND ((os.ordered_date >= v_curr_fy_start AND os.ordered_date < v_curr_fy_end)
            OR (os.ordered_date >= v_prev_fy_start AND os.ordered_date < v_prev_fy_end))
        GROUP BY
            os.org_id,
            n.alias_name,
            n.sort_by,
            TO_CHAR(os.ordered_date, 'MON'),
            CASE 
                WHEN EXTRACT(MONTH FROM os.ordered_date) >= 4 THEN EXTRACT(MONTH FROM os.ordered_date) - 3
                ELSE EXTRACT(MONTH FROM os.ordered_date) + 9
            END
        ORDER BY
            n.sort_by ASC,
            os.org_id ASC,
            fy_month_seq ASC;

    -- =========================================================================
    -- 4. SALES_TREND (MONTHLY SALES VALUE: CURRENT FY VS PREVIOUS FY)
    -- =========================================================================
    OPEN p_sales_trend_cv FOR
        SELECT
            os.org_id,
            n.alias_name AS ou_name,
            TO_CHAR(os.trx_date, 'MON') AS month_name,
            CASE 
                WHEN EXTRACT(MONTH FROM os.trx_date) >= 4 THEN EXTRACT(MONTH FROM os.trx_date) - 3
                ELSE EXTRACT(MONTH FROM os.trx_date) + 9
            END AS fy_month_seq,
            ROUND(
                SUM(
                    CASE 
                        WHEN os.trx_date >= v_curr_fy_start AND os.trx_date < v_curr_fy_end 
                        THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate 
                        ELSE 0 
                    END
                ) / 10000000, 
                2
            ) AS cy_sales_val,
            ROUND(
                SUM(
                    CASE 
                        WHEN os.trx_date >= v_prev_fy_start AND os.trx_date < v_prev_fy_end 
                        THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate 
                        ELSE 0 
                    END
                ) / 10000000, 
                2
            ) AS py_sales_val
        FROM jan_all_ou_ord_sales_v os
        JOIN (
            SELECT m.operating_unit AS valid_org_id
            FROM jan_all_ou_inventory_details a
            JOIN org_organization_definitions m ON m.organization_id = a.organization_id
            WHERE a.inventory_others = 'Planning Asset Sub-Inventories'
              AND a.organization_id NOT IN (564, 565)
            GROUP BY m.operating_unit
        ) filter_ou ON os.org_id = filter_ou.valid_org_id
        JOIN jan_ou_alias_name n ON n.org_id = os.org_id
        WHERE os.source_name = 'SALES'
          AND os.ord_empt_status = 'N'
          AND (p_stk_tfr_flg = 'Y' OR os.stk_tfr_flg = 'N')
          AND ((os.trx_date >= v_curr_fy_start AND os.trx_date < v_curr_fy_end)
            OR (os.trx_date >= v_prev_fy_start AND os.trx_date < v_prev_fy_end))
        GROUP BY
            os.org_id,
            n.alias_name,
            n.sort_by,
            TO_CHAR(os.trx_date, 'MON'),
            CASE 
                WHEN EXTRACT(MONTH FROM os.trx_date) >= 4 THEN EXTRACT(MONTH FROM os.trx_date) - 3
                ELSE EXTRACT(MONTH FROM os.trx_date) + 9
            END
        ORDER BY
            n.sort_by ASC,
            os.org_id ASC,
            fy_month_seq ASC;

    -- =========================================================================
    -- 5. 10Days_Sales (ROLLING 10-WORKING-DAY SALES: CURRENT VS PREVIOUS YEAR)
    -- =========================================================================
    OPEN p_rolling_10d_cv FOR
        WITH sales_summary AS (
            SELECT
                os.org_id,
                n.alias_name AS ou_name,
                n.sort_by,
                TO_CHAR(os.trx_date, 'DD MON') AS calendar_day,
                ROUND(
                    SUM(
                        CASE
                            WHEN os.trx_date >= v_window_start AND os.trx_date <= v_window_end
                            THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate
                        END
                    ) / 10000000,
                    2
                ) AS cy_sales,
                ROUND(
                    SUM(
                        CASE
                            WHEN os.trx_date >= v_ly_window_start AND os.trx_date <= v_ly_window_end
                            THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate
                        END
                    ) / 10000000,
                    2
                ) AS py_sales,
                TRUNC(os.trx_date) AS sort_date
            FROM jan_all_ou_ord_sales_v os
            JOIN (
                SELECT m.operating_unit AS valid_org_id
                FROM jan_all_ou_inventory_details a
                JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                WHERE a.inventory_others = 'Planning Asset Sub-Inventories'
                  AND a.organization_id NOT IN (564, 565)
                GROUP BY m.operating_unit
            ) filter_ou ON os.org_id = filter_ou.valid_org_id
            JOIN jan_ou_alias_name n ON n.org_id = os.org_id
            WHERE os.source_name = 'SALES'
              AND os.ord_empt_status = 'N'
              AND (p_stk_tfr_flg = 'Y' OR os.stk_tfr_flg = 'N')
              AND ((os.trx_date >= v_window_start AND os.trx_date <= v_window_end)
                OR (os.trx_date >= v_ly_window_start AND os.trx_date <= v_ly_window_end))
            GROUP BY
                os.org_id,
                n.alias_name,
                n.sort_by,
                TO_CHAR(os.trx_date, 'DD MON'),
                TRUNC(os.trx_date)
        )
        SELECT
            org_id,
            ou_name,
            calendar_day,
            cy_sales,
            py_sales
        FROM sales_summary
        ORDER BY
            sort_by ASC,
            org_id ASC,
            sort_date ASC;

    -- =========================================================================
    -- 6. CUM_SALES (CUMULATIVE YTD MONTHLY SALES: CURRENT FY VS PREVIOUS FY)
    -- =========================================================================
    OPEN p_cum_sales_cv FOR
        WITH monthly_sales AS (
            SELECT
                os.org_id,
                n.alias_name AS ou_name,
                n.sort_by,
                TO_CHAR(os.trx_date, 'MON') AS month_name,
                CASE 
                    WHEN EXTRACT(MONTH FROM os.trx_date) >= 4 THEN EXTRACT(MONTH FROM os.trx_date) - 3
                    ELSE EXTRACT(MONTH FROM os.trx_date) + 9
                END AS fy_month_seq,
                SUM(
                    CASE 
                        WHEN os.trx_date >= v_curr_fy_start AND os.trx_date < v_curr_fy_end 
                        THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate 
                        ELSE 0 
                    END
                ) AS cy_raw_sales,
                SUM(
                    CASE 
                        WHEN os.trx_date >= v_prev_fy_start AND os.trx_date < v_prev_fy_end 
                        THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate 
                        ELSE 0 
                    END
                ) AS py_raw_sales
            FROM jan_all_ou_ord_sales_v os
            JOIN (
                SELECT m.operating_unit AS valid_org_id
                FROM jan_all_ou_inventory_details a
                JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                WHERE a.inventory_others = 'Planning Asset Sub-Inventories'
                  AND a.organization_id NOT IN (564, 565)
                GROUP BY m.operating_unit
            ) filter_ou ON os.org_id = filter_ou.valid_org_id
            JOIN jan_ou_alias_name n ON n.org_id = os.org_id
            WHERE os.source_name = 'SALES'
              AND os.ord_empt_status = 'N'
              AND (p_stk_tfr_flg = 'Y' OR os.stk_tfr_flg = 'N')
              AND ((os.trx_date >= v_curr_fy_start AND os.trx_date < v_curr_fy_end)
                OR (os.trx_date >= v_prev_fy_start AND os.trx_date < v_prev_fy_end))
            GROUP BY
                os.org_id,
                n.alias_name,
                n.sort_by,
                TO_CHAR(os.trx_date, 'MON'),
                CASE 
                    WHEN EXTRACT(MONTH FROM os.trx_date) >= 4 THEN EXTRACT(MONTH FROM os.trx_date) - 3
                    ELSE EXTRACT(MONTH FROM os.trx_date) + 9
                END
        )
        SELECT
            org_id,
            ou_name,
            month_name,
            fy_month_seq,
            ROUND(cy_raw_sales / 10000000, 2) AS cy_monthly_sales_cr,
            ROUND(py_raw_sales / 10000000, 2) AS py_monthly_sales_cr,
            ROUND(SUM(cy_raw_sales) OVER (PARTITION BY org_id, ou_name ORDER BY fy_month_seq ASC) / 10000000, 2) AS cy_cum_sales_cr,
            ROUND(SUM(py_raw_sales) OVER (PARTITION BY org_id, ou_name ORDER BY fy_month_seq ASC) / 10000000, 2) AS py_cum_sales_cr
        FROM monthly_sales
        ORDER BY
            sort_by ASC,
            org_id ASC,
            fy_month_seq ASC;

EXCEPTION
    WHEN OTHERS THEN
        IF p_ou_performance_cv%ISOPEN THEN CLOSE p_ou_performance_cv; END IF;
        IF p_group_totals_cv%ISOPEN THEN CLOSE p_group_totals_cv; END IF;
        IF p_order_trend_cv%ISOPEN THEN CLOSE p_order_trend_cv; END IF;
        IF p_sales_trend_cv%ISOPEN THEN CLOSE p_sales_trend_cv; END IF;
        IF p_rolling_10d_cv%ISOPEN THEN CLOSE p_rolling_10d_cv; END IF;
        IF p_cum_sales_cv%ISOPEN THEN CLOSE p_cum_sales_cv; END IF;
        RAISE;

END JAN_ORDER_SALES_NEW_PROC;
/
