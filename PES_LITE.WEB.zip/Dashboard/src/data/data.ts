/**
 * <summary>
 *   <module>data.ts</module>
 *   <purpose>
 *     Typed data source for the Janatics Group Dashboard with dynamic date,
 *     fiscal year, month, and 10-working-day computations.
 *   </purpose>
 * </summary>
 */

// ============================================================================
// Types
// ============================================================================

export interface OperatingUnit {
  id: string;
  name: string;
  code: string;
  location: string;
  turnoverCurrentAsOnDate: number;
  turnoverCurrentMonth: number;
  turnoverPriorAsOnDate: number;
  turnoverPriorMonth: number;
  turnoverYoyPercent: number;
  pendingOrdersAsOnDate: number;
  pendingOrdersCurrentMonth: number;
  inventoryAsOnDate: number;
}

export interface GroupTotals {
  turnoverCurrentAsOnDate: number;
  turnoverCurrentMonth: number;
  turnoverPriorAsOnDate: number;
  turnoverPriorMonth: number;
  turnoverYoyPercent: number;
  pendingOrdersAsOnDate: number;
  pendingOrdersCurrentMonth: number;
  inventoryAsOnDate: number;
}

export interface KpiSummary {
  groupTurnover: {
    label: string;
    asOnDate: string;
    currentValue: number;
    previousValue: number;
    growthPercent: number;
    unit: string;
  };
  pendingOrders: {
    label: string;
    asOnDate: string;
    currentValue: number;
    unit: string;
  };
  inventoryValue: {
    label: string;
    asOnDate: string;
    currentValue: number;
    unit: string;
  };
}

export interface MonthlyTrendPoint {
  month: string;
  fy2627: number | null;
  fy2526: number | null;
}

export interface SalesTrendSummary {
  currentLabel: string;
  currentValue: number;
  priorLabel: string;
  priorValue: number;
  priorProgressPercent: number;
  yoyGrowthPercent: number;
  aheadByValue: number;
  unit: string;
}

export type SalesPeriod = '10day' | 'ytd' | 'cumulative';

export interface SalesPeriodOption {
  key: SalesPeriod;
  label: string;
  currentLabel: string;
  priorLabel: string;
  currentValue: number;
  priorValue: number;
  priorProgressPercent: number;
  series: MonthlyTrendPoint[];
  showTodayReference: boolean;
}

export interface UnitFilterChip {
  code: string;
  label: string;
}

// ============================================================================
// Dynamic Date & Fiscal Year Helper Functions
// ============================================================================

export function getDynamicDateInfo(referenceDate: Date = new Date()) {
  const monthNamesShort = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  const dayStr = String(referenceDate.getDate()).padStart(2, '0');
  const monthStr = monthNamesShort[referenceDate.getMonth()];
  const yearNum = referenceDate.getFullYear();
  const asOnDate = `${dayStr}-${monthStr}-${yearNum}`;

  // Calculate Indian Fiscal Year (Apr 1 to Mar 31)
  const currentMonthIdx = referenceDate.getMonth(); // 0 = Jan, 3 = Apr, etc.
  const fyStartYear = currentMonthIdx >= 3 ? yearNum : yearNum - 1;
  const fyEndYear = fyStartYear + 1;
  const priorFyStartYear = fyStartYear - 1;
  const priorFyEndYear = fyStartYear;

  const currentFyLabel = `FY ${fyStartYear}-${String(fyEndYear).slice(-2)}`;
  const priorFyLabel = `FY ${priorFyStartYear}-${String(priorFyEndYear).slice(-2)}`;

  return {
    asOnDate,
    currentFyLabel,
    priorFyLabel,
    currentMonthName: monthStr,
    currentMonthIdx,
    yearNum,
    fyStartYear,
  };
}

export function getDynamicLast10DaysSeries(endDate: Date = new Date()) {
  const baseValues2627 = [14.20, 13.30, 12.90, 14.50, 13.90, 14.20, 13.60, 14.00, 13.10, 12.80];
  const baseValues2526 = [13.22, 12.70, 12.30, 13.20, 12.60, 13.10, 12.80, 12.40, 12.00, 11.60];
  const monthNamesShort = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  const series: MonthlyTrendPoint[] = [];
  const curr = new Date(endDate);
  let count = 0;

  while (count < 10) {
    if (curr.getDay() !== 0) {
      // Skip Sunday
      const dayStr = String(curr.getDate()).padStart(2, '0');
      const monthStr = monthNamesShort[curr.getMonth()];
      series.unshift({
        month: `${dayStr} ${monthStr}`,
        fy2627: baseValues2627[count % 10],
        fy2526: baseValues2526[count % 10],
      });
      count++;
    }
    curr.setDate(curr.getDate() - 1);
  }
  return series;
}

// Compute active Date Info dynamically
export const dateInfo = getDynamicDateInfo();

// ============================================================================
// Report metadata (Dynamic)
// ============================================================================

export const REPORT_META = {
  groupName: 'Janatics Group',
  asOnDate: dateInfo.asOnDate,
  currentFyLabel: dateInfo.currentFyLabel,
  priorFyLabel: dateInfo.priorFyLabel,
  currency: '₹ Crores (INR)',
};

// ============================================================================
// KPI cards (Dynamic As-On Date)
// ============================================================================

export const kpiSummary: KpiSummary = {
  groupTurnover: {
    label: 'Group Turnover',
    asOnDate: dateInfo.asOnDate,
    currentValue: 229.70,
    previousValue: 213.10,
    growthPercent: 7.8,
    unit: 'Crores',
  },
  pendingOrders: {
    label: 'Pending Orders',
    asOnDate: dateInfo.asOnDate,
    currentValue: 723.30,
    unit: 'Crores (INR)',
  },
  inventoryValue: {
    label: 'Inventory Value',
    asOnDate: dateInfo.asOnDate,
    currentValue: 140.20,
    unit: 'Crores (INR)',
  },
};

// ============================================================================
// Operating Units — feeds the table
// ============================================================================

export const operatingUnits: OperatingUnit[] = [
  {
    id: 'dubai',
    name: 'Dubai Operating Unit',
    code: 'Dubai',
    location: 'Dubai',
    turnoverCurrentAsOnDate: 5.30,
    turnoverCurrentMonth: 2.80,
    turnoverPriorAsOnDate: 4.90,
    turnoverPriorMonth: 2.50,
    turnoverYoyPercent: 8.20,
    pendingOrdersAsOnDate: 18.50,
    pendingOrdersCurrentMonth: 3.50,
    inventoryAsOnDate: 4.20,
  },
  {
    id: 'global',
    name: 'Global Operating Unit',
    code: 'Global',
    location: 'Global',
    turnoverCurrentAsOnDate: 28.50,
    turnoverCurrentMonth: 14.20,
    turnoverPriorAsOnDate: 26.80,
    turnoverPriorMonth: 13.40,
    turnoverYoyPercent: 6.30,
    pendingOrdersAsOnDate: 89.20,
    pendingOrdersCurrentMonth: 16.80,
    inventoryAsOnDate: 18.50,
  },
  {
    id: 'germany',
    name: 'Janatics Germany Operating Unit',
    code: 'Germany',
    location: 'Germany',
    turnoverCurrentAsOnDate: 22.30,
    turnoverCurrentMonth: 11.60,
    turnoverPriorAsOnDate: 20.60,
    turnoverPriorMonth: 10.80,
    turnoverYoyPercent: 8.30,
    pendingOrdersAsOnDate: 67.50,
    pendingOrdersCurrentMonth: 12.40,
    inventoryAsOnDate: 14.20,
  },
  {
    id: 'iapl',
    name: 'Janatics Industrial Automation Pvt Ltd Operating Unit',
    code: 'IAPL',
    location: 'India',
    turnoverCurrentAsOnDate: 36.80,
    turnoverCurrentMonth: 18.50,
    turnoverPriorAsOnDate: 34.20,
    turnoverPriorMonth: 17.20,
    turnoverYoyPercent: 7.60,
    pendingOrdersAsOnDate: 112.40,
    pendingOrdersCurrentMonth: 21.20,
    inventoryAsOnDate: 22.80,
  },
  {
    id: 'iapl-coil',
    name: 'Janatics Industrial Automation Pvt Ltd - Coil',
    code: 'IAPL-Coil',
    location: 'India',
    turnoverCurrentAsOnDate: 18.40,
    turnoverCurrentMonth: 9.20,
    turnoverPriorAsOnDate: 16.80,
    turnoverPriorMonth: 8.50,
    turnoverYoyPercent: 9.50,
    pendingOrdersAsOnDate: 54.60,
    pendingOrdersCurrentMonth: 10.20,
    inventoryAsOnDate: 11.50,
  },
  {
    id: 'janatics-ou',
    name: 'Janatics Operating Unit',
    code: 'Janatics OU',
    location: 'India',
    turnoverCurrentAsOnDate: 67.20,
    turnoverCurrentMonth: 33.80,
    turnoverPriorAsOnDate: 62.50,
    turnoverPriorMonth: 31.40,
    turnoverYoyPercent: 7.50,
    pendingOrdersAsOnDate: 215.80,
    pendingOrdersCurrentMonth: 39.80,
    inventoryAsOnDate: 35.60,
  },
  {
    id: 'usa',
    name: 'Janatics USA Operating Unit',
    code: 'USA',
    location: 'USA',
    turnoverCurrentAsOnDate: 6.10,
    turnoverCurrentMonth: 3.20,
    turnoverPriorAsOnDate: 5.70,
    turnoverPriorMonth: 2.90,
    turnoverYoyPercent: 7.00,
    pendingOrdersAsOnDate: 21.20,
    pendingOrdersCurrentMonth: 4.10,
    inventoryAsOnDate: 4.80,
  },
  {
    id: 'polymer',
    name: 'Polymer Operating Unit',
    code: 'Polymer',
    location: 'India',
    turnoverCurrentAsOnDate: 21.10,
    turnoverCurrentMonth: 10.80,
    turnoverPriorAsOnDate: 19.40,
    turnoverPriorMonth: 9.90,
    turnoverYoyPercent: 8.80,
    pendingOrdersAsOnDate: 65.30,
    pendingOrdersCurrentMonth: 12.50,
    inventoryAsOnDate: 13.20,
  },
  {
    id: 'skyfast',
    name: 'Skyfast Operating Unit',
    code: 'Skyfast',
    location: 'India',
    turnoverCurrentAsOnDate: 24.00,
    turnoverCurrentMonth: 12.40,
    turnoverPriorAsOnDate: 22.20,
    turnoverPriorMonth: 11.50,
    turnoverYoyPercent: 8.10,
    pendingOrdersAsOnDate: 78.80,
    pendingOrdersCurrentMonth: 14.80,
    inventoryAsOnDate: 15.40,
  },
];

export const groupTotals: GroupTotals = {
  turnoverCurrentAsOnDate: 229.70,
  turnoverCurrentMonth: 116.50,
  turnoverPriorAsOnDate: 213.10,
  turnoverPriorMonth: 108.10,
  turnoverYoyPercent: 7.80,
  pendingOrdersAsOnDate: 723.30,
  pendingOrdersCurrentMonth: 135.30,
  inventoryAsOnDate: 140.20,
};

export const unitFilterChips: UnitFilterChip[] = operatingUnits.map((u) => ({
  code: u.code,
  label: u.code,
}));

// ============================================================================
// Chart 1 — Sales Orders, Month-wise Trend
// ============================================================================

export const salesOrdersMonthlyTrend: MonthlyTrendPoint[] = [
  { month: 'Apr', fy2627: 120.00, fy2526: 108.00 },
  { month: 'May', fy2627: 123.00, fy2526: 114.00 },
  { month: 'Jun', fy2627: null, fy2526: 118.50 },
  { month: 'Jul', fy2627: null, fy2526: 121.00 },
  { month: 'Aug', fy2627: null, fy2526: 116.00 },
  { month: 'Sep', fy2627: null, fy2526: 123.50 },
  { month: 'Oct', fy2627: null, fy2526: 129.00 },
  { month: 'Nov', fy2627: null, fy2526: 119.00 },
  { month: 'Dec', fy2627: null, fy2526: 112.00 },
  { month: 'Jan', fy2627: null, fy2526: 117.00 },
  { month: 'Feb', fy2627: null, fy2526: 120.50 },
  { month: 'Mar', fy2627: null, fy2526: 136.50 },
];

export const salesOrdersSummary: SalesTrendSummary = {
  currentLabel: `${dateInfo.currentFyLabel} YTD`,
  currentValue: 243.00,
  priorLabel: `${dateInfo.priorFyLabel} Same Period`,
  priorValue: 222.00,
  priorProgressPercent: 91,
  yoyGrowthPercent: 9.5,
  aheadByValue: 21.00,
  unit: 'Cr',
};

// ============================================================================
// Chart 2 — Sales: Actual vs Prior Year, switchable by period (Dynamic)
// ============================================================================

export const dynamic10DaySeries = getDynamicLast10DaysSeries();

export const salesActualVsPriorByPeriod: Record<SalesPeriod, SalesPeriodOption> = {
  '10day': {
    key: '10day',
    label: '10-Day',
    currentLabel: `10-Day Sales ${dateInfo.currentFyLabel}`,
    priorLabel: `Same Period ${dateInfo.priorFyLabel}`,
    currentValue: 136.50,
    priorValue: 125.92,
    priorProgressPercent: 92,
    showTodayReference: false,
    series: dynamic10DaySeries,
  },
  ytd: {
    key: 'ytd',
    label: 'YTD',
    currentLabel: `YTD Sales ${dateInfo.currentFyLabel}`,
    priorLabel: `Same Period ${dateInfo.priorFyLabel}`,
    currentValue: 471.50,
    priorValue: 433.80,
    priorProgressPercent: 92,
    showTodayReference: false,
    series: [
      { month: 'Apr', fy2627: 233.10, fy2526: 214.00 },
      { month: 'May', fy2627: 238.40, fy2526: 219.80 },
    ],
  },
  cumulative: {
    key: 'cumulative',
    label: 'Cumulative',
    currentLabel: 'Cumulative YTD',
    priorLabel: `Same Period ${dateInfo.priorFyLabel}`,
    currentValue: 701.20,
    priorValue: 646.10,
    priorProgressPercent: 92,
    showTodayReference: true,
    series: [
      { month: 'Apr', fy2627: 342.60, fy2526: 316.00 },
      { month: 'May', fy2627: 701.20, fy2526: 646.10 },
      { month: 'Jun', fy2627: null, fy2526: 972.00 },
      { month: 'Jul', fy2627: null, fy2526: 1256.00 },
      { month: 'Aug', fy2627: null, fy2526: 1518.00 },
      { month: 'Sep', fy2627: null, fy2526: 1802.00 },
      { month: 'Oct', fy2627: null, fy2526: 2098.00 },
      { month: 'Nov', fy2627: null, fy2526: 2364.00 },
      { month: 'Dec', fy2627: null, fy2526: 2598.00 },
      { month: 'Jan', fy2627: null, fy2526: 2862.00 },
      { month: 'Feb', fy2627: null, fy2526: 3128.00 },
      { month: 'Mar', fy2627: null, fy2526: 3420.00 },
    ],
  },
};
