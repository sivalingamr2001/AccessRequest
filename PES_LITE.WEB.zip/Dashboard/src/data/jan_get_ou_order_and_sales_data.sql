CREATE OR REPLACE PROCEDURE jan_get_ou_order_and_sales_data (
    p_order_trend_cv      OUT SYS_REFCURSOR,
    p_sales_trend_cv      OUT SYS_REFCURSOR,
    p_rolling_10d_cv      OUT SYS_REFCURSOR,
    p_ytd_cumulative_cv   OUT SYS_REFCURSOR,
    p_stk_tfr_flg         IN VARCHAR2 DEFAULT 'N'
) AS

    v_curr_fy_start     DATE := add_months(
        trunc(SYSDATE,'YYYY'),
        3
    );
    v_prev_fy_start     DATE := add_months(
        trunc(SYSDATE,'YYYY'),
        -9
    );
    v_window_end        DATE := trunc(SYSDATE) - 1;
    v_window_start      DATE := trunc(SYSDATE) - 10;
    v_ly_window_start   DATE := add_months(
        trunc(SYSDATE),
        -12
    ) - 10;
    v_ly_window_end     DATE := add_months(
        trunc(SYSDATE),
        -12
    );
BEGIN
    IF
        p_stk_tfr_flg = 'Y'
    THEN
        OPEN p_order_trend_cv FOR
            SELECT
                os.org_id,
                n.alias_name AS ou_name,
                    CASE
                        WHEN os.ordered_date >= v_curr_fy_start THEN 'Current FY'
                        ELSE 'Previous FY'
                    END
                AS fiscal_year_period,
                TO_CHAR(os.ordered_date,'YYYYMM') yrmn,
                TO_CHAR(os.ordered_date,'MON-YY') mnyr,
                round(
                    SUM(os.ordered_quantity * os.unit_selling_price * os.ou_currency_conv_rate) / 10000000,
                    2
                ) order_value
            FROM
                jan_all_ou_ord_sales_v os
                JOIN (
                    SELECT
                        m.operating_unit AS valid_org_id
                    FROM
                        jan_all_ou_inventory_details a
                        JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                    WHERE
                            a.inventory_others = 'Planning Asset Sub-Inventories'
                        AND
                            a.organization_id NOT IN (
                                564,565
                            )
                    GROUP BY
                        m.operating_unit
                ) filter_ou ON os.org_id = filter_ou.valid_org_id
                JOIN jan_ou_alias_name n ON n.org_id = os.org_id
            WHERE
                    os.source_name = 'ORDER'
                AND
                    os.ord_empt_status = 'N'
                AND
                    os.ordered_date >= v_prev_fy_start
                AND
                    os.stk_tfr_flg = p_stk_tfr_flg
            GROUP BY
                os.org_id,
                n.alias_name,
                n.sort_by,
                CASE
                    WHEN os.ordered_date >= v_curr_fy_start THEN 'Current FY'
                    ELSE 'Previous FY'
                END,
                TO_CHAR(os.ordered_date,'YYYYMM'),
                TO_CHAR(os.ordered_date,'MON-YY')
            ORDER BY
                n.sort_by ASC,
                yrmn ASC;

    -- 2. SALES TREND CURSOR

        OPEN p_sales_trend_cv FOR
            SELECT
                os.org_id,
                n.alias_name AS ou_name,
                    CASE
                        WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                        ELSE 'Previous FY'
                    END
                AS fiscal_year_period,
                TO_CHAR(os.trx_date,'YYYYMM') yrmn,
                TO_CHAR(os.trx_date,'MON-YY') mnyr,
                round(
                    SUM(os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate) / 10000000,
                    2
                ) sales_value_crores
            FROM
                jan_all_ou_ord_sales_v os
                JOIN (
                    SELECT
                        m.operating_unit AS valid_org_id
                    FROM
                        jan_all_ou_inventory_details a
                        JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                    WHERE
                            a.inventory_others = 'Planning Asset Sub-Inventories'
                        AND
                            a.organization_id NOT IN (
                                564,565
                            )
                    GROUP BY
                        m.operating_unit
                ) filter_ou ON os.org_id = filter_ou.valid_org_id
                JOIN jan_ou_alias_name n ON n.org_id = os.org_id
            WHERE
                    os.source_name = 'SALES'
                AND
                    os.ord_empt_status = 'N'
                AND
                    os.trx_date >= v_prev_fy_start
                AND
                    os.stk_tfr_flg = p_stk_tfr_flg
            GROUP BY
                os.org_id,
                n.alias_name,
                n.sort_by,
                CASE
                    WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                    ELSE 'Previous FY'
                END,
                TO_CHAR(os.trx_date,'YYYYMM'),
                TO_CHAR(os.trx_date,'MON-YY')
            ORDER BY
                n.sort_by ASC,
                yrmn ASC;

    -- 3. ROLLING 10D CURSOR

        OPEN p_rolling_10d_cv FOR
            WITH sales_summary AS (
                SELECT
                    os.org_id,
                    n.alias_name AS ou_name,
                    n.sort_by,
                    TO_CHAR(os.trx_date,'DD-MON') AS calendar_day,
                    round(
                        SUM(
                            CASE
                                WHEN
                                    os.trx_date >= v_window_start
                                AND
                                    os.trx_date <= v_window_end
                                THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate
                            END
                        ) / 10000000,
                        2
                    ) AS cy_sales,
                    round(
                        SUM(
                            CASE
                                WHEN
                                    os.trx_date >= v_ly_window_start
                                AND
                                    os.trx_date <= v_ly_window_end
                                THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate
                            END
                        ) / 10000000,
                        2
                    ) AS py_sales,
                    trunc(os.trx_date) AS sort_date
                FROM
                    jan_all_ou_ord_sales_v os
                    JOIN (
                        SELECT
                            m.operating_unit AS valid_org_id
                        FROM
                            jan_all_ou_inventory_details a
                            JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                        WHERE
                                a.inventory_others = 'Planning Asset Sub-Inventories'
                            AND
                                a.organization_id NOT IN (
                                    564,565
                                )
                        GROUP BY
                            m.operating_unit
                    ) filter_ou ON os.org_id = filter_ou.valid_org_id
                    JOIN jan_ou_alias_name n ON n.org_id = os.org_id
                WHERE
                        os.source_name = 'SALES'
                    AND
                        os.ord_empt_status = 'N'
                    AND (
                        (
                                os.trx_date >= v_window_start
                            AND
                                os.trx_date <= v_window_end
                        ) OR (
                                os.trx_date >= v_ly_window_start
                            AND
                                os.trx_date <= v_ly_window_end
                        )
                    )
                GROUP BY
                    os.org_id,
                    n.alias_name,
                    n.sort_by,
                    TO_CHAR(os.trx_date,'DD-MON'),
                    trunc(os.trx_date)
            ) SELECT
                org_id,
                ou_name,
                calendar_day,
                cy_sales,
                py_sales
            FROM
                sales_summary
            ORDER BY
                sort_by ASC,
                org_id ASC,
                sort_date ASC;
    -- 4. YTD CUMULATIVE CURSOR

        OPEN p_ytd_cumulative_cv FOR
            WITH dynamic_monthly_basis AS (
                SELECT
                    os.org_id,
                    n.alias_name AS ou_name,
                    n.sort_by,
                        CASE
                            WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                            ELSE 'Previous FY'
                        END
                    AS fiscal_year_period,
                    TO_CHAR(os.trx_date,'YYYYMM') AS yrmn,
                    TO_CHAR(os.trx_date,'MON-YY') AS mnyr,
                    SUM(os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate) AS monthly_raw_sales
                FROM
                    jan_all_ou_ord_sales_v os
                    JOIN (
                        SELECT
                            m.operating_unit AS valid_org_id
                        FROM
                            jan_all_ou_inventory_details a
                            JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                        WHERE
                                a.inventory_others = 'Planning Asset Sub-Inventories'
                            AND
                                a.organization_id NOT IN (
                                    564,565
                                )
                        GROUP BY
                            m.operating_unit
                    ) filter_ou ON os.org_id = filter_ou.valid_org_id
                    JOIN jan_ou_alias_name n ON n.org_id = os.org_id
                WHERE
                        os.source_name = 'SALES'
                    AND
                        os.ord_empt_status = 'N'
                    AND (
                        (
                                os.trx_date >= v_curr_fy_start
                            AND
                                os.trx_date <= v_window_end
                        ) OR (
                                os.trx_date >= v_prev_fy_start
                            AND
                                os.trx_date <= v_ly_window_end
                        )
                    )
                GROUP BY
                    os.org_id,
                    n.alias_name,
                    n.sort_by,
                    CASE
                        WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                        ELSE 'Previous FY'
                    END,
                    TO_CHAR(os.trx_date,'YYYYMM'),
                    TO_CHAR(os.trx_date,'MON-YY')
            ) SELECT
                org_id,
                ou_name,
                fiscal_year_period,
                yrmn,
                mnyr,
                round(monthly_raw_sales / 10000000,2) AS monthly_sales_crores,
                round(
                    SUM(
                        monthly_raw_sales
                    ) OVER(PARTITION BY
                        org_id,
                        ou_name,
                        fiscal_year_period
                        ORDER BY
                            yrmn
                        ASC
                    ) / 10000000,
                    2
                ) AS cumulative_ytd_crores
            FROM
                dynamic_monthly_basis
            ORDER BY
                sort_by ASC,
                org_id ASC,
                fiscal_year_period DESC,
                yrmn ASC;

    ELSE
        OPEN p_order_trend_cv FOR
            SELECT
                os.org_id,
                n.alias_name AS ou_name,
                    CASE
                        WHEN os.ordered_date >= v_curr_fy_start THEN 'Current FY'
                        ELSE 'Previous FY'
                    END
                AS fiscal_year_period,
                TO_CHAR(os.ordered_date,'YYYYMM') yrmn,
                TO_CHAR(os.ordered_date,'MON-YY') mnyr,
                round(
                    SUM(os.ordered_quantity * os.unit_selling_price * os.ou_currency_conv_rate) / 10000000,
                    2
                ) order_value
            FROM
                jan_all_ou_ord_sales_v os
                JOIN (
                    SELECT
                        m.operating_unit AS valid_org_id
                    FROM
                        jan_all_ou_inventory_details a
                        JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                    WHERE
                            a.inventory_others = 'Planning Asset Sub-Inventories'
                        AND
                            a.organization_id NOT IN (
                                564,565
                            )
                    GROUP BY
                        m.operating_unit
                ) filter_ou ON os.org_id = filter_ou.valid_org_id
                JOIN jan_ou_alias_name n ON n.org_id = os.org_id
            WHERE
                    os.source_name = 'ORDER'
                AND
                    os.ord_empt_status = 'N'
                AND
                    os.ordered_date >= v_prev_fy_start
                AND os.stk_tfr_flg = p_stk_tfr_flg
            GROUP BY
                os.org_id,
                n.alias_name,
                n.sort_by,
                CASE
                    WHEN os.ordered_date >= v_curr_fy_start THEN 'Current FY'
                    ELSE 'Previous FY'
                END,
                TO_CHAR(os.ordered_date,'YYYYMM'),
                TO_CHAR(os.ordered_date,'MON-YY')
            ORDER BY
                n.sort_by ASC,
                yrmn ASC;

    -- 2. SALES TREND CURSOR

        OPEN p_sales_trend_cv FOR
            SELECT
                os.org_id,
                n.alias_name AS ou_name,
                    CASE
                        WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                        ELSE 'Previous FY'
                    END
                AS fiscal_year_period,
                TO_CHAR(os.trx_date,'YYYYMM') yrmn,
                TO_CHAR(os.trx_date,'MON-YY') mnyr,
                round(
                    SUM(os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate) / 10000000,
                    2
                ) sales_value_crores
            FROM
                jan_all_ou_ord_sales_v os
                JOIN (
                    SELECT
                        m.operating_unit AS valid_org_id
                    FROM
                        jan_all_ou_inventory_details a
                        JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                    WHERE
                            a.inventory_others = 'Planning Asset Sub-Inventories'
                        AND
                            a.organization_id NOT IN (
                                564,565
                            )
                    GROUP BY
                        m.operating_unit
                ) filter_ou ON os.org_id = filter_ou.valid_org_id
                JOIN jan_ou_alias_name n ON n.org_id = os.org_id
            WHERE
                    os.source_name = 'SALES'
                AND
                    os.ord_empt_status = 'N'
                AND
                    os.trx_date >= v_prev_fy_start
                AND 
                    os.stk_tfr_flg = p_stk_tfr_flg
            GROUP BY
                os.org_id,
                n.alias_name,
                n.sort_by,
                CASE
                    WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                    ELSE 'Previous FY'
                END,
                TO_CHAR(os.trx_date,'YYYYMM'),
                TO_CHAR(os.trx_date,'MON-YY')
            ORDER BY
                n.sort_by ASC,
                yrmn ASC;

    -- 3. ROLLING 10D CURSOR

        OPEN p_rolling_10d_cv FOR
            WITH sales_summary AS (
                SELECT
                    os.org_id,
                    n.alias_name AS ou_name,
                    n.sort_by,
                    TO_CHAR(os.trx_date,'DD-MON') AS calendar_day,
                    round(
                        SUM(
                            CASE
                                WHEN
                                    os.trx_date >= v_window_start
                                AND
                                    os.trx_date <= v_window_end
                                THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate
                            END
                        ) / 10000000,
                        2
                    ) AS cy_sales,
                    round(
                        SUM(
                            CASE
                                WHEN
                                    os.trx_date >= v_ly_window_start
                                AND
                                    os.trx_date <= v_ly_window_end
                                THEN os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate
                            END
                        ) / 10000000,
                        2
                    ) AS py_sales,
                    trunc(os.trx_date) AS sort_date
                FROM
                    jan_all_ou_ord_sales_v os
                    JOIN (
                        SELECT
                            m.operating_unit AS valid_org_id
                        FROM
                            jan_all_ou_inventory_details a
                            JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                        WHERE
                                a.inventory_others = 'Planning Asset Sub-Inventories'
                            AND
                                a.organization_id NOT IN (
                                    564,565
                                )
                        GROUP BY
                            m.operating_unit
                    ) filter_ou ON os.org_id = filter_ou.valid_org_id
                    JOIN jan_ou_alias_name n ON n.org_id = os.org_id
                WHERE
                        os.source_name = 'SALES'
                    AND
                        os.ord_empt_status = 'N'
                    AND
                        os.stk_tfr_flg = p_stk_tfr_flg
                    AND (
                        (
                                os.trx_date >= v_window_start
                            AND
                                os.trx_date <= v_window_end
                        ) OR (
                                os.trx_date >= v_ly_window_start
                            AND
                                os.trx_date <= v_ly_window_end
                        )
                    )
                GROUP BY
                    os.org_id,
                    n.alias_name,
                    n.sort_by,
                    TO_CHAR(os.trx_date,'DD-MON'),
                    trunc(os.trx_date)
            ) SELECT
                org_id,
                ou_name,
                calendar_day,
                cy_sales,
                py_sales
            FROM
                sales_summary
            ORDER BY
                sort_by ASC,
                org_id ASC,
                sort_date ASC;
    -- 4. YTD CUMULATIVE CURSOR

        OPEN p_ytd_cumulative_cv FOR
            WITH dynamic_monthly_basis AS (
                SELECT
                    os.org_id,
                    n.alias_name AS ou_name,
                    n.sort_by,
                        CASE
                            WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                            ELSE 'Previous FY'
                        END
                    AS fiscal_year_period,
                    TO_CHAR(os.trx_date,'YYYYMM') AS yrmn,
                    TO_CHAR(os.trx_date,'MON-YY') AS mnyr,
                    SUM(os.quantity_invoiced * os.unit_selling_price * os.ou_currency_conv_rate) AS monthly_raw_sales
                FROM
                    jan_all_ou_ord_sales_v os
                    JOIN (
                        SELECT
                            m.operating_unit AS valid_org_id
                        FROM
                            jan_all_ou_inventory_details a
                            JOIN org_organization_definitions m ON m.organization_id = a.organization_id
                        WHERE
                                a.inventory_others = 'Planning Asset Sub-Inventories'
                            AND
                                a.organization_id NOT IN (
                                    564,565
                                )
                        GROUP BY
                            m.operating_unit
                    ) filter_ou ON os.org_id = filter_ou.valid_org_id
                    JOIN jan_ou_alias_name n ON n.org_id = os.org_id
                WHERE
                        os.source_name = 'SALES'
                    AND
                        os.ord_empt_status = 'N'
                    AND
                        os.stk_tfr_flg = p_stk_tfr_flg
                    AND (
                        (
                                os.trx_date >= v_curr_fy_start
                            AND
                                os.trx_date <= v_window_end
                        ) OR (
                                os.trx_date >= v_prev_fy_start
                            AND
                                os.trx_date <= v_ly_window_end
                        )
                    )
                GROUP BY
                    os.org_id,
                    n.alias_name,
                    n.sort_by,
                    CASE
                        WHEN os.trx_date >= v_curr_fy_start THEN 'Current FY'
                        ELSE 'Previous FY'
                    END,
                    TO_CHAR(os.trx_date,'YYYYMM'),
                    TO_CHAR(os.trx_date,'MON-YY')
            ) SELECT
                org_id,
                ou_name,
                fiscal_year_period,
                yrmn,
                mnyr,
                round(monthly_raw_sales / 10000000,2) AS monthly_sales_crores,
                round(
                    SUM(
                        monthly_raw_sales
                    ) OVER(PARTITION BY
                        org_id,
                        ou_name,
                        fiscal_year_period
                        ORDER BY
                            yrmn
                        ASC
                    ) / 10000000,
                    2
                ) AS cumulative_ytd_crores
            FROM
                dynamic_monthly_basis
            ORDER BY
                sort_by ASC,
                org_id ASC,
                fiscal_year_period DESC,
                yrmn ASC;

    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        IF
            p_order_trend_cv%isopen
        THEN
            CLOSE p_order_trend_cv;
        END IF;
        IF
            p_sales_trend_cv%isopen
        THEN
            CLOSE p_sales_trend_cv;
        END IF;
        IF
            p_rolling_10d_cv%isopen
        THEN
            CLOSE p_rolling_10d_cv;
        END IF;
        IF
            p_ytd_cumulative_cv%isopen
        THEN
            CLOSE p_ytd_cumulative_cv;
        END IF;
        RAISE;
END jan_get_ou_order_and_sales_data;