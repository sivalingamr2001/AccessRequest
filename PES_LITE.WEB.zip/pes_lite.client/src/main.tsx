import { createRoot } from "react-dom/client"
import { ThemeProvider } from "@/context/theme-provider.tsx"
import { BrowserRouter } from "react-router-dom"
import { Toaster } from 'sonner'
import App from "./App.tsx"
import { TooltipProvider } from "./components/ui/tooltip.tsx"
import { PesProvider } from "./context/PesProvider.tsx"
import "./index.css"
createRoot(document.getElementById("root")!).render(
  <>
    <TooltipProvider>
      <ThemeProvider>
        <BrowserRouter basename="/pes_lite/">
          <PesProvider>
            <Toaster position="top-right" richColors />
            <App />
          </PesProvider>
        </BrowserRouter>
      </ThemeProvider>
    </TooltipProvider>
  </>
)
