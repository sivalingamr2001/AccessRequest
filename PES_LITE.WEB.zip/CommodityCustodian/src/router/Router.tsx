import { Loader } from "@/components/Loader"
import { AppLayout } from "@/layout/AppLayout"
import { lazy, Suspense } from "react"
import { Route, Routes, Navigate } from "react-router-dom"

const DashboardPage = lazy(() =>
  import("@/pages/DashboardPage").then((module) => ({
    default: module.DashboardPage,
  }))
)

export const Router = () => {
  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        <Route path="/dashboard" element={<AppLayout />}>
          {/* Matches exactly "/commodity-dashboard" */}
          <Route index element={<DashboardPage />} />
        </Route>

        <Route path="/" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Suspense>
  )
}
