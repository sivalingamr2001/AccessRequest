import { Router } from "./router/Router"

export function App() {
  return (
    <div>
      <Router />
    </div>
  )
}

export default App
