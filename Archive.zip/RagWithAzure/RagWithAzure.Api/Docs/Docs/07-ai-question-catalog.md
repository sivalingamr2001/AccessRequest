# AI Question Catalog

The AI should recognize questions related to the focused Gate Entry flow.

## Gate Register

- What is the status of gate 12345?
- Show gate 12345 details.
- Is gate 12345 available?
- What supplier is associated with gate 12345?
- What is the DC number for gate 12345?
- What is the gate date?
- How many lines are on gate 12345?

## Counting

- Has counting completed for gate 12345?
- How many items have been counted?
- Which gate lines are not counted?
- What is the counted quantity?
- What is the accepted quantity?
- What is the rejected quantity?

## Validation

- Is gate 12345 valid?
- Why did gate 12345 fail validation?
- What validation errors exist?
- Is the PO approved?
- Is the PO line closed?
- Is the PO cancelled?
- Is there enough PO quantity for the inward quantity?
- Is an item revision available?

## Receipt

- Has gate 12345 been received?
- What is the receipt number?
- Does a receipt already exist?
- Is gate 12345 ready for receipt?
- Why can't gate 12345 be received?

## AI behavior

Extract at least:

- `gate_no`
- optional stage
- question intent

Then execute the appropriate approved read-only query.
