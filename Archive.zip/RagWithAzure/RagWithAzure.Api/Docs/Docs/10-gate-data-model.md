# Gate Data Model

## Focused source relationships

```text
JAN_GATE_HEADER
      |
      | gate_no
      v
JAN_GATE_LINES
      |
      +--------------------+
      |                    |
      v                    v
PO_LINE_LOCATIONS_ALL   PO_LINES_ALL
      |                    |
      |                    v
      |              PO_HEADERS_ALL
      |
      v
JAN_RECEIPT_PENDING
      |
      v
RCV_SHIPMENT_HEADERS
```

## Main fields/relationships used by the focused flow

### JAN_GATE_HEADER

Important concepts:

- `GATE_NO`
- `DC_NO`
- supplier information
- gate date
- unit
- `VALIDATED`
- receipt information where present

### JAN_GATE_LINES

Important concepts:

- `GATE_NO`
- line number
- PO reference
- item
- inward/supplier quantity
- PO line/location references

### JAN_RECEIPT_PENDING

Validation specifically checks pending receipt rows where:

```sql
shipment_line_id IS NULL
```

### RCV_SHIPMENT_HEADERS

Receipt existence is checked by matching:

```text
packing_slip = gate number
```

## Demo model

The demo SQL adds normalized helper tables such as `gate_counting`, `po_headers`, `po_lines`, and `po_line_locations` for large-scale dummy-data testing.

These are test-model constructs and are not claimed to be exact copies of the legacy Oracle schema.
