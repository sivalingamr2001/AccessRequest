# Gate Workflow

## End-to-End Flow

```text
Gate Register
     |
     v
Gate Lines
     |
     v
Counting
     |
     v
Validation
     |
     v
Receipt Creation
```

## Stage 1 - Gate Register

Identify the gate using `gate_no` and read the source status from `JAN_GATE_HEADER.VALIDATED`.

## Stage 2 - Counting

Determine whether every gate line has a corresponding counting result in the AI demo model.

## Stage 3 - Validation

Run the validation rules derived from the legacy `VALIDATE_Load` logic.

## Stage 4 - Receipt

Before receipt creation, verify that:

1. The gate exists.
2. The gate is not RTV, CANCEL ENTRY or No Reference.
3. The gate has lines.
4. Every line has counting information.
5. Validation has no blocking rows.
6. No receipt already exists for the gate.

## AI decision order

The AI should evaluate stages in this order:

1. Gate status
2. Counting completeness
3. Validation blockers
4. Receipt existence
5. Ready/created state
