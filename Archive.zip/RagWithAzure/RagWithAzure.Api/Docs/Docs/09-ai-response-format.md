# AI Response Format

The response should be compact and auditable.

```text
STATUS: <actual status>

STAGE: <current stage>
GATE: <gate number>

FACTS:
- Gate status: <database value + mapped source label>
- Lines: <count>
- Counted: <count>
- Validation blockers: <count>
- Receipt: <receipt number or NOT FOUND>

BLOCKERS:
- <rule code>: <reason>
- <database evidence>

NEXT_STATE:
- <next state>

SOURCE:
- Query/rule used
- Execution timestamp
```

## Example

```text
STATUS: VALIDATION FAILED

STAGE: VALIDATION
GATE: 100125

FACTS:
- Gate status: GATE
- Lines: 3
- Counted: 3
- Validation blockers: 1
- Receipt: NOT FOUND

BLOCKERS:
- PO_NOT_APPROVED
- PO authorization status is NOT APPROVED

NEXT_STATE:
- VALIDATION FAILED

SOURCE:
- VALIDATE_Load derived rule
```

## Response rule

When the database gives a definitive value, report it directly. Do not use uncertain language such as "probably" or "looks like".
