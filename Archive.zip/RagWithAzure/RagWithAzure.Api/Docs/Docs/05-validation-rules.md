# Validation Rules

These rules are derived from the legacy `VALIDATE_Load` query.

For each relevant gate line linked to a pending receipt row (`JAN_RECEIPT_PENDING` with `shipment_line_id IS NULL`), evaluate the conditions in this order.

## Rules

### 1. No pending Qty

```sql
quantity - (quantity_received + quantity_cancelled) = 0
```

Result:

`No pending Qty`

### 2. PO cancelled

```sql
quantity_cancelled > 0
```

Result:

`PO cancelled`

### 3. Line closed

```sql
NVL(closed_code, 'OPEN') <> 'OPEN'
```

Result:

`Line closed`

### 4. Approval pending

```sql
approved_flag <> 'Y'
```

Result:

`Approval Pend`

### 5. PO quantity less than inward quantity

```sql
quantity - (quantity_received + quantity_cancelled) < supdcqty
```

Result:

`Po Qty less than inward Qty`

### 6. PO not approved

Related `PO_HEADERS_ALL.authorization_status` is not `APPROVED`.

Result:

`PO Not Approved`

### 7. No revision for item in PO

Related `PO_LINES_ALL.item_revision` is NULL.

Result:

`No Revision for item in PO`

### 8. No exception

Otherwise the source query returns:

`NP`

The legacy validation query filters out `NP`, so returned rows represent validation problems.

## AI rule

The AI must report the actual database result and the corresponding source rule. It must not invent a validation failure when the query returned no blocker.
