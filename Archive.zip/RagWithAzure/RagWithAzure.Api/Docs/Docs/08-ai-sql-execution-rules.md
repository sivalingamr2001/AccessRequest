# AI SQL Execution Rules

## Objective

Allow the AI to retrieve factual status from the database without allowing arbitrary destructive SQL.

## Allowed

- `SELECT`
- `COUNT`
- aggregates
- documented joins
- parameterized reads
- approved validation queries
- approved status queries

## Restricted

- `INSERT`
- `UPDATE`
- `DELETE`
- DDL
- arbitrary dynamic SQL
- SQL assembled directly from user text

## Parameterization

Never do this:

```text
"... WHERE gate_no = " + userGateNo
```

Use a bound parameter:

```text
WHERE gate_no = :gate_no
```

## Recommended architecture

```text
User Question
    |
    v
LLM intent extraction
    |
    v
gate_no + intent + stage
    |
    v
Approved query selection
    |
    v
Parameterized SQL
    |
    v
Read-only database connection
    |
    v
Database result
    |
    v
AI interpretation
    |
    v
STATUS + FACTS + BLOCKERS + NEXT_STATE
```

## Security context

The source query catalog identifies many legacy SQL concatenation/injection points. The AI implementation should not reproduce that pattern.
