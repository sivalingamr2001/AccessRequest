# Receipt Rules

## Receipt existence

The legacy source checks receipt existence using:

```sql
select receipt_num
from rcv_shipment_headers
where packing_slip = <gate number>
```

The AI should parameterize the gate number rather than concatenate user input.

## Receipt readiness

Before creating a receipt, verify:

1. Gate exists.
2. Gate is not `RTV`.
3. Gate is not `CANCEL ENTRY`.
4. Gate is not `No Reference`.
5. Gate has at least one line.
6. Every line has a counting record.
7. Validation returns no blocking rows.
8. No existing receipt is found.
9. Receipt quantities come from the approved/accepted counting result.

## Receipt creation

Receipt creation should be controlled by the application or a dedicated stored procedure/command.

The AI should not generate arbitrary INSERT/UPDATE statements from natural-language user input.
