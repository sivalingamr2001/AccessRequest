# Gate Validation Test Cases

Use these scenarios to test the AI response layer against dummy data.

| Case | Gate state | Counting | Validation | Receipt | Expected AI status |
|---|---|---|---|---|---|
| 1 | GATE | Complete | No blockers | None | READY FOR RECEIPT |
| 2 | GATE | Incomplete | Not evaluated/secondary | None | COUNTING PENDING |
| 3 | GATE | Complete | PO Not Approved | None | VALIDATION FAILED |
| 4 | GATE | Complete | Line closed | None | VALIDATION FAILED |
| 5 | GATE | Complete | PO cancelled | None | VALIDATION FAILED |
| 6 | GATE | Complete | No revision | None | VALIDATION FAILED |
| 7 | GATE | Complete | No blockers | Exists | RECEIPT CREATED |
| 8 | RTV | Complete | Any | None | BLOCKED |
| 9 | CANCEL ENTRY | Complete | Any | None | BLOCKED |
| 10 | No Reference | Complete | Any | None | BLOCKED |
| 11 | GATE | Zero lines | N/A | None | INVALID |

## Verification principle

For every test case, the expected status must be derived from database results using the documented decision order, not hard-coded into the LLM response.

## Recommended AI test questions

- What is the status of gate <gate_no>?
- Why is gate <gate_no> not ready?
- Has counting completed?
- What validation issue is blocking this gate?
- Has this gate already been received?
- What is the receipt number?
