# Gate Status Mapping

The Gate dashboard query explicitly maps `JAN_GATE_HEADER.VALIDATED` as follows:

| `VALIDATED` | Source status |
|---:|---|
| 0 | `VALIDATED` |
| 1 | `GATE` |
| 2 | `NOT VALIDATED` |
| 3 | `ACTION TAKEN` |
| 4 | `RTV` |
| 5 | `CANCEL ENTRY` |
| 6 | `No Reference` |

## AI rule

These are source-defined labels. The AI must not invent alternative meanings.

For an unknown numeric value, return the numeric value and report the status as `UNKNOWN` rather than guessing.
