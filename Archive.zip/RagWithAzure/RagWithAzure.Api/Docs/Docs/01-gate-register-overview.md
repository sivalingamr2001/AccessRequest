# Gate Register Overview

## Scope

This AI knowledge set is intentionally limited to:

**Gate Entry Register → Counting → Validation → Receipt Creation**

The source project describes the application as a Gate Entry register and validation gatekeeper. The Gate Register is the central status/search area. Material inward records include delivery challan, supplier, vehicle and purchase-order information. Validation occurs before material is formally received in Oracle ERP.

## Source System

- Application: legacy VB.NET Windows Forms
- Primary database: Oracle
- Secondary database: SQL Server for selected external ASN-related integration
- The source query catalog contains 273 identified SQL queries across 65 tables.

## Main source tables for this focused flow

| Stage | Source table | Purpose |
|---|---|---|
| Gate Register | `JAN_GATE_HEADER` | Gate header, supplier, DC, date, unit and high-level status |
| Gate Lines | `JAN_GATE_LINES` | PO/item/quantity/line-level information |
| Counting / inward reporting | `JAN_PUR_LISTING` and related counting logic | Receipt/inward quantities and reporting |
| Validation queue | `JAN_RECEIPT_PENDING` | Pending receipt-related lines |
| Receipt | `RCV_SHIPMENT_HEADERS` | Receipt/shipment existence |

Validation also depends on `PO_LINE_LOCATIONS_ALL`, `PO_HEADERS_ALL`, and `PO_LINES_ALL`.

## Important limitation

The source material does not establish a production table named `gate_counting`. Any `gate_counting` table used in the demo SQL is a simplified test-data model.
