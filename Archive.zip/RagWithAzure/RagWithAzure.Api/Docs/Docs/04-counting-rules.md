# Counting Rules

## Source-supported behavior

The uploaded query catalog contains counting-related logic that reads/aggregates `JAN_GATE_LINES` and later uses receipt/inward records.

For the focused AI demo validation layer:

1. Every gate line must have one counting result.
2. Counted quantity must be non-negative.
3. Accepted quantity must be non-negative.
4. Rejected quantity must be non-negative.

## Counting completion

Compare:

- number of rows in `JAN_GATE_LINES` for the gate
- number of corresponding counting records

If the counts differ:

`COUNTING PENDING`

If every line has a counting result:

`COUNTING COMPLETE`

## Important limitation

The source material does not establish a complete production counting table/schema. The demo `gate_counting` table is explicitly a simplification for test data. Do not claim that these rules reproduce every legacy counting rule.
