-- ============================================================
-- Gate Entry AI Validation Demo
-- Scope: Gate Register -> Counting -> Validation -> Receipt Creation
-- PostgreSQL 15+
-- NOTE: This is a normalized DEMO schema derived from the uploaded
-- legacy query catalog. It is NOT a 1:1 Oracle schema replacement.
-- ============================================================

DROP SCHEMA IF EXISTS gate_demo CASCADE;
CREATE SCHEMA gate_demo;
SET search_path = gate_demo;

-- -----------------------------
-- 1. Master/reference tables
-- -----------------------------
CREATE TABLE suppliers (
    supplier_id      BIGINT PRIMARY KEY,
    supplier_name    TEXT NOT NULL,
    supplier_site    TEXT NOT NULL,
    gstin            TEXT,
    currency_code    CHAR(3) NOT NULL DEFAULT 'INR'
);

CREATE TABLE po_headers (
    po_header_id     BIGINT PRIMARY KEY,
    pono             TEXT NOT NULL UNIQUE,
    vendor_id        BIGINT NOT NULL REFERENCES suppliers(supplier_id),
    authorization_status TEXT NOT NULL DEFAULT 'APPROVED',
    po_date          DATE NOT NULL
);

CREATE TABLE po_lines (
    po_line_id       BIGINT PRIMARY KEY,
    po_header_id     BIGINT NOT NULL REFERENCES po_headers(po_header_id),
    line_no          INT NOT NULL,
    item_code        TEXT NOT NULL,
    item_revision    TEXT,
    line_description TEXT,
    uom              TEXT NOT NULL DEFAULT 'EA',
    PRIMARY KEY (po_header_id, line_no)
);

CREATE TABLE po_line_locations (
    line_location_id BIGINT PRIMARY KEY,
    po_line_id       BIGINT NOT NULL REFERENCES po_lines(po_line_id),
    quantity         NUMERIC(18,3) NOT NULL CHECK (quantity >= 0),
    quantity_received NUMERIC(18,3) NOT NULL DEFAULT 0 CHECK (quantity_received >= 0),
    quantity_cancelled NUMERIC(18,3) NOT NULL DEFAULT 0 CHECK (quantity_cancelled >= 0),
    approved_flag    CHAR(1) NOT NULL DEFAULT 'Y',
    closed_code      TEXT DEFAULT 'OPEN',
    organization_id  INT NOT NULL
);

-- -----------------------------
-- 2. Gate Register
-- Source terminology: JAN_GATE_HEADER
-- -----------------------------
CREATE TABLE jan_gate_header (
    gate_no          BIGINT PRIMARY KEY,
    gate_id          TEXT NOT NULL UNIQUE,
    supplier_name    TEXT NOT NULL,
    vendor_id        BIGINT NOT NULL REFERENCES suppliers(supplier_id),
    supplier_site    TEXT,
    dc_no            TEXT NOT NULL,
    dc_date          DATE NOT NULL,
    validated        INT NOT NULL DEFAULT 1,
    gtype            TEXT NOT NULL DEFAULT 'PO',
    gdate            TIMESTAMP NOT NULL,
    vehicle_det      TEXT,
    courier_name     TEXT,
    pod_no           TEXT,
    no_of_box        INT,
    po_wt            NUMERIC(18,3),
    rec_wt           NUMERIC(18,3),
    rec_wt_dt        TIMESTAMP,
    eway_no          TEXT,
    unit             TEXT NOT NULL,
    flag             INT NOT NULL DEFAULT 1,
    invoice_val      NUMERIC(18,2),
    inv_category     TEXT,
    responsible_person TEXT,
    responsible_dept TEXT,
    transport_mode   TEXT,
    person_name      TEXT,
    uname            TEXT,
    validated_by     TEXT,
    validated_on     TIMESTAMP,
    receipt_num      TEXT,
    receipt_date     TIMESTAMP
);

-- Source status mapping observed in the Gate dashboard queries:
-- 0 = VALIDATED
-- 1 = GATE
-- 2 = NOT VALIDATED
-- 3 = ACTION TAKEN
-- 4 = RTV
-- 5 = CANCEL ENTRY
-- 6 = No Reference

-- -----------------------------
-- 3. Gate lines
-- Source terminology: JAN_GATE_LINES
-- -----------------------------
CREATE TABLE jan_gate_lines (
    gate_no          BIGINT NOT NULL REFERENCES jan_gate_header(gate_no),
    line_no          INT NOT NULL,
    gate_id          TEXT NOT NULL,
    pono             TEXT NOT NULL,
    podt             DATE,
    item             TEXT NOT NULL,
    description      TEXT,
    rev              TEXT,
    popend           NUMERIC(18,3),
    supdcqty         NUMERIC(18,3) NOT NULL CHECK (supdcqty > 0),
    uom              TEXT NOT NULL DEFAULT 'EA',
    job              TEXT,
    oper             TEXT,
    osp              TEXT,
    type             TEXT NOT NULL DEFAULT 'PO',
    remark           TEXT,
    status           INT NOT NULL DEFAULT 1,
    validated        INT NOT NULL DEFAULT 1,
    org              TEXT,
    flag             INT NOT NULL DEFAULT 1,
    poline           BIGINT NOT NULL,
    pohead           BIGINT NOT NULL,
    location_id      BIGINT NOT NULL REFERENCES po_line_locations(line_location_id),
    poqty             NUMERIC(18,3) NOT NULL,
    actval            NUMERIC(18,2),
    ratecat           TEXT,
    potype            TEXT,
    tariff            TEXT,
    wip_entity_id    BIGINT,
    opn_seq          INT,
    need_by_dt       DATE,
    lot_no           TEXT,
    checked_by       TEXT,
    item_check_by    TEXT,
    item_checked_dt  TIMESTAMP,
    PRIMARY KEY (gate_no, line_no)
);

-- -----------------------------
-- 4. Counting / inward result
-- This is a focused demo equivalent for the counting information
-- that the legacy flow reads/aggregates from gate lines and later
-- JAN_PUR_LISTING/JAN_OSP_LISTING.
-- -----------------------------
CREATE TABLE gate_counting (
    counting_id      BIGSERIAL PRIMARY KEY,
    gate_no          BIGINT NOT NULL,
    line_no          INT NOT NULL,
    counted_qty      NUMERIC(18,3) NOT NULL CHECK (counted_qty >= 0),
    accepted_qty     NUMERIC(18,3) NOT NULL CHECK (accepted_qty >= 0),
    rejected_qty     NUMERIC(18,3) NOT NULL DEFAULT 0 CHECK (rejected_qty >= 0),
    checked_by       TEXT,
    checked_at       TIMESTAMP NOT NULL DEFAULT now(),
    status           TEXT NOT NULL DEFAULT 'COUNTED',
    UNIQUE (gate_no, line_no),
    FOREIGN KEY (gate_no, line_no)
        REFERENCES jan_gate_lines(gate_no, line_no)
);

-- -----------------------------
-- 5. Receipt pending
-- Source terminology: JAN_RECEIPT_PENDING
-- -----------------------------
CREATE TABLE jan_receipt_pending (
    pending_id       BIGSERIAL PRIMARY KEY,
    gate_no          BIGINT NOT NULL,
    line_no          INT NOT NULL,
    shipment_line_id BIGINT,
    pending_qty      NUMERIC(18,3) NOT NULL,
    created_at       TIMESTAMP NOT NULL DEFAULT now(),
    status            TEXT NOT NULL DEFAULT 'PENDING',
    UNIQUE (gate_no, line_no),
    FOREIGN KEY (gate_no, line_no)
        REFERENCES jan_gate_lines(gate_no, line_no)
);

-- -----------------------------
-- 6. Receipt creation result
-- Source terminology: RCV_SHIPMENT_HEADERS / JAN_PUR_LISTING
-- -----------------------------
CREATE TABLE rcv_shipment_headers (
    shipment_header_id BIGSERIAL PRIMARY KEY,
    shipment_num      TEXT NOT NULL UNIQUE,
    receipt_num       TEXT NOT NULL UNIQUE,
    packing_slip      TEXT NOT NULL UNIQUE,
    gate_no           BIGINT NOT NULL REFERENCES jan_gate_header(gate_no),
    vendor_id         BIGINT NOT NULL REFERENCES suppliers(supplier_id),
    ship_to_org_id    INT NOT NULL,
    creation_date     TIMESTAMP NOT NULL DEFAULT now(),
    status            TEXT NOT NULL DEFAULT 'RECEIVED'
);

CREATE TABLE jan_pur_listing (
    pur_id            BIGSERIAL PRIMARY KEY,
    gate_no            BIGINT NOT NULL,
    receipt_num        TEXT NOT NULL,
    receipt_date       TIMESTAMP NOT NULL,
    pono               TEXT NOT NULL,
    po_line_id         BIGINT NOT NULL,
    line_location_id   BIGINT NOT NULL,
    item_no            TEXT NOT NULL,
    item_description   TEXT,
    quantity_received  NUMERIC(18,3) NOT NULL,
    qty_appd           NUMERIC(18,3) NOT NULL,
    inv_no             TEXT,
    FOREIGN KEY (gate_no) REFERENCES jan_gate_header(gate_no)
);

-- -----------------------------
-- 7. Validation audit
-- -----------------------------
CREATE TABLE gate_validation_audit (
    validation_id BIGSERIAL PRIMARY KEY,
    gate_no       BIGINT NOT NULL,
    stage         TEXT NOT NULL,
    rule_code     TEXT NOT NULL,
    result        TEXT NOT NULL CHECK (result IN ('PASS','FAIL','WARN')),
    actual_value  TEXT,
    expected_value TEXT,
    message       TEXT NOT NULL,
    checked_at    TIMESTAMP NOT NULL DEFAULT now()
);

-- ============================================================
-- Indexes
-- ============================================================
CREATE INDEX ix_gate_header_gdate_unit ON jan_gate_header(unit, gdate);
CREATE INDEX ix_gate_header_supplier ON jan_gate_header(vendor_id, supplier_name);
CREATE INDEX ix_gate_header_status ON jan_gate_header(validated);
CREATE INDEX ix_gate_lines_gate ON jan_gate_lines(gate_no);
CREATE INDEX ix_gate_lines_po ON jan_gate_lines(pono, poline, location_id);
CREATE INDEX ix_receipt_pending_gate ON jan_receipt_pending(gate_no, status);
CREATE INDEX ix_receipt_packing_slip ON rcv_shipment_headers(packing_slip);
CREATE INDEX ix_pur_listing_gate ON jan_pur_listing(gate_no, receipt_num);

-- ============================================================
-- 8. Reference data
-- ============================================================
INSERT INTO suppliers
SELECT g,
       'SUPPLIER-' || lpad(g::text, 6, '0'),
       'SITE-' || ((g % 20) + 1),
       '33' || lpad(((g * 7919) % 1000000000)::text, 9, '0'),
       'INR'
FROM generate_series(1, 1000) AS g;

INSERT INTO po_headers
SELECT g,
       'PO-' || lpad(g::text, 8, '0'),
       ((g - 1) % 1000) + 1,
       CASE WHEN g % 25 = 0 THEN 'INCOMPLETE' ELSE 'APPROVED' END,
       CURRENT_DATE - ((g % 365) || ' days')::interval
FROM generate_series(1, 100000) AS g;

INSERT INTO po_lines
SELECT (h.po_header_id * 10) + l.line_no,
       h.po_header_id,
       l.line_no,
       'ITEM-' || lpad((((h.po_header_id - 1) * 5 + l.line_no) % 50000 + 1)::text, 6, '0'),
       CASE WHEN l.line_no % 11 = 0 THEN NULL ELSE 'REV-' || ((l.line_no % 4) + 1) END,
       'Demo item ' || l.line_no,
       'EA'
FROM po_headers h
CROSS JOIN generate_series(1, 3) AS l(line_no);

INSERT INTO po_line_locations
SELECT pl.po_line_id * 10,
       pl.po_line_id,
       100 + (pl.po_line_id % 900),
       CASE WHEN pl.po_line_id % 17 = 0 THEN 100 ELSE (pl.po_line_id % 40) END,
       CASE WHEN pl.po_line_id % 23 = 0 THEN 100 ELSE 0 END,
       CASE WHEN pl.po_line_id % 19 = 0 THEN 'N' ELSE 'Y' END,
       CASE WHEN pl.po_line_id % 29 = 0 THEN 'CLOSED' ELSE 'OPEN' END,
       444 + (pl.po_line_id % 5)
FROM po_lines pl;

-- ============================================================
-- 9. Lakhs of dummy gate data
--    200,000 gates x 3 lines = 600,000 gate lines
-- ============================================================
INSERT INTO jan_gate_header
SELECT g,
       g::text,
       'SUPPLIER-' || lpad((((g - 1) % 1000) + 1)::text, 6, '0'),
       ((g - 1) % 1000) + 1,
       'SITE-' || (((g - 1) % 20) + 1),
       'DC-' || lpad(g::text, 8, '0'),
       CURRENT_DATE - ((g % 180) || ' days')::interval,
       CASE
           WHEN g % 20 = 0 THEN 2
           WHEN g % 31 = 0 THEN 6
           WHEN g % 37 = 0 THEN 4
           ELSE 1
       END,
       'PO',
       CURRENT_TIMESTAMP - ((g % 180) || ' days')::interval,
       'TN-' || lpad((1000 + (g % 9000))::text, 4, '0'),
       NULL, 'POD-' || g, 1 + (g % 20),
       100 + (g % 900),
       NULL, NULL,
       '33' || lpad(((g * 7919) % 1000000000)::text, 9, '0'),
       CASE g % 5 WHEN 0 THEN 'UNIT1' WHEN 1 THEN 'UNIT2'
                 WHEN 2 THEN 'UNIT4' WHEN 3 THEN 'UNIT7' ELSE 'SPM' END,
       1, 1000 + (g % 100000),
       NULL, NULL, 'DEMO-USER', 'RECEIVING',
       'ROAD', 'DRIVER-' || g, 'GATEUSER',
       NULL, NULL, NULL
FROM generate_series(1, 200000) AS g;

INSERT INTO jan_gate_lines
SELECT g,
       l,
       g::text,
       'PO-' || lpad(g::text, 8, '0'),
       CURRENT_DATE - ((g % 365) || ' days')::interval,
       'ITEM-' || lpad((((g - 1) * 3 + l) % 50000 + 1)::text, 6, '0'),
       'Demo item ' || l,
       'REV-' || ((l % 4) + 1),
       100,
       CASE WHEN g % 17 = 0 THEN 150 ELSE 10 + ((g + l) % 80) END,
       'EA',
       NULL, NULL, NULL,
       'PO', NULL, 1, 1,
       'ORG-' || (444 + (g % 5)), 1,
       (g * 10) + l,
       g,
       (g * 10) + l,
       100 + ((g * 10 + l) % 900),
       10 + ((g + l) % 80),
       (10 + ((g + l) % 80)) * 25,
       'CAT-' || ((l % 5) + 1),
       'STANDARD', NULL,
       NULL, NULL, CURRENT_DATE + ((g % 30) || ' days')::interval,
       'LOT-' || g || '-' || l,
       CASE WHEN g % 7 = 0 THEN NULL ELSE 'CHECKER-' || ((g % 50) + 1) END,
       CASE WHEN g % 7 = 0 THEN NULL ELSE 'ITEMCHECK-' || ((g % 50) + 1) END,
       CASE WHEN g % 7 = 0 THEN NULL ELSE now() END
FROM generate_series(1, 200000) AS g
CROSS JOIN generate_series(1, 3) AS l;

-- ============================================================
-- 10. Counting rows
-- ============================================================
INSERT INTO gate_counting(gate_no, line_no, counted_qty, accepted_qty, rejected_qty, checked_by, status)
SELECT gl.gate_no,
       gl.line_no,
       CASE WHEN gl.gate_no % 17 = 0 THEN gl.supdcqty + 5 ELSE gl.supdcqty END,
       CASE WHEN gl.gate_no % 23 = 0 THEN gl.supdcqty - 2 ELSE gl.supdcqty END,
       CASE WHEN gl.gate_no % 23 = 0 THEN 2 ELSE 0 END,
       'COUNTER-' || ((gl.gate_no % 100) + 1),
       'COUNTED'
FROM jan_gate_lines gl;

-- ============================================================
-- 11. Receipt-pending rows
-- Keep shipment_line_id NULL to reproduce the validation query's
-- "not yet receipted" condition.
-- ============================================================
INSERT INTO jan_receipt_pending(gate_no, line_no, pending_qty, status)
SELECT gl.gate_no,
       gl.line_no,
       GREATEST(gl.supdcqty - COALESCE(pc.quantity_received,0), 0),
       'PENDING'
FROM jan_gate_lines gl
LEFT JOIN po_line_locations pc
       ON pc.line_location_id = gl.location_id
WHERE gl.gate_no % 10 <> 0;

-- ============================================================
-- 12. Canonical validation queries
-- ============================================================

-- A. Gate Register actual status
-- Parameter: :gate_no
SELECT gate_no,
       dc_no,
       supplier_name,
       gdate,
       validated,
       CASE validated
           WHEN 0 THEN 'VALIDATED'
           WHEN 1 THEN 'GATE'
           WHEN 2 THEN 'NOT VALIDATED'
           WHEN 3 THEN 'ACTION TAKEN'
           WHEN 4 THEN 'RTV'
           WHEN 5 THEN 'CANCEL ENTRY'
           WHEN 6 THEN 'No Reference'
           ELSE 'UNKNOWN'
       END AS actual_status,
       receipt_num,
       receipt_date
FROM jan_gate_header
WHERE gate_no = :gate_no;

-- B. Counting completeness
-- PASS means every gate line has a counting row.
SELECT h.gate_no,
       COUNT(gl.line_no) AS gate_lines,
       COUNT(gc.counting_id) AS counted_lines,
       CASE WHEN COUNT(gl.line_no) = COUNT(gc.counting_id)
            THEN 'PASS' ELSE 'FAIL' END AS counting_status
FROM jan_gate_header h
JOIN jan_gate_lines gl ON gl.gate_no = h.gate_no
LEFT JOIN gate_counting gc
       ON gc.gate_no = gl.gate_no AND gc.line_no = gl.line_no
WHERE h.gate_no = :gate_no
GROUP BY h.gate_no;

-- C. Validation rules derived from VALIDATE_Load:
--    No pending qty / cancelled / closed / approval pending /
--    inward quantity exceeds PO balance / PO not approved /
--    missing item revision.
SELECT gl.gate_no,
       gl.line_no,
       gl.pono,
       gl.item,
       ploc.quantity,
       ploc.quantity_received,
       ploc.quantity_cancelled,
       gl.supdcqty,
       CASE
         WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) = 0
              THEN 'No pending Qty'
         WHEN ploc.quantity_cancelled > 0
              THEN 'PO cancelled'
         WHEN COALESCE(ploc.closed_code,'OPEN') <> 'OPEN'
              THEN 'Line closed'
         WHEN ploc.approved_flag <> 'Y'
              THEN 'Approval Pend'
         WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) < gl.supdcqty
              THEN 'Po Qty less than inward Qty'
         WHEN ph.authorization_status <> 'APPROVED'
              THEN 'PO Not Approved'
         WHEN pl.item_revision IS NULL
              THEN 'No Revision for item in PO'
         ELSE 'NP'
       END AS validation_status
FROM jan_gate_lines gl
JOIN po_line_locations ploc ON ploc.line_location_id = gl.location_id
JOIN po_lines pl ON pl.po_line_id = gl.poline
JOIN po_headers ph ON ph.po_header_id = gl.pohead
WHERE gl.gate_no = :gate_no;

-- D. Receipt existence check, equivalent to the legacy valfun check.
SELECT receipt_num
FROM rcv_shipment_headers
WHERE packing_slip = :gate_no::text;

-- ============================================================
-- 13. Safe receipt creation transaction
-- Creates one shipment header and line records only when ALL
-- selected validation conditions pass.
-- ============================================================
-- Replace :gate_no with a real gate number and run in a transaction.
BEGIN;

-- Lock the gate so two receipt processes cannot create duplicates.
SELECT 1 FROM jan_gate_header
WHERE gate_no = :gate_no
FOR UPDATE;

-- Fail fast if an existing receipt is already present.
DO $$
DECLARE
    v_gate BIGINT := :gate_no;
    v_exists INT;
BEGIN
    SELECT COUNT(*) INTO v_exists
    FROM rcv_shipment_headers
    WHERE packing_slip = v_gate::text;

    IF v_exists > 0 THEN
        RAISE EXCEPTION 'Receipt already exists for gate %', v_gate;
    END IF;
END $$;

-- Create shipment header.
INSERT INTO rcv_shipment_headers
(shipment_num, receipt_num, packing_slip, gate_no, vendor_id, ship_to_org_id)
SELECT 'SHIP-' || gate_no,
       'REC-' || gate_no,
       gate_no::text,
       gate_no,
       vendor_id,
       444
FROM jan_gate_header
WHERE gate_no = :gate_no;

-- Create receipt lines from accepted counting quantity.
INSERT INTO jan_pur_listing
(gate_no, receipt_num, receipt_date, pono, po_line_id, line_location_id,
 item_no, item_description, quantity_received, qty_appd, inv_no)
SELECT gl.gate_no,
       'REC-' || gl.gate_no,
       now(),
       gl.pono,
       gl.poline,
       gl.location_id,
       gl.item,
       gl.description,
       gc.accepted_qty,
       gc.accepted_qty,
       'INV-' || gl.gate_no
FROM jan_gate_lines gl
JOIN gate_counting gc
  ON gc.gate_no = gl.gate_no AND gc.line_no = gl.line_no
WHERE gl.gate_no = :gate_no;

UPDATE jan_receipt_pending rp
SET status = 'RECEIVED',
    shipment_line_id = rp.pending_id
WHERE rp.gate_no = :gate_no;

UPDATE jan_gate_header
SET receipt_num = 'REC-' || gate_no,
    receipt_date = now()
WHERE gate_no = :gate_no;

COMMIT;

-- ============================================================
-- 14. Final end-to-end status query for the AI agent
-- ============================================================
WITH gate AS (
  SELECT * FROM jan_gate_header WHERE gate_no = :gate_no
),
lines AS (
  SELECT COUNT(*) line_count
  FROM jan_gate_lines WHERE gate_no = :gate_no
),
counting AS (
  SELECT COUNT(*) counted_lines
  FROM gate_counting WHERE gate_no = :gate_no
),
validation AS (
  SELECT COUNT(*) FILTER (WHERE validation_status <> 'NP') blocking_rules
  FROM (
    SELECT CASE
      WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) = 0 THEN 'No pending Qty'
      WHEN ploc.quantity_cancelled > 0 THEN 'PO cancelled'
      WHEN COALESCE(ploc.closed_code,'OPEN') <> 'OPEN' THEN 'Line closed'
      WHEN ploc.approved_flag <> 'Y' THEN 'Approval Pend'
      WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) < gl.supdcqty
           THEN 'Po Qty less than inward Qty'
      WHEN ph.authorization_status <> 'APPROVED' THEN 'PO Not Approved'
      WHEN pl.item_revision IS NULL THEN 'No Revision for item in PO'
      ELSE 'NP'
    END AS validation_status
    FROM jan_gate_lines gl
    JOIN po_line_locations ploc ON ploc.line_location_id = gl.location_id
    JOIN po_lines pl ON pl.po_line_id = gl.poline
    JOIN po_headers ph ON ph.po_header_id = gl.pohead
    WHERE gl.gate_no = :gate_no
  ) x
),
receipt AS (
  SELECT COUNT(*) receipt_count
  FROM rcv_shipment_headers
  WHERE packing_slip = :gate_no::text
)
SELECT g.gate_no,
       CASE g.validated
         WHEN 0 THEN 'VALIDATED'
         WHEN 1 THEN 'GATE'
         WHEN 2 THEN 'NOT VALIDATED'
         WHEN 3 THEN 'ACTION TAKEN'
         WHEN 4 THEN 'RTV'
         WHEN 5 THEN 'CANCEL ENTRY'
         WHEN 6 THEN 'No Reference'
         ELSE 'UNKNOWN'
       END AS gate_status,
       l.line_count,
       c.counted_lines,
       v.blocking_rules,
       r.receipt_count,
       CASE
         WHEN g.validated IN (4,5,6) THEN 'BLOCKED'
         WHEN l.line_count = 0 THEN 'INVALID'
         WHEN c.counted_lines <> l.line_count THEN 'COUNTING PENDING'
         WHEN v.blocking_rules > 0 THEN 'VALIDATION FAILED'
         WHEN r.receipt_count > 0 THEN 'RECEIPT CREATED'
         ELSE 'READY FOR RECEIPT'
       END AS actual_stage_status
FROM gate g CROSS JOIN lines l CROSS JOIN counting c
CROSS JOIN validation v CROSS JOIN receipt r;
