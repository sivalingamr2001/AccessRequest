# Gate Register AI Knowledge Base
## Scope
This knowledge base is derived from the uploaded Gate Entry Management System overview and SQL query catalog. It intentionally narrows the system to:

**Gate Entry Register → Counting → Validation → Receipt Creation**

The source describes the application as a gate-entry and validation gatekeeper. The Gate Register is the central status/search area; material inward records DC/supplier/vehicle/PO information; validation is performed before accounts posting; and receipts are ultimately represented in Oracle receiving data. The source identifies 273 SQL queries across 65 tables, so this document does not claim to model every legacy feature.

## 1. Source-of-truth tables for this focused flow

| Stage | Legacy/source table | Purpose |
|---|---|---|
| Gate Register | `JAN_GATE_HEADER` | Gate header, supplier, DC, date, unit and high-level status |
| Gate lines | `JAN_GATE_LINES` | PO/item/quantity/line-level data |
| Counting / inward result | `JAN_PUR_LISTING` and related counting logic | Receipt/inward quantities and receipt reporting |
| Validation queue | `JAN_RECEIPT_PENDING` | Pending receipt-related lines; the validation query specifically checks rows where `shipment_line_id IS NULL` |
| Receipt | `RCV_SHIPMENT_HEADERS` | Receipt/shipment existence; the legacy code checks `receipt_num` using `packing_slip = gate number` |

The source also shows validation dependencies on `PO_LINE_LOCATIONS_ALL`, `PO_HEADERS_ALL`, and `PO_LINES_ALL`.

## 2. Gate status mapping

The Gate dashboard query explicitly maps `JAN_GATE_HEADER.VALIDATED` as:

- `0` → `VALIDATED`
- `1` → `GATE`
- `2` → `NOT VALIDATED`
- `3` → `ACTION TAKEN`
- `4` → `RTV`
- `5` → `CANCEL ENTRY`
- `6` → `No Reference`

Important: an AI must report these as source-defined status labels. It should not invent a different meaning.

## 3. Gate Register questions the AI should answer

### Q: "What is the status of gate 12345?"
Run the canonical Gate Register query using `gate_no = 12345`.
Return:
- gate number
- DC number/date
- supplier
- gate date
- numeric validated value
- mapped status
- receipt number/date if present

### Q: "Has this gate been received?"
First check `RCV_SHIPMENT_HEADERS` using:
`packing_slip = gate number`.
If a receipt exists, report the actual `receipt_num`.
If none exists, say no matching receipt was found.

### Q: "Why is gate 12345 not ready?"
Run the stage checks in order:
1. Gate status
2. Counting completeness
3. Validation blockers
4. Receipt existence

Return the first blocking condition and the supporting database values.

### Q: "How many items are on the gate?"
Count rows in `JAN_GATE_LINES` for the gate.

### Q: "Has counting completed?"
Compare the number of gate lines with the number of counting rows for the gate. If every line has a counting result, counting is complete in the demo model.

## 4. Validation rules from the legacy `VALIDATE_Load` query

For each gate line linked to a pending receipt row (`JAN_RECEIPT_PENDING` with `shipment_line_id IS NULL`), evaluate these conditions in this order:

1. **No pending Qty**
   `quantity - (quantity_received + quantity_cancelled) = 0`

2. **PO cancelled**
   `quantity_cancelled > 0`

3. **Line closed**
   `NVL(closed_code, 'OPEN') <> 'OPEN'`

4. **Approval pending**
   `approved_flag <> 'Y'`

5. **PO quantity less than inward quantity**
   `quantity - (quantity_received + quantity_cancelled) < supdcqty`

6. **PO not approved**
   Related `PO_HEADERS_ALL.authorization_status <> 'APPROVED'`

7. **No revision for item in PO**
   Related `PO_LINES_ALL.item_revision IS NULL`

8. Otherwise the source query returns **`NP`**, meaning no validation exception under this query.

The legacy query filters out `NP`, so the rows returned by it are the validation problems.

## 5. Counting validation

The uploaded catalog contains counting-related logic that reads/aggregates `JAN_GATE_LINES` and later uses receipt/inward records. For an AI-facing simplified validation layer, use:

- Every gate line must have one counting result.
- Counted quantity must be non-negative.
- Accepted quantity must be non-negative.
- Rejected quantity must be non-negative.
- The source business rules should be treated as authoritative where a direct query exists; the demo schema's `gate_counting` table is an explicit simplification for test data.

Do not claim that every additional counting rule in the real application has been reproduced unless the exact source query supports it.

## 6. Receipt validation

Before creating a receipt:

1. Gate exists.
2. Gate is not `RTV`, `CANCEL ENTRY`, or `No Reference`.
3. Gate has at least one line.
4. Every gate line has a counting record.
5. Validation returns no blocking rows.
6. No existing receipt is found for the gate.
7. Receipt quantities come from the approved/accepted counting result.
8. Receipt creation and gate update should be performed transactionally.

The legacy source contains the direct duplicate/existence check:

`select receipt_num from rcv_shipment_headers where packing_slip = <gate number>`

## 7. AI execution contract

The AI should NOT freely generate destructive SQL.

Allowed:
- `SELECT`
- aggregate/count queries
- joins required to evaluate the documented rules
- parameterized queries against the approved validation views/tables

Restricted:
- `INSERT`
- `UPDATE`
- `DELETE`
- DDL
- dynamic SQL assembled from user text

Receipt creation should be an application-controlled command/procedure, not arbitrary SQL generated by the model.

### Required input normalization
Extract:
- `gate_no`
- optional stage (`gate`, `counting`, `validation`, `receipt`)
- optional question intent

Never concatenate a user-provided gate number into SQL. Bind it as a parameter.

## 8. AI response format

Return a compact but auditable response:

STATUS: <actual status>
STAGE: <current stage>
GATE: <gate number>

FACTS:
- Gate status: <database value + mapped label>
- Lines: <count>
- Counted: <count>
- Validation blockers: <count>
- Receipt: <receipt number or NOT FOUND>

BLOCKERS:
- <rule code>: <reason>
- <database evidence>

NEXT_STATE:
- <READY FOR RECEIPT / COUNTING PENDING / VALIDATION FAILED / RECEIPT CREATED / BLOCKED>

SOURCE:
- Query/rule used
- Execution timestamp

Do not say "probably", "looks like", or "should be" when the database returned a definitive value.

## 9. Example interpretations

### Example A — Gate created, counting incomplete
If gate status is `GATE`, 3 lines exist and only 2 counting rows exist:

`STATUS: COUNTING PENDING`

Reason:
`3 gate lines exist, but only 2 have counting records.`

### Example B — Counting complete, validation failed
If all lines are counted but one PO line returns `PO Not Approved`:

`STATUS: VALIDATION FAILED`

Do not create a receipt.

### Example C — Validation passes, receipt absent
If no validation blocker exists and no `RCV_SHIPMENT_HEADERS` row matches the gate:

`STATUS: READY FOR RECEIPT`

### Example D — Receipt exists
If `RCV_SHIPMENT_HEADERS` returns `REC-12345`:

`STATUS: RECEIPT CREATED`

Return the actual receipt number instead of merely saying "received".

## 10. Suggested user question catalogue

1. What is the current status of gate 12345?
2. Why is gate 12345 not validated?
3. Is gate 12345 counted?
4. How many lines are pending for gate 12345?
5. Which item is causing validation failure?
6. Is the PO approved?
7. Is the PO line closed?
8. Is there pending PO quantity?
9. Is the inward quantity greater than the remaining PO quantity?
10. Is the item revision missing?
11. Has a receipt already been created?
12. What is the receipt number?
13. When was the receipt created?
14. Which supplier belongs to gate 12345?
15. Which DC belongs to gate 12345?
16. What is the gate's validated numeric status?
17. What is the business status represented by that numeric value?
18. Why can't I create the receipt?
19. Which lines have not been counted?
20. Show all validation failures for this gate.
21. Show the evidence used to determine the status.
22. Recheck gate 12345.
23. Is gate 12345 ready for receipt creation?
24. How many gates are currently in `NOT VALIDATED` status?
25. How many gates have receipts?

## 11. Important source limitations

The uploaded project overview states that the primary database is Oracle and the application uses Oracle-specific constructs. The query catalog contains Oracle syntax such as `NVL`, `ROWNUM`, `DECODE`, `DUAL`, sequences, and Oracle receiving tables.

The supplied demo SQL therefore uses PostgreSQL syntax and a focused normalized schema. It is a **test/AI-validation model**, not a claim that the production Oracle schema can be replaced directly.

The source catalog also reports 212 concatenated/potential SQL injection points. Any new AI implementation should use parameterized queries rather than copying that legacy construction style.

## 12. Security note

The project overview contains database credentials and infrastructure details. Those values are intentionally excluded from this AI knowledge base. Production AI execution must use a restricted database identity with read-only access for validation and a separately controlled application operation for receipt creation.
