-- Final AI-facing status query.
-- PostgreSQL demo syntax.
WITH gate AS (
  SELECT * FROM jan_gate_header WHERE gate_no = :gate_no
),
lines AS (
  SELECT COUNT(*) line_count
  FROM jan_gate_lines WHERE gate_no = :gate_no
),
counting AS (
  SELECT COUNT(*) counted_lines
  FROM gate_counting WHERE gate_no = :gate_no
),
validation AS (
  SELECT COUNT(*) FILTER (WHERE validation_status <> 'NP') blocking_rules
  FROM (
    SELECT CASE
      WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) = 0 THEN 'No pending Qty'
      WHEN ploc.quantity_cancelled > 0 THEN 'PO cancelled'
      WHEN COALESCE(ploc.closed_code,'OPEN') <> 'OPEN' THEN 'Line closed'
      WHEN ploc.approved_flag <> 'Y' THEN 'Approval Pend'
      WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) < gl.supdcqty
           THEN 'Po Qty less than inward Qty'
      WHEN ph.authorization_status <> 'APPROVED' THEN 'PO Not Approved'
      WHEN pl.item_revision IS NULL THEN 'No Revision for item in PO'
      ELSE 'NP'
    END AS validation_status
    FROM jan_gate_lines gl
    JOIN po_line_locations ploc ON ploc.line_location_id = gl.location_id
    JOIN po_lines pl ON pl.po_line_id = gl.poline
    JOIN po_headers ph ON ph.po_header_id = gl.pohead
    WHERE gl.gate_no = :gate_no
  ) x
),
receipt AS (
  SELECT COUNT(*) receipt_count
  FROM rcv_shipment_headers
  WHERE packing_slip = CAST(:gate_no AS TEXT)
)
SELECT g.gate_no,
       CASE g.validated
         WHEN 0 THEN 'VALIDATED'
         WHEN 1 THEN 'GATE'
         WHEN 2 THEN 'NOT VALIDATED'
         WHEN 3 THEN 'ACTION TAKEN'
         WHEN 4 THEN 'RTV'
         WHEN 5 THEN 'CANCEL ENTRY'
         WHEN 6 THEN 'No Reference'
         ELSE 'UNKNOWN'
       END AS gate_status,
       l.line_count,
       c.counted_lines,
       v.blocking_rules,
       r.receipt_count,
       CASE
         WHEN g.validated IN (4,5,6) THEN 'BLOCKED'
         WHEN l.line_count = 0 THEN 'INVALID'
         WHEN c.counted_lines <> l.line_count THEN 'COUNTING PENDING'
         WHEN v.blocking_rules > 0 THEN 'VALIDATION FAILED'
         WHEN r.receipt_count > 0 THEN 'RECEIPT CREATED'
         ELSE 'READY FOR RECEIPT'
       END AS actual_stage_status
FROM gate g CROSS JOIN lines l CROSS JOIN counting c
CROSS JOIN validation v CROSS JOIN receipt r;
