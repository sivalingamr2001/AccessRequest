-- Legacy receipt existence check, parameterized.
SELECT receipt_num
FROM rcv_shipment_headers
WHERE packing_slip = CAST(:gate_no AS TEXT);
