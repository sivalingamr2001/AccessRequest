-- Canonical Gate Register status query
SELECT gate_no,
       dc_no,
       supplier_name,
       gdate,
       validated,
       CASE validated
           WHEN 0 THEN 'VALIDATED'
           WHEN 1 THEN 'GATE'
           WHEN 2 THEN 'NOT VALIDATED'
           WHEN 3 THEN 'ACTION TAKEN'
           WHEN 4 THEN 'RTV'
           WHEN 5 THEN 'CANCEL ENTRY'
           WHEN 6 THEN 'No Reference'
           ELSE 'UNKNOWN'
       END AS actual_status,
       receipt_num,
       receipt_date
FROM jan_gate_header
WHERE gate_no = :gate_no;
