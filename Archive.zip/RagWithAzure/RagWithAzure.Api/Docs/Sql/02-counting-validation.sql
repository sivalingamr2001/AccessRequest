-- Counting completeness
SELECT h.gate_no,
       COUNT(gl.line_no) AS gate_lines,
       COUNT(gc.counting_id) AS counted_lines,
       CASE WHEN COUNT(gl.line_no) = COUNT(gc.counting_id)
            THEN 'PASS' ELSE 'FAIL' END AS counting_status
FROM jan_gate_header h
JOIN jan_gate_lines gl ON gl.gate_no = h.gate_no
LEFT JOIN gate_counting gc
       ON gc.gate_no = gl.gate_no AND gc.line_no = gl.line_no
WHERE h.gate_no = :gate_no
GROUP BY h.gate_no;
