-- Validation rules derived from legacy VALIDATE_Load.
SELECT gl.gate_no,
       gl.line_no,
       gl.pono,
       gl.item,
       ploc.quantity,
       ploc.quantity_received,
       ploc.quantity_cancelled,
       gl.supdcqty,
       CASE
         WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) = 0
              THEN 'No pending Qty'
         WHEN ploc.quantity_cancelled > 0
              THEN 'PO cancelled'
         WHEN COALESCE(ploc.closed_code,'OPEN') <> 'OPEN'
              THEN 'Line closed'
         WHEN ploc.approved_flag <> 'Y'
              THEN 'Approval Pend'
         WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) < gl.supdcqty
              THEN 'Po Qty less than inward Qty'
         WHEN ph.authorization_status <> 'APPROVED'
              THEN 'PO Not Approved'
         WHEN pl.item_revision IS NULL
              THEN 'No Revision for item in PO'
         ELSE 'NP'
       END AS validation_status
FROM jan_gate_lines gl
JOIN po_line_locations ploc ON ploc.line_location_id = gl.location_id
JOIN po_lines pl ON pl.po_line_id = gl.poline
JOIN po_headers ph ON ph.po_header_id = gl.pohead
WHERE gl.gate_no = :gate_no;
