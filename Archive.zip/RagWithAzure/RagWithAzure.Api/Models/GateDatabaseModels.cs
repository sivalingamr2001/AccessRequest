namespace RagWithAzure.Api.Models;

public class GateHeaderDbRow
{
    public long Gate_No { get; set; }
    public string Supplier_Name { get; set; } = string.Empty;
    public string Dc_No { get; set; } = string.Empty;
    public DateTime? Dc_Date { get; set; }
    public string? Vehicle_Det { get; set; }
    public string Unit { get; set; } = string.Empty;
    public string Gate_Status { get; set; } = string.Empty;
    public int Line_Count { get; set; }
    public int Counted_Lines { get; set; }
    public int Blocking_Rules { get; set; }
    public int Receipt_Count { get; set; }
    public string Actual_Stage_Status { get; set; } = string.Empty;
    public string? Receipt_Num { get; set; }
    public DateTime? Receipt_Date { get; set; }
}

public class GateLineDbRow
{
    public long Gate_No { get; set; }
    public int Line_No { get; set; }
    public string Item { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Pono { get; set; } = string.Empty;
    public decimal? Poqty { get; set; }
    public decimal? Supdcqty { get; set; }
    public decimal? Counted_Qty { get; set; }
    public decimal? Accepted_Qty { get; set; }
    public decimal? Rejected_Qty { get; set; }
    public string? Counting_Status { get; set; }
    public string? Validation_Status { get; set; }
}

public class GateQueryResult
{
    public GateHeaderDbRow? Header { get; set; }
    public List<GateLineDbRow> Lines { get; set; } = [];
    public List<string> ValidationBlockers { get; set; } = [];
    public bool Found => Header != null;
}
