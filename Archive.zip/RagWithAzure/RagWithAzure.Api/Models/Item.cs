namespace RagWithAzure.Api.Models;

public class Item
{
    public string Title { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public int Score { get; set; }
}
