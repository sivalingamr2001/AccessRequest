using RagWithAzure.Api.Models;

namespace RagWithAzure.Api.Services;

public interface IGateDatabaseService
{
    bool IsConfigured { get; }
    Task<GateQueryResult?> GetGateDetailsAsync(long gateNo, CancellationToken cancellationToken = default);
    Task<string?> TryExecuteIntentQueryAsync(string userMessage, CancellationToken cancellationToken = default);
}
