namespace RagWithAzure.Api.Services;

public interface IGeminiChatService
{
    Task<string> GenerateAnswerAsync(
        string prompt,
        string? systemInstruction = null,
        string? model = null,
        CancellationToken cancellationToken = default);
}
