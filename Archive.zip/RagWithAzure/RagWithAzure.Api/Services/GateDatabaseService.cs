using System.Data;
using System.Text.RegularExpressions;
using Dapper;
using Npgsql;
using RagWithAzure.Api.Models;

namespace RagWithAzure.Api.Services;

public class GateDatabaseService : IGateDatabaseService
{
    private readonly string? _connectionString;
    private readonly string _schema;
    private readonly ILogger<GateDatabaseService> _logger;

    public bool IsConfigured => !string.IsNullOrWhiteSpace(_connectionString);

    public GateDatabaseService(IConfiguration configuration, ILogger<GateDatabaseService> logger)
    {
        _logger = logger;
        
        var rawConnStr = configuration.GetConnectionString("DefaultConnection")
            ?? configuration["connectionStrings:DefaultConnection"]
            ?? configuration["ConnectionStrings:DefaultConnection"];

        if (!string.IsNullOrWhiteSpace(rawConnStr))
        {
            // Handle schema/Search Path safely for Npgsql
            var schemaMatch = Regex.Match(rawConnStr, @"(?:schema|searchpath|search\s*path)\s*=\s*([^;]+)", RegexOptions.IgnoreCase);
            _schema = schemaMatch.Success ? schemaMatch.Groups[1].Value.Trim() : "gate_demo";

            // Build sanitized Npgsql connection string
            var cleanConnStr = Regex.Replace(rawConnStr, @"schema\s*=\s*[^;]+;?", "", RegexOptions.IgnoreCase);
            var builder = new NpgsqlConnectionStringBuilder(cleanConnStr)
            {
                SearchPath = _schema
            };
            _connectionString = builder.ConnectionString;
            _logger.LogInformation("GateDatabaseService initialized with schema {Schema}", _schema);
        }
        else
        {
            _schema = "gate_demo";
            _logger.LogWarning("No connection string configured for GateDatabaseService.");
        }
    }

    private async Task<NpgsqlConnection> CreateConnectionAsync(CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(_connectionString))
        {
            throw new InvalidOperationException("PostgreSQL connection string is not configured.");
        }

        var conn = new NpgsqlConnection(_connectionString);
        await conn.OpenAsync(cancellationToken);

        // Ensure search path is always set to the schema
        await conn.ExecuteAsync($"SET search_path = {_schema}, public;");
        return conn;
    }

    public async Task<GateQueryResult?> GetGateDetailsAsync(long gateNo, CancellationToken cancellationToken = default)
    {
        if (!IsConfigured) return null;

        try
        {
            await using var conn = await CreateConnectionAsync(cancellationToken);

            // 1. End-to-end gate header and stage status query
            const string endToEndSql = @"
WITH gate AS (
  SELECT * FROM jan_gate_header WHERE gate_no = @gateNo
),
lines AS (
  SELECT COUNT(*) line_count FROM jan_gate_lines WHERE gate_no = @gateNo
),
counting AS (
  SELECT COUNT(*) counted_lines FROM gate_counting WHERE gate_no = @gateNo
),
validation AS (
  SELECT COUNT(*) FILTER (WHERE validation_status <> 'NP') blocking_rules
  FROM (
    SELECT CASE
      WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) = 0 THEN 'No pending Qty'
      WHEN ploc.quantity_cancelled > 0 THEN 'PO cancelled'
      WHEN COALESCE(ploc.closed_code,'OPEN') <> 'OPEN' THEN 'Line closed'
      WHEN ploc.approved_flag <> 'Y' THEN 'Approval Pend'
      WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) < gl.supdcqty
           THEN 'Po Qty less than inward Qty'
      WHEN ph.authorization_status <> 'APPROVED' THEN 'PO Not Approved'
      WHEN pl.item_revision IS NULL THEN 'No Revision for item in PO'
      ELSE 'NP'
    END AS validation_status
    FROM jan_gate_lines gl
    JOIN po_line_locations ploc ON ploc.line_location_id = gl.location_id
    JOIN po_lines pl ON pl.po_line_id = gl.poline
    JOIN po_headers ph ON ph.po_header_id = gl.pohead
    WHERE gl.gate_no = @gateNo
  ) x
),
receipt AS (
  SELECT COUNT(*) receipt_count FROM rcv_shipment_headers WHERE packing_slip = CAST(@gateNo AS TEXT)
)
SELECT g.gate_no, g.supplier_name, g.dc_no, g.dc_date, g.vehicle_det, g.unit, g.receipt_num, g.receipt_date,
       CASE g.validated
         WHEN 0 THEN 'VALIDATED'
         WHEN 1 THEN 'GATE'
         WHEN 2 THEN 'NOT VALIDATED'
         WHEN 3 THEN 'ACTION TAKEN'
         WHEN 4 THEN 'RTV'
         WHEN 5 THEN 'CANCEL ENTRY'
         WHEN 6 THEN 'No Reference'
         ELSE 'UNKNOWN'
       END AS gate_status,
       l.line_count,
       c.counted_lines,
       v.blocking_rules,
       r.receipt_count,
       CASE
         WHEN g.validated IN (4,5,6) THEN 'BLOCKED'
         WHEN l.line_count = 0 THEN 'INVALID'
         WHEN c.counted_lines <> l.line_count THEN 'COUNTING PENDING'
         WHEN v.blocking_rules > 0 THEN 'VALIDATION FAILED'
         WHEN r.receipt_count > 0 THEN 'RECEIPT CREATED'
         ELSE 'READY FOR RECEIPT'
       END AS actual_stage_status
FROM gate g CROSS JOIN lines l CROSS JOIN counting c
CROSS JOIN validation v CROSS JOIN receipt r;";

            var header = await conn.QueryFirstOrDefaultAsync<GateHeaderDbRow>(
                new CommandDefinition(endToEndSql, new { gateNo }, cancellationToken: cancellationToken));

            if (header == null || header.Gate_No == 0)
            {
                return new GateQueryResult { Header = null };
            }

            // 2. Fetch line items and counting
            const string linesSql = @"
SELECT gl.gate_no, gl.line_no, gl.item, gl.description, gl.pono, gl.poqty, gl.supdcqty,
       gc.counted_qty, gc.accepted_qty, gc.rejected_qty, gc.status as counting_status
FROM jan_gate_lines gl
LEFT JOIN gate_counting gc ON gc.gate_no = gl.gate_no AND gc.line_no = gl.line_no
WHERE gl.gate_no = @gateNo
ORDER BY gl.line_no;";

            var lines = (await conn.QueryAsync<GateLineDbRow>(
                new CommandDefinition(linesSql, new { gateNo }, cancellationToken: cancellationToken))).ToList();

            // 3. Fetch specific validation blockers if any
            const string blockersSql = @"
SELECT gl.line_no || ': ' || CASE
    WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) = 0 THEN 'No pending Qty on PO'
    WHEN ploc.quantity_cancelled > 0 THEN 'PO cancelled'
    WHEN COALESCE(ploc.closed_code,'OPEN') <> 'OPEN' THEN 'PO Line is closed'
    WHEN ploc.approved_flag <> 'Y' THEN 'Approval pending on PO line'
    WHEN (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) < gl.supdcqty THEN 'Inward quantity exceeds open PO balance'
    WHEN ph.authorization_status <> 'APPROVED' THEN 'Purchase order authorization status is not APPROVED'
    WHEN pl.item_revision IS NULL THEN 'Missing item revision on PO line'
    ELSE 'NP'
  END AS blocker
FROM jan_gate_lines gl
JOIN po_line_locations ploc ON ploc.line_location_id = gl.location_id
JOIN po_lines pl ON pl.po_line_id = gl.poline
JOIN po_headers ph ON ph.po_header_id = gl.pohead
WHERE gl.gate_no = @gateNo
  AND (
    (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) = 0
    OR ploc.quantity_cancelled > 0
    OR COALESCE(ploc.closed_code,'OPEN') <> 'OPEN'
    OR ploc.approved_flag <> 'Y'
    OR (ploc.quantity - (ploc.quantity_received + ploc.quantity_cancelled)) < gl.supdcqty
    OR ph.authorization_status <> 'APPROVED'
    OR pl.item_revision IS NULL
  );";

            var blockers = (await conn.QueryAsync<string>(
                new CommandDefinition(blockersSql, new { gateNo }, cancellationToken: cancellationToken))).ToList();

            return new GateQueryResult
            {
                Header = header,
                Lines = lines,
                ValidationBlockers = blockers
            };
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex, "Failed to query gate {GateNo} from PostgreSQL", gateNo);
            return null;
        }
    }

    public async Task<string?> TryExecuteIntentQueryAsync(string userMessage, CancellationToken cancellationToken = default)
    {
        if (!IsConfigured) return null;

        var lower = userMessage.ToLowerInvariant();

        try
        {
            await using var conn = await CreateConnectionAsync(cancellationToken);

            // Case: How many gates are in NOT VALIDATED status?
            if (lower.Contains("not validated") && (lower.Contains("how many") || lower.Contains("count")))
            {
                var count = await conn.ExecuteScalarAsync<long>(
                    new CommandDefinition("SELECT count(*) FROM jan_gate_header WHERE validated = 2;", cancellationToken: cancellationToken));
                return $"Live database record count: There are exactly {count:N0} gates in 'NOT VALIDATED' status.";
            }

            // Case: How many gates have receipts?
            if (lower.Contains("receipt") && (lower.Contains("how many") || lower.Contains("count")))
            {
                var count = await conn.ExecuteScalarAsync<long>(
                    new CommandDefinition("SELECT count(*) FROM rcv_shipment_headers;", cancellationToken: cancellationToken));
                return $"Live database record count: There are exactly {count:N0} gates that currently have receipts created in the system.";
            }

            // Case: Total gates
            if ((lower.Contains("how many gates") || lower.Contains("total gates")) && !lower.Contains("line"))
            {
                var count = await conn.ExecuteScalarAsync<long>(
                    new CommandDefinition("SELECT count(*) FROM jan_gate_header;", cancellationToken: cancellationToken));
                return $"Live database record count: There are currently {count:N0} total gate entries recorded in the Gate Register.";
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex, "Failed executing aggregate SQL query for intent");
        }

        return null;
    }
}
