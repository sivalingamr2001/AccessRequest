using RagWithAzure.Api.Models;

namespace RagWithAzure.Api.Services;

/// <summary>
/// Abstraction for retrieving documents from a data store (e.g. local directory, Azure Blob, S3, GCS).
/// </summary>
public interface IDocumentStore
{
    Task<List<Item>> FindRelevantDocumentsAsync(string query, int topN = 3, CancellationToken cancellationToken = default);
}
