using System.Text.RegularExpressions;
using RagWithAzure.Api.Models;

namespace RagWithAzure.Api.Services;

/// <summary>
/// Local filesystem implementation of IDocumentStore reading files from the Docs folder.
/// </summary>
public class LocalFileDocumentStore : IDocumentStore
{
    private readonly string _docsDirectory;
    private readonly ILogger<LocalFileDocumentStore> _logger;
    private static readonly HashSet<string> SupportedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".md", ".sql", ".txt", ".json", ".csv", ".html", ".xml", ".yaml", ".yml"
    };

    private static readonly HashSet<string> CommonStopWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "what", "is", "the", "a", "an", "are", "of", "to", "for", "in", "on", "how", "why", "does", "do", "can", "about", "me", "tell", "show", "give", "and", "or", "with", "from"
    };

    public LocalFileDocumentStore(IConfiguration configuration, IWebHostEnvironment environment, ILogger<LocalFileDocumentStore> logger)
    {
        _logger = logger;
        var configuredPath = configuration["DocsDirectory"] ?? "Docs";
        
        // Support both absolute paths and relative paths within ContentRootPath
        _docsDirectory = Path.IsPathRooted(configuredPath)
            ? configuredPath
            : Path.GetFullPath(Path.Combine(environment.ContentRootPath, configuredPath));

        _logger.LogInformation("LocalFileDocumentStore initialized with directory: {Directory}", _docsDirectory);
    }

    public async Task<List<Item>> FindRelevantDocumentsAsync(string query, int topN = 5, CancellationToken cancellationToken = default)
    {
        try
        {
            var directory = new DirectoryInfo(_docsDirectory);
            if (!directory.Exists)
            {
                _logger.LogWarning("Docs directory {Directory} does not exist.", _docsDirectory);
                return [];
            }

            var relevantDocuments = new List<Item>();
            var allFiles = directory.GetFiles("*", SearchOption.AllDirectories)
                .Where(f => SupportedExtensions.Contains(f.Extension));

            var rawTerms = query.ToLowerInvariant()
                .Split([' ', ',', '.', '?', '!', ';', ':', '\t', '\n', '\r'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            if (rawTerms.Length == 0)
            {
                return [];
            }

            // Prefer domain terms over common stop words if available
            var filteredTerms = rawTerms.Where(t => !CommonStopWords.Contains(t)).ToArray();
            var searchTerms = filteredTerms.Length > 0 ? filteredTerms : rawTerms;

            foreach (var file in allFiles)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var content = await File.ReadAllTextAsync(file.FullName, cancellationToken);
                var contentLower = content.ToLowerInvariant();

                // Extract title: check frontmatter first, then top # Heading 1, fallback to filename
                var title = string.Empty;
                var titleMatch = Regex.Match(content, @"title:\s*(.+?)(?:\r?\n|$)", RegexOptions.IgnoreCase);
                if (titleMatch.Success)
                {
                    title = titleMatch.Groups[1].Value.Trim();
                }
                else
                {
                    var h1Match = Regex.Match(content, @"^#\s+(.+)$", RegexOptions.Multiline);
                    title = h1Match.Success
                        ? h1Match.Groups[1].Value.Trim()
                        : Path.GetFileNameWithoutExtension(file.Name);
                }

                var descriptionMatch = Regex.Match(content, @"description:\s*(.+?)(?:\r?\n|$)", RegexOptions.IgnoreCase);
                var description = descriptionMatch.Success
                    ? descriptionMatch.Groups[1].Value.Trim()
                    : string.Empty;

                var titleLower = title.ToLowerInvariant();
                var descriptionLower = description.ToLowerInvariant();

                // Calculate match score
                var matchCount = 0;
                foreach (var term in searchTerms)
                {
                    if (titleLower.Contains(term))
                    {
                        matchCount += 4; // highest weight for title matches
                    }
                    if (!string.IsNullOrEmpty(descriptionLower) && descriptionLower.Contains(term))
                    {
                        matchCount += 3; // high weight for description matches
                    }
                    if (contentLower.Contains(term))
                    {
                        matchCount += 1;
                    }
                }

                if (matchCount > 0)
                {
                    relevantDocuments.Add(new Item
                    {
                        Title = title,
                        Content = content,
                        Score = matchCount
                    });
                }
            }

            return relevantDocuments
                .OrderByDescending(d => d.Score)
                .Take(topN)
                .ToList();
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex, "Error occurred while searching documents in {Directory}", _docsDirectory);
            return [];
        }
    }
}
