using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;

namespace RagWithAzure.Api.Services;

public class GeminiChatService : IGeminiChatService
{
    private readonly HttpClient _httpClient;
    private readonly string _apiKey;
    private readonly string _defaultModel;
    private readonly ILogger<GeminiChatService> _logger;

    public GeminiChatService(HttpClient httpClient, IConfiguration configuration, ILogger<GeminiChatService> logger)
    {
        _httpClient = httpClient;
        _logger = logger;
        _apiKey = configuration["Gemini:ApiKey"]
            ?? configuration["GeminiApiKey"]
            ?? throw new InvalidOperationException("Gemini API key is not configured. Please set 'Gemini:ApiKey' in appsettings.");
        
        _defaultModel = configuration["Gemini:Model"] ?? "gemini-3.5-flash-lite";
    }

    public async Task<string> GenerateAnswerAsync(
        string prompt,
        string? systemInstruction = null,
        string? model = null,
        CancellationToken cancellationToken = default)
    {
        var targetModel = !string.IsNullOrWhiteSpace(model) ? model.Trim() : _defaultModel;
        var url = $"https://generativelanguage.googleapis.com/v1beta/models/{targetModel}:generateContent";

        var payload = new JsonObject();

        if (!string.IsNullOrWhiteSpace(systemInstruction))
        {
            payload["systemInstruction"] = new JsonObject
            {
                ["parts"] = new JsonArray
                {
                    new JsonObject { ["text"] = systemInstruction }
                }
            };
        }

        payload["contents"] = new JsonArray
        {
            new JsonObject
            {
                ["role"] = "user",
                ["parts"] = new JsonArray
                {
                    new JsonObject { ["text"] = prompt }
                }
            }
        };

        const int maxAttempts = 3;
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            cancellationToken.ThrowIfCancellationRequested();

            using var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("x-goog-api-key", _apiKey);
            request.Content = JsonContent.Create(payload);

            using var response = await _httpClient.SendAsync(request, cancellationToken);
            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);

            if (response.StatusCode == HttpStatusCode.ServiceUnavailable && attempt < maxAttempts)
            {
                _logger.LogWarning("Gemini API ({Model}) temporarily unavailable (503). Retrying attempt {Attempt} in 2s...", targetModel, attempt);
                await Task.Delay(2000, cancellationToken);
                continue;
            }

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Gemini API error for model {Model} (Status: {StatusCode}): {Response}", targetModel, response.StatusCode, responseContent);
                throw new HttpRequestException($"Gemini API ({targetModel}) returned status code {response.StatusCode}: {responseContent}");
            }

            var rootNode = JsonNode.Parse(responseContent);
            var candidates = rootNode?["candidates"]?.AsArray();
            if (candidates is null || candidates.Count == 0)
            {
                _logger.LogWarning("No candidates returned from Gemini API ({Model}): {Response}", targetModel, responseContent);
                return "No response could be generated.";
            }

            var parts = candidates[0]?["content"]?["parts"]?.AsArray();
            var text = parts is not null
                ? string.Join("", parts.Select(p => p?["text"]?.GetValue<string>() ?? ""))
                : null;

            if (string.IsNullOrWhiteSpace(text))
            {
                _logger.LogWarning("No candidate text found in Gemini response ({Model}): {Response}", targetModel, responseContent);
                return "No response could be generated.";
            }

            return text;
        }

        throw new HttpRequestException($"Gemini API call to {targetModel} exceeded maximum retry attempts.");
    }
}
