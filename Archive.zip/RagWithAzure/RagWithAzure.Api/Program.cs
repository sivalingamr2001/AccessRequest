using RagWithAzure.Api;
using RagWithAzure.Api.Services;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add OpenAPI documentation
builder.Services.AddOpenApi();

// Enable CORS for UI integration
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Register Document Store (Local files now; swap with Azure Blob / S3 / GCS bucket later)
builder.Services.AddSingleton<IDocumentStore, LocalFileDocumentStore>();

// Register PostgreSQL Database Service for live Gate Entry queries
builder.Services.AddSingleton<IGateDatabaseService, GateDatabaseService>();

// Register Gemini Chat Service via typed HttpClient
builder.Services.AddHttpClient<IGeminiChatService, GeminiChatService>();

// Register RAG Service orchestrator
builder.Services.AddScoped<RagService>();

var app = builder.Build();

app.UseCors();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference(options =>
    {
        options
            .WithTitle("RAG API Documentation")
            .WithTheme(ScalarTheme.Moon)
            .WithDefaultHttpClient(ScalarTarget.CSharp, ScalarClient.HttpClient);
    });

    // Conveniently redirect root URL to Scalar documentation
    app.MapGet("/", () => Results.Redirect("/scalar/v1")).ExcludeFromDescription();
}

app.UseHttpsRedirection();

// Available models endpoint
app.MapGet("/models", () =>
{
    var models = new[]
    {
        new
        {
            id = "gemini-3.5-flash-lite",
            name = "Gemini 3.5 Flash-Lite",
            tag = "Low Token",
            description = "Ultra-fast response with lowest token consumption and high cost efficiency.",
            isDefault = true
        },
        new
        {
            id = "gemini-3.1-flash-lite",
            name = "Gemini 3.1 Flash-Lite",
            tag = "Low Token Preview",
            description = "Experimental lightweight model optimized for low resource usage.",
            isDefault = false
        },
        new
        {
            id = "gemini-flash-latest",
            name = "Gemini Flash Latest",
            tag = "Balanced",
            description = "Standard Gemini flash model balancing speed and reasoning depth.",
            isDefault = false
        },
        new
        {
            id = "gemini-2.5-pro",
            name = "Gemini 2.5 Pro",
            tag = "Deep Reasoning",
            description = "Best for intricate, highly complex coding or multi-step analysis.",
            isDefault = false
        }
    };
    return Results.Ok(models);
})
.WithName("GetAvailableModels")
.WithSummary("Lists available Gemini AI models with token efficiency details");

// Ask endpoint supporting optional model parameter
app.MapGet("/ask", async (string question, string? model, RagService ragService, CancellationToken ct) =>
{
    if (string.IsNullOrWhiteSpace(question))
    {
        return Results.BadRequest(new { error = "Question query parameter cannot be empty." });
    }

    var response = await ragService.AskAsync(question, model, ct);
    return Results.Ok(response);
})
.WithName("AskQuestion")
.WithSummary("Ask a question answered from local documents via Gemini AI")
.WithDescription("Retrieves relevant markdown documents from the Docs folder and generates an answer using Google Gemini.")
.Produces<string>(StatusCodes.Status200OK)
.ProducesProblem(StatusCodes.Status400BadRequest);

app.Run();
