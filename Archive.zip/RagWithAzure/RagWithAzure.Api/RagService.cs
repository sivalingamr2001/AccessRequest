using System.Text.RegularExpressions;
using RagWithAzure.Api.Services;

namespace RagWithAzure.Api;

public class RagService
{
    private readonly IDocumentStore _documentStore;
    private readonly IGateDatabaseService _gateDbService;
    private readonly IGeminiChatService _geminiChatService;
    private readonly ILogger<RagService> _logger;

    public RagService(
        IDocumentStore documentStore,
        IGateDatabaseService gateDbService,
        IGeminiChatService geminiChatService,
        ILogger<RagService> logger)
    {
        _documentStore = documentStore;
        _gateDbService = gateDbService;
        _geminiChatService = geminiChatService;
        _logger = logger;
    }

    public async Task<string> AskAsync(string userMessage, string? model = null, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Processing question: {Question} with model: {Model}", userMessage, model ?? "default");

        var contextBlocks = new List<string>();

        // 1. Try Live Database Lookup if Gate Number is mentioned
        var gateNo = ExtractGateNumber(userMessage);
        if (gateNo.HasValue && _gateDbService.IsConfigured)
        {
            _logger.LogInformation("Extracted gate number {GateNo}. Querying PostgreSQL database...", gateNo.Value);
            var dbResult = await _gateDbService.GetGateDetailsAsync(gateNo.Value, cancellationToken);
            if (dbResult != null)
            {
                if (dbResult.Found && dbResult.Header != null)
                {
                    var h = dbResult.Header;
                    var dcDateStr = h.Dc_Date.HasValue ? h.Dc_Date.Value.ToString("yyyy-MM-dd") : "Not recorded";
                    var receiptDateStr = h.Receipt_Date.HasValue ? h.Receipt_Date.Value.ToString("yyyy-MM-dd HH:mm") : "None";
                    var blockersStr = dbResult.ValidationBlockers.Count > 0 
                        ? string.Join(", ", dbResult.ValidationBlockers) 
                        : "None (All validation checks passed)";

                    var linesSummary = dbResult.Lines.Count > 0
                        ? string.Join("\n", dbResult.Lines.Select(l => 
                            $"  - Line {l.Line_No}: Item {l.Item}, PO {l.Pono}, PO Qty {l.Poqty}, Challan Qty {l.Supdcqty}, Counted {l.Counted_Qty ?? 0}, Accepted {l.Accepted_Qty ?? 0}, Status {l.Counting_Status ?? "Not Counted"}"))
                        : "No line items registered.";

                    var dbContext = 
                        $"### LIVE DATABASE QUERY RESULT FOR GATE {h.Gate_No}:\n" +
                        $"- Gate Number: {h.Gate_No}\n" +
                        $"- Supplier Name: {h.Supplier_Name}\n" +
                        $"- Delivery Challan (DC) No: {h.Dc_No}\n" +
                        $"- DC Date: {dcDateStr}\n" +
                        $"- Vehicle Number: {h.Vehicle_Det ?? "Not specified"}\n" +
                        $"- Receiving Unit: {h.Unit}\n" +
                        $"- Gate Status: {h.Gate_Status}\n" +
                        $"- Total Line Items: {h.Line_Count}\n" +
                        $"- Counted Line Items: {h.Counted_Lines}\n" +
                        $"- Actual Operational Stage: {h.Actual_Stage_Status}\n" +
                        $"- Validation Blockers Count: {h.Blocking_Rules}\n" +
                        $"- Active Validation Blockers: {blockersStr}\n" +
                        $"- Receipt Count: {h.Receipt_Count}\n" +
                        $"- Receipt Number: {h.Receipt_Num ?? "Not created"}\n" +
                        $"- Receipt Date: {receiptDateStr}\n" +
                        $"- Gate Lines & Inward Counting:\n{linesSummary}";

                    contextBlocks.Add(dbContext);
                    _logger.LogInformation("Successfully retrieved live PostgreSQL data for Gate {GateNo}", h.Gate_No);
                }
                else
                {
                    contextBlocks.Add($"### LIVE DATABASE QUERY RESULT: Gate Number {gateNo.Value} does not exist in the live database.");
                }
            }
        }
        else if (_gateDbService.IsConfigured)
        {
            // Check for aggregate/statistical intent (e.g. how many gates in NOT VALIDATED status)
            var intentData = await _gateDbService.TryExecuteIntentQueryAsync(userMessage, cancellationToken);
            if (!string.IsNullOrWhiteSpace(intentData))
            {
                contextBlocks.Add($"### LIVE DATABASE AGGREGATE STATS:\n{intentData}");
            }
        }

        // 2. Retrieve relevant reference documents (rules, workflows, catalogs)
        var relevantDocuments = await _documentStore.FindRelevantDocumentsAsync(userMessage, topN: 3, cancellationToken);
        if (relevantDocuments.Count > 0)
        {
            foreach (var doc in relevantDocuments)
            {
                contextBlocks.Add($"### Reference Rule Document: {doc.Title}\n{doc.Content}");
            }
        }

        var fullContext = contextBlocks.Count > 0
            ? string.Join("\n\n---\n\n", contextBlocks)
            : "No specific local documents or database records found for this query.";

        var systemInstruction = 
            "You are a specialized Gate Entry AI Assistant connected to a live PostgreSQL enterprise database.\n\n" +
            "CRITICAL MANDATORY RULES:\n" +
            "1. NEVER RETURN ANY DATABASE TABLE NAMES OR SQL CODE IN YOUR RESPONSE:\n" +
            "   - Under NO circumstances should you output internal database table names (such as JAN_GATE_HEADER, JAN_GATE_LINES, JAN_RECEIPT_PENDING, RCV_SHIPMENT_HEADERS, JAN_PUR_LISTING, po_headers, po_lines, po_line_locations, gate_counting, etc.).\n" +
            "   - Do NOT output SQL queries, SQL code blocks (```sql), or database column names.\n" +
            "   - Use ONLY clean business terms: 'Gate Register', 'Gate Header Details', 'Line Items', 'Material Counting', 'Validation Queue', 'Receipt History', 'Purchase Order'.\n\n" +
            "2. LIVE DATABASE DATA GROUNDING:\n" +
            "   - When live database query results are provided in the context for a gate number, you MUST use the exact live data values (exact Gate Number, Supplier Name, DC No, DC Date, Vehicle No, Unit, Stage Status, Counts, Blockers, Receipt No).\n" +
            "   - Format the gate details cleanly into structured business sections:\n" +
            "     * **Gate Number**\n" +
            "     * **Status & Stage** (e.g., Counting Pending, Validation Failed, Ready for Receipt, Validated, Blocked)\n" +
            "     * **Gate Details**: Supplier Name, Delivery Challan (DC) No, DC Date, Vehicle No, Unit\n" +
            "     * **Line Items & Quantities**: Total lines, Counted lines, Accepted/Rejected quantities\n" +
            "     * **Validation Status & Blockers**: If blockers exist, list the business reasons clearly. If none, state 'All validation checks passed'.\n" +
            "     * **Receipt Status**: Receipt number or 'Pending creation'\n" +
            "     * **Next Action**: Recommended next step based on the actual stage status.\n\n" +
            "3. OFF-TOPIC REFUSAL (STRICT DOMAIN GUARDRAIL):\n" +
            "   - If the user asks ANY question not related to Gate Entry, Material Inward, Counting, Validation, or Receipt workflows (such as general knowledge, coding, weather, entertainment, non-gate topics, etc.), you MUST decline to answer and reply with this exact guidance:\n" +
            "\"I am a specialized Gate Entry AI Assistant. I can only assist with questions related to Gate Entry, Gate Register, Material Counting, Validation Rules, and Receipt workflows. Please ask a gate entry related question.\"\n\n" +
            "4. STYLE & TONE: Crisp, professional, factual, and strictly focused on business data without technical database schema jargon.";

        var prompt = $"Context Data & Documents:\n{fullContext}\n\nUser Question:\n{userMessage}";

        return await _geminiChatService.GenerateAnswerAsync(prompt, systemInstruction, model, cancellationToken);
    }

    private static long? ExtractGateNumber(string query)
    {
        // Matches "gate 81", "gate no 81", "gate #81", "gate number 81", "gate: 81"
        var match = Regex.Match(query, @"\bgate\s*(?:no\.?|number|#)?\s*[:#-]?\s*(\d+)\b", RegexOptions.IgnoreCase);
        if (match.Success && long.TryParse(match.Groups[1].Value, out var num))
        {
            return num;
        }

        // Matches standalone 2 to 7 digit numbers if query mentions gate
        if (query.Contains("gate", StringComparison.OrdinalIgnoreCase))
        {
            var numMatch = Regex.Match(query, @"\b(\d{1,7})\b");
            if (numMatch.Success && long.TryParse(numMatch.Groups[1].Value, out var n))
            {
                return n;
            }
        }

        return null;
    }
}