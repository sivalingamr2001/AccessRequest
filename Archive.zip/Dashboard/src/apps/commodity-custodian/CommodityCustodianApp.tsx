import { lazy, Suspense } from "react"
import { Route, Routes, Navigate } from "react-router-dom"
import { CommodityProvider } from "./context/CommodityProvider"
import { TooltipProvider } from "@/components/ui/tooltip"
import { Loader } from "@/components/Loader"
import { Toaster } from "sonner"

const AppLayout = lazy(() =>
  import("./layout/AppLayout").then((m) => ({ default: m.AppLayout }))
)
const DashboardPage = lazy(() =>
  import("./pages/DashboardPage").then((m) => ({ default: m.DashboardPage }))
)

export function CommodityCustodianApp() {
  return (
    <TooltipProvider>
      <CommodityProvider>
        <Toaster position="top-right" richColors />
        <Suspense fallback={<Loader />}>
          <Routes>
            <Route path="dashboard" element={<AppLayout />}>
              <Route index element={<DashboardPage />} />
            </Route>
            <Route path="" element={<Navigate to="dashboard" replace />} />
          </Routes>
        </Suspense>
      </CommodityProvider>
    </TooltipProvider>
  )
}

export default CommodityCustodianApp
