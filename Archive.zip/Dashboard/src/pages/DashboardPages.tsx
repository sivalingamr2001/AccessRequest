import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Calendar,
  ChartColumn,
  CheckCircle,
  Clock,
  Factory,
  FileText,
  Info,
  Shield,
  ShoppingCart,
  Star,
  Wallet,
  X,
  Zap,
  CircleAlert,
} from 'lucide-react';

const modules = [
  { name: 'Admin', description: 'System administration & configuration', color: '#6366f1', icon: Shield },
  { name: 'PES', description: 'Planning Execution System', color: '#1a5fd6', icon: Zap },
  { name: 'PES Lite', description: 'Simplified planning execution', color: '#0ea5e9', icon: Zap },
  { name: 'DMS', description: 'Dealer Management System', color: '#10b981', icon: FileText },
  { name: 'SCM', description: 'Supply Chain Management', color: '#f59e0b', icon: ShoppingCart },
  { name: 'PMS', description: 'Performance Monitoring System', color: '#ec4899', icon: ChartColumn },
  { name: 'MES', description: 'Manufacturing Execution System', color: '#8b5cf6', icon: Factory },
  { name: 'Finance', description: 'Financial Accounting & Reporting', color: '#0d9488', icon: Wallet },
];

const activities = [
  { title: 'Production Order #PO-2241 created', user: 'John M.', module: 'PES', time: '5m ago', color: '#1a5fd6' },
  { title: 'Document REV-112 approved and published', user: 'Sara K.', module: 'DMS', time: '23m ago', color: '#10b981' },
  { title: 'Purchase Order #SCM-904 submitted', user: 'Raj P.', module: 'SCM', time: '1h ago', color: '#f59e0b' },
  { title: 'New user account activated: m.chen@acme.com', user: 'Admin', module: 'Admin', time: '2h ago', color: '#6366f1' },
  { title: 'MES Work Center WC-07 maintenance completed', user: 'Tech Team', module: 'MES', time: '3h ago', color: '#8b5cf6' },
];

const newsItems = [
  {
    category: 'news',
    label: 'System Update',
    title: 'Platform v4.2.1 Released',
    body: 'New performance improvements and bug fixes across PES and MES modules. Downtime scheduled Sunday 02:00-04:00 UTC.',
    time: '2 hours ago',
    color: '#10b981',
    icon: CheckCircle,
  },
  {
    category: 'events',
    label: 'Upcoming Event',
    title: 'Q3 Production Review - Board Meeting',
    body: 'All department heads are required to submit KPI reports by Friday. Review session at Conference Room A.',
    time: 'Tomorrow, 10:00 AM',
    color: '#1a5fd6',
    icon: Calendar,
  },
  {
    category: 'alert',
    label: 'Alert',
    title: 'SCM: Low Stock Threshold Reached',
    body: 'Item #SKU-4421 (Bearing Assembly) has dropped below minimum stock level. Reorder recommended.',
    time: '4 hours ago',
    color: '#f59e0b',
    icon: CircleAlert,
  },
  {
    category: 'news',
    label: 'Announcement',
    title: 'New Supplier Onboarded - TechParts Asia',
    body: 'TechParts Asia Pte Ltd has been approved and activated in the vendor master. SCM team to configure payment terms.',
    time: 'Yesterday',
    color: '#6366f1',
    icon: Star,
  },
  {
    category: 'events',
    label: 'Training',
    title: 'MES Operator Training - Batch 3',
    body: 'Scheduled for next Monday 09:00-17:00. 24 operators enrolled. Venue: Training Center Block B.',
    time: 'Aug 5, 2026',
    color: '#ec4899',
    icon: Info,
  },
  {
    category: 'alert',
    label: 'Compliance',
    title: 'ISO 9001:2015 Audit Scheduled',
    body: 'External audit team visits Aug 12-14. All departments to ensure documentation is current in DMS.',
    time: 'Aug 12-14, 2026',
    color: '#8b5cf6',
    icon: Shield,
  },
];

const quickStats = [
  { id: 'work-orders', value: '37', label: 'Open Work Orders', note: '4 critical', color: '#f59e0b', icon: FileText },
  { id: 'approvals', value: '12', label: 'Approvals Pending', note: '3 overdue', color: '#ec4899', icon: FileText },
  { id: 'health', value: '99.9%', label: 'System Health', note: 'All green', color: '#10b981', icon: CheckCircle },
];

export const DashboardPages = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [newsFilter, setNewsFilter] = useState('all');
  const [selectedNews, setSelectedNews] = useState<typeof newsItems[0] | null>(null);
  const [selectedStat, setSelectedStat] = useState<string | null>(null);

  const query = searchParams.get('q') || '';
  const activeModule = 'PES Lite';
  const activePlanner = 'Branch Planner';
  const activeUtility = 'Dashboard';

  const activeModuleData = modules.find((module) => module.name === activeModule) ?? modules[2];

  const visibleModules = useMemo(() => {
    const loweredQuery = query.trim().toLowerCase();
    if (!loweredQuery) return modules;

    return modules.filter((module) =>
      `${module.name} ${module.description}`.toLowerCase().includes(loweredQuery),
    );
  }, [query]);

  const filteredNews = useMemo(() => {
    if (newsFilter === 'all') return newsItems;
    return newsItems.filter((item) => item.category === newsFilter);
  }, [newsFilter]);

  const clearSelections = () => {
    setSearchParams({});
    setNewsFilter('all');
    setSelectedNews(null);
    setSelectedStat(null);
  };

  return (
    <div className="h-full w-full overflow-y-auto bg-slate-100 font-sans text-slate-800">
      <div className="mx-auto max-w-screen-xl p-4 xl:p-5">
        <div className="mb-3 flex items-start justify-between gap-4">
          <div>
            <h1 className="text-base font-bold text-slate-800">{activeModuleData.name}</h1>
            <p className="text-xs text-slate-400">
              {activeUtility} / {activePlanner} / {activeModuleData.description}
            </p>
          </div>
          <button
            type="button"
            onClick={clearSelections}
            className="flex items-center gap-1 rounded-md px-2.5 py-1 text-xs text-slate-500 transition-colors hover:bg-slate-200"
          >
            <X size={12} />
            Clear
          </button>
        </div>

        <div className="mb-4 grid grid-cols-1 gap-2.5 sm:grid-cols-3">
          {quickStats.map(({ id, value, label, note, color, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setSelectedStat(id)}
              className={`flex items-center gap-2.5 rounded-lg border bg-white px-3 py-2.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-md ${
                selectedStat === id ? 'border-blue-500 ring-2 ring-blue-100' : 'border-slate-200'
              }`}
            >
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md" style={{ background: `${color}12` }}>
                <Icon size={15} style={{ color }} />
              </span>
              <span>
                <span className="block text-base font-bold leading-none text-slate-800">{value}</span>
                <span className="mt-0.5 block text-xs text-slate-400">{label}</span>
                <span className="mt-0.5 block text-xs font-medium" style={{ color }}>
                  {note}
                </span>
              </span>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          <section className="xl:col-span-2">
            <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-bold text-slate-700">Your Modules</h2>
                  <p className="mt-0.5 text-xs text-slate-400">Manage operations for each functional module</p>
                </div>
                <span className="rounded-md bg-slate-100 px-2 py-0.5 text-xs font-medium text-blue-600">
                  {visibleModules.length} available
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
                {visibleModules.map(({ name, description, color, icon: Icon }) => {
                  const isActive = activeModule === name;

                  return (
                    <button
                      key={name}
                      type="button"
                      className={`flex min-h-28 flex-col items-start rounded-lg border p-3 text-left transition-all duration-150 hover:-translate-y-0.5 hover:shadow-md ${
                        isActive ? 'border-sky-500 bg-sky-500 shadow-sky-200' : 'border-slate-200 bg-white'
                      }`}
                    >
                      <span
                        className="mb-2 flex h-8 w-8 items-center justify-center rounded-md"
                        style={{ background: isActive ? 'rgba(255,255,255,0.2)' : `${color}15` }}
                      >
                        <Icon size={16} style={{ color: isActive ? '#fff' : color }} />
                      </span>
                      <span className={`text-sm font-semibold ${isActive ? 'text-white' : 'text-slate-900'}`}>{name}</span>
                      <span className={`mt-0.5 text-xs leading-snug ${isActive ? 'text-white/80' : 'text-blue-900/60'}`}>
                        {description}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-4 rounded-lg border border-slate-200 bg-white p-4">
              <h2 className="mb-2 text-sm font-bold text-slate-700">Recent Activity</h2>
              <div className="flex flex-col gap-1">
                {activities.map((activity) => (
                  <div
                    key={activity.title}
                    className="flex items-start gap-2.5 rounded-md px-1 py-1.5 text-left transition-colors hover:bg-slate-50"
                  >
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: activity.color }} />
                    <span className="min-w-0 flex-1">
                      <span className="text-xs text-slate-600">{activity.title}</span>
                      <span className="text-xs text-slate-400"> - {activity.user}</span>
                    </span>
                    <span className="flex shrink-0 items-center gap-2">
                      <span className="rounded px-1.5 py-0.5 text-xs font-medium" style={{ background: `${activity.color}15`, color: activity.color }}>
                        {activity.module}
                      </span>
                      <span className="text-xs text-slate-400">{activity.time}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="xl:col-span-1">
            <div className="flex max-h-[620px] flex-col rounded-lg border border-slate-200 bg-white p-4">
              <div className="mb-2.5 flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-bold text-slate-700">News & Events</h2>
                  <p className="mt-0.5 text-xs text-slate-400">Latest updates & announcements</p>
                </div>
                <button
                  type="button"
                  onClick={() => setNewsFilter('all')}
                  className="text-xs font-medium text-blue-500 hover:underline"
                >
                  View all
                </button>
              </div>

              <div className="mb-3 flex gap-1">
                {['all', 'news', 'events', 'alert'].map((filter) => (
                  <button
                    key={filter}
                    type="button"
                    onClick={() => setNewsFilter(filter)}
                    className={`rounded-md px-2 py-1 text-xs font-medium capitalize transition-all ${
                      newsFilter === filter ? 'bg-blue-700 text-white' : 'text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>

              <div className="flex flex-1 flex-col gap-2 overflow-y-auto pr-1">
                {filteredNews.map((item) => {
                  const Icon = item.icon;

                  return (
                    <button
                      key={item.title}
                      type="button"
                      onClick={() => setSelectedNews(item)}
                      className="flex gap-2.5 rounded-lg border border-slate-200 bg-slate-50 p-2.5 text-left transition-all hover:border-blue-200 hover:bg-white hover:shadow-sm"
                    >
                      <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-md" style={{ background: `${item.color}15` }}>
                        <Icon size={14} style={{ color: item.color }} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="mb-0.5 inline-flex rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: `${item.color}15`, color: item.color }}>
                          {item.label}
                        </span>
                        <span className="mb-1 block text-xs font-semibold leading-snug text-slate-700">{item.title}</span>
                        <span className="block text-xs leading-relaxed text-slate-500">{item.body}</span>
                        <span className="mt-1.5 flex items-center gap-1">
                          <Clock size={10} className="text-slate-400" />
                          <span className="text-xs text-slate-400">{item.time}</span>
                        </span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </section>
        </div>
      </div>

      {selectedNews && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-xl">
            <div className="mb-3 flex items-start justify-between gap-4">
              <div>
                <span className="rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: `${selectedNews.color}15`, color: selectedNews.color }}>
                  {selectedNews.label}
                </span>
                <h3 className="mt-2 text-base font-bold text-slate-800">{selectedNews.title}</h3>
              </div>
              <button
                type="button"
                aria-label="Close news detail"
                onClick={() => setSelectedNews(null)}
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X size={16} />
              </button>
            </div>
            <p className="text-sm leading-6 text-slate-600">{selectedNews.body}</p>
            <div className="mt-4 flex items-center gap-1 text-xs text-slate-400">
              <Clock size={12} />
              {selectedNews.time}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DashboardPages;
