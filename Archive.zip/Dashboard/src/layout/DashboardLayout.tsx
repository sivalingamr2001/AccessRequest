import React, { useMemo, useState } from 'react';
import { Outlet, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import {
  Bell,
  Calendar,
  ChevronDown,
  Clock,
  Factory,
  Home,
  Menu,
  Search,
  Settings,
  Star,
  X,
  CircleAlert,
  ChartColumn,
} from 'lucide-react';

const planningLinks = [
  'Branch Planner',
  'HO Planner',
  'Product Custodian',
  'Commodity Custodian',
  'Vendor Planner',
];

const utilityLinks = [
  { label: 'Dashboard', icon: Home },
  { label: 'Analytics', icon: ChartColumn },
  { label: 'Preferences', icon: Settings },
];

const newsItems = [
  {
    category: 'news',
    label: 'System Update',
    title: 'Platform v4.2.1 Released',
    body: 'New performance improvements and bug fixes across PES and MES modules. Downtime scheduled Sunday 02:00-04:00 UTC.',
    time: '2 hours ago',
    color: '#10b981',
    icon: CheckCircle,
  },
  {
    category: 'events',
    label: 'Upcoming Event',
    title: 'Q3 Production Review - Board Meeting',
    body: 'All department heads are required to submit KPI reports by Friday. Review session at Conference Room A.',
    time: 'Tomorrow, 10:00 AM',
    color: '#1a5fd6',
    icon: Calendar,
  },
  {
    category: 'alert',
    label: 'Alert',
    title: 'SCM: Low Stock Threshold Reached',
    body: 'Item #SKU-4421 (Bearing Assembly) has dropped below minimum stock level. Reorder recommended.',
    time: '4 hours ago',
    color: '#f59e0b',
    icon: CircleAlert,
  },
  {
    category: 'news',
    label: 'Announcement',
    title: 'New Supplier Onboarded - TechParts Asia',
    body: 'TechParts Asia Pte Ltd has been approved and activated in the vendor master. SCM team to configure payment terms.',
    time: 'Yesterday',
    color: '#6366f1',
    icon: Star,
  },
];

// Helper icon mapping if check circle is needed
function CheckCircle(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <path d="m9 11 3 3L22 4" />
    </svg>
  );
}

export const DashboardLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [selectedNews, setSelectedNews] = useState<typeof newsItems[0] | null>(null);

  const query = searchParams.get('q') || '';

  // Derive active menu items from routing pathname
  const activePlanner = useMemo(() => {
    if (location.pathname.startsWith('/product-custodian')) return 'Product Custodian';
    if (location.pathname.startsWith('/commodity-custodian')) return 'Commodity Custodian';
    return '';
  }, [location.pathname]);

  const activeUtility = useMemo(() => {
    if (location.pathname === '/' || location.pathname === '') return 'Dashboard';
    if (location.pathname.startsWith('/analytics')) return 'Analytics';
    if (location.pathname.startsWith('/preferences')) return 'Preferences';
    return '';
  }, [location.pathname]);

  const activeModule = useMemo(() => {
    if (activePlanner) {
      return 'PES Lite';
    }
    return 'PES Lite'; // Default
  }, [activePlanner]);

  const handlePlannerClick = (link: string) => {
    if (link === 'Product Custodian') {
      navigate('/product-custodian');
    } else if (link === 'Commodity Custodian') {
      navigate('/commodity-custodian');
    } else {
      // Other links could map to default layouts
      console.log(`Link clicked: ${link}`);
    }
  };

  const handleUtilityClick = (label: string) => {
    if (label === 'Dashboard') {
      navigate('/');
    } else {
      console.log(`Utility clicked: ${label}`);
    }
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const val = event.target.value;
    if (location.pathname !== '/') {
      // If we are on a sub-app page and search, go back to the home page with the search query active
      navigate(`/?q=${encodeURIComponent(val)}`);
    } else {
      setSearchParams(val ? { q: val } : {});
    }
  };

  return (
    <div className="flex h-screen w-full flex-col bg-slate-100 font-sans text-slate-800">
      {/* Global Portal Header */}
      <header className="z-30 flex h-12 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-4 shadow-sm">
        <div className="flex items-center gap-2">
          <button
            type="button"
            aria-label="Toggle navigation"
            onClick={() => setSidebarOpen((isOpen) => !isOpen)}
            className="flex h-7 w-7 items-center justify-center rounded-md transition-colors hover:bg-slate-100"
          >
            <Menu size={15} className="text-slate-500" />
          </button>

          <button
            type="button"
            onClick={() => navigate('/')}
            className="flex items-center gap-2 rounded-md text-left"
          >
            <span className="flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-blue-700 to-sky-500">
              <Factory size={15} className="text-white" />
            </span>
            <span className="hidden sm:block">
              <span className="text-[13px] font-bold text-blue-700">JANATICS</span>
              <span className="ml-1 text-xs font-normal text-slate-400">Unified Suite</span>
              <span className="ml-3 hidden text-xs text-slate-400 md:inline">Thursday, August 13, 2026</span>
            </span>
          </button>
        </div>

        {/* Global Search Bar */}
        <div className="hidden max-w-sm flex-1 md:mx-5 md:flex">
          <label className="relative w-full">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              placeholder="Search modules, documents, reports..."
              value={query}
              onChange={handleSearchChange}
              className="w-full rounded-md border border-slate-200 bg-slate-100 py-1 pl-8 pr-3 text-xs text-slate-800 outline-none transition-all focus:border-blue-500 focus:bg-white"
            />
          </label>
        </div>

        <div className="flex items-center gap-1.5">
          <div className="relative">
            <button
              type="button"
              aria-label="Open notifications"
              onClick={() => setShowNotifications((isOpen) => !isOpen)}
              className="relative flex h-7 w-7 items-center justify-center rounded-md transition-colors hover:bg-slate-100"
            >
              <Bell size={15} className="text-slate-500" />
              <span className="absolute right-0.5 top-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-red-600 text-[8px] font-bold text-white">
                4
              </span>
            </button>
            {showNotifications && (
              <div className="absolute right-0 top-9 z-40 w-72 rounded-lg border border-slate-200 bg-white p-2 shadow-lg">
                <div className="mb-2 text-xs font-bold text-slate-700">Notifications</div>
                {newsItems.map((item) => (
                  <button
                    key={item.title}
                    type="button"
                    onClick={() => {
                      setSelectedNews(item);
                      setShowNotifications(false);
                    }}
                    className="block w-full rounded-md px-2 py-1.5 text-left text-xs text-slate-600 hover:bg-slate-100"
                  >
                    <span className="font-semibold text-slate-700">{item.label}</span>
                    <span className="block truncate">{item.title}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="mx-1 h-5 w-px bg-slate-200" />

          <div className="relative">
            <button
              type="button"
              onClick={() => setShowUserMenu((isOpen) => !isOpen)}
              className="flex items-center gap-2 rounded-md px-2 py-1 transition-all hover:bg-slate-100"
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-blue-700 to-sky-500 text-xs font-semibold text-white">
                A
              </span>
              <span className="hidden text-left sm:block">
                <span className="block text-xs font-semibold leading-tight text-slate-700">Administrator</span>
                <span className="block text-xs text-slate-400">admin@janatics.com</span>
              </span>
              <ChevronDown
                size={13}
                className={`text-slate-400 transition-transform ${showUserMenu ? 'rotate-180' : ''}`}
              />
            </button>
            {showUserMenu && (
              <div className="absolute right-0 top-9 z-40 w-48 rounded-lg border border-slate-200 bg-white p-1.5 shadow-lg">
                {['Profile', 'Account settings', 'Sign out'].map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => {
                      setShowUserMenu(false);
                      if (item === 'Sign out') {
                        navigate('/login');
                      }
                    }}
                    className="block w-full rounded-md px-2.5 py-1.5 text-left text-xs text-slate-600 hover:bg-slate-100"
                  >
                    {item}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Framework Body */}
      <div className="flex flex-1 overflow-hidden">
        {/* Portal Sidebar */}
        <aside
          className={`flex shrink-0 flex-col overflow-hidden bg-[#0f2a52] transition-all duration-300 ${
            sidebarOpen ? 'w-52 border-r border-white/10' : 'w-0 border-r-0'
          }`}
        >
          <div className="flex h-full min-w-52 flex-col">
            <div className="border-b border-white/10 px-3 py-3">
              <div className="text-[11px] font-semibold uppercase tracking-widest text-blue-300">Navigation</div>
              <div className="mt-1.5 flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-sky-500" />
                <span className="text-[13px] font-semibold text-slate-100">{activeModule}</span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-2 py-2">
              {planningLinks.map((link) => (
                <button
                  key={link}
                  type="button"
                  onClick={() => handlePlannerClick(link)}
                  className={`flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs font-medium transition-all ${
                    activePlanner === link ? 'bg-white/10 text-white' : 'text-blue-100 hover:bg-white/5'
                  }`}
                >
                  <span className="flex h-3 w-3 shrink-0 items-center justify-center">
                    <span className={`h-1.5 w-1.5 rounded-full ${activePlanner === link ? 'bg-sky-400' : 'bg-blue-300'}`} />
                  </span>
                  <span className="truncate">{link}</span>
                </button>
              ))}
            </div>

            <div className="border-t border-white/10 px-2 py-2">
              {utilityLinks.map(({ label, icon: Icon }) => (
                <button
                  key={label}
                  type="button"
                  onClick={() => handleUtilityClick(label)}
                  className={`flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs transition-all ${
                    activeUtility === label ? 'bg-white/10 text-white' : 'text-blue-200 hover:bg-white/5'
                  }`}
                >
                  <Icon size={13} />
                  {label}
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Unified Application View Panel */}
        <main className="flex-1 overflow-hidden bg-slate-100">
          <Outlet />
        </main>
      </div>

      {/* Global Detail Modal */}
      {selectedNews && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-xl">
            <div className="mb-3 flex items-start justify-between gap-4">
              <div>
                <span className="rounded px-1.5 py-0.5 text-xs font-semibold" style={{ background: `${selectedNews.color}15`, color: selectedNews.color }}>
                  {selectedNews.label}
                </span>
                <h3 className="mt-2 text-base font-bold text-slate-800">{selectedNews.title}</h3>
              </div>
              <button
                type="button"
                aria-label="Close news detail"
                onClick={() => setSelectedNews(null)}
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X size={16} />
              </button>
            </div>
            <p className="text-sm leading-6 text-slate-600">{selectedNews.body}</p>
            <div className="mt-4 flex items-center gap-1 text-xs text-slate-400">
              <Clock size={12} />
              {selectedNews.time}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DashboardLayout;
