import { lazy, Suspense } from "react"
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom"
import { Loader } from "./components/Loader"

const LoginPage = lazy(() => import("./pages/LoginPage"))
const DashboardLayout = lazy(() =>
  import("./layout/DashboardLayout").then((m) => ({ default: m.DashboardLayout }))
)
const MainDashboard = lazy(() => import("./pages/DashboardPages"))

// Sub-applications
const ProductCustodianApp = lazy(() =>
  import("./apps/product-custodian/ProductCustodianApp")
)
const CommodityCustodianApp = lazy(() =>
  import("./apps/commodity-custodian/CommodityCustodianApp")
)

export function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<Loader />}>
        <Routes>
          {/* Authenticated Portal Shell */}
          <Route path="/" element={<DashboardLayout />}>
            <Route index element={<MainDashboard />} />
            
            {/* Lazy-loaded nested custodian applications */}
            <Route path="product-custodian/*" element={<ProductCustodianApp />} />
            <Route path="commodity-custodian/*" element={<CommodityCustodianApp />} />
            
            {/* Fallback to unified dashboard */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>

          <Route path="/login" element={<LoginPage />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  )
}

export default App
