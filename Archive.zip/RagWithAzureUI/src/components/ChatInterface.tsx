import * as React from "react"
import {
  AlertCircle,
  Bot,
  Check,
  ChevronDown,
  Copy,
  FileText,
  Moon,
  Send,
  Sparkles,
  Square,
  Sun,
  Trash2,
  User,
  Zap,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { MarkdownContent } from "@/components/MarkdownContent"
import {
  askQuestion,
  checkBackendHealth,
  fetchAvailableModels,
  FALLBACK_MODELS,
  type ModelOption,
} from "@/lib/api"

export interface ChatMessage {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  model?: string
  isError?: boolean
}

const SUGGESTED_PROMPTS = [
  {
    title: "Gate Entry Workflow",
    query: "What is the complete Gate Entry workflow from register to receipt?",
    icon: Sparkles,
  },
  {
    title: "Validation Rules & Blockers",
    query: "What validation rules and blockers can prevent a gate pass from being received?",
    icon: FileText,
  },
  {
    title: "Counting & Inward Rules",
    query: "How does the counting stage work and which source tables are involved?",
    icon: FileText,
  },
]

export function ChatInterface() {
  const [messages, setMessages] = React.useState<ChatMessage[]>([])
  const [input, setInput] = React.useState("")
  const [isLoading, setIsLoading] = React.useState(false)
  const [backendOnline, setBackendOnline] = React.useState<boolean | null>(null)
  const [copiedId, setCopiedId] = React.useState<string | null>(null)
  const [isDark, setIsDark] = React.useState(false)

  // Models state
  const [models, setModels] = React.useState<ModelOption[]>(FALLBACK_MODELS)
  const [selectedModel, setSelectedModel] = React.useState<string>("gemini-3.5-flash-lite")
  const [isModelMenuOpen, setIsModelMenuOpen] = React.useState(false)

  const messagesEndRef = React.useRef<HTMLDivElement>(null)
  const textareaRef = React.useRef<HTMLTextAreaElement>(null)
  const abortControllerRef = React.useRef<AbortController | null>(null)
  const modelMenuRef = React.useRef<HTMLDivElement>(null)

  // Initialize theme & load saved model
  React.useEffect(() => {
    const isDarkMode =
      localStorage.getItem("theme") === "dark" ||
      (!("theme" in localStorage) && window.matchMedia("(prefers-color-scheme: dark)").matches)
    setIsDark(isDarkMode)
    if (isDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }

    const savedModel = localStorage.getItem("rag_model")
    if (savedModel) {
      setSelectedModel(savedModel)
    }

    // Load available models from backend
    fetchAvailableModels().then((data) => {
      setModels(data)
      // If no saved model, default to the one marked isDefault or first one
      if (!savedModel) {
        const def = data.find((m) => m.isDefault) || data[0]
        if (def) setSelectedModel(def.id)
      }
    })
  }, [])

  // Close model menu when clicking outside
  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (modelMenuRef.current && !modelMenuRef.current.contains(event.target as Node)) {
        setIsModelMenuOpen(false)
      }
    }
    if (isModelMenuOpen) {
      document.addEventListener("mousedown", handleClickOutside)
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isModelMenuOpen])

  const toggleTheme = () => {
    const newDark = !isDark
    setIsDark(newDark)
    if (newDark) {
      document.documentElement.classList.add("dark")
      localStorage.setItem("theme", "dark")
    } else {
      document.documentElement.classList.remove("dark")
      localStorage.setItem("theme", "light")
    }
  }

  const handleSelectModel = (modelId: string) => {
    setSelectedModel(modelId)
    localStorage.setItem("rag_model", modelId)
    setIsModelMenuOpen(false)
  }

  // Periodic health check
  React.useEffect(() => {
    let mounted = true
    const checkHealth = async () => {
      const isUp = await checkBackendHealth()
      if (mounted) setBackendOnline(isUp)
    }

    checkHealth()
    const interval = setInterval(checkHealth, 15000)
    return () => {
      mounted = false
      clearInterval(interval)
    }
  }, [])

  // Auto scroll to bottom
  const scrollToBottom = React.useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [])

  React.useEffect(() => {
    scrollToBottom()
  }, [messages, isLoading, scrollToBottom])

  // Resize textarea automatically
  React.useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto"
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 180)}px`
    }
  }, [input])

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend ?? input).trim()
    if (!query || isLoading) return

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: query,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    const controller = new AbortController()
    abortControllerRef.current = controller

    try {
      const answer = await askQuestion(query, selectedModel, controller.signal)
      const currentModelObj = models.find((m) => m.id === selectedModel)
      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: "assistant",
        content: answer,
        timestamp: new Date(),
        model: currentModelObj?.name || selectedModel,
      }
      setMessages((prev) => [...prev, assistantMessage])
      setBackendOnline(true)
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === "AbortError") {
        setMessages((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            role: "assistant",
            content: "Request cancelled by user.",
            timestamp: new Date(),
            isError: true,
          },
        ])
      } else {
        const errorMsg =
          err instanceof Error
            ? err.message
            : "Failed to communicate with RAG API service. Please verify the backend is running."
        setMessages((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            role: "assistant",
            content: errorMsg,
            timestamp: new Date(),
            isError: true,
          },
        ])
        setBackendOnline(false)
      }
    } finally {
      setIsLoading(false)
      abortControllerRef.current = null
      setTimeout(() => textareaRef.current?.focus(), 50)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleStop = () => {
    abortControllerRef.current?.abort()
  }

  const handleClear = () => {
    if (isLoading) handleStop()
    setMessages([])
  }

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  const currentModel = models.find((m) => m.id === selectedModel) || models[0]

  return (
    <div className="flex h-screen w-full flex-col bg-background text-foreground antialiased">
      {/* Top Header */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-background px-4 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex size-8 items-center justify-center rounded-md border border-border bg-muted/60 text-foreground">
            <Bot className="size-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-semibold tracking-tight text-foreground">Gate Entry AI Assistant</h1>
              <span className="rounded-md border border-border bg-muted/50 px-1.5 py-0.2 text-[10px] font-mono text-muted-foreground">
                Gate Register & Validation
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              {backendOnline === true ? (
                <>
                  <span className="size-1.5 rounded-full bg-emerald-500 shrink-0" />
                  <span className="text-[11px]">Backend API connected</span>
                </>
              ) : backendOnline === false ? (
                <>
                  <span className="size-1.5 rounded-full bg-red-500 shrink-0" />
                  <span className="text-[11px] text-red-500">API offline (localhost:5062)</span>
                </>
              ) : (
                <>
                  <span className="size-1.5 rounded-full bg-amber-500 shrink-0" />
                  <span className="text-[11px]">Checking API status...</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Header Right: Model Switcher + Actions */}
        <div className="flex items-center gap-2">
          {/* Model Switcher Dropdown */}
          <div className="relative" ref={modelMenuRef}>
            <button
              type="button"
              onClick={() => setIsModelMenuOpen((prev) => !prev)}
              className="flex h-8 items-center gap-1.5 rounded-md border border-border bg-card px-2.5 text-xs font-medium text-foreground hover:bg-muted/50 transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              title="Select AI Model"
            >
              <Zap className="size-3 text-amber-500 shrink-0" />
              <span className="max-w-[130px] sm:max-w-[160px] truncate">{currentModel.name}</span>
              <span className="hidden md:inline rounded border border-border bg-muted px-1 py-0.2 text-[9px] font-mono text-muted-foreground">
                {currentModel.tag}
              </span>
              <ChevronDown className={`size-3 text-muted-foreground transition-transform ${isModelMenuOpen ? "rotate-180" : ""}`} />
            </button>

            {/* Model Dropdown Menu (Flat, crisp, no shadow, no glass) */}
            {isModelMenuOpen && (
              <div className="absolute right-0 top-full mt-1.5 z-50 w-72 sm:w-80 rounded-lg border border-border bg-card p-1.5 text-foreground">
                <div className="px-2 py-1.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider border-b border-border mb-1">
                  Select AI Model
                </div>
                <div className="space-y-1">
                  {models.map((m) => {
                    const isSelected = m.id === selectedModel
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => handleSelectModel(m.id)}
                        className={`w-full flex items-start gap-2.5 rounded-md p-2 text-left transition-colors ${
                          isSelected
                            ? "bg-muted text-foreground border border-border"
                            : "hover:bg-muted/40 text-foreground/80 border border-transparent"
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <span className="text-xs font-medium truncate">{m.name}</span>
                            <span className="rounded border border-border bg-background px-1 py-0.2 text-[9px] font-mono text-muted-foreground shrink-0">
                              {m.tag}
                            </span>
                          </div>
                          <p className="text-[11px] text-muted-foreground leading-snug line-clamp-2">
                            {m.description}
                          </p>
                        </div>
                        {isSelected && <Check className="size-3.5 text-foreground shrink-0 mt-0.5" />}
                      </button>
                    )
                  })}
                </div>
                <div className="mt-2 pt-1.5 border-t border-border px-2 text-[10px] text-muted-foreground">
                  ⚡ <strong>Flash-Lite</strong> models minimize token usage and latency.
                </div>
              </div>
            )}
          </div>

          {messages.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleClear}
              className="h-8 gap-1.5 text-xs text-muted-foreground hover:text-foreground border-border bg-background"
            >
              <Trash2 className="size-3.5" />
              <span className="hidden sm:inline">Clear</span>
            </Button>
          )}

          <Button
            variant="outline"
            size="icon"
            onClick={toggleTheme}
            className="size-8 border-border bg-background text-muted-foreground hover:text-foreground"
            title={isDark ? "Switch to light mode" : "Switch to dark mode"}
          >
            {isDark ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </Button>
        </div>
      </header>

      {/* Main Chat Area */}
      <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto max-w-3xl space-y-6">
          {/* Empty State */}
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 sm:py-20 text-center">
              <div className="flex size-12 items-center justify-center rounded-xl border border-border bg-muted/40 text-foreground mb-4">
                <Sparkles className="size-6" />
              </div>
              <h2 className="text-lg font-semibold tracking-tight text-foreground">
                Gate Entry AI Assistant
              </h2>
              <p className="mt-1 max-w-md text-sm text-muted-foreground">
                Specialized in Gate Register, Counting, Validation Rules, Blockers, and Receipt workflows.
                Ask any question related to Gate Entry or material inward.
              </p>

              {/* Quick suggestions */}
              <div className="mt-8 grid w-full max-w-2xl gap-2.5 sm:grid-cols-3 text-left">
                {SUGGESTED_PROMPTS.map((prompt, i) => {
                  const Icon = prompt.icon
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleSend(prompt.query)}
                      className="group flex flex-col justify-between rounded-lg border border-border bg-card p-3.5 text-left transition-colors hover:border-foreground/30 hover:bg-muted/30 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    >
                      <div className="flex items-center gap-2 mb-2 text-foreground font-medium text-xs">
                        <Icon className="size-3.5 text-muted-foreground group-hover:text-foreground transition-colors" />
                        <span>{prompt.title}</span>
                      </div>
                      <p className="text-[12px] text-muted-foreground leading-normal line-clamp-2">
                        {prompt.query}
                      </p>
                    </button>
                  )
                })}
              </div>
            </div>
          ) : (
            // Message List
            messages.map((message) => {
              const isUser = message.role === "user"
              return (
                <div
                  key={message.id}
                  className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}
                >
                  {!isUser && (
                    <div className="flex size-7 shrink-0 select-none items-center justify-center rounded-md border border-border bg-muted/60 text-foreground mt-0.5">
                      <Bot className="size-3.5" />
                    </div>
                  )}

                  <div
                    className={`group relative flex flex-col ${
                      isUser ? "items-end max-w-[85%]" : "items-start max-w-[90%]"
                    }`}
                  >
                    <div
                      className={`rounded-xl px-4 py-3 text-sm leading-relaxed border ${
                        isUser
                          ? "bg-foreground text-background border-foreground font-medium"
                          : message.isError
                          ? "bg-destructive/10 text-destructive border-destructive/30"
                          : "bg-muted/40 text-foreground border-border"
                      }`}
                    >
                      {message.isError && (
                        <div className="flex items-center gap-1.5 text-xs font-semibold mb-1 text-destructive">
                          <AlertCircle className="size-3.5" />
                          <span>Error</span>
                        </div>
                      )}
                      {isUser ? (
                        <p className="whitespace-pre-wrap">{message.content}</p>
                      ) : (
                        <MarkdownContent content={message.content} />
                      )}
                    </div>

                    {/* Metadata & Actions */}
                    <div
                      className={`mt-1 flex items-center gap-2 px-1 text-[11px] text-muted-foreground ${
                        isUser ? "justify-end" : "justify-start"
                      }`}
                    >
                      <span>
                        {message.timestamp.toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>

                      {!isUser && message.model && (
                        <span className="rounded border border-border bg-muted/40 px-1 py-0.2 text-[9px] font-mono">
                          {message.model}
                        </span>
                      )}

                      {!isUser && !message.isError && (
                        <button
                          type="button"
                          onClick={() => handleCopy(message.id, message.content)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity hover:text-foreground flex items-center gap-1 text-[11px]"
                          title="Copy response"
                        >
                          {copiedId === message.id ? (
                            <>
                              <Check className="size-3 text-emerald-500" />
                              <span className="text-emerald-500">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="size-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>

                  {isUser && (
                    <div className="flex size-7 shrink-0 select-none items-center justify-center rounded-md border border-border bg-foreground text-background mt-0.5">
                      <User className="size-3.5" />
                    </div>
                  )}
                </div>
              )
            })
          )}

          {/* Loading Indicator */}
          {isLoading && (
            <div className="flex gap-3 justify-start items-start">
              <div className="flex size-7 shrink-0 select-none items-center justify-center rounded-md border border-border bg-muted/60 text-foreground mt-0.5">
                <Bot className="size-3.5" />
              </div>
              <div className="rounded-xl border border-border bg-muted/40 px-4 py-3 text-sm text-foreground flex items-center gap-3">
                <div className="flex items-center gap-1">
                  <span className="size-1.5 rounded-full bg-foreground/60 animate-bounce [animation-delay:-0.3s]" />
                  <span className="size-1.5 rounded-full bg-foreground/60 animate-bounce [animation-delay:-0.15s]" />
                  <span className="size-1.5 rounded-full bg-foreground/60 animate-bounce" />
                </div>
                <span className="text-xs text-muted-foreground">
                  Searching docs & generating with {currentModel.name}...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer className="border-t border-border bg-background p-4 sm:px-6">
        <div className="mx-auto max-w-3xl">
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSend()
            }}
            className="relative flex flex-col rounded-xl border border-border bg-background focus-within:border-foreground/40 transition-colors"
          >
            <textarea
              ref={textareaRef}
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question about Gate Entry, counting, validation rules, or receipts... (Press Enter to send)"
              disabled={isLoading}
              className="w-full resize-none bg-transparent px-3.5 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none disabled:opacity-50 min-h-[44px] max-h-[180px]"
            />

            <div className="flex items-center justify-between border-t border-border/50 px-3 py-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-2">
                <span className="text-[11px]">
                  {backendOnline === false ? (
                    <span className="text-red-500 font-medium">Backend offline — make sure API is running</span>
                  ) : (
                    <span>Enter to send · Shift+Enter for new line</span>
                  )}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {isLoading ? (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleStop}
                    className="h-7 gap-1 px-2.5 text-xs border-border bg-background text-foreground hover:bg-muted"
                  >
                    <Square className="size-3 fill-current" />
                    <span>Stop</span>
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    size="sm"
                    disabled={!input.trim()}
                    className="h-7 gap-1 px-2.5 text-xs bg-foreground text-background hover:bg-foreground/90 disabled:opacity-30"
                  >
                    <span>Send</span>
                    <Send className="size-3" />
                  </Button>
                )}
              </div>
            </div>
          </form>

          <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground px-1">
            <span>
              Using model: <strong className="text-foreground font-mono">{currentModel.id}</strong> ({currentModel.tag})
            </span>
            <span>
              Scope: <span className="font-medium text-foreground">Gate Entry &amp; Inward Register</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  )
}
