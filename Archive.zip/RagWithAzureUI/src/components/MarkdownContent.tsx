import * as React from "react"
import { Copy, Check } from "lucide-react"

interface MarkdownContentProps {
  content: string
}

export function MarkdownContent({ content }: MarkdownContentProps) {
  // Simple, safe block parser for chat messages without heavy dependencies
  const blocks = React.useMemo(() => parseBlocks(content), [content])

  return (
    <div className="space-y-3 text-sm leading-relaxed break-words">
      {blocks.map((block, idx) => {
        if (block.type === "code") {
          return <CodeBlock key={idx} code={block.content} language={block.language} />
        }
        if (block.type === "heading") {
          const Tag = block.level === 1 ? "h1" : block.level === 2 ? "h2" : "h3"
          const headingStyles =
            block.level === 1
              ? "text-base font-semibold mt-4 mb-2 text-foreground"
              : block.level === 2
              ? "text-sm font-semibold mt-3 mb-1.5 text-foreground"
              : "text-xs font-semibold uppercase tracking-wider mt-2.5 mb-1 text-muted-foreground"
          return (
            <Tag key={idx} className={headingStyles}>
              <InlineText text={block.content} />
            </Tag>
          )
        }
        if (block.type === "list") {
          return (
            <ul key={idx} className="space-y-1.5 my-2 list-none pl-1">
              {block.items.map((item, itemIdx) => (
                <li key={itemIdx} className="flex items-start gap-2">
                  <span className="mt-1.5 size-1.5 rounded-full bg-foreground/60 shrink-0" />
                  <div className="flex-1">
                    <InlineText text={item} />
                  </div>
                </li>
              ))}
            </ul>
          )
        }
        if (block.type === "numbered-list") {
          return (
            <ol key={idx} className="space-y-1.5 my-2 list-none pl-1">
              {block.items.map((item, itemIdx) => (
                <li key={itemIdx} className="flex items-start gap-2">
                  <span className="text-xs font-mono font-medium text-muted-foreground shrink-0 w-4 text-right">
                    {itemIdx + 1}.
                  </span>
                  <div className="flex-1">
                    <InlineText text={item} />
                  </div>
                </li>
              ))}
            </ol>
          )
        }
        return (
          <p key={idx} className="text-foreground/90">
            <InlineText text={block.content} />
          </p>
        )
      })}
    </div>
  )
}

function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [copied, setCopied] = React.useState(false)

  const onCopy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="my-3 rounded-lg border border-border bg-muted/60 overflow-hidden">
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-border bg-muted/90 text-xs text-muted-foreground font-mono">
        <span>{language || "code"}</span>
        <button
          type="button"
          onClick={onCopy}
          className="flex items-center gap-1 text-xs hover:text-foreground transition-colors p-1 rounded hover:bg-background"
          title="Copy code"
        >
          {copied ? <Check className="size-3 text-green-500" /> : <Copy className="size-3" />}
          <span>{copied ? "Copied" : "Copy"}</span>
        </button>
      </div>
      <pre className="p-3 text-xs font-mono overflow-x-auto text-foreground">
        <code>{code}</code>
      </pre>
    </div>
  )
}

function InlineText({ text }: { text: string }) {
  // Parse inline elements: **bold**, `code`, *italic*
  const parts: React.ReactNode[] = []
  const regex = /(\*\*.*?\*\*|`.*?`|\*.*?\*)/g
  let lastIndex = 0
  let match: RegExpExecArray | null

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.slice(lastIndex, match.index))
    }
    const token = match[0]
    if (token.startsWith("**") && token.endsWith("**")) {
      parts.push(
        <strong key={match.index} className="font-semibold text-foreground">
          {token.slice(2, -2)}
        </strong>
      )
    } else if (token.startsWith("`") && token.endsWith("`")) {
      parts.push(
        <code
          key={match.index}
          className="px-1.5 py-0.5 rounded border border-border bg-muted font-mono text-[0.8em] text-foreground"
        >
          {token.slice(1, -1)}
        </code>
      )
    } else if (token.startsWith("*") && token.endsWith("*")) {
      parts.push(
        <em key={match.index} className="italic text-foreground">
          {token.slice(1, -1)}
        </em>
      )
    }
    lastIndex = regex.lastIndex
  }

  if (lastIndex < text.length) {
    parts.push(text.slice(lastIndex))
  }

  return <>{parts}</>
}

type ParsedBlock =
  | { type: "code"; content: string; language?: string }
  | { type: "heading"; content: string; level: number }
  | { type: "list"; items: string[] }
  | { type: "numbered-list"; items: string[] }
  | { type: "paragraph"; content: string }

function parseBlocks(markdown: string): ParsedBlock[] {
  const lines = markdown.replace(/\r\n/g, "\n").split("\n")
  const blocks: ParsedBlock[] = []
  let i = 0

  while (i < lines.length) {
    const line = lines[i]

    // Code block
    if (line.trim().startsWith("```")) {
      const language = line.trim().slice(3).trim()
      const codeLines: string[] = []
      i++
      while (i < lines.length && !lines[i].trim().startsWith("```")) {
        codeLines.push(lines[i])
        i++
      }
      blocks.push({
        type: "code",
        content: codeLines.join("\n"),
        language: language || undefined,
      })
      i++
      continue
    }

    // Headings
    if (line.startsWith("#")) {
      const match = line.match(/^(#{1,3})\s+(.*)$/)
      if (match) {
        blocks.push({
          type: "heading",
          level: match[1].length,
          content: match[2].trim(),
        })
        i++
        continue
      }
    }

    // Bullet lists
    if (/^\s*[-*]\s+/.test(line)) {
      const items: string[] = []
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*[-*]\s+/, "").trim())
        i++
      }
      blocks.push({ type: "list", items })
      continue
    }

    // Numbered lists
    if (/^\s*\d+\.\s+/.test(line)) {
      const items: string[] = []
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*\d+\.\s+/, "").trim())
        i++
      }
      blocks.push({ type: "numbered-list", items })
      continue
    }

    // Empty lines
    if (line.trim() === "") {
      i++
      continue
    }

    // Paragraph
    const paraLines: string[] = [line]
    i++
    while (
      i < lines.length &&
      lines[i].trim() !== "" &&
      !lines[i].trim().startsWith("```") &&
      !lines[i].startsWith("#") &&
      !/^\s*[-*]\s+/.test(lines[i]) &&
      !/^\s*\d+\.\s+/.test(lines[i])
    ) {
      paraLines.push(lines[i])
      i++
    }
    blocks.push({ type: "paragraph", content: paraLines.join(" ") })
  }

  return blocks
}
