const BACKEND_DIRECT_URL = "http://localhost:5062"

export interface ModelOption {
  id: string
  name: string
  tag: string
  description: string
  isDefault?: boolean
}

export const FALLBACK_MODELS: ModelOption[] = [
  {
    id: "gemini-3.5-flash-lite",
    name: "Gemini 3.5 Flash-Lite",
    tag: "Low Token / Fast",
    description: "Ultra-fast response with lowest token consumption and high cost efficiency.",
    isDefault: true,
  },
  {
    id: "gemini-3.1-flash-lite",
    name: "Gemini 3.1 Flash-Lite",
    tag: "Low Token Preview",
    description: "Lightweight experimental model optimized for low resource usage.",
    isDefault: false,
  },
  {
    id: "gemini-flash-latest",
    name: "Gemini Flash Latest",
    tag: "Balanced",
    description: "Standard Gemini flash model balancing speed and reasoning depth.",
    isDefault: false,
  },
  {
    id: "gemini-2.5-pro",
    name: "Gemini 2.5 Pro",
    tag: "Deep Reasoning",
    description: "Best for intricate, highly complex coding or multi-step analysis.",
    isDefault: false,
  },
]

export async function fetchAvailableModels(): Promise<ModelOption[]> {
  const urls = ["/api/models", `${BACKEND_DIRECT_URL}/models`]
  for (const url of urls) {
    try {
      const res = await fetch(url, {
        method: "GET",
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(3000),
      })
      if (res.ok) {
        const data = await res.json()
        if (Array.isArray(data) && data.length > 0) {
          return data
        }
      }
    } catch {
      // Continue to next URL attempt
    }
  }
  return FALLBACK_MODELS
}

export async function askQuestion(
  question: string,
  model?: string,
  signal?: AbortSignal
): Promise<string> {
  const trimmed = question.trim()
  if (!trimmed) {
    throw new Error("Question cannot be empty.")
  }

  const modelQuery = model ? `&model=${encodeURIComponent(model.trim())}` : ""

  // Try proxied endpoint first (/api/ask), fallback to direct backend URL
  const urlsToTry = [
    `/api/ask?question=${encodeURIComponent(trimmed)}${modelQuery}`,
    `${BACKEND_DIRECT_URL}/ask?question=${encodeURIComponent(trimmed)}${modelQuery}`,
  ]

  let lastError: Error | null = null

  for (const url of urlsToTry) {
    try {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        signal,
      })

      if (!response.ok) {
        const errorText = await response.text().catch(() => "")
        throw new Error(
          `Backend returned ${response.status}: ${errorText || response.statusText}`
        )
      }

      const contentType = response.headers.get("content-type") || ""
      if (contentType.includes("application/json")) {
        const data = await response.json()
        return typeof data === "string" ? data : JSON.stringify(data, null, 2)
      }

      return await response.text()
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === "AbortError") {
        throw err
      }
      lastError = err instanceof Error ? err : new Error(String(err))
      // Continue to next URL attempt
    }
  }

  throw (
    lastError ??
    new Error(
      "Could not connect to backend API. Please make sure the API is running at http://localhost:5062."
    )
  )
}

export async function checkBackendHealth(): Promise<boolean> {
  try {
    const res = await fetch("/api/openapi/v1.json", {
      method: "GET",
      signal: AbortSignal.timeout(2000),
    }).catch(() =>
      fetch(`${BACKEND_DIRECT_URL}/openapi/v1.json`, {
        method: "GET",
        signal: AbortSignal.timeout(2000),
      })
    )
    return res.ok
  } catch {
    return false
  }
}
