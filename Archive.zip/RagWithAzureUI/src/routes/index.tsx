import { createFileRoute } from "@tanstack/react-router"
import { ChatInterface } from "@/components/ChatInterface"

export const Route = createFileRoute("/")({
  component: ChatPage,
})

function ChatPage() {
  return <ChatInterface />
}
