import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { BarcodeView } from '@/features/gate'

interface BarcodeSearchParams {
  entry?: string
}

export const Route = createFileRoute('/_authenticated/barcode')({
  validateSearch: (search: Record<string, unknown>): BarcodeSearchParams => ({
    entry: typeof search.entry === 'string' ? search.entry : undefined,
  }),
  component: BarcodeRoute,
})

function BarcodeRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <BarcodeView />
      </Main>
    </>
  )
}
