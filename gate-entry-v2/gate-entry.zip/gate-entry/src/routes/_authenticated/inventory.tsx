import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { InventoryView } from '@/features/gate'

export const Route = createFileRoute('/_authenticated/inventory')({
  component: InventoryRoute,
})

function InventoryRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <InventoryView />
      </Main>
    </>
  )
}
