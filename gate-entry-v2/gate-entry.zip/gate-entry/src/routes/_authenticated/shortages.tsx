import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { ShortagesView } from '@/features/gate'

export const Route = createFileRoute('/_authenticated/shortages')({
  component: ShortagesRoute,
})

function ShortagesRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <ShortagesView />
      </Main>
    </>
  )
}
