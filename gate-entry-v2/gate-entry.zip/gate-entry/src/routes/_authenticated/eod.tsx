import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { EodView } from '@/features/gate'

export const Route = createFileRoute('/_authenticated/eod')({
  component: EodRoute,
})

function EodRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <EodView />
      </Main>
    </>
  )
}
