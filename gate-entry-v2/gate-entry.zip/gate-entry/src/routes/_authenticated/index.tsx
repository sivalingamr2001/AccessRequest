import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { DashboardView } from '@/features/gate'

export const Route = createFileRoute('/_authenticated/')({
  component: DashboardRoute,
})

function DashboardRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <DashboardView />
      </Main>
    </>
  )
}
