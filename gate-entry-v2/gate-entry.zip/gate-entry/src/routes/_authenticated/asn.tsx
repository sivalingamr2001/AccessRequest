import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { AsnView } from '@/features/gate'

export const Route = createFileRoute('/_authenticated/asn')({
  component: AsnRoute,
})

function AsnRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <AsnView />
      </Main>
    </>
  )
}
