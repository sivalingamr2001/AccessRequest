import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { ValidationView } from '@/features/gate'

interface ValidationSearchParams {
  entry?: string
}

export const Route = createFileRoute('/_authenticated/gate-validation')({
  validateSearch: (search: Record<string, unknown>): ValidationSearchParams => ({
    entry: typeof search.entry === 'string' ? search.entry : undefined,
  }),
  component: ValidationRoute,
})

function ValidationRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <ValidationView />
      </Main>
    </>
  )
}
