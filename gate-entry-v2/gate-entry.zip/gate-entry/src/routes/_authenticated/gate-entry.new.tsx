import { createFileRoute } from '@tanstack/react-router'
import { PortalHeader } from '@/components/layout/portal-header'
import { Main } from '@/layout/main'
import { NewEntryForm } from '@/features/gate'

export const Route = createFileRoute('/_authenticated/gate-entry/new')({
  component: NewEntryRoute,
})

function NewEntryRoute() {
  return (
    <>
      <PortalHeader />
      <Main>
        <NewEntryForm />
      </Main>
    </>
  )
}
