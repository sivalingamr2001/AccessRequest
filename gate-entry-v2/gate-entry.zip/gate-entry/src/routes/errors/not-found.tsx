import { createFileRoute } from '@tanstack/react-router'
import { NotFoundError } from '@/features/errors'

export const Route = createFileRoute('/errors/not-found')({
  component: NotFoundError,
})
