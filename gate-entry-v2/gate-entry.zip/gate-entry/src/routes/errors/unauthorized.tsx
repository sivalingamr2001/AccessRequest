import { createFileRoute } from '@tanstack/react-router'
import { UnauthorisedError } from '@/features/errors'

export const Route = createFileRoute('/errors/unauthorized')({
  component: UnauthorisedError,
})
