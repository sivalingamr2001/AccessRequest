import { createFileRoute } from '@tanstack/react-router'
import { ForbiddenError } from '@/features/errors'

export const Route = createFileRoute('/errors/forbidden')({
  component: ForbiddenError,
})
