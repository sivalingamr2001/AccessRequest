import { createFileRoute } from '@tanstack/react-router'
import { GeneralError } from '@/features/errors'

export const Route = createFileRoute('/errors/internal-server-error')({
  component: GeneralError,
})
