import { createFileRoute } from '@tanstack/react-router'
import { LoginView } from '@/features/gate'

export const Route = createFileRoute('/login')({
  component: LoginView,
})
