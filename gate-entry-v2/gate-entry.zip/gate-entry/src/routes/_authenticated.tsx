import { createFileRoute, Outlet } from '@tanstack/react-router'
import { AuthenticatedLayout } from '@/layout/authenticated-layout'
import { CommandMenu } from '@/components/command-menu'

export const Route = createFileRoute('/_authenticated')({
  component: AuthenticatedRouteComponent,
})

function AuthenticatedRouteComponent() {
  return (
    <AuthenticatedLayout>
      <CommandMenu />
      <Outlet />
    </AuthenticatedLayout>
  )
}
