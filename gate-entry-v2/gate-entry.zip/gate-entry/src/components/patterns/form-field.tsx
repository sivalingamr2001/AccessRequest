import * as React from 'react'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'

interface FormFieldWrapperProps {
  label: string
  htmlFor?: string
  error?: string | string[]
  hint?: string
  required?: boolean
  className?: string
  children: React.ReactNode
}

export function FormFieldWrapper({
  label,
  htmlFor,
  error,
  hint,
  required,
  className,
  children,
}: FormFieldWrapperProps) {
  const errorMessage = Array.isArray(error) ? error[0] : error

  return (
    <div className={cn('space-y-1.5', className)}>
      <Label htmlFor={htmlFor} className='text-xs font-medium text-foreground flex items-center gap-1'>
        {label}
        {required && <span className='text-destructive'>*</span>}
      </Label>
      {children}
      {hint && !errorMessage && (
        <p className='text-[11px] text-muted-foreground leading-normal'>{hint}</p>
      )}
      {errorMessage && (
        <p className='text-[11px] font-medium text-destructive leading-normal animate-in fade-in-50'>
          {errorMessage}
        </p>
      )}
    </div>
  )
}
