import * as React from 'react'
import { Badge } from '@/components/ui/badge'

interface PageHeaderProps {
  eyebrow?: string
  title: string
  description?: string
  badge?: string
  actions?: React.ReactNode
}

export function PageHeader({
  eyebrow,
  title,
  description,
  badge,
  actions,
}: PageHeaderProps) {
  return (
    <div className='flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-border/60'>
      <div className='space-y-1'>
        {eyebrow && (
          <p className='font-mono text-[11px] font-semibold tracking-wider uppercase text-primary'>
            {eyebrow}
          </p>
        )}
        <div className='flex items-center gap-3'>
          <h1 className='text-2xl font-bold tracking-tight text-foreground font-heading'>
            {title}
          </h1>
          {badge && (
            <Badge variant='outline' className='text-[10px] font-mono uppercase'>
              {badge}
            </Badge>
          )}
        </div>
        {description && (
          <p className='text-xs text-muted-foreground max-w-2xl leading-relaxed'>
            {description}
          </p>
        )}
      </div>
      {actions && <div className='flex items-center gap-2 shrink-0'>{actions}</div>}
    </div>
  )
}
