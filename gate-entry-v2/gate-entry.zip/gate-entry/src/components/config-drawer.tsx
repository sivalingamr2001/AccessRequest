import { RadioGroup as RadioGroupPrimitive } from 'radix-ui'
import {
  CircleCheck,
  RotateCcw,
  Palette,
  Sun,
  Moon,
  Laptop,
  PanelLeft,
  Columns2,
  PanelsTopLeft,
  LayoutGrid,
  Minimize2,
  Maximize2,
  Type,
  Check,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useLayout } from '@/context/layout-provider'
import type { Collapsible } from '@/context/layout-provider'
import {
  useTheme,
  type ThemeColor,
  type FontBody,
  type FontHeading,
} from '@/context/theme-provider'
import { Button } from '@/components/ui/button'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { useSidebar } from './ui/sidebar'

const Radio = RadioGroupPrimitive.Root
const Item = RadioGroupPrimitive.Item

const COLOR_OPTIONS: { name: ThemeColor; label: string; bgClass: string }[] = [
  { name: 'blue', label: 'Blue', bgClass: 'bg-blue-600' },
  { name: 'zinc', label: 'Zinc', bgClass: 'bg-zinc-800' },
  { name: 'slate', label: 'Slate', bgClass: 'bg-slate-700' },
  { name: 'violet', label: 'Violet', bgClass: 'bg-violet-600' },
  { name: 'green', label: 'Green', bgClass: 'bg-emerald-600' },
  { name: 'orange', label: 'Orange', bgClass: 'bg-orange-500' },
  { name: 'rose', label: 'Rose', bgClass: 'bg-rose-500' },
  { name: 'yellow', label: 'Yellow', bgClass: 'bg-amber-400' },
  { name: 'red', label: 'Red', bgClass: 'bg-red-600' },
]

const FONT_BODY_OPTIONS: { id: FontBody; label: string; sample: string }[] = [
  { id: 'figtree', label: 'Figtree (Default)', sample: 'Clean modern sans' },
  { id: 'inter', label: 'Inter', sample: 'Neutral enterprise typeface' },
  { id: 'jakarta', label: 'Plus Jakarta Sans', sample: 'Geometric precision' },
  { id: 'outfit', label: 'Outfit', sample: 'Modern display curves' },
  { id: 'roboto', label: 'Roboto', sample: 'Industrial readability' },
  { id: 'mono', label: 'JetBrains Mono', sample: 'Technical monospace' },
]

const FONT_HEADING_OPTIONS: { id: FontHeading; label: string }[] = [
  { id: 'mono', label: 'JetBrains Mono (Technical)' },
  { id: 'inter', label: 'Inter (Corporate)' },
  { id: 'figtree', label: 'Figtree (Modern)' },
  { id: 'jakarta', label: 'Plus Jakarta (Bold)' },
  { id: 'outfit', label: 'Outfit (Sleek)' },
  { id: 'roboto', label: 'Roboto (Standard)' },
]

export function ConfigDrawer() {
  const { setOpen } = useSidebar()
  const { resetAll } = useTheme()
  const { resetLayout } = useLayout()

  const handleReset = () => {
    setOpen(true)
    resetAll()
    resetLayout()
  }

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button
          size='icon'
          variant='ghost'
          aria-label='Open theme settings'
          className='rounded-full hover:bg-muted transition-colors'
        >
          <Palette className='size-4' aria-hidden='true' />
        </Button>
      </SheetTrigger>
      <SheetContent className='flex flex-col w-full sm:max-w-md overflow-hidden'>
        <SheetHeader className='pb-2 text-start border-b border-border/50'>
          <SheetTitle className='flex items-center gap-2 text-base font-bold'>
            <Palette className='size-5 text-primary' />
            Theme & Typography Settings
          </SheetTitle>
          <SheetDescription className='text-xs'>
            Customize theme colors, body typography, heading fonts, and portal layouts.
          </SheetDescription>
        </SheetHeader>

        <div className='flex-1 space-y-6 overflow-y-auto px-4 py-4'>
          {/* Primary Color Palette */}
          <ColorConfig />

          {/* Heading Font */}
          <HeadingFontConfig />

          {/* Body Font */}
          <BodyFontConfig />

          {/* Theme Mode */}
          <ThemeModeConfig />

          {/* Sidebar Style */}
          <SidebarConfig />

          {/* Layout Mode */}
          <LayoutConfig />
        </div>

        <SheetFooter className='gap-2 border-t border-border/50 pt-3'>
          <Button
            variant='outline'
            size='sm'
            onClick={handleReset}
            className='w-full text-xs font-semibold'
          >
            <RotateCcw className='size-3.5 me-1.5' />
            Reset to Default
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}

function SectionTitle({
  title,
  icon: Icon,
  showReset = false,
  onReset,
  resetAriaLabel,
}: {
  title: string
  icon?: LucideIcon
  showReset?: boolean
  onReset?: () => void
  resetAriaLabel?: string
}) {
  return (
    <div className='mb-2 flex items-center justify-between'>
      <div className='flex items-center gap-1.5'>
        {Icon && <Icon className='size-3.5 text-muted-foreground' />}
        <h4 className='text-xs font-bold uppercase tracking-wider text-muted-foreground'>
          {title}
        </h4>
      </div>
      {showReset && onReset && (
        <Button
          type='button'
          size='icon'
          variant='ghost'
          className='size-6 rounded-full'
          onClick={onReset}
          aria-label={resetAriaLabel}
        >
          <RotateCcw className='size-3' />
        </Button>
      )}
    </div>
  )
}

function ColorConfig() {
  const { color, setColor, defaultColor } = useTheme()

  return (
    <div>
      <SectionTitle
        title='Primary Accent Color'
        icon={Palette}
        showReset={color !== defaultColor}
        onReset={() => setColor(defaultColor)}
        resetAriaLabel='Reset color to default'
      />
      <div className='grid grid-cols-3 gap-2'>
        {COLOR_OPTIONS.map((item) => {
          const isActive = color === item.name
          return (
            <button
              key={item.name}
              type='button'
              onClick={() => setColor(item.name)}
              className={cn(
                'flex items-center gap-2 rounded-lg border p-2 text-xs font-medium transition-all text-start',
                isActive
                  ? 'border-primary bg-primary/10 text-foreground ring-1 ring-primary'
                  : 'border-border/70 hover:border-border hover:bg-muted/50 text-muted-foreground'
              )}
            >
              <span
                className={cn(
                  'flex size-4 shrink-0 items-center justify-center rounded-full text-white shadow-xs',
                  item.bgClass
                )}
              >
                {isActive && <Check className='size-2.5 stroke-[3]' />}
              </span>
              <span className='truncate'>{item.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function HeadingFontConfig() {
  const { fontHeading, setFontHeading, defaultFontHeading } = useTheme()

  return (
    <div>
      <SectionTitle
        title='Header & Title Font'
        icon={Type}
        showReset={fontHeading !== defaultFontHeading}
        onReset={() => setFontHeading(defaultFontHeading)}
        resetAriaLabel='Reset heading font to default'
      />
      <div className='grid grid-cols-2 gap-2'>
        {FONT_HEADING_OPTIONS.map((item) => {
          const isActive = fontHeading === item.id
          return (
            <button
              key={item.id}
              type='button'
              onClick={() => setFontHeading(item.id)}
              className={cn(
                'rounded-lg border px-3 py-2 text-xs text-start transition-all',
                isActive
                  ? 'border-primary bg-primary/10 font-bold text-primary ring-1 ring-primary'
                  : 'border-border/70 hover:bg-muted/50 text-muted-foreground'
              )}
            >
              <div className='flex items-center justify-between'>
                <span className='truncate font-medium'>{item.label}</span>
                {isActive && <Check className='size-3 text-primary shrink-0' />}
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function BodyFontConfig() {
  const { fontBody, setFontBody, defaultFontBody } = useTheme()

  return (
    <div>
      <SectionTitle
        title='Body & Text Font'
        icon={Type}
        showReset={fontBody !== defaultFontBody}
        onReset={() => setFontBody(defaultFontBody)}
        resetAriaLabel='Reset body font to default'
      />
      <div className='grid grid-cols-2 gap-2'>
        {FONT_BODY_OPTIONS.map((item) => {
          const isActive = fontBody === item.id
          return (
            <button
              key={item.id}
              type='button'
              onClick={() => setFontBody(item.id)}
              className={cn(
                'rounded-lg border px-3 py-2 text-xs text-start transition-all',
                isActive
                  ? 'border-primary bg-primary/10 font-semibold text-primary ring-1 ring-primary'
                  : 'border-border/70 hover:bg-muted/50 text-muted-foreground'
              )}
            >
              <div className='flex items-center justify-between'>
                <span className='font-medium'>{item.label}</span>
                {isActive && <Check className='size-3 text-primary shrink-0' />}
              </div>
              <span className='text-[10px] text-muted-foreground/80 block truncate mt-0.5'>
                {item.sample}
              </span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function ThemeModeConfig() {
  const { defaultTheme, theme, setTheme } = useTheme()

  return (
    <div>
      <SectionTitle
        title='Appearance'
        showReset={defaultTheme !== theme}
        onReset={() => setTheme(defaultTheme)}
        resetAriaLabel='Reset theme to default'
      />
      <Radio
        value={theme}
        onValueChange={setTheme}
        className='grid grid-cols-3 gap-2'
        aria-label='Select theme mode'
      >
        {[
          { value: 'system', label: 'System', icon: Laptop },
          { value: 'light', label: 'Light', icon: Sun },
          { value: 'dark', label: 'Dark', icon: Moon },
        ].map((item) => (
          <RadioCardItem key={item.value} item={item} />
        ))}
      </Radio>
    </div>
  )
}

function SidebarConfig() {
  const { defaultVariant, variant, setVariant } = useLayout()

  return (
    <div className='max-md:hidden'>
      <SectionTitle
        title='Sidebar Variant'
        showReset={defaultVariant !== variant}
        onReset={() => setVariant(defaultVariant)}
        resetAriaLabel='Reset sidebar style to default'
      />
      <Radio
        value={variant}
        onValueChange={(val) => setVariant(val as 'inset' | 'floating' | 'sidebar')}
        className='grid grid-cols-3 gap-2'
        aria-label='Select sidebar style'
      >
        {[
          { value: 'inset', label: 'Inset', icon: PanelLeft },
          { value: 'floating', label: 'Floating', icon: Columns2 },
          { value: 'sidebar', label: 'Sidebar', icon: PanelsTopLeft },
        ].map((item) => (
          <RadioCardItem key={item.value} item={item} />
        ))}
      </Radio>
    </div>
  )
}

function LayoutConfig() {
  const { open, setOpen } = useSidebar()
  const { defaultCollapsible, collapsible, setCollapsible } = useLayout()

  const radioState = open ? 'default' : collapsible

  return (
    <div className='max-md:hidden'>
      <SectionTitle
        title='Sidebar Behavior'
        showReset={radioState !== 'default'}
        onReset={() => {
          setOpen(true)
          setCollapsible(defaultCollapsible)
        }}
        resetAriaLabel='Reset layout options to default'
      />
      <Radio
        value={radioState}
        onValueChange={(v) => {
          if (v === 'default') {
            setOpen(true)
            return
          }
          setOpen(false)
          setCollapsible(v as Collapsible)
        }}
        className='grid grid-cols-3 gap-2'
        aria-label='Select layout style'
      >
        {[
          { value: 'default', label: 'Expanded', icon: LayoutGrid },
          { value: 'icon', label: 'Compact', icon: Minimize2 },
          { value: 'offcanvas', label: 'Full', icon: Maximize2 },
        ].map((item) => (
          <RadioCardItem key={item.value} item={item} />
        ))}
      </Radio>
    </div>
  )
}

function RadioCardItem({
  item,
}: {
  item: {
    value: string
    label: string
    icon: LucideIcon
  }
}) {
  return (
    <Item
      value={item.value}
      className={cn(
        'group flex flex-col items-center justify-between rounded-lg border border-border/70 p-2.5 text-xs transition-all outline-none',
        'hover:bg-muted/50 hover:border-border',
        'data-[state=checked]:border-primary data-[state=checked]:bg-primary/10 data-[state=checked]:text-primary data-[state=checked]:ring-1 data-[state=checked]:ring-primary'
      )}
      aria-label={item.label}
    >
      <item.icon className='size-5 mb-1.5 opacity-80 group-data-[state=checked]:opacity-100' />
      <span className='font-medium text-[11px]'>{item.label}</span>
      <CircleCheck className='mt-1 size-3.5 opacity-0 group-data-[state=checked]:opacity-100 text-primary' />
    </Item>
  )
}
