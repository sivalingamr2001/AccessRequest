import { LayoutGrid  } from 'lucide-react'
import type {LucideProps} from 'lucide-react';

export function IconLayoutDefault(props: LucideProps) {
  return <LayoutGrid {...props} />
}

export default IconLayoutDefault
