import { Minimize2  } from 'lucide-react'
import type {LucideProps} from 'lucide-react';

export function IconLayoutCompact(props: LucideProps) {
  return <Minimize2 {...props} />
}

export default IconLayoutCompact
