import { Maximize2  } from 'lucide-react'
import type {LucideProps} from 'lucide-react';

export function IconLayoutFull(props: LucideProps) {
  return <Maximize2 {...props} />
}

export default IconLayoutFull
