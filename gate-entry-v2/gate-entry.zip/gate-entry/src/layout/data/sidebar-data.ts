import {
  LayoutDashboard,
  PackagePlus,
  ClipboardCheck,
  ShieldAlert,
  ScanLine,
  Barcode,
  CalendarCheck,
  Boxes,
  Bot,
  AlertTriangle,
  Factory,
  Truck,
  Warehouse,
  Lock,
  UserX,
  FileX,
  ServerOff,
  Construction,
} from 'lucide-react'
import type {SidebarData} from '../types';

export const sidebarData: SidebarData = {
  user: {
    name: 'Gate Inward Officer',
    email: 'gate.officer@enterprise.com',
    avatar: '/avatars/shadcn.jpg',
  },
  teams: [
    {
      name: 'Unit 7 Factory (Org 444)',
      logo: Factory,
      plan: 'Main Manufacturing Gate',
    },
    {
      name: 'Automotive Division (Plant 1)',
      logo: Truck,
      plan: 'Commercial Vehicle Gate',
    },
    {
      name: 'Central Logistics Hub',
      logo: Warehouse,
      plan: 'Skyfast Inward Terminal',
    },
  ],
  navGroups: [
    {
      title: 'Overview',
      items: [
        {
          title: 'Gate Register',
          url: '/',
          icon: LayoutDashboard,
        },
      ],
    },
    {
      title: 'Gate Operations',
      items: [
        {
          title: 'Material Inward',
          url: '/gate-entry/new',
          icon: PackagePlus,
        },
        {
          title: 'Validation Desk',
          url: '/gate-validation',
          icon: ClipboardCheck,
        },
        {
          title: 'Job Shortages',
          url: '/shortages',
          icon: ShieldAlert,
        },
      ],
    },
    {
      title: 'Logistics & Tools',
      items: [
        {
          title: 'ASN Verification (ADI)',
          url: '/asn',
          icon: ScanLine,
        },
        {
          title: 'Barcode & Lot Printing',
          url: '/barcode',
          icon: Barcode,
        },
        {
          title: 'End of Day (EOD) Close',
          url: '/eod',
          icon: CalendarCheck,
        },
        {
          title: 'Min-Max Inventory',
          url: '/inventory',
          icon: Boxes,
        },
      ],
    },
    {
      title: 'AI & Diagnostics',
      items: [
        {
          title: 'GateFlow AI Assistant',
          url: '/chats',
          badge: 'AI',
          icon: Bot,
        },
        {
          title: 'System Errors',
          icon: AlertTriangle,
          items: [
            {
              title: 'Unauthorized (401)',
              url: '/errors/unauthorized',
              icon: Lock,
            },
            {
              title: 'Forbidden (403)',
              url: '/errors/forbidden',
              icon: UserX,
            },
            {
              title: 'Not Found (404)',
              url: '/errors/not-found',
              icon: FileX,
            },
            {
              title: 'Server Error (500)',
              url: '/errors/internal-server-error',
              icon: ServerOff,
            },
            {
              title: 'Maintenance (503)',
              url: '/errors/maintenance-error',
              icon: Construction,
            },
          ],
        },
      ],
    },
  ],
}
