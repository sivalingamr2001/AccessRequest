import { Link } from '@tanstack/react-router'
import { ShieldCheck } from 'lucide-react'
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar'

export function BrandHeader() {
  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <SidebarMenuButton
          size='lg'
          asChild
          className='data-[state=open]:bg-sidebar-accent data-[state=open]:text-sidebar-accent-foreground transition-colors'
        >
          <Link to='/' className='flex items-center gap-3'>
            <div className='flex aspect-square size-8 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-xs'>
              <ShieldCheck className='size-5' />
            </div>
            <div className='grid flex-1 text-start leading-tight'>
              <span className='truncate font-extrabold tracking-wider text-sm font-heading'>
                JANATICS
              </span>
              <span className='truncate text-[11px] font-medium text-muted-foreground'>
                Gate Keeper
              </span>
            </div>
          </Link>
        </SidebarMenuButton>
      </SidebarMenuItem>
    </SidebarMenu>
  )
}
