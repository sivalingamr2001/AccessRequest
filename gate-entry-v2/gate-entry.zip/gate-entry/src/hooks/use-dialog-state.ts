import { useState } from 'react'

export default function useDialogState(initialState = false) {
  return useState(initialState)
}

export { useDialogState }
