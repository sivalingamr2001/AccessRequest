import { toast } from 'sonner'

export function showSubmittedData(data: unknown, title = 'Submitted Data') {
  toast.success(title, {
    description: typeof data === 'string' ? data : JSON.stringify(data, null, 2),
  })
}
