import { describe, expect, it } from 'vitest'
import { cn, getDisplayNameInitials, formatTimestamp } from './utils'

describe('utils', () => {
  it('merges class names correctly', () => {
    expect(cn('px-2 py-1', 'bg-blue-500')).toContain('bg-blue-500')
    const dynamicClasses: (string | undefined)[] = ['px-2', 'text-sm', undefined]
    expect(cn(...dynamicClasses)).toBe('px-2 text-sm')
  })

  it('generates initials from display name', () => {
    expect(getDisplayNameInitials('John Doe')).toBe('JD')
    expect(getDisplayNameInitials('Single')).toBe('SI')
    expect(getDisplayNameInitials('')).toBe('GE')
  })

  it('formats timestamp safely', () => {
    const formatted = formatTimestamp('2026-09-30T10:00:00Z')
    expect(formatted).toBeDefined()
    expect(typeof formatted).toBe('string')
  })
})
