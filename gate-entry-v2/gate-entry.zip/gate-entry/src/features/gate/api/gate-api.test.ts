import { describe, expect, it } from 'vitest'
import { gateApi } from './gate-api'
import { GateEntrySchema } from '../types'

describe('gateApi', () => {
  it('fetches initial gate entries correctly', async () => {
    const entries = await gateApi.getGateEntries()
    expect(Array.isArray(entries)).toBe(true)
    expect(entries.length).toBeGreaterThan(0)
    
    // Verify first entry passes zod validation
    const parsed = GateEntrySchema.safeParse(entries[0])
    expect(parsed.success).toBe(true)
  })

  it('fetches job shortages', async () => {
    const shortages = await gateApi.getJobShortages()
    expect(Array.isArray(shortages)).toBe(true)
    expect(shortages.length).toBeGreaterThan(0)
  })

  it('fetches ASN notices', async () => {
    const asns = await gateApi.getAsnNotices()
    expect(Array.isArray(asns)).toBe(true)
    expect(asns.length).toBeGreaterThan(0)
  })

  it('fetches inventory locators', async () => {
    const inventory = await gateApi.getInventory()
    expect(Array.isArray(inventory)).toBe(true)
    expect(inventory.length).toBeGreaterThan(0)
  })
})
