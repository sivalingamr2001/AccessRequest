import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import type {GateEntry, CreateGateEntryInput, JobShortage, AsnNotice, InventoryLocator, EodCloseRecord} from '../types';

const GATE_ENTRIES_KEY = 'gateflow_entries_v2'
const SHORTAGES_KEY = 'gateflow_shortages_v2'
const ASN_KEY = 'gateflow_asn_v2'
const INVENTORY_KEY = 'gateflow_inventory_v2'
const EOD_KEY = 'gateflow_eod_v2'

// Initial realistic enterprise factory data
const INITIAL_ENTRIES: GateEntry[] = [
  {
    id: 'entry-1',
    gateNo: 'GE-20260930-7481',
    createdAt: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
    type: 'Purchase order',
    supplier: 'Apex Precision Castings Ltd',
    poNumber: 'PO-444-9921',
    dcNumber: 'DC-88291',
    dcDate: '2026-09-30',
    vehicle: 'TN 09 BX 4412',
    courier: 'Skyfast Logistics Express',
    boxes: 14,
    item: 'Cast Iron Clutch Housing Machined (Part #CI-882)',
    quantity: 280,
    weight: 1420.5,
    taxRate: 18,
    ewayBillNo: 'EWB-88192039128',
    status: 'Pending validation',
    reason: '',
    lotBarcode: 'LOT-20260930-001',
  },
  {
    id: 'entry-2',
    gateNo: 'GE-20260930-6192',
    createdAt: new Date(Date.now() - 1000 * 60 * 95).toISOString(),
    type: 'Purchase order',
    supplier: 'Bharat High-Tensile Fasteners',
    poNumber: 'PO-444-9905',
    dcNumber: 'DC-2026-0941',
    dcDate: '2026-09-30',
    vehicle: 'TN 22 CZ 7719',
    courier: 'VRL Surface Transport',
    boxes: 28,
    item: 'Grade 10.9 Flange Hex Bolts M12x1.75 (Part #FB-12-G10)',
    quantity: 12500,
    weight: 680.0,
    taxRate: 18,
    ewayBillNo: 'EWB-44182901923',
    status: 'Approved',
    reason: '',
    validatedAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    validatedBy: 'Supervisor UNIT7',
    lotBarcode: 'LOT-20260930-002',
  },
  {
    id: 'entry-3',
    gateNo: 'GE-20260930-5519',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    type: 'OSP challan',
    supplier: 'Modern Surface Electroplaters',
    poNumber: 'OSP-444-1240',
    dcNumber: 'DC-PLT-3321',
    dcDate: '2026-09-29',
    vehicle: 'TN 04 AD 9102',
    courier: 'Direct Vendor Van',
    boxes: 6,
    item: 'Zinc Nickel Plated Brake Actuator Arms (Batch 99)',
    quantity: 450,
    weight: 312.0,
    taxRate: 18,
    ewayBillNo: 'EWB-55910294102',
    status: 'On hold',
    reason: 'Challan missing mandatory chemical plating certificate and test heat barcode',
    validatedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    validatedBy: 'QA Inspector Skyfast',
    lotBarcode: 'LOT-20260930-003',
  },
  {
    id: 'entry-4',
    gateNo: 'GE-20260929-9182',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 25).toISOString(),
    type: 'Purchase order',
    supplier: 'Sundaram Sensor Systems',
    poNumber: 'PO-444-9887',
    dcNumber: 'SSS-CHN-771',
    dcDate: '2026-09-29',
    vehicle: 'KA 01 MJ 3301',
    courier: 'BlueDart Express Couriers',
    boxes: 4,
    item: 'Hall-Effect Gearbox Speed Sensors with O-Ring Seals',
    quantity: 600,
    weight: 48.5,
    taxRate: 18,
    ewayBillNo: 'EWB-99102938471',
    status: 'Approved',
    reason: '',
    validatedAt: new Date(Date.now() - 1000 * 60 * 60 * 22).toISOString(),
    validatedBy: 'Supervisor UNIT7',
    lotBarcode: 'LOT-20260929-004',
  },
  {
    id: 'entry-5',
    gateNo: 'GE-20260929-8831',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 28).toISOString(),
    type: 'Non-PO courier',
    supplier: 'Kavitha Bearings International',
    poNumber: '',
    dcNumber: 'SMP-1092',
    dcDate: '2026-09-28',
    vehicle: 'Courier Delivery Bike',
    courier: 'DTDC Couriers Ltd',
    boxes: 2,
    item: 'R&D Prototype Deep Groove Ceramic Ball Bearings 6205',
    quantity: 10,
    weight: 5.2,
    taxRate: 18,
    ewayBillNo: '',
    status: 'Approved',
    reason: '',
    validatedAt: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    validatedBy: 'Gate Officer',
    lotBarcode: 'LOT-20260929-005',
  },
]

const INITIAL_SHORTAGES: JobShortage[] = [
  {
    id: 'sh-1',
    itemCode: 'CI-882',
    itemName: 'Cast Iron Clutch Housing Machined',
    poNumber: 'PO-444-9921',
    supplier: 'Apex Precision Castings Ltd',
    shortageQty: 180,
    requiredByDate: '2026-10-01',
    productionLine: 'Line 2 - Powertrain Assembly',
    priority: 'CRITICAL',
    status: 'BLOCKED',
  },
  {
    id: 'sh-2',
    itemCode: 'FB-12-G10',
    itemName: 'Grade 10.9 Flange Hex Bolts M12x1.75',
    poNumber: 'PO-444-9905',
    supplier: 'Bharat High-Tensile Fasteners',
    shortageQty: 4200,
    requiredByDate: '2026-10-02',
    productionLine: 'Line 1 - Chassis Integration',
    priority: 'HIGH',
    status: 'RESOLVED',
  },
  {
    id: 'sh-3',
    itemCode: 'PLT-BA-99',
    itemName: 'Zinc Nickel Plated Brake Actuator Arms',
    poNumber: 'OSP-444-1240',
    supplier: 'Modern Surface Electroplaters',
    shortageQty: 250,
    requiredByDate: '2026-09-30',
    productionLine: 'Line 4 - Brake & Safety Systems',
    priority: 'CRITICAL',
    status: 'BLOCKED',
  },
  {
    id: 'sh-4',
    itemCode: 'SE-SN-41',
    itemName: 'Hall-Effect Gearbox Speed Sensors',
    poNumber: 'PO-444-9887',
    supplier: 'Sundaram Sensor Systems',
    shortageQty: 120,
    requiredByDate: '2026-10-04',
    productionLine: 'Line 3 - EV Subassembly',
    priority: 'MEDIUM',
    status: 'PENDING_DELIVERY',
  },
]

const INITIAL_ASN: AsnNotice[] = [
  {
    id: 'asn-1',
    asnNumber: 'ASN-SCM-2026-00481',
    supplier: 'Apex Precision Castings Ltd',
    poNumber: 'PO-444-9921',
    dispatchDate: '2026-09-29',
    etaDate: '2026-09-30',
    vehicleNo: 'TN 09 BX 4412',
    totalPackages: 14,
    itemCount: 280,
    declaredValue: 245000,
    status: 'VERIFIED',
    exemptionStatus: 'STANDARD',
  },
  {
    id: 'asn-2',
    asnNumber: 'ASN-SCM-2026-00482',
    supplier: 'Sundaram Sensor Systems',
    poNumber: 'PO-444-9887',
    dispatchDate: '2026-09-28',
    etaDate: '2026-09-29',
    vehicleNo: 'KA 01 MJ 3301',
    totalPackages: 4,
    itemCount: 600,
    declaredValue: 180000,
    status: 'VERIFIED',
    exemptionStatus: 'EXEMPT',
  },
  {
    id: 'asn-3',
    asnNumber: 'ASN-SCM-2026-00483',
    supplier: 'Precision Gaskets & O-Rings Co',
    poNumber: 'PO-444-9960',
    dispatchDate: '2026-09-30',
    etaDate: '2026-10-01',
    vehicleNo: 'TN 18 KK 8820',
    totalPackages: 8,
    itemCount: 1500,
    declaredValue: 62000,
    status: 'PENDING',
    exemptionStatus: 'STANDARD',
  },
]

const INITIAL_INVENTORY: InventoryLocator[] = [
  {
    id: 'inv-1',
    itemCode: 'CI-882',
    description: 'Cast Iron Clutch Housing Machined',
    locator: 'BAY-04-A-12',
    minQty: 200,
    maxQty: 800,
    onHandQty: 110,
    uom: 'NOS',
    status: 'CRITICAL',
    lastAuditDate: '2026-09-28',
  },
  {
    id: 'inv-2',
    itemCode: 'FB-12-G10',
    description: 'Grade 10.9 Flange Hex Bolts M12x1.75',
    locator: 'RACK-02-B-05',
    minQty: 5000,
    maxQty: 25000,
    onHandQty: 16800,
    uom: 'NOS',
    status: 'NORMAL',
    lastAuditDate: '2026-09-29',
  },
  {
    id: 'inv-3',
    itemCode: 'PLT-BA-99',
    description: 'Zinc Nickel Plated Brake Actuator Arms',
    locator: 'BAY-01-C-08',
    minQty: 300,
    maxQty: 1200,
    onHandQty: 195,
    uom: 'NOS',
    status: 'REPLENISH',
    lastAuditDate: '2026-09-30',
  },
  {
    id: 'inv-4',
    itemCode: 'SE-SN-41',
    description: 'Hall-Effect Gearbox Speed Sensors',
    locator: 'SEC-08-D-02',
    minQty: 150,
    maxQty: 900,
    onHandQty: 680,
    uom: 'NOS',
    status: 'NORMAL',
    lastAuditDate: '2026-09-27',
  },
]

// Helper storage functions
function getStorage<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback
  try {
    const item = localStorage.getItem(key)
    return item ? (JSON.parse(item) as T) : fallback
  } catch {
    return fallback
  }
}

function setStorage<T>(key: string, data: T): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(key, JSON.stringify(data))
  } catch {
    // ignore quota errors
  }
}

// Data access operations
export async function fetchGateEntries(): Promise<GateEntry[]> {
  await new Promise((resolve) => setTimeout(resolve, 120))
  let entries = getStorage<GateEntry[]>(GATE_ENTRIES_KEY, INITIAL_ENTRIES)
  if (entries.length === 0) {
    entries = INITIAL_ENTRIES
    setStorage(GATE_ENTRIES_KEY, entries)
  }
  return entries
}

export async function fetchGateEntry(id: string): Promise<GateEntry | undefined> {
  const entries = await fetchGateEntries()
  return entries.find((e) => e.id === id)
}

export async function createGateEntry(input: CreateGateEntryInput): Promise<GateEntry> {
  await new Promise((resolve) => setTimeout(resolve, 200))
  const entries = await fetchGateEntries()
  const now = new Date()
  const dateStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(
    now.getDate()
  ).padStart(2, '0')}`
  const randSeq = Math.floor(1000 + Math.random() * 9000)
  const lotNumber = `LOT-${dateStr}-${String(entries.length + 1).padStart(3, '0')}`

  const newEntry: GateEntry = {
    ...input,
    id: `entry-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    gateNo: `GE-${dateStr}-${randSeq}`,
    createdAt: now.toISOString(),
    status: 'Pending validation',
    reason: '',
    lotBarcode: lotNumber,
  }

  const updated = [newEntry, ...entries]
  setStorage(GATE_ENTRIES_KEY, updated)
  return newEntry
}

export async function validateGateEntry(
  id: string,
  status: 'Approved' | 'On hold',
  reason = ''
): Promise<GateEntry> {
  await new Promise((resolve) => setTimeout(resolve, 180))
  const entries = await fetchGateEntries()
  const target = entries.find((e) => e.id === id)
  if (!target) throw new Error('Gate entry not found')

  const updatedEntry: GateEntry = {
    ...target,
    status,
    reason: status === 'On hold' ? reason.trim() : '',
    validatedAt: new Date().toISOString(),
    validatedBy: 'Gate Supervisor (Active)',
  }

  const updated = entries.map((e) => (e.id === id ? updatedEntry : e))
  setStorage(GATE_ENTRIES_KEY, updated)
  return updatedEntry
}

export async function fetchJobShortages(): Promise<JobShortage[]> {
  await new Promise((resolve) => setTimeout(resolve, 100))
  let data = getStorage<JobShortage[]>(SHORTAGES_KEY, INITIAL_SHORTAGES)
  if (data.length === 0) {
    data = INITIAL_SHORTAGES
    setStorage(SHORTAGES_KEY, data)
  }
  return data
}

export async function fetchAsnNotices(): Promise<AsnNotice[]> {
  await new Promise((resolve) => setTimeout(resolve, 100))
  let data = getStorage<AsnNotice[]>(ASN_KEY, INITIAL_ASN)
  if (data.length === 0) {
    data = INITIAL_ASN
    setStorage(ASN_KEY, data)
  }
  return data
}

export async function fetchInventory(): Promise<InventoryLocator[]> {
  await new Promise((resolve) => setTimeout(resolve, 100))
  let data = getStorage<InventoryLocator[]>(INVENTORY_KEY, INITIAL_INVENTORY)
  if (data.length === 0) {
    data = INITIAL_INVENTORY
    setStorage(INVENTORY_KEY, data)
  }
  return data
}

export async function fetchEodSummary(): Promise<EodCloseRecord> {
  await new Promise((resolve) => setTimeout(resolve, 100))
  const entries = await fetchGateEntries()
  const todayStr = new Date().toDateString()
  const todayEntries = entries.filter(
    (e) => new Date(e.createdAt).toDateString() === todayStr
  )

  const savedEod = getStorage<EodCloseRecord | null>(EOD_KEY, null)
  if (savedEod && savedEod.date === todayStr) {
    return savedEod
  }

  return {
    date: todayStr,
    totalEntries: todayEntries.length,
    approvedCount: todayEntries.filter((e) => e.status === 'Approved').length,
    onHoldCount: todayEntries.filter((e) => e.status === 'On hold').length,
    pendingCount: todayEntries.filter((e) => e.status === 'Pending validation').length,
    status: 'OPEN',
    totalWeightKg: todayEntries.reduce((acc, curr) => acc + (curr.weight || 0), 0),
  }
}

export async function closeEodRegister(): Promise<EodCloseRecord> {
  await new Promise((resolve) => setTimeout(resolve, 200))
  const current = await fetchEodSummary()
  const closed: EodCloseRecord = {
    ...current,
    status: 'CLOSED',
    closedAt: new Date().toISOString(),
    closedBy: 'Officer UNIT7 (EOD Authorized)',
  }
  setStorage(EOD_KEY, closed)
  return closed
}

// React Query Hooks
export function useGateEntriesQuery() {
  return useQuery({
    queryKey: ['gateEntries'],
    queryFn: fetchGateEntries,
  })
}

export function useGateEntryQuery(id?: string) {
  return useQuery({
    queryKey: ['gateEntry', id],
    queryFn: () => (id ? fetchGateEntry(id) : Promise.resolve(undefined)),
    enabled: !!id,
  })
}

export function useCreateGateEntryMutation() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: (input: CreateGateEntryInput) => createGateEntry(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['gateEntries'] })
      queryClient.invalidateQueries({ queryKey: ['eodSummary'] })
    },
  })
}

export function useValidateGateEntryMutation() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: ({
      id,
      status,
      reason,
    }: {
      id: string
      status: 'Approved' | 'On hold'
      reason?: string
    }) => validateGateEntry(id, status, reason),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['gateEntries'] })
      queryClient.invalidateQueries({ queryKey: ['gateEntry', variables.id] })
      queryClient.invalidateQueries({ queryKey: ['eodSummary'] })
    },
  })
}

export function useJobShortagesQuery() {
  return useQuery({
    queryKey: ['jobShortages'],
    queryFn: fetchJobShortages,
  })
}

export function useAsnNoticesQuery() {
  return useQuery({
    queryKey: ['asnNotices'],
    queryFn: fetchAsnNotices,
  })
}

export function useInventoryQuery() {
  return useQuery({
    queryKey: ['inventoryLocators'],
    queryFn: fetchInventory,
  })
}

export function useEodSummaryQuery() {
  return useQuery({
    queryKey: ['eodSummary'],
    queryFn: fetchEodSummary,
  })
}

export function useCloseEodMutation() {
  const queryClient = useQueryClient()
  return useMutation({
    mutationFn: closeEodRegister,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['eodSummary'] })
    },
  })
}

export const gateApi = {
  getGateEntries: fetchGateEntries,
  getGateEntryById: fetchGateEntry,
  createGateEntry,
  validateGateEntry,
  getJobShortages: fetchJobShortages,
  getAsnNotices: fetchAsnNotices,
  getInventory: fetchInventory,
  getEodSummary: fetchEodSummary,
  closeEod: closeEodRegister,
}

