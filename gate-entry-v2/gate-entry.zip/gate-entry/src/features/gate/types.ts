import { z } from 'zod'

export const EntryStatusSchema = z.enum([
  'Pending validation',
  'Approved',
  'On hold',
])
export type EntryStatus = z.infer<typeof EntryStatusSchema>

export const EntryTypeSchema = z.enum([
  'Purchase order',
  'OSP challan',
  'Non-PO courier',
  'Direct delivery',
])
export type EntryType = z.infer<typeof EntryTypeSchema>

export const GateEntrySchema = z.object({
  id: z.string(),
  gateNo: z.string(),
  createdAt: z.string(),
  type: EntryTypeSchema,
  supplier: z.string().min(1, 'Supplier name is required'),
  poNumber: z.string().optional().default(''),
  dcNumber: z.string().min(1, 'DC Number is required'),
  dcDate: z.string().min(1, 'DC Date is required'),
  vehicle: z.string().optional().default(''),
  courier: z.string().optional().default(''),
  boxes: z.number().int().nonnegative().default(1),
  item: z.string().min(1, 'Material description is required'),
  quantity: z.number().positive('Quantity must be greater than 0'),
  weight: z.number().nonnegative().default(0),
  taxRate: z.number().min(0).max(100).default(18),
  ewayBillNo: z.string().optional().default(''),
  status: EntryStatusSchema.default('Pending validation'),
  reason: z.string().optional().default(''),
  validatedAt: z.string().optional(),
  validatedBy: z.string().optional(),
  lotBarcode: z.string().optional(),
})

export type GateEntry = z.infer<typeof GateEntrySchema>

export const CreateGateEntryInputSchema = z.object({
  type: EntryTypeSchema,
  supplier: z.string().min(2, 'Supplier name must be at least 2 characters'),
  poNumber: z.string().optional().default(''),
  dcNumber: z.string().min(1, 'DC Number is required'),
  dcDate: z.string().min(1, 'DC Date is required'),
  vehicle: z.string().optional().default(''),
  courier: z.string().optional().default(''),
  boxes: z.coerce.number().int().min(1, 'At least 1 box is required').default(1),
  item: z.string().min(2, 'Item name must be at least 2 characters'),
  quantity: z.coerce.number().positive('Quantity must be greater than 0'),
  weight: z.coerce.number().min(0, 'Weight cannot be negative').default(0),
  taxRate: z.coerce.number().min(0).max(100).default(18),
  ewayBillNo: z.string().optional().default(''),
})

export type CreateGateEntryInput = z.infer<typeof CreateGateEntryInputSchema>

export interface JobShortage {
  id: string
  itemCode: string
  itemName: string
  poNumber: string
  supplier: string
  shortageQty: number
  requiredByDate: string
  productionLine: string
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM'
  status: 'BLOCKED' | 'PENDING_DELIVERY' | 'RESOLVED'
}

export interface AsnNotice {
  id: string
  asnNumber: string
  supplier: string
  poNumber: string
  dispatchDate: string
  etaDate: string
  vehicleNo: string
  totalPackages: number
  itemCount: number
  declaredValue: number
  status: 'VERIFIED' | 'PENDING' | 'DISCREPANCY'
  exemptionStatus: 'EXEMPT' | 'STANDARD'
}

export interface InventoryLocator {
  id: string
  itemCode: string
  description: string
  locator: string
  minQty: number
  maxQty: number
  onHandQty: number
  uom: string
  status: 'NORMAL' | 'REPLENISH' | 'CRITICAL'
  lastAuditDate: string
}

export interface EodCloseRecord {
  date: string
  totalEntries: number
  approvedCount: number
  onHoldCount: number
  pendingCount: number
  closedAt?: string
  closedBy?: string
  status: 'OPEN' | 'CLOSED'
  totalWeightKg: number
}
