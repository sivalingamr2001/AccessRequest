import { useState, useMemo, useEffect } from 'react'
import { Link, useSearch } from '@tanstack/react-router'
import { toast } from 'sonner'
import {
  CheckCircle2,
  AlertCircle,
  Clock,
  ShieldCheck,
  Building2,
  AlertTriangle,
  Barcode,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { PageHeader } from '@/components/patterns/page-header'
import { useGateEntriesQuery, useValidateGateEntryMutation } from '../api/gate-api'
import { formatDate } from '@/lib/utils'

export function ValidationView() {
  const searchParams: { entry?: string } = useSearch({ strict: false })
  const { data: entries = [], isLoading } = useGateEntriesQuery()
  const validateMutation = useValidateGateEntryMutation()

  const [selectedId, setSelectedId] = useState<string | null>(searchParams.entry || null)
  const [filter, setFilter] = useState<string>('Pending validation')
  const [holdReason, setHoldReason] = useState<string>('')

  // Sync initial selection
  useEffect(() => {
    if (searchParams.entry) {
      setSelectedId(searchParams.entry)
    } else if (!selectedId && entries.length > 0) {
      const firstPending = entries.find((e) => e.status === 'Pending validation')
      setSelectedId(firstPending ? firstPending.id : entries[0].id)
    }
  }, [searchParams.entry, entries, selectedId])

  const filteredList = useMemo(() => {
    if (filter === 'ALL') return entries
    return entries.filter((e) => e.status === filter)
  }, [entries, filter])

  const selectedEntry = useMemo(() => {
    return entries.find((e) => e.id === selectedId) || null
  }, [entries, selectedId])

  const handleDecision = async (status: 'Approved' | 'On hold') => {
    if (!selectedEntry) return
    if (status === 'On hold' && !holdReason.trim()) {
      toast.error('Hold Reason Required', {
        description: 'Please provide a clear justification before placing this delivery on hold.',
      })
      return
    }

    try {
      await validateMutation.mutateAsync({
        id: selectedEntry.id,
        status,
        reason: status === 'On hold' ? holdReason.trim() : undefined,
      })
      toast.success(status === 'Approved' ? 'Gate Entry Approved!' : 'Consignment Placed on Hold', {
        description: `${selectedEntry.gateNo} status updated to ${status}.`,
      })
      setHoldReason('')
    } catch (err: unknown) {
      toast.error('Validation action failed', {
        description: err instanceof Error ? err.message : 'Please try again',
      })
    }
  }

  const pendingCount = entries.filter((e) => e.status === 'Pending validation').length

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Gate Operations / Review & Quality Gate'
        title='Gate Validation Desk'
        description='Supervisor desk to inspect physical challans, verify E-Way bills, and approve materials before formal Oracle ERP receipt.'
        badge={`${pendingCount} Awaiting Review`}
        actions={
          <Button asChild variant='outline' size='sm' className='h-9 text-xs'>
            <Link to='/'>
              View Register <ArrowRight className='ml-1 size-3.5' />
            </Link>
          </Button>
        }
      />

      <div className='grid gap-6 lg:grid-cols-[380px_1fr]'>
        {/* Left Side: Queue List */}
        <Card className='shadow-xs border-border/80 flex flex-col h-[740px]'>
          <CardHeader className='border-b border-border/60 p-4 space-y-3'>
            <div className='flex items-center justify-between'>
              <CardTitle className='text-xs font-bold font-heading flex items-center gap-1.5'>
                <Clock className='size-3.5 text-primary' />
                Review Queue
              </CardTitle>
              <Badge variant='secondary' className='text-[10px]'>
                {filteredList.length} item(s)
              </Badge>
            </div>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className='h-8 text-xs'>
                <SelectValue placeholder='Filter status' />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value='Pending validation' className='text-xs'>Pending Validation</SelectItem>
                <SelectItem value='On hold' className='text-xs'>On Hold</SelectItem>
                <SelectItem value='Approved' className='text-xs'>Approved</SelectItem>
                <SelectItem value='ALL' className='text-xs'>All Entries</SelectItem>
              </SelectContent>
            </Select>
          </CardHeader>
          <div className='flex-1 overflow-y-auto divide-y divide-border/60'>
            {isLoading ? (
              <div className='p-6 text-center text-xs text-muted-foreground'>
                Loading validation queue...
              </div>
            ) : filteredList.length ? (
              filteredList.map((entry) => {
                const isSelected = entry.id === selectedId
                return (
                  <button
                    key={entry.id}
                    type='button'
                    onClick={() => {
                      setSelectedId(entry.id)
                      setHoldReason(entry.reason || '')
                    }}
                    className={`w-full text-left p-4 transition-colors hover:bg-muted/40 flex flex-col gap-1.5 ${
                      isSelected ? 'bg-primary/10 border-l-4 border-primary' : ''
                    }`}
                  >
                    <div className='flex items-center justify-between'>
                      <span className='font-mono font-bold text-xs text-primary'>
                        {entry.gateNo}
                      </span>
                      {entry.status === 'Approved' ? (
                        <Badge className='bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-[10px] border-emerald-500/20'>
                          Approved
                        </Badge>
                      ) : entry.status === 'On hold' ? (
                        <Badge className='bg-amber-500/15 text-amber-700 dark:text-amber-300 text-[10px] border-amber-500/20'>
                          On hold
                        </Badge>
                      ) : (
                        <Badge variant='outline' className='text-[10px] text-primary border-primary/30'>
                          Pending
                        </Badge>
                      )}
                    </div>
                    <p className='text-xs font-semibold text-foreground truncate'>
                      {entry.supplier}
                    </p>
                    <p className='text-[11px] text-muted-foreground truncate'>
                      DC: {entry.dcNumber} · {entry.item}
                    </p>
                    <span className='text-[10px] text-muted-foreground/70 font-mono'>
                      {formatDate(entry.createdAt)}
                    </span>
                  </button>
                )
              })
            ) : (
              <div className='p-8 text-center text-xs text-muted-foreground space-y-2'>
                <ShieldCheck className='size-8 text-muted-foreground/40 mx-auto' />
                <p className='font-semibold text-foreground'>Queue is clear</p>
                <p className='text-[11px]'>No gate entries found matching this status.</p>
              </div>
            )}
          </div>
        </Card>

        {/* Right Side: Detailed Inspection & Decision */}
        {selectedEntry ? (
          <Card className='shadow-xs border-border/80 flex flex-col h-[740px] overflow-hidden'>
            <CardHeader className='border-b border-border/60 pb-4 bg-muted/20'>
              <div className='flex flex-wrap items-center justify-between gap-3'>
                <div>
                  <div className='flex items-center gap-2'>
                    <span className='font-mono text-base font-bold text-primary font-heading'>
                      {selectedEntry.gateNo}
                    </span>
                    <Badge variant='outline' className='text-[10px] uppercase font-mono'>
                      {selectedEntry.type}
                    </Badge>
                  </div>
                  <CardDescription className='text-xs mt-0.5'>
                    Registered on {formatDate(selectedEntry.createdAt)} by Unit 7 Security Gate
                  </CardDescription>
                </div>

                <div className='flex items-center gap-2'>
                  {selectedEntry.status === 'Approved' ? (
                    <Badge className='bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-xs py-1 px-3 border-emerald-500/30 gap-1.5'>
                      <CheckCircle2 className='size-3.5' /> Approved
                    </Badge>
                  ) : selectedEntry.status === 'On hold' ? (
                    <Badge className='bg-amber-500/15 text-amber-700 dark:text-amber-300 text-xs py-1 px-3 border-amber-500/30 gap-1.5'>
                      <AlertCircle className='size-3.5' /> On hold
                    </Badge>
                  ) : (
                    <Badge variant='outline' className='text-xs py-1 px-3 text-primary border-primary/30 gap-1.5'>
                      <Clock className='size-3.5' /> Pending validation
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>

            <CardContent className='p-6 space-y-6 overflow-y-auto flex-1'>
              {/* Specification Grid */}
              <div className='grid gap-4 sm:grid-cols-2 md:grid-cols-3 rounded-lg border border-border/70 p-4 bg-card/60'>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Supplier Name</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.supplier}</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>DC Number & Date</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.dcNumber} ({formatDate(selectedEntry.dcDate)})</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>PO / OSP Ref</span>
                  <p className='font-mono font-semibold text-xs text-primary mt-0.5'>{selectedEntry.poNumber || 'None'}</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Vehicle Number</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.vehicle || 'Direct Delivery'}</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Transporter</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.courier || 'Vendor Vehicle'}</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Package Count</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.boxes} Box(es)</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Material Description</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.item}</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Received Qty</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.quantity.toLocaleString()} pcs</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Gross Weight</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.weight} kg</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Declared Tax Rate</span>
                  <p className='font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.taxRate}% GST</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>E-Way Bill</span>
                  <p className='font-mono font-semibold text-xs text-foreground mt-0.5'>{selectedEntry.ewayBillNo || 'Not declared'}</p>
                </div>
                <div>
                  <span className='text-[11px] text-muted-foreground uppercase font-medium'>Assigned Lot Barcode</span>
                  <p className='font-mono font-semibold text-xs text-primary mt-0.5'>{selectedEntry.lotBarcode || 'Generated on approval'}</p>
                </div>
              </div>

              {/* Status Note or Hold Banner */}
              {selectedEntry.status === 'On hold' && selectedEntry.reason && (
                <div className='rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 space-y-1 text-xs'>
                  <div className='flex items-center gap-1.5 font-bold text-amber-800 dark:text-amber-200'>
                    <AlertTriangle className='size-4 text-amber-600' />
                    Consignment Currently On Hold
                  </div>
                  <p className='text-amber-900/90 dark:text-amber-100 text-[11px] pl-5'>
                    Reason recorded: {selectedEntry.reason}
                  </p>
                  {selectedEntry.validatedBy && (
                    <p className='text-[10px] text-amber-700/70 dark:text-amber-300/70 pl-5'>
                      Placed by {selectedEntry.validatedBy} at {formatDate(selectedEntry.validatedAt)}
                    </p>
                  )}
                </div>
              )}

              {/* Validation Controls */}
              <div className='border-t border-border pt-4 space-y-3'>
                <h4 className='text-xs font-bold font-heading text-foreground'>
                  Supervisor Decision & Lot Clearance
                </h4>
                <div className='space-y-1.5'>
                  <label htmlFor='hold-reason' className='text-xs font-medium text-muted-foreground'>
                    Hold Reason / Discrepancy Note (Mandatory if placing on hold)
                  </label>
                  <Textarea
                    id='hold-reason'
                    placeholder='Explain reason for hold: e.g., Challan qty differs from physical boxes, missing test cert, e-way bill expired...'
                    value={holdReason}
                    onChange={(e) => setHoldReason(e.target.value)}
                    className='text-xs min-h-[70px]'
                  />
                </div>

                <div className='flex flex-wrap items-center gap-3 pt-2'>
                  <Button
                    onClick={() => handleDecision('Approved')}
                    disabled={validateMutation.isPending || selectedEntry.status === 'Approved'}
                    className='h-9 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-semibold'
                  >
                    <CheckCircle2 className='mr-1.5 size-4' />
                    {selectedEntry.status === 'On hold' ? 'Release Hold & Approve' : 'Approve & Release Lot'}
                  </Button>

                  <Button
                    variant='outline'
                    onClick={() => handleDecision('On hold')}
                    disabled={validateMutation.isPending || selectedEntry.status === 'On hold'}
                    className='h-9 text-xs text-amber-700 border-amber-500/40 hover:bg-amber-500/10'
                  >
                    <AlertCircle className='mr-1.5 size-4' />
                    Place On Hold
                  </Button>

                  {selectedEntry.status === 'Approved' && (
                    <Button variant='secondary' size='sm' className='h-9 text-xs' asChild>
                      <Link to='/barcode' search={{ entry: selectedEntry.id } as any}>
                        <Barcode className='mr-1.5 size-4' />
                        Print Lot Barcode
                      </Link>
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className='shadow-xs border-border/80 flex items-center justify-center h-[740px] text-center p-6'>
            <div className='max-w-sm space-y-2 text-muted-foreground text-xs'>
              <Building2 className='size-12 mx-auto text-muted-foreground/30' />
              <h3 className='font-bold text-foreground text-sm font-heading'>No Delivery Selected</h3>
              <p>Select a gate entry consignment from the review queue on the left to inspect documents and record validation decisions.</p>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
