import { useState, useMemo } from 'react'
import { useSearch, Link } from '@tanstack/react-router'
import { toast } from 'sonner'
import {
  Barcode,
  Printer,
  FileCode2,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { PageHeader } from '@/components/patterns/page-header'
import { useGateEntriesQuery } from '../api/gate-api'
import { formatDate } from '@/lib/utils'

export function BarcodeView() {
  const searchParams: { entry?: string } = useSearch({ strict: false })
  const { data: entries = [] } = useGateEntriesQuery()

  const approvedEntries = useMemo(() => {
    return entries.filter((e) => e.status === 'Approved' || e.lotBarcode)
  }, [entries])

  const initialEntry = approvedEntries.find((e) => e.id === searchParams.entry) || approvedEntries[0]
  const [selectedEntryId, setSelectedEntryId] = useState<string>(initialEntry.id)
  const [printer, setPrinter] = useState<string>('zebra-zt411')
  const [copies, setCopies] = useState<number>(2)

  const activeEntry = approvedEntries.find((e) => e.id === selectedEntryId) || initialEntry

  // Generate real Zebra Programming Language (ZPL II) string
  const zplCode = useMemo(() => {
    const lot = activeEntry.lotBarcode || 'LOT-2026-UNKNOWN'
    return `^XA
^FO50,50^A0N,36,36^FDENTERPRISE PORTAL - UNIT 7 GATE^FS
^FO50,95^GB700,2,2^FS
^FO50,115^A0N,28,28^FDSUPPLIER: ${activeEntry.supplier.toUpperCase()}^FS
^FO50,150^A0N,24,24^FDPO NO: ${activeEntry.poNumber || 'N/A'}^FS
^FO50,180^A0N,24,24^FDDC NO: ${activeEntry.dcNumber}^FS
^FO50,210^A0N,26,26^FDPART: ${activeEntry.item}^FS
^FO50,245^A0N,24,24^FDQTY: ${activeEntry.quantity} PCS  |  WT: ${activeEntry.weight} KG^FS
^FO50,285^BY3,3,70^BCN,70,Y,N,N^FD${lot}^FS
^FO50,380^A0N,20,20^FDDATE: ${formatDate(activeEntry.createdAt)}  |  COPIES: ${copies}^FS
^XZ`
  }, [activeEntry, copies])

  const handlePrint = () => {
    toast.success('ZPL Sticker Sent to Network Printer', {
      description: `Dispatched ${copies} label(s) for ${activeEntry.lotBarcode || 'LOT'} to ${printer.toUpperCase()}.`,
    })
  }

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Tools & Logistics / Label Serialization'
        title='Barcode & Lot Printing'
        description='Generate industrial Zebra ZPL II barcode stickers for approved gate receipts and FIFO material identification.'
        badge='Zebra ZPL II Active'
        actions={
          <Button asChild variant='outline' size='sm' className='h-9 text-xs'>
            <Link to='/'>
              View Register <ArrowRight className='ml-1 size-3.5' />
            </Link>
          </Button>
        }
      />

      <div className='grid gap-6 lg:grid-cols-[1fr_420px]'>
        {/* Left Side: Configuration & ZPL code */}
        <div className='space-y-6'>
          <Card className='shadow-xs border-border/80'>
            <CardHeader className='border-b border-border/60 pb-4'>
              <div className='flex items-center gap-2'>
                <div className='flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary'>
                  <Printer className='size-4' />
                </div>
                <div>
                  <CardTitle className='text-sm font-bold font-heading'>
                    Printer Station & Delivery Selection
                  </CardTitle>
                  <CardDescription className='text-xs'>
                    Select an approved gate entry and configure the active factory thermal printer.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className='p-6 space-y-4'>
              <div className='grid gap-4 sm:grid-cols-2'>
                <div className='space-y-1.5'>
                  <label htmlFor='select-entry' className='text-xs font-medium text-foreground'>
                    Select Cleared Inward Entry
                  </label>
                  <Select
                    value={selectedEntryId}
                    onValueChange={setSelectedEntryId}
                  >
                    <SelectTrigger id='select-entry' className='h-9 text-xs'>
                      <SelectValue placeholder='Select an entry' />
                    </SelectTrigger>
                    <SelectContent>
                      {approvedEntries.map((e) => (
                        <SelectItem key={e.id} value={e.id} className='text-xs'>
                          {e.gateNo} — {e.supplier}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className='space-y-1.5'>
                  <label htmlFor='select-printer' className='text-xs font-medium text-foreground'>
                    Network Zebra Printer Target
                  </label>
                  <Select value={printer} onValueChange={setPrinter}>
                    <SelectTrigger id='select-printer' className='h-9 text-xs'>
                      <SelectValue placeholder='Select printer' />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value='zebra-zt411' className='text-xs'>
                        Gate Office Zebra ZT411 (192.168.1.140:9100)
                      </SelectItem>
                      <SelectItem value='zebra-gx420' className='text-xs'>
                        Unit 7 Warehouse Desk Zebra GX420d
                      </SelectItem>
                      <SelectItem value='skyfast-usb' className='text-xs'>
                        Skyfast Inward Direct USB Thermal
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className='space-y-1.5'>
                  <label htmlFor='copies-input' className='text-xs font-medium text-foreground'>
                    Number of Sticker Copies
                  </label>
                  <Input
                    id='copies-input'
                    type='number'
                    min='1'
                    max='50'
                    value={copies}
                    onChange={(e) => setCopies(Math.max(1, Number(e.target.value)))}
                    className='h-9 text-xs'
                  />
                </div>
              </div>

              <div className='pt-2 flex items-center justify-end gap-3'>
                <Button onClick={handlePrint} className='h-9 text-xs font-semibold px-6'>
                  <Printer className='mr-1.5 size-4' />
                  Print {copies} Label(s) Now
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* ZPL II Raw Payload Card */}
          <Card className='shadow-xs border-border/80'>
            <CardHeader className='border-b border-border/60 pb-3'>
              <div className='flex items-center justify-between'>
                <div className='flex items-center gap-2'>
                  <FileCode2 className='size-4 text-primary' />
                  <CardTitle className='text-xs font-bold font-heading'>
                    Zebra Programming Language (ZPL II) Command Stream
                  </CardTitle>
                </div>
                <Badge variant='outline' className='text-[10px] font-mono'>
                  Raw ASCII Socket Output
                </Badge>
              </div>
            </CardHeader>
            <CardContent className='p-4'>
              <pre className='rounded-lg bg-muted/60 p-4 font-mono text-[11px] text-muted-foreground overflow-x-auto leading-relaxed border border-border/50'>
                {zplCode}
              </pre>
            </CardContent>
          </Card>
        </div>

        {/* Right Side: Physical Sticker Visual Preview */}
        <div className='space-y-4'>
          <Card className='shadow-xs border-border/80 bg-muted/20'>
            <CardHeader className='pb-3'>
              <div className='flex items-center gap-2'>
                <Barcode className='size-4 text-primary' />
                <CardTitle className='text-xs font-bold font-heading'>
                  4" x 2" Physical Label Simulation
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className='p-4 space-y-4'>
              {/* Sticker Card */}
              <div className='rounded-xl border-2 border-dashed border-border bg-white text-slate-900 p-5 shadow-md space-y-3 font-sans'>
                <div className='flex items-center justify-between border-b pb-2 border-slate-300'>
                  <div>
                    <p className='font-mono text-[9px] uppercase tracking-wider text-slate-500 font-bold'>
                      ENTERPRISE PORTAL
                    </p>
                    <p className='text-xs font-bold text-slate-900'>UNIT 7 GATE RECEIPT</p>
                  </div>
                  <Badge variant='outline' className='text-[9px] font-mono font-bold text-slate-700 border-slate-400'>
                    FIFO LOT
                  </Badge>
                </div>

                <div className='space-y-1 text-[11px] leading-tight text-slate-800'>
                  <p>
                    <span className='font-bold text-slate-500'>SUPPLIER:</span>{' '}
                    <span className='font-semibold'>{activeEntry.supplier || '—'}</span>
                  </p>
                  <p>
                    <span className='font-bold text-slate-500'>DC NO:</span>{' '}
                    <span className='font-mono font-semibold'>{activeEntry.dcNumber || '—'}</span>{' '}
                    | <span className='font-bold text-slate-500'>PO:</span>{' '}
                    <span className='font-mono'>{activeEntry.poNumber || 'N/A'}</span>
                  </p>
                  <p>
                    <span className='font-bold text-slate-500'>ITEM:</span>{' '}
                    <span className='font-semibold'>{activeEntry.item || '—'}</span>
                  </p>
                  <p>
                    <span className='font-bold text-slate-500'>QUANTITY:</span>{' '}
                    <span className='font-bold text-slate-950'>{activeEntry.quantity} PCS</span>{' '}
                    | <span className='font-bold text-slate-500'>WT:</span> {activeEntry.weight} KG
                  </p>
                </div>

                {/* Simulated Barcode */}
                <div className='border-t border-slate-200 pt-3 text-center'>
                  <p className='font-mono font-bold text-xs text-slate-900 tracking-wider'>
                    {activeEntry.lotBarcode || 'LOT-20260930-001'}
                  </p>
                  <div className='mt-1 flex justify-center items-end gap-[2px] h-12 bg-white px-2 py-1'>
                    {[
                      3, 1, 2, 4, 1, 3, 2, 1, 4, 2, 3, 1, 2, 3, 1, 4, 2, 1, 3, 2, 1, 4,
                      2, 1, 3, 2, 4, 1, 2, 3, 1, 4, 2, 1, 3, 2, 1, 4, 2, 3, 1, 2,
                    ].map((w, idx) => (
                      <div
                        key={idx}
                        className='bg-slate-900'
                        style={{ width: `${w}px`, height: '100%' }}
                      />
                    ))}
                  </div>
                  <p className='text-[9px] font-mono text-slate-500 mt-1'>
                    {activeEntry.gateNo} · {formatDate(activeEntry.createdAt)}
                  </p>
                </div>
              </div>

              <div className='text-[11px] text-muted-foreground space-y-1.5 pt-1'>
                <div className='flex items-center gap-1.5'>
                  <CheckCircle2 className='size-3.5 text-emerald-600' />
                  <span>Compatible with standard Zebra ZPL socket clients (e.g. QZ Tray).</span>
                </div>
                <div className='flex items-center gap-1.5'>
                  <CheckCircle2 className='size-3.5 text-emerald-600' />
                  <span>Enforces FIFO rotation with ISO 8601 serialized date stamping.</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
