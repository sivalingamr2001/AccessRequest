import { useMemo } from 'react'
import { Link } from '@tanstack/react-router'
import type {ColumnDef} from '@tanstack/react-table';
import {
  CheckCircle2,
  Clock,
  AlertCircle,
  Database,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { DataTable } from '@/components/patterns/data-table'
import { PageHeader } from '@/components/patterns/page-header'
import { useAsnNoticesQuery } from '../api/gate-api'
import type {AsnNotice} from '../types';
import { formatDate } from '@/lib/utils'

export function AsnView() {
  const { data: asns = [], isLoading } = useAsnNoticesQuery()

  const columns = useMemo<ColumnDef<AsnNotice>[]>(
    () => [
      {
        accessorKey: 'asnNumber',
        header: 'ASN Number',
        cell: ({ row }) => (
          <div>
            <span className='font-mono font-bold text-xs text-primary'>
              {row.original.asnNumber}
            </span>
            <p className='text-[11px] text-muted-foreground'>
              Vehicle: {row.original.vehicleNo}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'supplier',
        header: 'Supplier / PO',
        cell: ({ row }) => (
          <div>
            <span className='font-medium text-xs text-foreground'>
              {row.original.supplier}
            </span>
            <p className='font-mono text-[11px] text-muted-foreground'>
              {row.original.poNumber}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'dispatchDate',
        header: 'Dispatch / ETA',
        cell: ({ row }) => (
          <div className='text-xs'>
            <span className='text-muted-foreground'>
              Dispatched: {formatDate(row.original.dispatchDate)}
            </span>
            <p className='font-medium text-foreground text-[11px]'>
              ETA: {formatDate(row.original.etaDate)}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'itemCount',
        header: 'Declared Consignment',
        cell: ({ row }) => (
          <div>
            <span className='font-medium text-xs'>
              {row.original.itemCount.toLocaleString()} items
            </span>
            <p className='text-[11px] text-muted-foreground'>
              {row.original.totalPackages} package(s) · ₹{row.original.declaredValue.toLocaleString()}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'exemptionStatus',
        header: 'ADI Exemption',
        cell: ({ row }) => {
          const isExempt = row.original.exemptionStatus === 'EXEMPT'
          return (
            <Badge
              variant='outline'
              className={`text-[10px] font-mono ${
                isExempt
                  ? 'border-emerald-500/40 text-emerald-600 bg-emerald-500/10'
                  : 'border-border text-muted-foreground'
              }`}
            >
              {row.original.exemptionStatus}
            </Badge>
          )
        },
      },
      {
        accessorKey: 'status',
        header: 'Reconciliation',
        cell: ({ row }) => {
          const status = row.original.status
          if (status === 'VERIFIED') {
            return (
              <Badge className='bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 text-[10px] gap-1 font-semibold'>
                <CheckCircle2 className='size-3' /> VERIFIED
              </Badge>
            )
          }
          if (status === 'PENDING') {
            return (
              <Badge variant='outline' className='bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30 text-[10px] gap-1'>
                <Clock className='size-3' /> PENDING
              </Badge>
            )
          }
          return (
            <Badge className='bg-destructive/15 text-destructive border-destructive/30 text-[10px] gap-1'>
              <AlertCircle className='size-3' /> DISCREPANCY
            </Badge>
          )
        },
      },
      {
        id: 'actions',
        header: () => <div className='text-right'>Action</div>,
        cell: () => (
          <div className='text-right'>
            <Button variant='outline' size='sm' className='h-7 text-[11px]' asChild>
              <Link to='/gate-entry/new'>
                Match Inward <ArrowRight className='ml-1 size-3' />
              </Link>
            </Button>
          </div>
        ),
      },
    ],
    []
  )

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Tools / Logistics & SCM Sync'
        title='Advance Shipping Notice (ASN / ADI)'
        description='Compare supplier advance dispatch advisories with Oracle pending deliveries. Verify vendor ADI exemption certificates.'
        badge='SCM Gateway Active'
      />

      <div className='grid gap-4 sm:grid-cols-3'>
        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Synced ASNs</span>
            <Database className='size-4 text-primary' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-foreground'>
            {isLoading ? '...' : asns.length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Direct from SCM SQL Server database</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Verified Notices</span>
            <CheckCircle2 className='size-4 text-emerald-600' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-emerald-600 dark:text-emerald-400'>
            {isLoading ? '...' : asns.filter((a) => a.status === 'VERIFIED').length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Ready for immediate gate clearance</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Exempt Suppliers</span>
            <ShieldCheck className='size-4 text-blue-600' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-blue-600 dark:text-blue-400'>
            {isLoading ? '...' : asns.filter((a) => a.exemptionStatus === 'EXEMPT').length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>No manual ADI approval required</p>
        </Card>
      </div>

      <Card className='shadow-xs border-border/80 overflow-hidden'>
        <CardContent className='p-6 space-y-4'>
          <div>
            <h3 className='text-sm font-bold font-heading'>Advance Shipping Notices Registry</h3>
            <p className='text-xs text-muted-foreground mt-0.5'>
              Integrated with Supplier SCM Portal. Cross-referenced against Oracle delivery expectations.
            </p>
          </div>

          <DataTable
            columns={columns}
            data={asns}
            searchPlaceholder='Search by ASN, supplier, PO, or vehicle...'
            exportFilename={`asn-notices-${new Date().toLocaleDateString('en-CA')}.csv`}
          />
        </CardContent>
      </Card>
    </div>
  )
}
