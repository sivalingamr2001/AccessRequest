import { useMemo } from 'react'
import { Link } from '@tanstack/react-router'
import type {ColumnDef} from '@tanstack/react-table';
import {
  Boxes,
  AlertTriangle,
  CheckCircle2,
  PackagePlus,
  TrendingDown,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { DataTable } from '@/components/patterns/data-table'
import { PageHeader } from '@/components/patterns/page-header'
import { useInventoryQuery } from '../api/gate-api'
import type {InventoryLocator} from '../types';
import { formatDate } from '@/lib/utils'

export function InventoryView() {
  const { data: inventory = [], isLoading } = useInventoryQuery()

  const replenishCount = inventory.filter((i) => i.status === 'REPLENISH' || i.status === 'CRITICAL').length

  const columns = useMemo<ColumnDef<InventoryLocator>[]>(
    () => [
      {
        accessorKey: 'itemCode',
        header: 'Item Code',
        cell: ({ row }) => (
          <div>
            <span className='font-mono font-bold text-xs text-primary'>
              {row.original.itemCode}
            </span>
            <p className='text-[11px] text-muted-foreground truncate max-w-xs'>
              {row.original.description}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'locator',
        header: 'Warehouse Locator',
        cell: ({ row }) => (
          <Badge variant='outline' className='font-mono text-xs'>
            {row.original.locator}
          </Badge>
        ),
      },
      {
        accessorKey: 'onHandQty',
        header: 'On Hand Balance',
        cell: ({ row }) => (
          <div>
            <span className='font-mono font-bold text-xs text-foreground'>
              {row.original.onHandQty.toLocaleString()} {row.original.uom}
            </span>
          </div>
        ),
      },
      {
        accessorKey: 'minQty',
        header: 'Min Threshold',
        cell: ({ row }) => (
          <span className='font-mono text-xs text-muted-foreground'>
            {row.original.minQty.toLocaleString()}
          </span>
        ),
      },
      {
        accessorKey: 'maxQty',
        header: 'Max Threshold',
        cell: ({ row }) => (
          <span className='font-mono text-xs text-muted-foreground'>
            {row.original.maxQty.toLocaleString()}
          </span>
        ),
      },
      {
        accessorKey: 'status',
        header: 'Stock Status',
        cell: ({ row }) => {
          const status = row.original.status
          if (status === 'CRITICAL') {
            return (
              <Badge className='bg-destructive/15 text-destructive border-destructive/30 text-[10px] gap-1 font-bold'>
                <AlertTriangle className='size-3' /> CRITICAL LOW
              </Badge>
            )
          }
          if (status === 'REPLENISH') {
            return (
              <Badge className='bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30 text-[10px] gap-1 font-semibold'>
                <TrendingDown className='size-3' /> REPLENISH
              </Badge>
            )
          }
          return (
            <Badge className='bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 text-[10px] gap-1'>
              <CheckCircle2 className='size-3' /> OPTIMAL
            </Badge>
          )
        },
      },
      {
        accessorKey: 'lastAuditDate',
        header: 'Last Audit',
        cell: ({ row }) => (
          <span className='text-xs text-muted-foreground font-mono'>
            {formatDate(row.original.lastAuditDate)}
          </span>
        ),
      },
      {
        id: 'actions',
        header: () => <div className='text-right'>Action</div>,
        cell: () => (
          <div className='text-right'>
            <Button variant='outline' size='sm' className='h-7 text-[11px]' asChild>
              <Link to='/gate-entry/new'>
                <PackagePlus className='mr-1 size-3' /> Inward
              </Link>
            </Button>
          </div>
        ),
      },
    ],
    []
  )

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Tools & Logistics / Inventory Control'
        title='Min-Max Inventory & Locator Control'
        description='Track shop-floor buffer stock, bin locators, and replenishment trigger levels connected to the Oracle master card.'
        badge={`${replenishCount} Below Min Level`}
      />

      <div className='grid gap-4 sm:grid-cols-3'>
        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Tracked Items</span>
            <Boxes className='size-4 text-primary' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-foreground'>
            {isLoading ? '...' : inventory.length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Managed locator bin cards</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Stock Alert Items</span>
            <AlertTriangle className='size-4 text-amber-500' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-amber-600 dark:text-amber-400'>
            {isLoading ? '...' : replenishCount}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Under minimum stock threshold</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Optimal Stock</span>
            <CheckCircle2 className='size-4 text-emerald-600' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-emerald-600 dark:text-emerald-400'>
            {isLoading ? '...' : inventory.filter((i) => i.status === 'NORMAL').length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Sufficient buffer for active shifts</p>
        </Card>
      </div>

      <Card className='shadow-xs border-border/80 overflow-hidden'>
        <CardContent className='p-6 space-y-4'>
          <div>
            <h3 className='text-sm font-bold font-heading'>Locator Min-Max Balance Cards</h3>
            <p className='text-xs text-muted-foreground mt-0.5'>
              Integrated with Oracle ERP Inventory Module. Real-time balance inspection.
            </p>
          </div>

          <DataTable
            columns={columns}
            data={inventory}
            searchPlaceholder='Search by item code, description, or locator...'
            exportFilename={`inventory-locators-${new Date().toLocaleDateString('en-CA')}.csv`}
          />
        </CardContent>
      </Card>
    </div>
  )
}
