import { useMemo } from 'react'
import { Link } from '@tanstack/react-router'
import type {ColumnDef} from '@tanstack/react-table';
import {
  ShieldAlert,
  AlertTriangle,
  PackagePlus,
  Clock,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { DataTable } from '@/components/patterns/data-table'
import { PageHeader } from '@/components/patterns/page-header'
import { useJobShortagesQuery } from '../api/gate-api'
import type {JobShortage} from '../types';
import { formatDate } from '@/lib/utils'

export function ShortagesView() {
  const { data: shortages = [], isLoading } = useJobShortagesQuery()

  const criticalCount = shortages.filter((s) => s.priority === 'CRITICAL').length
  const blockedCount = shortages.filter((s) => s.status === 'BLOCKED').length

  const columns = useMemo<ColumnDef<JobShortage>[]>(
    () => [
      {
        accessorKey: 'itemCode',
        header: 'Item Code',
        cell: ({ row }) => (
          <div>
            <span className='font-mono font-bold text-xs text-primary'>
              {row.original.itemCode}
            </span>
            <p className='text-[11px] text-muted-foreground truncate max-w-xs'>
              {row.original.itemName}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'poNumber',
        header: 'PO Reference & Supplier',
        cell: ({ row }) => (
          <div>
            <span className='font-mono font-medium text-xs text-foreground'>
              {row.original.poNumber}
            </span>
            <p className='text-[11px] text-muted-foreground'>
              {row.original.supplier}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'shortageQty',
        header: 'Shortage Qty',
        cell: ({ row }) => (
          <span className='font-mono font-bold text-xs text-destructive'>
            -{row.original.shortageQty.toLocaleString()} units
          </span>
        ),
      },
      {
        accessorKey: 'productionLine',
        header: 'Assembly Line',
        cell: ({ row }) => (
          <span className='text-xs text-foreground font-medium'>
            {row.original.productionLine}
          </span>
        ),
      },
      {
        accessorKey: 'requiredByDate',
        header: 'Required By',
        cell: ({ row }) => (
          <span className='text-xs text-muted-foreground font-mono'>
            {formatDate(row.original.requiredByDate)}
          </span>
        ),
      },
      {
        accessorKey: 'priority',
        header: 'Priority',
        cell: ({ row }) => {
          const p = row.original.priority
          if (p === 'CRITICAL') {
            return (
              <Badge className='bg-destructive/15 text-destructive border-destructive/30 text-[10px] gap-1 font-bold'>
                <AlertTriangle className='size-3' />
                CRITICAL
              </Badge>
            )
          }
          if (p === 'HIGH') {
            return (
              <Badge className='bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30 text-[10px] gap-1 font-semibold'>
                HIGH
              </Badge>
            )
          }
          return (
            <Badge variant='outline' className='text-[10px] text-muted-foreground'>
              MEDIUM
            </Badge>
          )
        },
      },
      {
        accessorKey: 'status',
        header: 'Block Status',
        cell: ({ row }) => {
          const status = row.original.status
          if (status === 'BLOCKED') {
            return (
              <Badge variant='outline' className='bg-destructive/10 text-destructive border-destructive/30 text-[10px] font-mono'>
                PO BLOCKED
              </Badge>
            )
          }
          if (status === 'RESOLVED') {
            return (
              <Badge variant='outline' className='bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-[10px] font-mono'>
                RESOLVED
              </Badge>
            )
          }
          return (
            <Badge variant='outline' className='bg-primary/10 text-primary border-primary/30 text-[10px] font-mono'>
              TRANSIT
            </Badge>
          )
        },
      },
      {
        id: 'actions',
        header: () => <div className='text-right'>Action</div>,
        cell: () => (
          <div className='text-right'>
            <Button variant='outline' size='sm' className='h-7 text-[11px]' asChild>
              <Link to='/gate-entry/new'>
                <PackagePlus className='mr-1 size-3' /> Inward
              </Link>
            </Button>
          </div>
        ),
      },
    ],
    []
  )

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Operations / Shortages & PO Block'
        title='Job Shortages Monitor'
        description='Real-time shortage audit enforcing gate validation priorities. Deliveries corresponding to critical POs are expedited for manufacturing lines.'
        badge={`${criticalCount} Critical Shortages`}
      />

      <div className='grid gap-4 sm:grid-cols-3'>
        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Active Shortages</span>
            <ShieldAlert className='size-4 text-destructive' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-foreground'>
            {isLoading ? '...' : shortages.length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Tracking ERP assembly line demands</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Critical Line Halts</span>
            <AlertTriangle className='size-4 text-amber-500' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-amber-600 dark:text-amber-400'>
            {isLoading ? '...' : criticalCount}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Must clear gate receipt immediately</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Blocked POs</span>
            <Clock className='size-4 text-primary' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-primary'>
            {isLoading ? '...' : blockedCount}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Requires gate pass release</p>
        </Card>
      </div>

      <Card className='shadow-xs border-border/80 overflow-hidden'>
        <CardContent className='p-6 space-y-4'>
          <div>
            <h3 className='text-sm font-bold font-heading'>Critical Job Shortages Registry</h3>
            <p className='text-xs text-muted-foreground mt-0.5'>
              Cross-checked against Oracle bill of materials and factory pending purchase orders.
            </p>
          </div>

          <DataTable
            columns={columns}
            data={shortages}
            searchPlaceholder='Search by item, PO, supplier, or assembly line...'
            exportFilename={`job-shortages-${new Date().toLocaleDateString('en-CA')}.csv`}
          />
        </CardContent>
      </Card>
    </div>
  )
}
