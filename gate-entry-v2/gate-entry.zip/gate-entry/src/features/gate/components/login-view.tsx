import { useState } from 'react'
import { useNavigate } from '@tanstack/react-router'
import {
  Boxes,
  ShieldCheck,
  LockKeyhole,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'

export function LoginView() {
  const navigate = useNavigate()
  const [userId, setUserId] = useState('UNIT7')
  const [orgId, setOrgId] = useState('444')
  const [password, setPassword] = useState('••••••••')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    navigate({ to: '/' })
  }

  return (
    <div className='flex min-h-screen bg-background text-foreground'>
      {/* Left Artwork Banner (from Figma Template) */}
      <div className='relative hidden w-[48%] min-h-screen overflow-hidden bg-[#1e224f] p-12 text-white lg:flex lg:flex-col lg:justify-between shadow-2xl'>
        {/* Ambient glow */}
        <div className='pointer-events-none absolute -top-32 -right-48 size-[700px] rounded-full bg-primary/20 blur-3xl' />

        <div className='relative flex items-center gap-3'>
          <div className='flex size-10 items-center justify-center rounded-xl border border-white/20 bg-white/10 shadow-sm'>
            <Boxes className='size-5 text-white' />
          </div>
          <span className='text-lg font-bold tracking-tight font-heading'>
            GateFlow<span className='text-primary'>.</span>
          </span>
          <Badge variant='outline' className='border-white/20 text-white/80 text-[10px] uppercase font-mono ml-2'>
            Enterprise Portal Shell
          </Badge>
        </div>

        <div className='relative max-w-lg pb-10 space-y-4'>
          <div className='flex size-14 items-center justify-center rounded-2xl border border-white/20 bg-white/10 shadow-sm'>
            <ShieldCheck className='size-7 text-primary' />
          </div>
          <p className='font-mono text-xs font-semibold uppercase tracking-[0.2em] text-primary/80'>
            Factory Security & Material Gateway
          </p>
          <h1 className='font-mono text-4xl font-bold leading-tight tracking-tight xl:text-5xl font-heading'>
            Controlled Inward.<br />Zero Shortages.
          </h1>
          <p className='text-sm leading-relaxed text-slate-300'>
            Next-generation factory gate register replacing legacy desktop systems. Enforcing PO matching, e-way bill verification, and instant Zebra lot serialization.
          </p>

          <div className='pt-4 space-y-2 text-xs text-slate-300'>
            <div className='flex items-center gap-2'>
              <CheckCircle2 className='size-4 text-primary' />
              <span>Full TanStack Type-Safe Router, Form & Query</span>
            </div>
            <div className='flex items-center gap-2'>
              <CheckCircle2 className='size-4 text-primary' />
              <span>Zebra ZPL II Thermal Label Printing</span>
            </div>
            <div className='flex items-center gap-2'>
              <CheckCircle2 className='size-4 text-primary' />
              <span>Integrated GateFlow AI Assistant</span>
            </div>
          </div>
        </div>

        <p className='relative text-xs text-slate-400 font-mono'>
          © {new Date().getFullYear()} Factory Portal Shell · Org 444 Manufacturing
        </p>
      </div>

      {/* Right Login Form */}
      <div className='flex min-h-screen flex-1 flex-col px-6 py-8 sm:px-12 lg:px-20'>
        <div className='flex items-center gap-2.5 lg:invisible'>
          <div className='flex size-9 items-center justify-center rounded-xl bg-primary text-primary-foreground'>
            <Boxes className='size-5' />
          </div>
          <span className='text-lg font-bold font-heading'>GateFlow.</span>
        </div>

        <div className='mx-auto flex w-full max-w-[420px] flex-1 flex-col justify-center py-12'>
          <div className='mb-6 flex size-12 items-center justify-center rounded-2xl bg-primary/10 text-primary'>
            <LockKeyhole className='size-6' />
          </div>

          <p className='font-mono text-xs font-semibold uppercase tracking-wider text-primary'>
            Gatekeeper Access
          </p>
          <h2 className='text-2xl font-bold tracking-tight text-foreground font-heading mt-1 sm:text-3xl'>
            Sign in to Gate Portal
          </h2>
          <p className='text-xs text-muted-foreground mt-2 leading-relaxed'>
            Enter operator credentials or select standard factory test role to access registers and the validation desk.
          </p>

          {/* Quick Role Fill Buttons */}
          <div className='mt-6 grid grid-cols-2 gap-2 text-xs'>
            <button
              type='button'
              onClick={() => {
                setUserId('UNIT7')
                setOrgId('444')
              }}
              className={`rounded-lg border p-2.5 text-left transition-colors ${
                userId === 'UNIT7' ? 'border-primary bg-primary/5 text-primary font-bold' : 'border-border hover:bg-muted'
              }`}
            >
              <div className='font-mono text-[10px] uppercase text-muted-foreground'>Gate Operator</div>
              <div className='font-medium text-xs mt-0.5'>UNIT7 (Org 444)</div>
            </button>
            <button
              type='button'
              onClick={() => {
                setUserId('SUPERVISOR')
                setOrgId('444')
              }}
              className={`rounded-lg border p-2.5 text-left transition-colors ${
                userId === 'SUPERVISOR' ? 'border-primary bg-primary/5 text-primary font-bold' : 'border-border hover:bg-muted'
              }`}
            >
              <div className='font-mono text-[10px] uppercase text-muted-foreground'>QA Supervisor</div>
              <div className='font-medium text-xs mt-0.5'>VALID (Plant 1)</div>
            </button>
          </div>

          <form onSubmit={handleSubmit} className='mt-6 space-y-4'>
            <div className='space-y-1.5'>
              <label htmlFor='user-id' className='text-xs font-medium text-foreground'>
                Operator User ID
              </label>
              <Input
                id='user-id'
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                required
                className='h-10 text-xs font-mono'
              />
            </div>

            <div className='space-y-1.5'>
              <label htmlFor='org-id' className='text-xs font-medium text-foreground'>
                Organization Code (Org ID)
              </label>
              <Input
                id='org-id'
                value={orgId}
                onChange={(e) => setOrgId(e.target.value)}
                required
                className='h-10 text-xs font-mono'
              />
            </div>

            <div className='space-y-1.5'>
              <label htmlFor='password' className='text-xs font-medium text-foreground'>
                Security Password
              </label>
              <Input
                id='password'
                type='password'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className='h-10 text-xs'
              />
            </div>

            <Button type='submit' className='w-full h-10 text-xs font-semibold mt-2 justify-between px-4'>
              Continue to Inward Register <ArrowRight className='size-4' />
            </Button>
          </form>

          <p className='mt-8 text-center text-[11px] text-muted-foreground'>
            Authentication mapped to Oracle <code className='text-foreground'>jan_gate_login</code>.
          </p>
        </div>
      </div>
    </div>
  )
}
