import { useMemo, useState } from 'react'
import { Link } from '@tanstack/react-router'
import type {ColumnDef} from '@tanstack/react-table';
import {
  Truck,
  Clock,
  CheckCircle2,
  PackagePlus,
  ArrowRight,
  ShieldAlert,
  AlertCircle,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { DataTable } from '@/components/patterns/data-table'
import { PageHeader } from '@/components/patterns/page-header'
import { useGateEntriesQuery } from '../api/gate-api'
import type {GateEntry, EntryStatus} from '../types';
import { formatDate } from '@/lib/utils'

function StatusBadge({ status }: { status: EntryStatus }) {
  if (status === 'Approved') {
    return (
      <Badge className='bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/20 border-emerald-500/30 gap-1 text-[11px] font-medium'>
        <CheckCircle2 className='size-3 text-emerald-600 dark:text-emerald-400' />
        Approved
      </Badge>
    )
  }
  if (status === 'On hold') {
    return (
      <Badge className='bg-amber-500/15 text-amber-700 dark:text-amber-300 hover:bg-amber-500/20 border-amber-500/30 gap-1 text-[11px] font-medium'>
        <AlertCircle className='size-3 text-amber-600 dark:text-amber-400' />
        On hold
      </Badge>
    )
  }
  return (
    <Badge variant='outline' className='bg-primary/10 text-primary hover:bg-primary/15 border-primary/30 gap-1 text-[11px] font-medium'>
      <Clock className='size-3' />
      Pending validation
    </Badge>
  )
}

export function DashboardView() {
  const { data: entries = [], isLoading } = useGateEntriesQuery()
  const [statusFilter, setStatusFilter] = useState<string>('ALL')

  const todayStr = new Date().toDateString()
  const stats = useMemo(() => {
    return [
      {
        label: 'Total Inward Entries',
        value: entries.length,
        note: 'Across factory active register',
        icon: Truck,
        color: 'text-primary',
      },
      {
        label: 'Awaiting Validation',
        value: entries.filter((e) => e.status === 'Pending validation').length,
        note: 'Ready for gatekeeper review',
        icon: Clock,
        color: 'text-amber-600 dark:text-amber-400',
      },
      {
        label: 'Approved & Cleared',
        value: entries.filter((e) => e.status === 'Approved').length,
        note: 'Ready for Oracle inventory posting',
        icon: CheckCircle2,
        color: 'text-emerald-600 dark:text-emerald-400',
      },
      {
        label: 'Arrived Today',
        value: entries.filter((e) => new Date(e.createdAt).toDateString() === todayStr).length,
        note: 'New factory gate receipts',
        icon: PackagePlus,
        color: 'text-blue-600 dark:text-blue-400',
      },
    ]
  }, [entries, todayStr])

  const filteredEntries = useMemo(() => {
    if (statusFilter === 'ALL') return entries
    return entries.filter((e) => e.status === statusFilter)
  }, [entries, statusFilter])

  // TanStack Table Column Definitions
  const columns = useMemo<ColumnDef<GateEntry>[]>(
    () => [
      {
        accessorKey: 'gateNo',
        header: 'Gate Entry No',
        cell: ({ row }) => (
          <div>
            <span className='font-mono font-bold text-primary text-xs'>
              {row.original.gateNo}
            </span>
            <p className='text-[11px] text-muted-foreground truncate max-w-xs mt-0.5'>
              {row.original.item}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'supplier',
        header: 'Supplier / Delivery Challan',
        cell: ({ row }) => (
          <div>
            <span className='font-medium text-foreground text-xs'>
              {row.original.supplier}
            </span>
            <p className='text-[11px] text-muted-foreground mt-0.5'>
              DC: <span className='font-mono font-medium'>{row.original.dcNumber}</span> ({formatDate(row.original.dcDate)})
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'poNumber',
        header: 'PO / Entry Type',
        cell: ({ row }) => (
          <div>
            <span className='font-mono font-medium text-xs'>
              {row.original.poNumber || '—'}
            </span>
            <p className='text-[11px] text-muted-foreground mt-0.5'>
              {row.original.type}
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'quantity',
        header: 'Qty / Weight',
        cell: ({ row }) => (
          <div>
            <span className='font-medium text-xs'>
              {row.original.quantity.toLocaleString()} pcs
            </span>
            <p className='text-[11px] text-muted-foreground mt-0.5'>
              {row.original.weight} kg · {row.original.boxes} box(es)
            </p>
          </div>
        ),
      },
      {
        accessorKey: 'createdAt',
        header: 'Received At',
        cell: ({ row }) => (
          <span className='text-xs text-muted-foreground font-mono'>
            {formatDate(row.original.createdAt)}
          </span>
        ),
      },
      {
        accessorKey: 'status',
        header: 'Status',
        cell: ({ row }) => <StatusBadge status={row.original.status} />,
      },
      {
        id: 'actions',
        header: () => <div className='text-right'>Action</div>,
        cell: ({ row }) => (
          <div className='text-right'>
            <Button variant='ghost' size='sm' className='h-8 text-xs' asChild>
              <Link to='/gate-validation' search={{ entry: row.original.id } as any}>
                Inspect <ArrowRight className='ml-1 size-3' />
              </Link>
            </Button>
          </div>
        ),
      },
    ],
    []
  )

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Overview / Live Factory Register'
        title='Gate Register & Dashboard'
        description='Real-time monitor for factory gate material inward receipts, delivery challans, and Oracle validation.'
        badge='Unit 7 Active'
        actions={
          <Button asChild size='sm' className='h-9 text-xs'>
            <Link to='/gate-entry/new'>
              <PackagePlus className='mr-1.5 size-4' />
              New Gate Entry
            </Link>
          </Button>
        }
      />

      {/* KPI Cards */}
      <div className='grid gap-4 sm:grid-cols-2 lg:grid-cols-4'>
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.label} className='shadow-xs border-border/80'>
              <CardContent className='p-5'>
                <div className='flex items-center justify-between'>
                  <span className='text-xs font-medium text-muted-foreground'>
                    {stat.label}
                  </span>
                  <div className='flex size-8 items-center justify-center rounded-lg bg-muted/60'>
                    <Icon className={`size-4 ${stat.color}`} />
                  </div>
                </div>
                <div className='mt-4 font-mono text-3xl font-bold tracking-tight text-foreground'>
                  {isLoading ? '...' : String(stat.value).padStart(2, '0')}
                </div>
                <p className='mt-1 text-[11px] text-muted-foreground'>{stat.note}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Action Banners */}
      <div className='grid gap-4 lg:grid-cols-3'>
        <div className='lg:col-span-2 rounded-xl bg-primary p-6 text-primary-foreground flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm'>
          <div className='space-y-1.5 max-w-lg'>
            <div className='flex items-center gap-2'>
              <p className='font-mono text-[11px] font-semibold tracking-wider uppercase opacity-80'>
                Gate Desk / Quick Process
              </p>
              <Badge variant='outline' className='border-primary-foreground/30 text-primary-foreground text-[10px]'>
                Fast Track
              </Badge>
            </div>
            <h2 className='text-lg font-bold font-heading'>Truck Arrived at Gate?</h2>
            <p className='text-xs text-primary-foreground/80 leading-relaxed'>
              Record the supplier delivery challan, box count, and physical items to automatically cross-reference pending purchase orders.
            </p>
            <div className='pt-2'>
              <Button asChild variant='secondary' size='sm' className='h-8 text-xs font-semibold'>
                <Link to='/gate-entry/new'>
                  Create Inward Entry <ArrowRight className='ml-1.5 size-3.5' />
                </Link>
              </Button>
            </div>
          </div>
          <Truck className='hidden sm:block size-20 opacity-20 shrink-0' />
        </div>

        <Card className='flex flex-col justify-between p-6 shadow-xs border-border/80'>
          <div className='space-y-2'>
            <div className='flex items-center justify-between'>
              <p className='font-mono text-[11px] font-semibold tracking-wider uppercase text-primary'>
                Review Desk
              </p>
              <ShieldAlert className='size-4 text-amber-500' />
            </div>
            <h3 className='font-heading text-base font-bold'>Validation Queue</h3>
            <p className='text-xs text-muted-foreground leading-relaxed'>
              Verify physical delivery challans against purchase orders, tax rates, and E-Way bills before final approval.
            </p>
          </div>
          <div className='pt-4'>
            <Button asChild variant='outline' size='sm' className='w-full text-xs'>
              <Link to='/gate-validation'>
                Open Validation Desk <ArrowRight className='ml-1.5 size-3.5' />
              </Link>
            </Button>
          </div>
        </Card>
      </div>

      {/* Dynamic TanStack Table */}
      <Card className='shadow-xs border-border/80 overflow-hidden'>
        <CardContent className='p-6 space-y-4'>
          <div className='flex items-center justify-between'>
            <div>
              <h3 className='text-sm font-bold font-heading'>Factory Gate Inward Register</h3>
              <p className='text-xs text-muted-foreground mt-0.5'>
                Search and sort records by Gate Number, Supplier, DC Number, or Material description.
              </p>
            </div>
          </div>

          <DataTable
            columns={columns}
            data={filteredEntries}
            searchPlaceholder='Search by supplier, DC, PO, or material...'
            exportFilename={`gate-register-${new Date().toLocaleDateString('en-CA')}.csv`}
            filterElement={
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className='h-9 w-40 text-xs'>
                  <SelectValue placeholder='Status Filter' />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value='ALL' className='text-xs'>All Statuses</SelectItem>
                  <SelectItem value='Pending validation' className='text-xs'>Pending Validation</SelectItem>
                  <SelectItem value='Approved' className='text-xs'>Approved</SelectItem>
                  <SelectItem value='On hold' className='text-xs'>On Hold</SelectItem>
                </SelectContent>
              </Select>
            }
          />
        </CardContent>
      </Card>
    </div>
  )
}
