import { useNavigate, Link } from '@tanstack/react-router'
import { useForm } from '@tanstack/react-form'
import { toast } from 'sonner'
import {
  Check,
  ClipboardCheck,
  Barcode,
  Truck,
  FileText,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { PageHeader } from '@/components/patterns/page-header'
import { FormFieldWrapper } from '@/components/patterns/form-field'
import { useCreateGateEntryMutation } from '../api/gate-api'
import { CreateGateEntryInputSchema  } from '../types'
import type {CreateGateEntryInput} from '../types';

export function NewEntryForm() {
  const navigate = useNavigate()
  const createMutation = useCreateGateEntryMutation()

  const defaultValues: CreateGateEntryInput = {
    type: 'Purchase order',
    supplier: '',
    poNumber: '',
    dcNumber: '',
    dcDate: new Date().toLocaleDateString('en-CA'),
    vehicle: '',
    courier: '',
    boxes: 1,
    item: '',
    quantity: 1,
    weight: 0,
    taxRate: 18,
    ewayBillNo: '',
  }

  const form = useForm({
    defaultValues,
    onSubmit: async ({ value }) => {
      const parsed = CreateGateEntryInputSchema.safeParse(value)
      if (!parsed.success) {
        toast.error('Validation Error', {
          description: parsed.error.issues[0]?.message || 'Please fill in all required fields.',
        })
        return
      }

      try {
        const result = await createMutation.mutateAsync(parsed.data)
        toast.success('Gate Entry Registered Successfully!', {
          description: `Entry ${result.gateNo} generated. Lot barcode: ${result.lotBarcode}`,
        })
        navigate({ to: '/' })
      } catch (err: unknown) {
        toast.error('Failed to create gate entry', {
          description: err instanceof Error ? err.message : 'Please check the form fields and try again',
        })
      }
    },
  })

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Gate Operations / Inward Consignment'
        title='Material Inward Entry'
        description='Record incoming supplier delivery challans and physical materials. Entries are immediately queued for inspection.'
        badge='New Inward'
        actions={
          <Button asChild variant='outline' size='sm' className='h-9 text-xs'>
            <Link to='/'>Back to Register</Link>
          </Button>
        }
      />

      <form
        onSubmit={(e) => {
          e.preventDefault()
          e.stopPropagation()
          form.handleSubmit()
        }}
        className='grid gap-6 xl:grid-cols-[1fr_320px]'
      >
        <div className='space-y-6'>
          {/* Panel 1: Consignment & Supplier Details */}
          <Card className='shadow-xs border-border/80'>
            <CardHeader className='border-b border-border/60 pb-4'>
              <div className='flex items-center gap-2'>
                <div className='flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary'>
                  <Truck className='size-4' />
                </div>
                <div>
                  <CardTitle className='text-sm font-bold font-heading'>
                    01 / Delivery & Consignment Details
                  </CardTitle>
                  <CardDescription className='text-xs'>
                    Identify the carrier, vendor identity, and shipping document.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className='p-6'>
              <div className='grid gap-4 sm:grid-cols-2'>
                <form.Field name='type'>
                  {(field) => (
                    <FormFieldWrapper
                      label='Entry Type'
                      required
                    >
                      <Select
                        value={field.state.value}
                        onValueChange={(val) => field.handleChange(val as any)}
                      >
                        <SelectTrigger className='h-9 text-xs'>
                          <SelectValue placeholder='Select Type' />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value='Purchase order' className='text-xs'>Purchase Order (PO)</SelectItem>
                          <SelectItem value='OSP challan' className='text-xs'>OSP Processing Challan</SelectItem>
                          <SelectItem value='Non-PO courier' className='text-xs'>Non-PO Courier / Samples</SelectItem>
                          <SelectItem value='Direct delivery' className='text-xs'>Direct Plant Delivery</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field
                  name='supplier'
                  validators={{
                    onChange: ({ value }) => (!value.trim() ? 'Supplier name is required' : undefined),
                  }}
                >
                  {(field) => (
                    <FormFieldWrapper
                      label='Supplier / Vendor Name'
                      required
                      error={field.state.meta.errors[0] ? String(field.state.meta.errors[0]) : undefined}
                      hint='e.g., Apex Precision Castings Ltd'
                    >
                      <Input
                        value={field.state.value}
                        onChange={(e) => field.handleChange(e.target.value)}
                        placeholder='Enter vendor name'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field
                  name='dcNumber'
                  validators={{
                    onChange: ({ value }) => (!value.trim() ? 'DC number is required' : undefined),
                  }}
                >
                  {(field) => (
                    <FormFieldWrapper
                      label='Delivery Challan (DC) No'
                      required
                      error={field.state.meta.errors[0] ? String(field.state.meta.errors[0]) : undefined}
                    >
                      <Input
                        value={field.state.value}
                        onChange={(e) => field.handleChange(e.target.value)}
                        placeholder='e.g., DC-88291'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field
                  name='dcDate'
                  validators={{
                    onChange: ({ value }) => (!value ? 'DC date is required' : undefined),
                  }}
                >
                  {(field) => (
                    <FormFieldWrapper
                      label='Challan Date'
                      required
                      error={field.state.meta.errors[0] ? String(field.state.meta.errors[0]) : undefined}
                    >
                      <Input
                        type='date'
                        value={field.state.value}
                        onChange={(e) => field.handleChange(e.target.value)}
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field name='poNumber'>
                  {(field) => (
                    <FormFieldWrapper
                      label='PO / OSP Reference'
                      hint='Required for standard purchase order validation'
                    >
                      <Input
                        value={field.state.value}
                        onChange={(e) => field.handleChange(e.target.value)}
                        placeholder='e.g., PO-444-9921'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field name='ewayBillNo'>
                  {(field) => (
                    <FormFieldWrapper
                      label='E-Way Bill Number'
                      hint='Required for taxable goods exceeding INR 50,000'
                    >
                      <Input
                        value={field.state.value}
                        onChange={(e) => field.handleChange(e.target.value)}
                        placeholder='e.g., EWB-88192039128'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field name='vehicle'>
                  {(field) => (
                    <FormFieldWrapper label='Vehicle Number'>
                      <Input
                        value={field.state.value}
                        onChange={(e) => field.handleChange(e.target.value)}
                        placeholder='e.g., TN 09 BX 4412'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field name='courier'>
                  {(field) => (
                    <FormFieldWrapper label='Transporter / Courier Name'>
                      <Input
                        value={field.state.value}
                        onChange={(e) => field.handleChange(e.target.value)}
                        placeholder='e.g., Skyfast Logistics'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>
              </div>
            </CardContent>
          </Card>

          {/* Panel 2: Physical Material Details */}
          <Card className='shadow-xs border-border/80'>
            <CardHeader className='border-b border-border/60 pb-4'>
              <div className='flex items-center gap-2'>
                <div className='flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary'>
                  <FileText className='size-4' />
                </div>
                <div>
                  <CardTitle className='text-sm font-bold font-heading'>
                    02 / Material & Declared Quantity Details
                  </CardTitle>
                  <CardDescription className='text-xs'>
                    Enter the items received for warehouse physical inventory matching.
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className='p-6'>
              <div className='grid gap-4 sm:grid-cols-2'>
                <div className='sm:col-span-2'>
                  <form.Field
                    name='item'
                    validators={{
                      onChange: ({ value }) => (!value.trim() ? 'Item description is required' : undefined),
                    }}
                  >
                    {(field) => (
                      <FormFieldWrapper
                        label='Material Description / Part Number'
                        required
                        error={field.state.meta.errors[0] ? String(field.state.meta.errors[0]) : undefined}
                        hint='Full component description as declared on delivery challan'
                      >
                        <Input
                          value={field.state.value}
                          onChange={(e) => field.handleChange(e.target.value)}
                          placeholder='e.g., Cast Iron Clutch Housing Machined (CI-882)'
                          className='h-9 text-xs'
                        />
                      </FormFieldWrapper>
                    )}
                  </form.Field>
                </div>

                <form.Field
                  name='quantity'
                  validators={{
                    onChange: ({ value }) => (Number(value) <= 0 ? 'Quantity must be greater than 0' : undefined),
                  }}
                >
                  {(field) => (
                    <FormFieldWrapper
                      label='Received Quantity (Units)'
                      required
                      error={field.state.meta.errors[0] ? String(field.state.meta.errors[0]) : undefined}
                    >
                      <Input
                        type='number'
                        min='1'
                        step='any'
                        value={field.state.value}
                        onChange={(e) => field.handleChange(Number(e.target.value))}
                        placeholder='0'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field name='weight'>
                  {(field) => (
                    <FormFieldWrapper
                      label='Total Weight (kg)'
                      hint='Weighbridge or package scale gross reading'
                    >
                      <Input
                        type='number'
                        min='0'
                        step='any'
                        value={field.state.value}
                        onChange={(e) => field.handleChange(Number(e.target.value))}
                        placeholder='0.0'
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field name='boxes'>
                  {(field) => (
                    <FormFieldWrapper label='Number of Packages / Boxes' required>
                      <Input
                        type='number'
                        min='1'
                        step='1'
                        value={field.state.value}
                        onChange={(e) => field.handleChange(Number(e.target.value))}
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>

                <form.Field name='taxRate'>
                  {(field) => (
                    <FormFieldWrapper
                      label='PO Tax Rate (%)'
                      hint='Declared GST rate for supervisor review'
                    >
                      <Input
                        type='number'
                        min='0'
                        max='100'
                        step='any'
                        value={field.state.value}
                        onChange={(e) => field.handleChange(Number(e.target.value))}
                        className='h-9 text-xs'
                      />
                    </FormFieldWrapper>
                  )}
                </form.Field>
              </div>
            </CardContent>
          </Card>

          {/* Form Actions */}
          <div className='flex items-center justify-end gap-3 pt-2'>
            <Button asChild variant='outline' className='h-9 text-xs'>
              <Link to='/'>Cancel</Link>
            </Button>
            <Button
              type='submit'
              disabled={createMutation.isPending}
              className='h-9 text-xs font-semibold px-6'
            >
              <Check className='mr-1.5 size-4' />
              {createMutation.isPending ? 'Generating Gate Entry...' : 'Save & Register Inward'}
            </Button>
          </div>
        </div>

        {/* Sidebar Info & Barcode Preview */}
        <div className='space-y-6'>
          <Card className='shadow-xs border-border/80'>
            <CardHeader className='pb-3'>
              <div className='flex items-center gap-2'>
                <div className='flex size-8 items-center justify-center rounded-lg bg-primary/10 text-primary'>
                  <ClipboardCheck className='size-4' />
                </div>
                <div>
                  <CardTitle className='text-xs font-bold font-heading'>
                    Inward Workflow
                  </CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent className='space-y-4 text-xs text-muted-foreground'>
              <div className='border-l-2 border-primary/40 pl-3 space-y-1'>
                <p className='font-bold text-foreground'>1. Log Arrival</p>
                <p className='text-[11px] leading-relaxed'>
                  Capture Challan, vendor, and package count at factory security.
                </p>
              </div>
              <div className='border-l-2 border-border pl-3 space-y-1'>
                <p className='font-bold text-foreground'>2. Supervisor Review</p>
                <p className='text-[11px] leading-relaxed'>
                  Validation desk checks PO tax rate, E-way bill, and shortages.
                </p>
              </div>
              <div className='border-l-2 border-border pl-3 space-y-1'>
                <p className='font-bold text-foreground'>3. Lot Print & ERP Post</p>
                <p className='text-[11px] leading-relaxed'>
                  Approved lots generate ZPL barcode stickers and update Oracle.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className='shadow-xs border-border/80 bg-muted/20'>
            <CardHeader className='pb-2'>
              <div className='flex items-center gap-2'>
                <Barcode className='size-4 text-primary' />
                <CardTitle className='text-xs font-bold font-heading'>
                  Lot Barcode Generator
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className='space-y-2 text-[11px] text-muted-foreground'>
              <div className='rounded-lg border border-dashed border-border bg-card p-3 font-mono text-center'>
                <p className='text-[10px] text-muted-foreground uppercase'>Preview Stamp</p>
                <p className='font-bold text-xs text-primary mt-1'>
                  LOT-{new Date().getFullYear()}{String(new Date().getMonth() + 1).padStart(2, '0')}{String(new Date().getDate()).padStart(2, '0')}-XXX
                </p>
                <div className='mt-2 flex justify-center gap-0.5 opacity-60'>
                  {[...Array(24)].map((_, i) => (
                    <div
                      key={i}
                      className='bg-foreground'
                      style={{
                        width: (i % 3 === 0 ? 3 : i % 2 === 0 ? 2 : 1),
                        height: 24,
                      }}
                    />
                  ))}
                </div>
              </div>
              <p className='text-[10px] leading-tight text-center pt-1'>
                Automatically generated and assigned upon save.
              </p>
            </CardContent>
          </Card>
        </div>
      </form>
    </div>
  )
}
