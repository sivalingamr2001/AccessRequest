import { Link } from '@tanstack/react-router'
import { toast } from 'sonner'
import {
  CalendarCheck,
  Download,
  Lock,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldCheck,
  FileSpreadsheet,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { PageHeader } from '@/components/patterns/page-header'
import { useGateEntriesQuery, useEodSummaryQuery, useCloseEodMutation } from '../api/gate-api'
import { formatDate } from '@/lib/utils'

export function EodView() {
  const { data: entries = [] } = useGateEntriesQuery()
  const { data: eod, isLoading } = useEodSummaryQuery()
  const closeEodMutation = useCloseEodMutation()

  const todayStr = new Date().toDateString()
  const todayEntries = entries.filter(
    (e) => new Date(e.createdAt).toDateString() === todayStr
  )

  const handleExportTodayCsv = () => {
    if (!todayEntries.length) {
      toast.info('No Entries Recorded Today', {
        description: 'The gate register for today has no records to export yet.',
      })
      return
    }

    const headers = [
      'Gate Entry No',
      'Received At',
      'Supplier',
      'DC Number',
      'DC Date',
      'PO Number',
      'Item Description',
      'Quantity',
      'Weight (kg)',
      'Boxes',
      'Vehicle',
      'Transporter',
      'Tax Rate (%)',
      'E-Way Bill',
      'Status',
      'Hold Reason',
      'Lot Barcode',
    ]

    const rows = todayEntries.map((e) => [
      e.gateNo,
      e.createdAt,
      e.supplier,
      e.dcNumber,
      e.dcDate,
      e.poNumber,
      e.item,
      e.quantity,
      e.weight,
      e.boxes,
      e.vehicle,
      e.courier,
      e.taxRate,
      e.ewayBillNo,
      e.status,
      e.reason,
      e.lotBarcode || '',
    ])

    const csv = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\r\n')

    const blob = new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `gate-register-eod-${new Date().toLocaleDateString('en-CA')}.csv`
    link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)

    toast.success('Daily Register CSV Downloaded', {
      description: `Exported ${todayEntries.length} consignment records for ${new Date().toLocaleDateString()}.`,
    })
  }

  const handleCloseEod = async () => {
    try {
      await closeEodMutation.mutateAsync()
      toast.success('End of Day (EOD) Register Closed!', {
        description: 'Daily ledger locked. Inward transactions marked for Oracle ERP nightly batch synchronization.',
      })
    } catch {
      toast.error('Failed to close EOD register')
    }
  }

  const isClosed = eod?.status === 'CLOSED'

  return (
    <div className='space-y-6'>
      <PageHeader
        eyebrow='Tools & Logistics / Daily Closure'
        title='End of Day (EOD) Close'
        description='Reconcile daily material gate inward transactions, export audited CSV manifests, and perform daily ledger locking.'
        badge={isClosed ? 'EOD Closed' : 'EOD Open'}
        actions={
          <Button asChild variant='outline' size='sm' className='h-9 text-xs'>
            <Link to='/'>
              View Register <ArrowRight className='ml-1 size-3.5' />
            </Link>
          </Button>
        }
      />

      <div className='grid gap-4 sm:grid-cols-4'>
        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Today's Arrivals</span>
            <CalendarCheck className='size-4 text-primary' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-foreground'>
            {isLoading ? '...' : todayEntries.length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Material consignments logged</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Cleared & Approved</span>
            <CheckCircle2 className='size-4 text-emerald-600' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-emerald-600 dark:text-emerald-400'>
            {isLoading ? '...' : todayEntries.filter((e) => e.status === 'Approved').length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Ready for inventory receipt</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>Pending Validation</span>
            <Clock className='size-4 text-amber-500' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-amber-600 dark:text-amber-400'>
            {isLoading ? '...' : todayEntries.filter((e) => e.status === 'Pending validation').length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Requires supervisor review</p>
        </Card>

        <Card className='shadow-xs border-border/80 p-5'>
          <div className='flex items-center justify-between'>
            <span className='text-xs font-medium text-muted-foreground'>On Hold / Blocked</span>
            <AlertTriangle className='size-4 text-destructive' />
          </div>
          <p className='mt-3 font-mono text-3xl font-bold text-destructive'>
            {isLoading ? '...' : todayEntries.filter((e) => e.status === 'On hold').length}
          </p>
          <p className='text-[11px] text-muted-foreground mt-1'>Challan discrepancies noted</p>
        </Card>
      </div>

      <div className='grid gap-6 lg:grid-cols-[1fr_360px]'>
        {/* Main Reconciliation Details */}
        <Card className='shadow-xs border-border/80'>
          <CardHeader className='border-b border-border/60 pb-4'>
            <div className='flex items-center justify-between'>
              <div className='flex items-center gap-2'>
                <div className='flex size-7 items-center justify-center rounded-md bg-primary/10 text-primary'>
                  <FileSpreadsheet className='size-4' />
                </div>
                <div>
                  <CardTitle className='text-sm font-bold font-heading'>
                    Daily Inward Ledger — {new Date().toLocaleDateString(undefined, { dateStyle: 'full' })}
                  </CardTitle>
                  <CardDescription className='text-xs'>
                    Review all recorded lots before executing EOD transaction lock.
                  </CardDescription>
                </div>
              </div>

              {isClosed ? (
                <Badge className='bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 text-xs py-1 px-3 gap-1'>
                  <Lock className='size-3' /> Ledger Locked
                </Badge>
              ) : (
                <Badge variant='outline' className='text-xs py-1 px-3 text-primary border-primary/30 gap-1'>
                  <CalendarCheck className='size-3' /> Active Inward Session
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className='p-6 space-y-6'>
            <div className='rounded-lg border border-border/60 p-4 space-y-3 bg-muted/20 text-xs'>
              <h4 className='font-bold text-foreground text-sm font-heading'>Daily Summary Metrics</h4>
              <div className='grid gap-3 sm:grid-cols-2'>
                <div>
                  <span className='text-muted-foreground text-[11px]'>Total Gross Inward Weight</span>
                  <p className='font-mono font-bold text-sm text-foreground'>
                    {todayEntries.reduce((acc, c) => acc + (c.weight || 0), 0).toLocaleString()} kg
                  </p>
                </div>
                <div>
                  <span className='text-muted-foreground text-[11px]'>Total Consignment Packages</span>
                  <p className='font-mono font-bold text-sm text-foreground'>
                    {todayEntries.reduce((acc, c) => acc + (c.boxes || 0), 0)} boxes
                  </p>
                </div>
                <div>
                  <span className='text-muted-foreground text-[11px]'>Last Closed By</span>
                  <p className='font-medium text-xs text-foreground'>
                    {eod?.closedBy || 'Not closed yet'}
                  </p>
                </div>
                <div>
                  <span className='text-muted-foreground text-[11px]'>Closed Timestamp</span>
                  <p className='font-mono text-xs text-foreground'>
                    {eod?.closedAt ? formatDate(eod.closedAt) : 'Pending EOD action'}
                  </p>
                </div>
              </div>
            </div>

            <div className='flex flex-wrap items-center gap-3 pt-2'>
              <Button
                variant='outline'
                onClick={handleExportTodayCsv}
                className='h-9 text-xs'
              >
                <Download className='mr-1.5 size-4' />
                Download Today's CSV Register
              </Button>

              <Button
                onClick={handleCloseEod}
                disabled={closeEodMutation.isPending || isClosed}
                className='h-9 text-xs font-semibold'
              >
                <Lock className='mr-1.5 size-4' />
                {isClosed ? 'EOD Already Closed' : 'Execute Formal EOD Close & Lock'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Sidebar Info */}
        <div className='space-y-4'>
          <Card className='shadow-xs border-border/80 p-5 space-y-3'>
            <div className='flex items-center gap-2 text-primary font-bold text-xs font-heading'>
              <ShieldCheck className='size-4' />
              EOD Close Checklist
            </div>
            <div className='space-y-2.5 text-xs text-muted-foreground'>
              <div className='flex items-start gap-2'>
                <CheckCircle2 className='size-3.5 text-emerald-600 shrink-0 mt-0.5' />
                <span>All physical delivery challans accounted for in file cabinet.</span>
              </div>
              <div className='flex items-start gap-2'>
                <CheckCircle2 className='size-3.5 text-emerald-600 shrink-0 mt-0.5' />
                <span>Lots on hold documented with non-conformance reports.</span>
              </div>
              <div className='flex items-start gap-2'>
                <CheckCircle2 className='size-3.5 text-emerald-600 shrink-0 mt-0.5' />
                <span>ZPL barcode stickers verified and affixed to pallets.</span>
              </div>
              <div className='flex items-start gap-2'>
                <CheckCircle2 className='size-3.5 text-emerald-600 shrink-0 mt-0.5' />
                <span>Accounts e-way bill reconciliation batch prepared.</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
