import { describe, expect, it } from 'vitest'
import { processGateAiQuery } from './gate-ai-assistant'

describe('processGateAiQuery', () => {
  it('processes shortage queries and returns critical shortages', async () => {
    const response = await processGateAiQuery('Show me critical shortages')
    expect(response.role).toBe('assistant')
    expect(response.content).toContain('Job Shortage Monitor')
    expect(response.metadata?.type).toBe('shortage')
  })

  it('processes ASN reconciliation queries', async () => {
    const response = await processGateAiQuery('Check ASN status')
    expect(response.role).toBe('assistant')
    expect(response.content).toContain('Advance Shipping Notice')
    expect(response.metadata?.type).toBe('asn')
  })

  it('processes EOD queries', async () => {
    const response = await processGateAiQuery('What is the EOD summary?')
    expect(response.role).toBe('assistant')
    expect(response.content).toContain('Daily Gate Register Summary')
    expect(response.metadata?.type).toBe('eod')
  })

  it('handles general queries gracefully', async () => {
    const response = await processGateAiQuery('Hello, what can you do?')
    expect(response.role).toBe('assistant')
    expect(response.content).toContain('GateFlow AI Assistant')
  })
})
