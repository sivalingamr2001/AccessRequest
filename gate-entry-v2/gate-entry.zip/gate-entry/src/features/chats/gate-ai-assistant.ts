import { fetchGateEntries, fetchJobShortages, fetchAsnNotices, fetchEodSummary } from '@/features/gate/api/gate-api'

export interface AiChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: string
  metadata?: {
    type?: 'entry' | 'shortage' | 'asn' | 'eod' | 'action'
    data?: unknown
    suggestedActions?: { label: string; action: string; targetUrl?: string }[]
  }
}

export async function processGateAiQuery(query: string): Promise<AiChatMessage> {
  const lower = query.toLowerCase().trim()
  const timestamp = new Date().toISOString()
  const id = `ai-msg-${Date.now()}`

  // 1. Gate Entry Lookup
  if (lower.includes('ge-') || lower.includes('gate no') || lower.includes('entry') || lower.includes('status of')) {
    const entries = await fetchGateEntries()
    const matched = entries.find((e) => lower.includes(e.gateNo.toLowerCase()) || lower.includes(e.supplier.toLowerCase()))

    if (matched) {
      return {
        id,
        role: 'assistant',
        content: `**Gate Entry Found: ${matched.gateNo}**\n\n- **Supplier**: ${matched.supplier}\n- **DC Number**: ${matched.dcNumber} (Date: ${matched.dcDate})\n- **PO / Ref**: ${matched.poNumber || 'None'}\n- **Material**: ${matched.item}\n- **Quantity**: ${matched.quantity} (Weight: ${matched.weight} kg)\n- **Status**: **${matched.status}** ${matched.status === 'On hold' ? `(Reason: ${matched.reason})` : ''}\n- **Lot Barcode**: \`${matched.lotBarcode || 'Generated on approval'}\``,
        timestamp,
        metadata: {
          type: 'entry',
          data: matched,
          suggestedActions: [
            { label: 'Review in Validation Desk', action: 'navigate', targetUrl: `/gate-validation?entry=${matched.id}` },
            { label: 'Print Barcode Sticker', action: 'navigate', targetUrl: `/barcode?entry=${matched.id}` },
          ],
        },
      }
    }
  }

  // 2. Job Shortages Lookup
  if (lower.includes('shortage') || lower.includes('po block') || lower.includes('blocked') || lower.includes('critical')) {
    const shortages = await fetchJobShortages()
    const critical = shortages.filter((s) => s.priority === 'CRITICAL' || s.status === 'BLOCKED')

    return {
      id,
      role: 'assistant',
      content: `**Job Shortage Monitor (PO Block Audit)**\n\nFound **${critical.length} critical material shortages** affecting active assembly lines:\n\n${critical
        .map(
          (s) =>
            `- ⚠️ **${s.itemCode}** (${s.itemName}): Shortage of **${s.shortageQty} units** for ${s.productionLine}. Tied to ${s.poNumber} (${s.supplier}). Status: **${s.status}**.`
        )
        .join('\n')}\n\n*Gate Entry recommendation: Prioritize inward validation when trucks bearing these POs arrive at the gate.*`,
      timestamp,
      metadata: {
        type: 'shortage',
        data: critical,
        suggestedActions: [
          { label: 'Open Job Shortages Dashboard', action: 'navigate', targetUrl: '/shortages' },
          { label: 'Create Material Inward', action: 'navigate', targetUrl: '/gate-entry/new' },
        ],
      },
    }
  }

  // 3. ASN / ADI Verification
  if (lower.includes('asn') || lower.includes('adi') || lower.includes('advance shipping') || lower.includes('exemption')) {
    const asns = await fetchAsnNotices()
    return {
      id,
      role: 'assistant',
      content: `**Advance Shipping Notice (ADI / SCM Server) Status**\n\nActive ASNs synced from SQL Server gateway:\n\n${asns
        .map(
          (a) =>
            `- **${a.asnNumber}** (${a.supplier}): ${a.itemCount} items, Vehicle: ${a.vehicleNo}. Status: **${a.status}** [Exemption: ${a.exemptionStatus}]`
        )
        .join('\n')}\n\n*Suppliers marked \`EXEMPT\` may proceed without manual ADI download approval.*`,
      timestamp,
      metadata: {
        type: 'asn',
        data: asns,
        suggestedActions: [
          { label: 'Open ASN Reconciliation Desk', action: 'navigate', targetUrl: '/asn' },
        ],
      },
    }
  }

  // 4. EOD Close & Summary
  if (lower.includes('eod') || lower.includes('close') || lower.includes('summary') || lower.includes('today')) {
    const eod = await fetchEodSummary()
    return {
      id,
      role: 'assistant',
      content: `**Daily Gate Register Summary (${eod.date})**\n\n- **Total Receipts**: ${eod.totalEntries}\n- **Approved & Inward Cleared**: ${eod.approvedCount}\n- **Placed On Hold**: ${eod.onHoldCount}\n- **Pending Validation**: ${eod.pendingCount}\n- **Gross Inward Weight**: ${eod.totalWeightKg.toLocaleString()} kg\n- **EOD Register State**: **${eod.status}** ${eod.closedAt ? `(Closed at ${new Date(eod.closedAt).toLocaleTimeString()})` : '(Open for new arrivals)'}`,
      timestamp,
      metadata: {
        type: 'eod',
        data: eod,
        suggestedActions: [
          { label: 'Go to EOD Close Desk', action: 'navigate', targetUrl: '/eod' },
          { label: 'View Gate Register', action: 'navigate', targetUrl: '/' },
        ],
      },
    }
  }

  // Default assistance
  return {
    id,
    role: 'assistant',
    content: `I am your **GateFlow AI Assistant**, connected to your factory ERP, gate registers, and Oracle inventory bridge.\n\nYou can ask me to:\n- **Verify Gate Entries**: *"Check status of GE-20260930-7481"* or *"Find deliveries from Apex Precision"*\n- **Audit Job Shortages**: *"Show critical PO blocks and shortages"*\n- **Review ASN / ADI**: *"Check Advance Shipping Notices and exemption status"*\n- **EOD Metrics**: *"What is today's inward summary?"*\n- **Validation Assistance**: *"Draft hold reason for missing e-way bill"*`,
    timestamp,
    metadata: {
      type: 'action',
      suggestedActions: [
        { label: 'Check Critical Shortages', action: 'prompt', targetUrl: 'Show critical shortages' },
        { label: 'Today\'s Inward Summary', action: 'prompt', targetUrl: 'Summarize today\'s gate activity' },
        { label: 'Lookup ASN Notices', action: 'prompt', targetUrl: 'Check ASN notices' },
      ],
    },
  }
}
