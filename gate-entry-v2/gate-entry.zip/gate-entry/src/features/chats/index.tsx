import { useState, useRef, useEffect } from 'react'
import {
  Send,
  Bot,
  User,
  Sparkles,
  RefreshCw,
  ExternalLink,
  ShieldAlert,
  Package,
  CalendarCheck,
  ScanLine,
} from 'lucide-react'
import { Link } from '@tanstack/react-router'
import { Header } from '@/layout/header'
import { Main } from '@/layout/main'
import { ProfileDropdown } from '@/components/profile-dropdown'
import { Search } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { ConfigDrawer } from '@/components/config-drawer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Card, CardContent } from '@/components/ui/card'
import {
  
  processGateAiQuery
} from './gate-ai-assistant'
import type {AiChatMessage} from './gate-ai-assistant';

const INITIAL_MESSAGES: AiChatMessage[] = [
  {
    id: 'intro',
    role: 'assistant',
    content:
      '👋 Hello! I am your **GateFlow AI Assistant**.\n\nI monitor incoming factory deliveries, ERP purchase orders, material shortages, and SQL Server ASN notices in real-time.\n\nHow can I help streamline your gate operations today?',
    timestamp: new Date().toISOString(),
    metadata: {
      suggestedActions: [
        { label: 'Check Critical Shortages', action: 'prompt', targetUrl: 'Show critical shortages' },
        { label: "Today's Inward Summary", action: 'prompt', targetUrl: "Summarize today's gate activity" },
        { label: 'Verify ASN Notices', action: 'prompt', targetUrl: 'Check ASN notices' },
        { label: 'Lookup Entry GE-20260930-7481', action: 'prompt', targetUrl: 'Check status of GE-20260930-7481' },
      ],
    },
  },
]

export function Chats() {
  const [messages, setMessages] = useState<AiChatMessage[]>(INITIAL_MESSAGES)
  const [input, setInput] = useState('')
  const [isThinking, setIsThinking] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isThinking])

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || input
    if (!textToSend.trim() || isThinking) return

    const userMessage: AiChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toISOString(),
    }

    setMessages((prev) => [...prev, userMessage])
    if (!queryText) setInput('')
    setIsThinking(true)

    try {
      const response = await processGateAiQuery(textToSend)
      setMessages((prev) => [...prev, response])
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          content: 'Sorry, I encountered an issue accessing the gate register. Please try again.',
          timestamp: new Date().toISOString(),
        },
      ])
    } finally {
      setIsThinking(false)
    }
  }

  return (
    <>
      <Header>
        <Search className='me-auto' />
        <ThemeSwitch />
        <ConfigDrawer />
        <ProfileDropdown />
      </Header>

      <Main fixed fluid>
        <div className='flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card shadow-xs'>
          {/* Header */}
          <div className='flex items-center justify-between border-b border-border bg-muted/30 px-6 py-4'>
            <div className='flex items-center gap-3'>
              <div className='flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary'>
                <Bot className='size-5' />
              </div>
              <div>
                <div className='flex items-center gap-2'>
                  <h2 className='text-sm font-bold text-foreground font-heading'>
                    GateFlow AI Assistant
                  </h2>
                  <Badge variant='outline' className='text-[10px] uppercase font-mono tracking-wider text-primary border-primary/30'>
                    TanStack AI Engine
                  </Badge>
                </div>
                <p className='text-xs text-muted-foreground'>
                  Autonomous factory gate validation, shortages cross-referencing & ERP bridge
                </p>
              </div>
            </div>

            <Button
              variant='outline'
              size='sm'
              onClick={() => setMessages(INITIAL_MESSAGES)}
              className='h-8 text-xs'
            >
              <RefreshCw className='mr-1.5 size-3.5' />
              Reset Session
            </Button>
          </div>

          {/* Quick Shortcuts Bar */}
          <div className='flex items-center gap-2 overflow-x-auto border-b border-border/60 bg-muted/10 px-6 py-2'>
            <span className='flex items-center gap-1 text-[11px] font-semibold text-muted-foreground shrink-0'>
              <Sparkles className='size-3 text-primary' /> Quick Queries:
            </span>
            <button
              type='button'
              onClick={() => handleSend('Show critical job shortages')}
              className='inline-flex items-center gap-1 rounded-full border border-border bg-background px-3 py-1 text-[11px] text-foreground hover:bg-muted transition-colors shrink-0'
            >
              <ShieldAlert className='size-3 text-amber-500' />
              Critical Shortages
            </button>
            <button
              type='button'
              onClick={() => handleSend("Summarize today's gate activity")}
              className='inline-flex items-center gap-1 rounded-full border border-border bg-background px-3 py-1 text-[11px] text-foreground hover:bg-muted transition-colors shrink-0'
            >
              <CalendarCheck className='size-3 text-emerald-500' />
              Today's Inward
            </button>
            <button
              type='button'
              onClick={() => handleSend('Check ASN notices and exemptions')}
              className='inline-flex items-center gap-1 rounded-full border border-border bg-background px-3 py-1 text-[11px] text-foreground hover:bg-muted transition-colors shrink-0'
            >
              <ScanLine className='size-3 text-blue-500' />
              ASN Status
            </button>
            <button
              type='button'
              onClick={() => handleSend('Show delivery for Apex Precision')}
              className='inline-flex items-center gap-1 rounded-full border border-border bg-background px-3 py-1 text-[11px] text-foreground hover:bg-muted transition-colors shrink-0'
            >
              <Package className='size-3 text-primary' />
              Apex Deliveries
            </button>
          </div>

          {/* Chat Messages */}
          <ScrollArea className='flex-1 p-6'>
            <div className='space-y-6 max-w-4xl mx-auto'>
              {messages.map((message) => {
                const isAssistant = message.role === 'assistant'
                return (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${isAssistant ? 'justify-start' : 'justify-end'}`}
                  >
                    {isAssistant && (
                      <Avatar className='size-8 shrink-0 bg-primary/10 border border-primary/20'>
                        <AvatarFallback className='text-primary text-xs font-bold'>
                          AI
                        </AvatarFallback>
                      </Avatar>
                    )}

                    <div
                      className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed space-y-3 ${
                        isAssistant
                          ? 'bg-muted/40 border border-border text-foreground'
                          : 'bg-primary text-primary-foreground font-medium'
                      }`}
                    >
                      <div className='whitespace-pre-wrap'>{message.content}</div>

                      {/* Suggested Actions within messages */}
                      {message.metadata?.suggestedActions && (
                        <div className='flex flex-wrap gap-2 pt-2 border-t border-border/50'>
                          {message.metadata.suggestedActions.map((action, idx) => {
                            if (action.action === 'navigate' && action.targetUrl) {
                              return (
                                <Button
                                  key={idx}
                                  variant='secondary'
                                  size='sm'
                                  className='h-7 text-[11px]'
                                  asChild
                                >
                                  <Link to={action.targetUrl}>
                                    <ExternalLink className='mr-1 size-3' />
                                    {action.label}
                                  </Link>
                                </Button>
                              )
                            }
                            return (
                              <Button
                                key={idx}
                                variant='outline'
                                size='sm'
                                className='h-7 text-[11px]'
                                onClick={() => handleSend(action.targetUrl || action.label)}
                              >
                                {action.label}
                              </Button>
                            )
                          })}
                        </div>
                      )}

                      <div
                        className={`text-[10px] ${
                          isAssistant ? 'text-muted-foreground' : 'text-primary-foreground/70'
                        }`}
                      >
                        {new Date(message.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>

                    {!isAssistant && (
                      <Avatar className='size-8 shrink-0 bg-secondary border border-border'>
                        <AvatarFallback className='text-secondary-foreground text-xs font-bold'>
                          <User className='size-4' />
                        </AvatarFallback>
                      </Avatar>
                    )}
                  </div>
                )
              })}

              {isThinking && (
                <div className='flex gap-3 items-center text-xs text-muted-foreground animate-pulse'>
                  <Avatar className='size-8 bg-primary/10 border border-primary/20'>
                    <AvatarFallback className='text-primary text-xs font-bold'>
                      AI
                    </AvatarFallback>
                  </Avatar>
                  <Card className='p-3 bg-muted/40 border-border'>
                    <CardContent className='p-0 flex items-center gap-2'>
                      <Sparkles className='size-3.5 text-primary animate-spin' />
                      <span>GateFlow AI is cross-referencing gate registers and ERP PO lines...</span>
                    </CardContent>
                  </Card>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
          </ScrollArea>

          {/* Input Box */}
          <div className='border-t border-border bg-background p-4'>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                handleSend()
              }}
              className='flex items-center gap-3 max-w-4xl mx-auto'
            >
              <Input
                placeholder='Ask GateFlow AI: "Check status of GE-20260930-7481", "Show PO shortages", "Verify ASN"...'
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={isThinking}
                className='h-11 text-xs bg-muted/30 focus-visible:bg-background'
              />
              <Button type='submit' disabled={isThinking || !input.trim()} className='h-11 px-5'>
                <Send className='size-4 mr-1.5' />
                Send
              </Button>
            </form>
          </div>
        </div>
      </Main>
    </>
  )
}
