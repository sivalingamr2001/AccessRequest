import React, { createContext, useContext, useEffect, useState } from 'react'

export type Theme = 'dark' | 'light' | 'system'
export type ThemeColor =
  | 'blue'
  | 'zinc'
  | 'slate'
  | 'violet'
  | 'green'
  | 'orange'
  | 'rose'
  | 'yellow'
  | 'red'

export type FontBody =
  | 'figtree'
  | 'inter'
  | 'jakarta'
  | 'outfit'
  | 'roboto'
  | 'mono'

export type FontHeading =
  | 'mono'
  | 'figtree'
  | 'inter'
  | 'jakarta'
  | 'outfit'
  | 'roboto'

interface ThemeContextType {
  theme: Theme
  setTheme: (theme: Theme) => void
  defaultTheme: Theme
  resetTheme: () => void

  color: ThemeColor
  setColor: (color: ThemeColor) => void
  defaultColor: ThemeColor

  fontBody: FontBody
  setFontBody: (font: FontBody) => void
  defaultFontBody: FontBody

  fontHeading: FontHeading
  setFontHeading: (font: FontHeading) => void
  defaultFontHeading: FontHeading

  resetAll: () => void
}

const DEFAULT_THEME: Theme = 'system'
const DEFAULT_COLOR: ThemeColor = 'blue'
const DEFAULT_FONT_BODY: FontBody = 'figtree'
const DEFAULT_FONT_HEADING: FontHeading = 'mono'

const STORAGE_THEME_KEY = 'vite-ui-theme'
const STORAGE_COLOR_KEY = 'vite-ui-color'
const STORAGE_FONT_BODY_KEY = 'vite-ui-font-body'
const STORAGE_FONT_HEADING_KEY = 'vite-ui-font-heading'

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({
  children,
  defaultTheme = DEFAULT_THEME,
  defaultColor = DEFAULT_COLOR,
  defaultFontBody = DEFAULT_FONT_BODY,
  defaultFontHeading = DEFAULT_FONT_HEADING,
}: {
  children: React.ReactNode
  defaultTheme?: Theme
  defaultColor?: ThemeColor
  defaultFontBody?: FontBody
  defaultFontHeading?: FontHeading
}) {
  const [theme, setThemeState] = useState<Theme>(() => {
    if (typeof window === 'undefined') return defaultTheme
    const stored = localStorage.getItem(STORAGE_THEME_KEY) as Theme | null
    return stored ?? defaultTheme
  })

  const [color, setColorState] = useState<ThemeColor>(() => {
    if (typeof window === 'undefined') return defaultColor
    const stored = localStorage.getItem(STORAGE_COLOR_KEY) as ThemeColor | null
    return stored ?? defaultColor
  })

  const [fontBody, setFontBodyState] = useState<FontBody>(() => {
    if (typeof window === 'undefined') return defaultFontBody
    const stored = localStorage.getItem(STORAGE_FONT_BODY_KEY) as FontBody | null
    return stored ?? defaultFontBody
  })

  const [fontHeading, setFontHeadingState] = useState<FontHeading>(() => {
    if (typeof window === 'undefined') return defaultFontHeading
    const stored = localStorage.getItem(STORAGE_FONT_HEADING_KEY) as FontHeading | null
    return stored ?? defaultFontHeading
  })

  // Theme application
  useEffect(() => {
    const root = window.document.documentElement
    root.classList.remove('light', 'dark')

    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light'
      root.classList.add(systemTheme)
    } else {
      root.classList.add(theme)
    }
  }, [theme])

  // Color application
  useEffect(() => {
    const root = window.document.documentElement
    root.setAttribute('data-color', color)
  }, [color])

  // Font applications
  useEffect(() => {
    const root = window.document.documentElement
    root.setAttribute('data-font-body', fontBody)
  }, [fontBody])

  useEffect(() => {
    const root = window.document.documentElement
    root.setAttribute('data-font-heading', fontHeading)
  }, [fontHeading])

  const setTheme = (newTheme: Theme) => {
    localStorage.setItem(STORAGE_THEME_KEY, newTheme)
    setThemeState(newTheme)
  }

  const setColor = (newColor: ThemeColor) => {
    localStorage.setItem(STORAGE_COLOR_KEY, newColor)
    setColorState(newColor)
  }

  const setFontBody = (newFont: FontBody) => {
    localStorage.setItem(STORAGE_FONT_BODY_KEY, newFont)
    setFontBodyState(newFont)
  }

  const setFontHeading = (newFont: FontHeading) => {
    localStorage.setItem(STORAGE_FONT_HEADING_KEY, newFont)
    setFontHeadingState(newFont)
  }

  const resetTheme = () => {
    setTheme(defaultTheme)
  }

  const resetAll = () => {
    setTheme(defaultTheme)
    setColor(defaultColor)
    setFontBody(defaultFontBody)
    setFontHeading(defaultFontHeading)
  }

  return (
    <ThemeContext.Provider
      value={{
        theme,
        setTheme,
        defaultTheme,
        resetTheme,
        color,
        setColor,
        defaultColor,
        fontBody,
        setFontBody,
        defaultFontBody,
        fontHeading,
        setFontHeading,
        defaultFontHeading,
        resetAll,
      }}
    >
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}
