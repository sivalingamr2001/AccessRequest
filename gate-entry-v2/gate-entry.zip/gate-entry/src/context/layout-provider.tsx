import { createContext, useContext, useState  } from 'react'
import type {ReactNode} from 'react';
import { getCookie, setCookie } from '@/lib/cookies'

export type Collapsible = 'default' | 'icon' | 'offcanvas'
export type Variant = 'inset' | 'floating' | 'sidebar'

interface LayoutContextType {
  collapsible: Collapsible
  setCollapsible: (val: Collapsible) => void
  defaultCollapsible: Collapsible
  variant: Variant
  setVariant: (val: Variant) => void
  defaultVariant: Variant
  resetLayout: () => void
}

const DEFAULT_COLLAPSIBLE: Collapsible = 'icon'
const DEFAULT_VARIANT: Variant = 'inset'

const LayoutContext = createContext<LayoutContextType | undefined>(undefined)

export function LayoutProvider({ children }: { children: ReactNode }) {
  const [collapsible, setCollapsibleState] = useState<Collapsible>(() => {
    const val = getCookie('layout_collapsible') as Collapsible | null
    return val ?? DEFAULT_COLLAPSIBLE
  })

  const [variant, setVariantState] = useState<Variant>(() => {
    const val = getCookie('layout_variant') as Variant | null
    return val ?? DEFAULT_VARIANT
  })

  const setCollapsible = (val: Collapsible) => {
    setCollapsibleState(val)
    setCookie('layout_collapsible', val)
  }

  const setVariant = (val: Variant) => {
    setVariantState(val)
    setCookie('layout_variant', val)
  }

  const resetLayout = () => {
    setCollapsible(DEFAULT_COLLAPSIBLE)
    setVariant(DEFAULT_VARIANT)
  }

  return (
    <LayoutContext.Provider
      value={{
        collapsible,
        setCollapsible,
        defaultCollapsible: DEFAULT_COLLAPSIBLE,
        variant,
        setVariant,
        defaultVariant: DEFAULT_VARIANT,
        resetLayout,
      }}
    >
      {children}
    </LayoutContext.Provider>
  )
}

export function useLayout() {
  const context = useContext(LayoutContext)
  if (!context) {
    throw new Error('useLayout must be used within a LayoutProvider')
  }
  return context
}
