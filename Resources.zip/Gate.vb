Imports System.IO
Imports oracleclass
Imports System.Data.OracleClient
Imports System.ComponentModel

Public Class Gate
    Dim s, a, b, c, gdt As String
    '  Dim cl.ds As New DataSet

    Dim i, invno, j, k, a1, d, Z As Integer
    Dim dr As DialogResult
    Dim cc, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17, c18, c19, c20 As New DataGridViewTextBoxColumn
    Dim chkBox As CheckBox
    Dim CH As DataGridViewCheckBoxColumn
    Dim cl As New oracleclass.Class1
    Private WithEvents CHK As DataGridViewCheckBoxColumn

    Private Sub Gate_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed

        End
    End Sub

    Private Sub Gate_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If OP_ID = 103 Then job_shrt.Visible = True
        'userid = Environment.GetCommandLineArgs(1)
        'swid = Environment.GetCommandLineArgs(2)

        'orgid = Environment.GetCommandLineArgs(3)
        'opid = Environment.GetCommandLineArgs(4)
        'unit = Environment.GetCommandLineArgs(5)
        'role = Environment.GetCommandLineArgs(6)

        ''userid = Environment.GetCommandLineArgs(1)
        ''swid = 161
        ''orgid = "444,464,484,504,524,505,384"

        'cl.sql = " Select  C.cl.oraconTROL_DETAIL,PARAMETER_VALUE From JAN_SW_LINES L,JAN_SW_USER_cl.oraconTROLS C, JAN_SW_USER_PARAMETERS P Where L.USERID = c.USERID And L.SW_HEADER_ID = c.SW_HEADER_ID And P.SW_HEADER_ID = L.SW_HEADER_ID And P.USERID = L.USERID And L.USERID = " & userid & " And L.SW_HEADER_ID = " & swid & " "

        'cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        'cl.ds = New DataSet
        'cl.oradap.Fill(cl.ds, "resultab")
        ''Login.txtuser.Text = txtlog.Text


        'For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
        '    With cl.ds.Tables("resultab").Rows(i)
        '        cl.oracontrol = .Item(1)
        '        If .Item(1) = "VIEW" Then
        '            btnadd.Enabled = False ' Gate.btnvou.Enabled = False
        '            btnreport.Visible = True
        '            txtrole.Text = "USER" : mmcarcl.ds.Visible = True : btncan.Enabled = False
        '            linkpwd.Visible = False : btndel.Enabled = False
        '            suplist.rdadi.Enabled = False : suplist.sealed.Enabled = False : suplist.btncan.Enabled = False

        '            If .Item(1) = "ALL" Then
        '                mmcarcl.ds.Visible = True

        '                '  Gate.txtlog.Text = txtuser.Text : Gate.txtrole.Text = c
        '                'Gate.btnrtv.Location = New System.Drawing.Point(554, 196) : Gate.btnrtv.Visible = True
        '                ' Gate.btnxs.Visible = True
        '                btncan.Enabled = True
        '                btnnonpo.Visible = True
        '                ADI.Visible = True : UNBLOCK.Visible = True : lbupdt.Visible = True
        '                btn_auto_receipt.Visible = True
        '            End If

        '        End If
        '    End With
        'Next

        '    

        '       

        'If Login.txtuser.Text = "JAN_SKY" Then
        '    Label5.Text = "GATE REGISTER - SKY FAST"
        'Else
        '    Label5.Text = "GATE REGISTER - JANATICS"
        'End If

        Try
            Me.Top = 0
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "GATE ENTRY")
        End Try
        Me.StartPosition = FormStartPosition.CenterScreen
        Try
            sql = "select REPLACE(vendor_name,'''','''''')supplier,vendor_id from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' AND END_DATE_ACTIVE IS NULL "


            sql &= " AND VENDOR_ID IN (SELECT VENDOR_ID FROM PO_vENDOR_SITES_ALL WHERE ORG_ID=" & OP_ID & " AND INACTIVE_DATE IS NULL ) ORDER BY VENDOR_NAME "

            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            cl.ds = New DataSet
            cl.oradap.Fill(cl.ds, "resultab")
            For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
                cmbsup.Items.Add(cl.ds.Tables("resultab").Rows(i).Item("supplier"))
            Next
            cl.sql = "select organization_code  from org_organization_definitions where organization_id in (" & orgid & " ) order by organization_code"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            cl.ds = New DataSet
            cl.oradap.Fill(cl.ds, "resultab")
            For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
                cmborg.Items.Add(cl.ds.Tables("resultab").Rows(i).Item("organization_code"))
            Next

            cl.sql = "SELECT REA_NAME FROM JAN_GATE_REASON WHERE REA_CODE IN (42,43,44,45,46)"

            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            cl.ds = New DataSet
            cl.oradap.Fill(cl.ds, "resultab")
            For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
                TXTREF.Items.Add(cl.ds.Tables("resultab").Rows(i).Item("REA_NAME"))
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        cmbval.SelectedItem = "All"
        '' btngo_Click(sender, e)
        'cl.sql = "select adi_chk from jan_check_adi"
        'cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        'cl.ds = New DataSet
        'cl.oradap.Fill(cl.ds, "adi_chk")
        'If cl.ds.Tables("adi_chk").Rows(0).Item("adi_chk") = 0 Then
        '    but_val_adi.Text = "ADI Enabled"
        'Else
        '    but_val_adi.Text = "ADI Disabled"
        'End If
        'If txtrole.Text = "ADD" Or txtrole.Text = "ADD1" Or txtrole.Text = "ADD2" Then
        '    cl.sql = "SELECT COUNT(*)CNT,TO_CHAR(JAN_FYR_DATE,'yyyy')||1 YR FROM DUAL WHERE SYSDATE  BETWEEN JAN_FYR_DATE AND JAN_FYR_END_DATE"
        '    cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        '    cl.ds = New DataSet
        '    cl.oradap.Fill(cl.ds, "DT")

        '    If cl.ds.Tables("DT").Rows(0).Item(0) = 1 Then
        '        txtinw.Text = cl.ds.Tables("DT").Rows(0).Item(1)
        '    End If

        'End If
    End Sub

    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Try
            cl.ds.Clear()
            cl.ds.Dispose()
            Me.Cursor = Cursors.WaitCursor
            ' dgv1.Columns.Clear()
            dgv.Columns.Clear()
            'Commeneted by Sangeetha.T on 13-AUG-2020 13:42 PM (added supplier site cl.oracondition in gst column - faced single row sub query error)-

            'cl.sql = "select distinct a.gate_no,a.supplier_name,a.supplier_site,(select registration_number from  JAN_GST_REG_DETAILS_VIEW where PARTY_CLASS_NAME='Supplier' AND REGISTRATION_TYPE_CODE='GSTIN' and org_id=103 and party_id=a.vendor_id )gst, a.gdate,a.dc_no,a.dc_Date,A.VALIDATED,"

            cl.sql = "select   a.gate_no,a.gdate,a.supplier_name,a.supplier_site,(select registration_number from  JAN_GST_REG_DETAILS_VIEW where PARTY_CLASS_NAME='Supplier' AND REGISTRATION_TYPE_CODE='GSTIN' and rownum=1   "

            'ADDED on 28-nov-2020
            If opid <> "" Then
                cl.sql &= " And org_id = " & opid & " "
            Else
                cl.sql &= " And org_id = 103 "

            End If

            cl.sql &= " And party_id=a.vendor_id  And PARTY_SITE_ID=(Select VENDOR_SITE_ID FROM PO_VENDOR_SITES_ALL WHERE VENDOR_SITE_CODE=A.SUPPLIER_SITE And inactive_Date Is null "

            'ADDED on 28-nov-2020
            If opid <> "" Then
                cl.sql &= " And org_id=" & opid & " "
            Else
                cl.sql &= " And org_id = 103 "
            End If

            cl.sql &= " And vendor_id=a.vendor_id))gst, a.dc_no,a.dc_Date,A.VALIDATED,"


            cl.sql &= "(Case When (Select DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,"

            cl.sql &= " DECODE(A.VALIDATED,'0','VALIDATED','1','GATE','2','NOT VALIDATED','3','ACTION TAKEN','4','RTV','5','CANCEL ENTRY','6','No Reference')STATUS,(Select max(reaSON_dATE) rea_dt from jan_gatE_nval_reason where gate_no=a.gate_no and REA_CODE=28) rea_dt,a.org,"

            cl.sql &= "adi_no,adi_date,reason,decode(uname,null,(SELECT UNAME FROM JAN_GATe_NVAL_REASON WHERE GATe_NO=A.GATE_NO AND ROWNUM=1 HAVING REASON_DATE=MAX(REASON_DATE) GROUP BY UNAME,REASON_DATE ),uname) UNAME,NVL(VENDOR_ID ,0) VENDOR_ID,vehicle_Det,inv_category ,rearef ,"

            cl.sql &= "(SELECT  COUNT(*)  FROM JAN_Dds_SHORTAGE_VS_COMPLETION xx,jan_gate_lines bb   WHERE NEED_BY_WEEK<=TO_NUMBER(TO_CHAR(SYSDATE-14,'IYYYIW'))  AND REQUIREMENT-CANCELLED_QTY-RECEIVED_QUANTITY>0 and organization_id=bb.org_id and inventory_item_id=bb.item_id and gate_no=a.gate_no) dds,(select count(*) from jan_gate_lines where gate_no=a.gate_no and flag=1 )gcnt,dcval ,mmcard ,(select count(*) from jan_gate_nval_reason where gate_no=a.gate_no and rea_code=48)eway,validated_by,(select count(*) from jan_gate_lines where gate_no=a.gate_no and item_location is not null)loc_ent, (select item_checked_dt from jan_gate_lines where gate_no=a.gate_no and rownum=1 AND CHECKED_BY IS NOT NULL) item_checked_dt,(select count(*) from jan_gate_lines gl,po_lines_all pol where  GL.type='OSP' AND pol.po_line_id=gl.poline and pol.po_header_id=gl.pohead and unit_price=0 and gl.gate_no=a.gate_no) wop ,responsible_person ,shortage_form_no ,(select nvl(checked_by,item_check_by) ||'-'||other_checked_by from jan_gate_lines where gate_no=a.gate_no and rownum=1 AND CHECKED_BY IS NOT NULL )checked_by,kanban_flag , responsible_dept , transport_mode ,person_name ,(select  TO_CHAR(item_check_start, 'DD/MM/YYYY HH24:MI:SS AM')  ||'-'||  item_check_by from jan_gate_lines where gate_no=a.gate_no and rownum=1) item_check_dt  ,nvl(open_challan_recpt ,0) open_challan_recpt,bin_qty, (select  case when item_checked_dt is not null AND ROUND((item_checked_dt - item_check_start) * 1440) >0  then  case when ROUND((item_checked_dt - item_check_start) * 1440) >60 then    TRUNC(MOD(item_checked_dt - item_check_start, 1) * 24) || 'h ' || ROUND(MOD(MOD(item_checked_dt - item_check_start, 1) * 24, 1) * 60) || 'm' else   ROUND(MOD(MOD(item_checked_dt - item_check_start, 1) * 24, 1) * 60) || 'm' end end   from jan_gate_lines where gate_no=a.gate_no and rownum=1)diff_time,(SELECT  COUNT(*)  FROM jan_vendor_item_master_Temp1 xx,jan_gate_lines bb   WHERE sourcing_percent >0 and xx.self_Certified=1   AND  gcs_from_Date is not null and vendor_id=a.vendor_id and xx.org_id=bb.org_id and inventory_item_id=JAN_ITEMNO(BB.ITEM) and gate_no=a.gate_no) gcs"

            cl.sql &= " from jan_gate_header a where a.gdate>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            If cmbsup.SelectedItem <> "" Then cl.sql &= " and  a.VENDOR_ID=JAN_VENDORNO('" & cmbsup.SelectedItem.ToString.Replace("'", "''") & "') "

            If txtinw.Text <> "" Then cl.sql &= " and a.gate_no=" & txtinw.Text & ""

            If TXTREF.Text <> "" Then cl.sql &= " and rearef ='" & TXTREF.Text & "'"

            If cmbval.SelectedItem <> "" Then
                If cmbval.SelectedItem = "Validated" Then cl.sql &= " and validated='0'"
                If cmbval.SelectedItem = "Gate" Then cl.sql &= " and validated='1'"
                If cmbval.SelectedItem = "Not Validated" Then cl.sql &= " and validated='2'"
                If cmbval.SelectedItem = "Action Taken" Then cl.sql &= " and validated='3'"
                If cmbval.SelectedItem = "RTV" Then cl.sql &= " and validated='4'"
                If cmbval.SelectedItem = "Cancel Entry" Then cl.sql &= " and validated='5'"
                If cmbval.SelectedItem = "No Reference" Then cl.sql &= " and validated='6'"
            End If

            If cmborg.SelectedItem <> "" Then cl.sql &= " and gate_no in (select gate_no from jan_gate_lines where gate_no=a.gate_no and org_id =jan_orgid('" & cmborg.SelectedItem & "') )  "

            If gtype.SelectedItem <> "" And gtype.SelectedIndex <> 3 Then cl.sql &= " and gtype='" & gtype.SelectedItem & "'"
            If gtype.SelectedIndex = 3 Then cl.sql &= " and inv_Category is not null "

            If unit.ToString.Contains(",") = False Then cl.sql &= "And UNIT='" & unit & "' " Else cl.sql &= " and gate_no in (select gate_no from jan_gate_lines where gate_no=a.gate_no and org_id  IN (" & orgid & " ) UNION ALL SELECT gate_no from jan_gate_header where inv_category is not null  and unit  in ('" & unit.ToString.Replace(",", "','") & "') UNION All select gate_no from jan_gate_header where validated in (6) and unit  in ('" & unit.ToString.Replace(",", "','") & "'))  "

            ' If txtrole.Text = "POVIEW" Then cl.sql &= " And gate_no In (Select gate_no from jan_gate_lines xx where upper((Select DESCRIPTION FROM JAN_PUR_CAT WHERE rownum=1 And  CAT_NO=   nvl( nvl( (Select ATTRIBUTE1  FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=xx.POHEAD), (Select ATTRIBUTE8  FROM PO_lines_ALL WHERE PO_line_ID=xx.POline)) , (Select ATTRIBUTE15  FROM PO_line_locationS_ALL WHERE line_location_ID=xx.location_id))))  Like 'EDP%') "


            'If txtrole.Text = "UNIT4" Then

            '    cl.sql &= " AND UNIT='UNIT4'"

            'ElseIf txtrole.Text = "UNIT7" Or txtrole.Text = "U7_ADD" Or TXTROLE.Text = "USER" Or txtrole.Text = "INWARD" Or  Then

            '    cl.sql &= " AND UNIT='UNIT7'"

            'ElseIf txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Or txtrole.Text = "PURVIEW" Then

            '    cl.sql &= " AND UNIT='UNIT1'"

            'ElseIf txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Then

            '    cl.sql &= " AND UNIT='SKYFAST'"

            'ElseIf txtrole.Text = "JAPL" Then

            '    cl.sql &= " and unit='JAPL'"
            'End If

            cl.sql &= " order by A.gate_no"
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.oradap = New OracleDataAdapter(cl.orcmd)
            DSGATE = New DataSet
            cl.oradap.Fill(DSGATE, "gt")
            Dim cc As New DataGridViewCheckBoxColumn
            cc.Width = 30
            Me.dgv.Columns.Add(cc)
            With dgv
                .DataSource = DSGATE.Tables("gt")
                .Columns(1).HeaderText = "Gate No" : .Columns(1).Width = 80
                .Columns(2).HeaderText = "Gate Dt" : .Columns(2).Width = 95
                .Columns(3).HeaderText = "Supplier" : .Columns(3).Width = 140
                .Columns(4).HeaderText = "Sup Site" : .Columns(4).Width = 45
                .Columns(5).HeaderText = "GST" : .Columns(5).Width = 70
                .Columns(6).HeaderText = "DC.No" : .Columns(6).Width = 60
                .Columns(7).HeaderText = "Dc.Dt" : .Columns(7).Width = 70
                .Columns(8).HeaderText = "Validated" : .Columns(8).Visible = False
                .Columns(9).HeaderText = "Type" : .Columns(9).Width = 35 : .Columns(9).DisplayIndex = 9
                .Columns(10).HeaderText = "Status" : .Columns(10).Width = 80 : .Columns(10).Visible = False

                .Columns(12).HeaderText = "Org" : .Columns(12).Width = 40 : .Columns(12).DisplayIndex = 8
                .Columns(13).HeaderText = "ADI.No" : .Columns(13).Width = 45 : .Columns(13).DisplayIndex = 11
                .Columns(14).HeaderText = "ADI.Dt" : .Columns(14).Width = 70 : .Columns(14).DisplayIndex = 12
                .Columns(15).Visible = False
                .Columns(16).HeaderText = "Enter by" : .Columns(16).Width = 60 : .Columns(16).Visible = False
                .Columns(17).Visible = False
                .Columns(18).HeaderText = "Vehicle Det" : .Columns(18).Width = 85 : .Columns(18).DisplayIndex = 22
                .Columns(19).HeaderText = "Category" : .Columns(19).Width = 55 : .Columns(19).DisplayIndex = 23
                .Columns(20).Visible = False : .Columns(21).Visible = False : .Columns(22).Visible = False
                .Columns(23).HeaderText = "DC.Val" : .Columns(23).Width = 80
                .Columns(24).Visible = False : .Columns(25).Visible = False
                .Columns(26).HeaderText = "Validated By" : .Columns(26).Width = 60 : .Columns(26).DisplayIndex = 14
                .Columns(11).HeaderText = "Val.Dt" : .Columns(11).Width = 75 : .Columns(11).DisplayIndex = 15
                .Columns(27).Visible = False
                .Columns(28).HeaderText = "Checked Dt " : .Columns(28).Width = 50 : .Columns(28).DisplayIndex = 13
                .Columns(29).Visible = False
                .Columns(30).HeaderText = "Res Person" : .Columns(30).Width = 50 : .Columns(30).DisplayIndex = 17
                .Columns(31).Visible = False
                .Columns(32).HeaderText = "Checked by " : .Columns(32).Width = 50 : .Columns(32).DisplayIndex = 14
                .Columns(33).Visible = False
                .Columns(34).HeaderText = "Res.Dept" : .Columns(34).Width = 60 : .Columns(34).DisplayIndex = 19
                .Columns(35).HeaderText = "Trans.Mode" : .Columns(35).Width = 60 : .Columns(35).DisplayIndex = 20
                .Columns(36).HeaderText = "Person Name" : .Columns(36).Width = 60 : .Columns(36).DisplayIndex = 21
                .Columns(37).HeaderText = "Item Check Start" : .Columns(37).Width = 60 : .Columns(37).DisplayIndex = 13
                .Columns(38).Visible = False
                .Columns(39).HeaderText = "Bin Qty" : .Columns(39).Width = 40 : .Columns(39).DisplayIndex = 19
                If unit = "UNIT7" Then
                    .Columns(40).HeaderText = "Total Counting Time"
                    .Columns(40).Width = 60
                    .Columns(40).DisplayIndex = 18
                Else
                    .Columns(40).Visible = False
                End If
                .Columns(41).Visible = False
            End With

            Dim gcnt As Integer = 0
            For i = 0 To dgv.Rows.Count - 1
                gcnt += dgv.Rows(i).Cells(22).Value
            Next
            Dim c As Color

            For i = 0 To dgv.Rows.Count - 1
                With dgv.Rows(i)
                    If .Cells(8).Value.ToString = "0" Then
                        c = Color.DarkKhaki
                        '   btnedit.Enabled = False
                    ElseIf .Cells(8).Value.ToString = "1" And IsDBNull(.Cells(19).Value) And .Cells(41).Value.ToString = "0" Then
                        c = Color.White
                    ElseIf .Cells(8).Value = "2" Then
                        c = Color.Peru
                    ElseIf .Cells(8).Value = "3" Then
                        c = Color.CornflowerBlue
                    ElseIf .Cells(8).Value = "4" Then
                        c = Color.Thistle
                    ElseIf .Cells(8).Value = "5" Then
                        c = Color.Tomato
                    ElseIf .Cells(8).Value = "6" Then
                        c = Color.Khaki
                    ElseIf .Cells(8).Value = "1" And Not IsDBNull(.Cells(19).Value) Then
                        c = Color.Aquamarine
                    End If
                    .DefaultCellStyle.BackColor = c
                    If .Cells(21).Value.ToString > "0" Then
                        .Cells(1).Style.ForeColor = Color.DarkRed
                        .Cells(1).Style.Font = New Font("Tahoma", 10)
                    End If

                    If .Cells(24).Value.ToString > "0" Then
                        .Cells(2).Style.ForeColor = Color.MediumVioletRed
                        .Cells(2).Style.Font = New Font("Tahoma", 10)
                    End If
                    If .Cells(25).Value.ToString > "0" Then
                        .Cells(3).Style.ForeColor = Color.RoyalBlue
                        .Cells(3).Style.Font = New Font("Tahoma", 10)
                    End If
                    If .Cells(27).Value.ToString > "0" Then
                        .Cells(3).Style.BackColor = Color.HotPink
                        .Cells(3).Style.Font = New Font("Tahoma", 10)
                    End If

                    If .Cells(29).Value.ToString > "0" Then
                        .Cells(6).Style.BackColor = Color.Red
                        .Cells(6).Style.Font = New Font("Tahoma", 10)
                    End If
                    If .Cells(33).Value.ToString = "1" Then
                        .Cells(6).Style.BackColor = Color.Teal
                        .Cells(7).Style.BackColor = Color.Teal
                        ' .Cells(6).Style.Font = New Font("Tahoma", 10)
                    End If

                    If Not IsDBNull(.Cells(37).Value) Then
                        If .Cells(37).Value <> "-" Then
                            .Cells(37).Style.BackColor = Color.Cyan
                        End If

                    End If
                    If .Cells(41).Value.ToString > "0" And .Cells(8).Value = 1 Then
                        .DefaultCellStyle.BackColor = Color.DarkGreen
                        .DefaultCellStyle.ForeColor = Color.White
                    End If


                    If .Cells(38).Value > 0 Then
                        .DefaultCellStyle.BackColor = Color.LawnGreen
                    End If

                    If Not IsDBNull(.Cells(39).Value) Then
                        .Cells(39).Style.BackColor = Color.Goldenrod

                        .Cells(39).Style.Font = New Font("Tahoma", 10)
                    End If

                End With
            Next

            lblcnt.Text = DSGATE.Tables("gt").Rows.Count
            Label21.Text = gcnt
            Login.Hide()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cl.oracon.Close()
        End Try
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        FLG = True
        Me.Cursor = Cursors.WaitCursor
        Dim ADD As New Add
        ADD.txtrole.Text = txtrole.Text
        If txtrole.Text = "UNIT2" Then
            ADD.txtgno.Visible = False
            ADD.Label9.Visible = False
        End If

        ADD.Show()
        'If but_val_adi.Text = "ADI Enabled" Then
        '    ADD.chk_adi.Checked = True
        'Else
        '    ADD.chk_adi.Checked = False
        'End If
        Me.Cursor = Cursors.Arrow
        INS = "ADD"
    End Sub

    Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click
        Try
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            i = dgv.CurrentRow.Index
            k = dgv1.CurrentRow.Index
            dr = MessageBox.Show("Do You Want to delete?", "Gate Entry", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
            If dr = Windows.Forms.DialogResult.Yes Then
                Dim del As New del
                del.TextBox1.Text = dgv.Rows(i).Cells(0).Value
                del.TextBox2.Text = dgv1.Rows(k).Cells(1).Value
                del.TextBox5.Text = dgv1.Rows(k).Cells(4).Value
                del.TextBox6.Text = dgv1.Rows(k).Cells(23).Value
                del.Show()

            End If
            'btngo_Click(sender, e)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cl.oracon.Close()
        End Try
    End Sub

    Private Sub btnval_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnval.Click

        If dgv1.Rows.Count > 0 Then
            ' Me.Cursor = Cursors.WaitCursor 
            If txtrole.Text = "UNIT1" Or txtrole.Text = "ADD2" Or txtrole.Text = "UNIT7" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "ADD1" And (dgv.Rows(dgv.CurrentRow.Index).Cells(9).Value = "PO" Or dgv.Rows(dgv.CurrentRow.Index).Cells(9).Value = "Services") Then
                cl.sql = "select dcval from jan_gatE_header a  where gatE_no='" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & "'"
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                cl.ds = New DataSet
                cl.oradap.Fill(cl.ds, "resultab")
                If IsDBNull(cl.ds.Tables("resultab").Rows(0).Item("dcval")) Then
                    MessageBox.Show("View Tax Values", "Gate Register")
                Else

                    val()
                End If
            Else
                val()

            End If

        Else
            Exit Sub
        End If
        'If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "ADD1" Then
        '    cl.sql = "select invoice_val,dcval,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype from jan_gatE_header a  where gatE_no='" & dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value & "'"
        '    cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        '    cl.ds = New DataSet
        '    cl.oradap.Fill(cl.ds, "resultab")
        '    If cl.ds.Tables("resultab").Rows.Count > 0 And Not IsDBNull(cl.ds.Tables("resultab").Rows(0).Item("invoice_val")) And cl.ds.Tables("resultab").Rows(0).Item("gtype") <> "OSP" And cl.ds.Tables("resultab").Rows(0).Item("gtype") <> "Services" Then
        '        Dim r As Double = cl.ds.Tables("resultab").Rows(0).Item("invoice_val")
        '        Dim d As Double = cl.ds.Tables("resultab").Rows(0).Item("dcval")
        '        If Math.Abs((d - r)) >= 5 Then
        '            btnval.Enabled = False
        '            Me.Cursor = Cursors.Arrow
        '            If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "ADD1" Then
        '                Dim DR As DialogResult = MessageBox.Show("Diff between Invoice & DC Value is more than Rs.5", "Gate Register", MessageBoxButtons.YesNoCancel)
        '                If DR = Windows.Forms.DialogResult.Yes Then btnval.Enabled = True : val()
        '                If DR = Windows.Forms.DialogResult.No Or DR = Windows.Forms.DialogResult.Cancel Then btnval.Enabled = False
        '            End If

        '        Else
        '            btnval.Enabled = True
        '            val()
        '        End If
        '    Else
        '        btnval.Enabled = True
        '        val()
        '    End If
        'ElseIf txtrole.Text = "UNIT2" Then
        '    val()
        'Else

        '       End If
    End Sub
    Public Sub val()
        If dgv1.Rows.Count <> 0 Then
            Dim f As New Validate
            Dim LINEJOIN As String = ""
            f.txtgno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            f.txtpo.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(2).Value
            f.txtitem.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(6).Value
            f.lbtype.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(9).Value

            For k = 0 To dgv1.Rows.Count - 1
                If dgv1.Rows(k).Cells(0).Value = True Then
                    LINEJOIN = String.Concat(dgv1.Rows(k).Cells(1).Value, ",", LINEJOIN)

                End If
            Next

            If LINEJOIN.ToString = "" Then
                f.TXTLINE.Text = dgv1.CurrentRow.Cells(1).Value
            Else
                f.TXTLINE.Text = LINEJOIN.ToString.Substring(0, LINEJOIN.Length - 1)

            End If


            f.txttypt.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(21).Value
            f.txtlog.Text = txtlog.Text
            f.txtrole.Text = txtrole.Text
            f.txtorg.Text = dgv1.CurrentRow.Cells(28).Value.ToString
            f.Show()

        End If
    End Sub

    Public Sub dg()
        c6 = New DataGridViewTextBoxColumn()
        c6.HeaderText = "LineID"
        c6.DataPropertyName = "line_no"
        c6.Width = 50
        Me.dgv1.Columns.Add(c6)
        c13 = New DataGridViewTextBoxColumn()
        c13.HeaderText = "DcQty"
        c13.DataPropertyName = "supdcqty"
        c13.Width = 60
        Me.dgv1.Columns.Add(c13)
        c7 = New DataGridViewTextBoxColumn()
        c7.HeaderText = "PoNo"
        c7.DataPropertyName = "pono"
        c7.Width = 90
        Me.dgv1.Columns.Add(c7)
        c8 = New DataGridViewTextBoxColumn()
        c8.HeaderText = "PoDT"
        c8.DataPropertyName = "podt"
        c8.Width = 80
        Me.dgv1.Columns.Add(c8)
        c9 = New DataGridViewTextBoxColumn()
        c9.HeaderText = "Item"
        c9.DataPropertyName = "item"
        c9.Width = 120
        Me.dgv1.Columns.Add(c9)
        c10 = New DataGridViewTextBoxColumn()
        c10.HeaderText = "Description"
        c10.DataPropertyName = "description"
        c10.Width = 190
        Me.dgv1.Columns.Add(c10)
        c12 = New DataGridViewTextBoxColumn()
        c12.HeaderText = "PoPend"
        c12.DataPropertyName = "popend"
        c12.Width = 60
        Me.dgv1.Columns.Add(c12)
        c11 = New DataGridViewTextBoxColumn()
        c11.HeaderText = "Rev"
        c11.DataPropertyName = "rev"
        c11.Width = 30
        Me.dgv1.Columns.Add(c11)
        c14 = New DataGridViewTextBoxColumn()
        c14.HeaderText = "UOM"
        c14.DataPropertyName = "uom"
        c14.Width = 60
        Me.dgv1.Columns.Add(c14)
        c15 = New DataGridViewTextBoxColumn()
        c15.HeaderText = "Job"
        c15.DataPropertyName = "job"
        c15.Width = 100
        Me.dgv1.Columns.Add(c15)
        c16 = New DataGridViewTextBoxColumn()
        c16.HeaderText = "Operation"
        c16.DataPropertyName = "oper"
        c16.Width = 150
        Me.dgv1.Columns.Add(c16)
        c17 = New DataGridViewTextBoxColumn()
        c17.HeaderText = "OSPNo"
        c17.DataPropertyName = "osp"
        c17.Width = 80
        Me.dgv1.Columns.Add(c17)
        c18 = New DataGridViewTextBoxColumn()
        c18.HeaderText = "Type"
        c18.DataPropertyName = "type"
        c18.Width = 50
        Me.dgv1.Columns.Add(c18)
        c19 = New DataGridViewTextBoxColumn()
        c19.HeaderText = "Remark"
        c19.DataPropertyName = "remark"
        c19.Width = 100
        Me.dgv1.Columns.Add(c19)
        c20 = New DataGridViewTextBoxColumn()
        c20.HeaderText = "Validated"
        c20.DataPropertyName = "validated"
        c20.Width = 50
        c20.Visible = False
        c19 = New DataGridViewTextBoxColumn()
        c19.HeaderText = "PoLine"
        c19.DataPropertyName = "poline"
        c19.Width = 50
        Me.dgv1.Columns.Add(c19)
        c20 = New DataGridViewTextBoxColumn()
        c20.HeaderText = "PoHead"
        c20.DataPropertyName = "pohead"
        c20.Width = 50
        Me.dgv1.Columns.Add(c20)
    End Sub

    Private Sub dgv_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellClick

        If userid = "U7_VIEW" Then
            If dgv.CurrentCell.ColumnIndex = 0 Then
                sql = "select count(*) from jan_gate_lines where gate_no=" & dgv.CurrentRow.Cells(1).Value & " and item_check_Start is    null"
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "cnt")
                If ds.Tables("cnt").Rows(0).Item(0) > 0 Then
                    Dim DR1 As DialogResult
                    DR1 = MessageBox.Show("Do you want to start counting the item", "Gate Register", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                    If DR1 = Windows.Forms.DialogResult.Yes Then
                        gt_checked.txtgate.Text = dgv.CurrentRow.Cells(1).Value
                        gt_checked.Show()
                    End If
                End If
            End If
        End If
        'Try
        '  headerval.Show()
        'btnval.Enabled = True
        'If dgv.Rows.Count <> 0 Then
        '    i = dgv.CurrentRow.Index
        '    cl.sql = "select distinct b.line_no,b.pono,b.podt,b.item,b.description,b.org,b.poqty,b.popend,b.supdcqty,b.potype,b.ratecat,b.actval,b.rev,b.uom,b.job,b.oper,b.osp,b.type,b.remark,B.VALIDATED,DECODE(B.VALIDATED,'0','VALIDATED','1','GATE','2','NOT VALIDATED','3','ACTION TAKEN','4','RETURN TO VENDOR')STATUS, b.poline,b.pohead,(select nvl(invoice_val,0) from jan_gate_header where gatE_no= " & dgv.Rows(i).Cells(0).Value & ")invoice_val  from jan_gate_lines b  where  b.gate_no='" & dgv.Rows(i).Cells(0).Value & "'and flag ='1'"
        '    cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        '    cl.ds = New DataSet
        '    cl.oradap.Fill(cl.ds, "resultab")
        '    dgv1.DataSource = cl.ds.Tables("resultab")
        '    If txtlog.Text = "PURCHASE" Then
        '        btndel.Enabled = False
        '    End If
        'End If
        '''''DISPLAYING REASON AND BLOCKING GATE VALIDATION >=15 DAYS
        'If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "ADD1" Or txtrole.Text = "ADD2" Then
        '    cl.sql = "select reason,rearef,invoice_val from jan_gate_header where gate_no='" & dgv.Rows(i).Cells(0).Value & "'"
        '    cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        '    cl.ds = New DataSet
        '    cl.oradap.Fill(cl.ds, "resultab")
        '    txtremark.Text = cl.ds.Tables("resultab").Rows(0).Item("reason").ToString
        '    txtref.Text = cl.ds.Tables("resultab").Rows(0).Item("rearef").ToString
        '    txtinv.Text = cl.ds.Tables("resultab").Rows(0).Item("invoice_val").ToString
        '    cl.sql = "select gate_no from jan_gatE_header where (sysdate-gdate)>=15 AND  gate_no='" & dgv.Rows(i).Cells(0).Value & "' AND VALIDATED<>0"
        '    cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        '    cl.ds = New DataSet
        '    cl.oradap.Fill(cl.ds, "resultab")
        '    Dim DR As DialogResult
        '    If cl.ds.Tables("resultab").Rows.Count > 0 Then btnval.Enabled = False : DR = MessageBox.Show("Gate No : " & dgv.Rows(i).Cells(0).Value & " can't be validated", "Gate Register", MessageBoxButtons.YesNoCancel)

        '    If DR = Windows.Forms.DialogResult.Yes Then
        '        btnval.Enabled = True
        '    ElseIf DR = Windows.Forms.DialogResult.No Or DR = Windows.Forms.DialogResult.Cancel Then
        '        btnval.Enabled = False
        '    End If
        'End If
        ''''' BLOCKING GATE VALIDATION >=15 DAYS
        'If txtrole.Text = "ADD" Or txtrole.Text = "ADD1" Or txtrole.Text = "ADD2" Then
        '    cl.sql = "select gate_no from jan_gatE_header where (sysdate-gdate)>=15 AND  gate_no='" & dgv.Rows(i).Cells(0).Value & "' AND VALIDATED<>0"
        '    cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        '    cl.ds = New DataSet
        '    cl.oradap.Fill(cl.ds, "resultab")
        '    If cl.ds.Tables("resultab").Rows.Count > 0 Then btnval.Enabled = False Else btnval.Enabled = True
        'End If

        'If dgv1.Rows.Count <> 0 Then
        '    For k = 0 To dgv1.Rows.Count - 1
        '        cl.sql = "select supplier_name,item from jan_gate_supplier where supplier_name='" & dgv.Rows(i).Cells(1).Value.ToString.Replace("'", " ") & "' and  item='" & dgv1.Rows(k).Cells(3).Value & "' and type='URGENT' and dt>='" & dgv.Rows(i).Cells(3).Value & "' "
        '        'and dt ='" & dgv.Rows(i).Cells(3).Value & "' "
        '        cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        '        cl.ds = New DataSet
        '        cl.oradap.Fill(cl.ds, "resultab")
        '        If cl.ds.Tables("resultab").Rows.Count > 0 Then
        '            Label29.Visible = True
        '            dgv1.Rows(k).Cells(2).Style.ForeColor = Color.DarkViolet
        '            dgv1.Rows(k).Cells(3).Style.ForeColor = Color.DarkViolet
        '        Else
        '            dgv1.Rows(k).Cells(2).Style.ForeColor = Color.Black
        '            dgv1.Rows(k).Cells(3).Style.ForeColor = Color.Black
        '            Label29.Visible = False
        '        End If

        'If dgv1.Rows(j).Cells(19).Value = "0" Then
        '    Label29.Visible = False
        '    dgv1.Rows(j).Cells(2).Style.ForeColor = Color.Black
        '    dgv1.Rows(j).Cells(3).Style.ForeColor = Color.Black
        'End If
        '    Next
        'End If
        'Catch ex As Exception
        '    MessageBox.Show(ex.Message, "Gate Entry")
        'End Try
        Try
            dgv1.Columns.Clear()
            btnval.Enabled = True
            If dgv.Rows.Count <> 0 Then
                i = dgv.CurrentRow.Index

                cl.sql = "select courier_name,pod_no ,no_of_box ,po_wt ,rec_Wt from jan_gate_header where gate_no='" & dgv.Rows(i).Cells(1).Value & "'"
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                cl.ds = New DataSet
                cl.oradap.Fill(cl.ds, "sdt")
                With dgvcr
                    .DataSource = cl.ds.Tables("sdt")
                    .Columns(0).HeaderText = "Courier Name" : .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft : .Columns(0).Width = 120
                    .Columns(1).HeaderText = "POD No" : .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft : .Columns(1).Width = 100
                    .Columns(2).HeaderText = "Box Qty" : .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight : .Columns(2).Width = 45
                    .Columns(3).HeaderText = "POD Wt" : .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight : .Columns(3).Width = 50
                    .Columns(4).HeaderText = "Rec Wt" : .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight : .Columns(4).Width = 50


                End With
                sql = "select jan_orgcode(ship_to_org_id)org,receipt_num from rcv_shipment_headers where packing_slip='" & dgv.Rows(i).Cells(1).Value & "'"
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                cl.ds = New DataSet
                cl.oradap.Fill(cl.ds, "sdt")
                With dgvr
                    .DataSource = cl.ds.Tables("sdt")
                    .Columns(0).HeaderText = "Org" : .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft : .Columns(0).Width = 40
                    .Columns(1).HeaderText = "Receipt No" : .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft : .Columns(1).Width = 150
                End With


                cl.sql = "select distinct b.line_no,b.pono,(select creation_Date from po_line_locations_All where line_location_id=b.location_id)podt,(select approved_Date from po_line_locations_All where line_location_id=b.location_id)poapp_dt,case when type='OSP' then (select jan_challan_no from jan_osp_regular_challan_mast where po_header_id=b.pohead and wip_entity_id=b.wip_entity_id and rownum=1)else '' end  challan_no,b.item,b.description,b.org,b.poqty,b.popend,b.supdcqty , case when org_id<110 then to_date(null) else  Need_by_dt end need_by_dt ,b.potype,b.ratecat,b.actval,b.rev,b.uom,b.job,b.oper,b.osp,b.type,b.remark,B.VALIDATED,DECODE(B.VALIDATED,'0','VALIDATED','1','GATE','2','NOT VALIDATED','3','ACTION TAKEN','4','RETURN TO VENDOR')STATUS , b.poline,b.pohead,(select nvl(invoice_val,0) from jan_gate_header where gatE_no= " & dgv.Rows(i).Cells(1).Value & ")invoice_val,org_id,(SELECT  COUNT(*)  FROM JAN_Dds_SHORTAGE_VS_COMPLETION xx  WHERE NEED_BY_WEEK<=TO_NUMBER(TO_CHAR(SYSDATE-14,'IYYYIW'))  AND REQUIREMENT-CANCELLED_QTY-RECEIVED_QUANTITY>0 and organization_id=b.org_id and inventory_item_id=b.item_id ) dds,(SELECT  min(NEED_BY_WEEK)  FROM JAN_Dds_SHORTAGE_VS_COMPLETION xx  WHERE REQUIREMENT-CANCELLED_QTY-RECEIVED_QUANTITY>0 and organization_id=b.org_id and inventory_item_id=b.item_id )dds_wk,(select buyer_name from jan_item_master_Tab where inventory_item_id=b.item_id and organization_id=b.org_id)buyer_name, CASE WHEN NVL(" & dgv.Rows(i).Cells(17).Value & ",0) =0 THEN 0 ELSE nvl((SELECT SELF_certified from jan_vendor_item_master_temp1 where  inventory_item_id=JAN_ITEMNO(B.ITEM) and org_id=b.org_id and sourcing_percent >0 and vendor_id= " & dgv.Rows(i).Cells(17).Value & " and osp_no=b.osp),0) END  sc ,nvl(shortage_Qty,0)shortage_Qty ,pack_type,pack_qty , "


                cl.sql &= " nvl((select sum(stg_mtl_cost) from jan_wip_materials where entity_id=b.wip_entity_id) ,0) stage_mtl_cost ,
                nvl((select  stage_cost from jan_osp_Rate_all_view x where plan_id=100 and vendor_id=" & dgv.Rows(i).Cells(17).Value & " and part_no=b.item
and  (osp_no,bom_revision) in (select jan_itemname(item_id),(select bom_revision from wip_discrete_jobs where wip_entity_id= b.wip_entity_id )
from po_lines_all y where po_line_id=b.poline) and  (TRUNC(SYSDATE)<=TRUNC(TO_dATE(x.end_date_ACTIVE,'YYYY/MM/DD HH24:MI:SS '))
OR x.end_date_ACTIVE  IS NULL and  TRUNC(sysdate) >= TRUNC(TO_DATE(x.start_date_ACTIVE, 'YYYY/MM/DD HH24:MI:SS ')))    ),0) stage_cost ,
(select unit_price from po_lines_all where po_line_id=b.poline and rownum=1 ) po_price ,(select  weight  from jan_weight_master where organization_id=b.org_id and inventory_item_id=jan_itemno(b.item) 
 and rev=b.rev and osp_no=b.osp and end_Date is null and  Creation_date  = (select max(creation_Date) from jan_weight_master where  
 organization_id=b.org_id and inventory_item_id=jan_itemno(b.item) 
 and rev=b.rev and osp_no=b.osp  )) weight "


                cl.sql &= " From jan_gate_lines b  where  b.gate_no='" & dgv.Rows(i).Cells(1).Value & "'and flag ='1' order by line_no "
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                cl.ds = New DataSet
                cl.oradap.Fill(cl.ds, "resultab")

                ' AddHeaderCheckBox()



                Dim cc As New DataGridViewCheckBoxColumn
                cc.Width = 30
                'cc.Name = "Checkbox"
                Me.dgv1.Columns.Add(cc)
                'chkBox = New CheckBox()
                'Dim rect As Rectangle = Me.dgv1.GetCellDisplayRectangle(0, -1, True)
                'chkBox.Size = New Size(18, 18)
                'chkBox.Location = rect.Location
                'AddHandler chkBox.CheckedChanged, AddressOf chkBox_CheckedChanged
                'Me.dgv1.cl.oracontrols.Add(chkBox)

                With dgv1
                    .DataSource = cl.ds.Tables("resultab")
                End With

                If dgv1.Rows.Count > 0 Then
                    For Z = 0 To dgv1.Rows.Count - 1
                        With dgv1.Rows(Z)
                            If (.Cells(23).Value) = "0" Then
                                .DefaultCellStyle.BackColor = Color.DarkKhaki
                            ElseIf (.Cells(23).Value) = "1" Then
                                .DefaultCellStyle.BackColor = Color.White
                            ElseIf (.Cells(23).Value) = "2" Then
                                .DefaultCellStyle.BackColor = Color.Peru
                            ElseIf (.Cells(23).Value) = "3" Then
                                .DefaultCellStyle.BackColor = Color.CornflowerBlue
                            ElseIf (.Cells(23).Value) = "4" Then
                                .DefaultCellStyle.BackColor = Color.Thistle
                            ElseIf (.Cells(23).Value) = "5" Then
                                .DefaultCellStyle.BackColor = Color.Tomato
                            End If
                            If (.Cells(29).Value) > 0 Then
                                .Cells(6).Style.ForeColor = Color.DarkRed
                                .Cells(6).Style.Font = New Font("Tahoma", 10)
                            End If
                            If (.Cells(32).Value) > 0 Then
                                .Cells(6).Style.ForeColor = Color.DarkGreen
                                .Cells(6).Style.Font = New Font("Tahoma", 10)
                            End If

                            If (.Cells(33).Value) > 0 Then
                                .Cells(1).Style.BackColor = Color.Red
                                .Cells(1).Style.Font = New Font("Tahoma", 10)

                            End If
                        End With
                    Next
                End If
                dgv1.Columns(8).Width = 35
                dgv1.Columns(9).Width = 55
                dgv1.Columns(10).Width = 55
                dgv1.Columns(11).Width = 60
                dgv1.Columns(0).Width = 25
                dgv1.Columns(1).Width = 45

                dgv1.Columns(33).DisplayIndex = 12 'shortage qty
                If userid = "UNIT7" Then
                    dgv1.Columns(36).DisplayIndex = 13 'stg_mcost
                    dgv1.Columns(37).DisplayIndex = 14 'stg cost
                    dgv1.Columns(38).DisplayIndex = 15 'po price
                Else
                    dgv1.Columns(36).Visible = False
                    dgv1.Columns(37).Visible = False 'stg cost
                    dgv1.Columns(38).Visible = False 'po price
                End If


                dgv1.Columns(34).DisplayIndex = 16 'pack type
                dgv1.Columns(35).DisplayIndex = 17 'pack qty
                dgv1.Columns(39).DisplayIndex = 7

                If txtlog.Text = "PURCHASE" Then
                    btndel.Enabled = False
                End If
                '  lbvehicle.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(32).Value.ToString
                '  lbrearef.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(32).Value.ToString
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    'Private Sub dgv_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv.CellFormatting
    '    Try
    '        If e.RowIndex >= 0 Then
    '            If e.RowIndex <= dgv.Rows.Count - 1 Then
    '                Dim c As Color
    '                If dgv.Rows(e.RowIndex).Cells(8).Value = "0" Then
    '                    c = Color.DarkKhaki
    '                    '   btnedit.Enabled = False
    '                ElseIf dgv.Rows(e.RowIndex).Cells(8).Value = "1" And IsDBNull(dgv.Rows(e.RowIndex).Cells(19).Value) Then
    '                    c = Color.White
    '                ElseIf dgv.Rows(e.RowIndex).Cells(8).Value = "2" Then
    '                    c = Color.Peru
    '                ElseIf dgv.Rows(e.RowIndex).Cells(8).Value = "3" Then
    '                    c = Color.CornflowerBlue
    '                ElseIf dgv.Rows(e.RowIndex).Cells(8).Value = "4" Then
    '                    c = Color.Thistle
    '                ElseIf dgv.Rows(e.RowIndex).Cells(8).Value = "5" Then
    '                    c = Color.Tomato
    '                ElseIf dgv.Rows(e.RowIndex).Cells(8).Value = "6" Then
    '                    c = Color.Khaki
    '                ElseIf dgv.Rows(e.RowIndex).Cells(8).Value = "1" And Not IsDBNull(dgv.Rows(e.RowIndex).Cells(19).Value) Then
    '                    c = Color.Aquamarine
    '                End If

    '                If dgv.Rows(e.RowIndex).Cells(21).Value > "0" Then
    '                    dgv.Rows(e.RowIndex).Cells(1).Style.ForeColor = Color.DarkRed
    '                    dgv.Rows(e.RowIndex).Cells(1).Style.Font = New Font("Tahoma", 10)
    '                End If
    '                e.CellStyle.BackColor = c
    '            End If
    '        End If
    '    Catch ex As Exception
    '        MessageBox.Show(ex.Message, "Gate Entry")
    '    End Try
    'End Sub

    Private Sub Gate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        btngo_Click(sender, e)
    End Sub

    Private Sub dgv1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv1.CellClick
        'Label22.Text = ""
        'cl.sql = "select action,action_dt from jan_gate_nval_reason where gate_no='" & dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value & "' and line_no='" & dgv1.Rows(dgv1.CurrentRow.Index).Cells(0).Value & "'"
        'cl.oradap= New OracleDataAdapter(cl.sql, cl.oracon)
        'cl.ds = New DataSet
        'cl.oradap.Fill(cl.ds, "resultab")
        'If cl.ds.Tables("resultab").Rows.Count > 0 Then
        '    Label22.Text = cl.ds.Tables("resultab").Rows(0).Item("action") & "  " & "on" & "  " & cl.ds.Tables("resultab").Rows(0).Item("action_dt")
        'End If
        'If txtlog.Text = "I10" Then
        '    If dgv1.CurrentCell.ColumnIndex = 0 Then
        '        If dgv1.Rows(dgv1.CurrentRow.Index).Cells(16).Value = "2" Then
        '            valreason.gate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
        '            valreason.line.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(0).Value
        '            valreason.ShowDialog()
        '        End If
        '    End If
        'End If
    End Sub

    Private Sub dgv1_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv1.CellFormatting
        'Try
        '    If e.RowIndex >= 0 Then
        '        If e.RowIndex <= dgv1.Rows.Count - 1 Then
        '            Dim c As Color
        '            If dgv1.Rows(e.RowIndex).Cells(20).Value = "0" Then
        '                c = Color.DarkKhaki
        '            ElseIf dgv1.Rows(e.RowIndex).Cells(20).Value = "1" Then
        '                c = Color.White
        '            ElseIf dgv1.Rows(e.RowIndex).Cells(20).Value = "2" Then
        '                c = Color.Peru
        '            ElseIf dgv1.Rows(e.RowIndex).Cells(20).Value = "3" Then
        '                c = Color.CornflowerBlue
        '            ElseIf dgv1.Rows(e.RowIndex).Cells(20).Value = "4" Then
        '                c = Color.Thistle
        '            ElseIf dgv1.Rows(e.RowIndex).Cells(20).Value = "5" Then
        '                c = Color.Tomato
        '            End If
        '            e.CellStyle.BackColor = c
        '        End If
        '    End If
        'Catch ex As Exception
        '    MessageBox.Show(ex.StackTrace, "Gate Entry")
        'End Try
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click

        If dgv.Rows(dgv.CurrentRow.Index).Cells(8).Value <> 6 Then
            Me.Cursor = Cursors.WaitCursor
            Dim f As New pocheck
            f.txtpo.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(2).Value
            f.txtrole.Text = txtrole.Text
            f.TXTITEM.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(6).Value
            f.TXTPQTY.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(11).Value
            f.TXTPOOSP.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(21).Value
            f.TXTGNO.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
            Me.Cursor = Cursors.Arrow
            f.Show()
        End If

    End Sub

    Private Sub btnsta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsta.Click
        Me.Cursor = Cursors.WaitCursor
        Dim st As New Status
        st.TextBox1.Text = txtlog.Text
        st.txtrole.Text = txtrole.Text
        st.Show()
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub BTNCLOSE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        End
    End Sub

    Private Sub btnvou_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim vou As New Voucher
        vou.txtsup.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(2).Value
        vou.txtgate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
        vou.txtdc.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(5).Value
        vou.Show()
    End Sub

    Private Sub btnmod_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmod.Click

        If Not IsDBNull(dgv.Rows(dgv.CurrentRow.Index).Cells(13).Value) And modify_Flag <> 1 Then
            MessageBox.Show("Modifying the Gate No With ADI is not allowed", "Gate Entry")
            Exit Sub
        End If

        FLG = False
        Me.Cursor = Cursors.WaitCursor
        Add.TXTUSER.Text = txtlog.Text
        Add.txtrole.Text = txtrole.Text
        Add.txtgno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
        ''''''ON 11TH DEC
        cl.sql = "select gtype ,CASE WHEN GTYPE='PO' THEN  (select count(*) from jan_blanket_vendor_status where vendor_id=a.vendor_id and releases>0 ) ELSE 0 END cnt from jan_gate_header a  where gate_no='" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & "'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        cl.ds = New DataSet
        cl.oradap.Fill(cl.ds, "resultab")
        Add.txttype.Text = cl.ds.Tables("resultab").Rows(0).Item("gtype").ToString  ''''ON 11TH DEC
        Add.txtsite.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(4).Value.ToString
        Add.TextBox1.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(3).Value
        Add.txtdcno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value
        MOD_LOAD()
        If txtrole.Text = "UNIT7" Then
            If cl.ds.Tables("resultab").Rows(0).Item(0) = "PO" And cl.ds.Tables("resultab").Rows(0).Item(1) > 0 Then
                MOD_LOAD()
                MessageBox.Show("Gate entry editing not allowed for Blanket suppliers")
                Me.Cursor = Cursors.Arrow
            Else

            End If
        Else
            MOD_LOAD()
        End If

    End Sub

    Sub MOD_LOAD()
        If dgv1.Rows.Count > 0 Then
            Add.txtinv.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(25).Value.ToString
        Else
            Add.txtinv.Text = 0
        End If
        Add.Show()
        Me.Cursor = Cursors.Arrow
        INS = "UPDT"
    End Sub


    Private Sub btnpri_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        j = dgv1.CurrentRow.Index
        If dgv1.CurrentCell.ColumnIndex = 0 Then
            If j = dgv1.Rows(dgv1.CurrentRow.Index).Cells(16).Value = "2" Then
                valreason.gate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
                valreason.line.Text = dgv1.Rows(dgv1.CurrentRow.Index).Cells(0).Value
                valreason.Show()
            End If
        End If
    End Sub

    Private Sub btn_auto_receipt_Click(sender As Object, e As EventArgs)

        System.Diagnostics.Process.Start("http://192.168.0.22/auto_receipt")
    End Sub

    Private Sub btndel_Click_1(sender As Object, e As EventArgs) Handles btndel.Click

    End Sub

    Private Sub glist_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles glist.Click
        gatelist.Show()
    End Sub

    Public Sub bind()
        'Me.dgv.ShowCellToolTips = False
        Dim chk As New DataGridViewCheckBoxColumn
        chk.Width = 30
        chk.ReadOnly = False
        Me.dgv.Columns.Add(chk)
        dgv.DataSource = DSGATE.Tables("gt")
        dgv.Columns(1).HeaderText = "Gate No" : dgv.Columns(1).Width = 80
        dgv.Columns(2).HeaderText = "Gate Dt" : dgv.Columns(2).Width = 95
        dgv.Columns(3).HeaderText = "Supplier" : dgv.Columns(3).Width = 140
        dgv.Columns(4).HeaderText = "Sup Site" : dgv.Columns(4).Width = 65
        dgv.Columns(5).HeaderText = "GST" : dgv.Columns(5).Width = 70
        dgv.Columns(6).HeaderText = "DC.No" : dgv.Columns(6).Width = 60
        dgv.Columns(7).HeaderText = "Dc.Dt" : dgv.Columns(7).Width = 80
        dgv.Columns(8).HeaderText = "Validated" : dgv.Columns(8).Width = 100 : dgv.Columns(8).Visible = False
        dgv.Columns(9).HeaderText = "Type" : dgv.Columns(9).Width = 35
        dgv.Columns(10).HeaderText = "Status" : dgv.Columns(10).Width = 80
        dgv.Columns(11).HeaderText = "Val.Dt" : dgv.Columns(11).Width = 75
        dgv.Columns(12).HeaderText = "Org" : dgv.Columns(12).Width = 40

        dgv.Columns(13).HeaderText = "ADI.No" : dgv.Columns(13).Width = 45

        dgv.Columns(14).HeaderText = "ADI.Dt" : dgv.Columns(14).Width = 70
        dgv.Columns(15).Visible = False
        dgv.Columns(16).HeaderText = "Enter by" : dgv.Columns(16).Width = 60
        dgv.Columns(17).Visible=False
        dgv.Columns(18).HeaderText = "Vehicle Det" : dgv.Columns(18).Width = 85
        dgv.Columns(19).HeaderText = "Category" : dgv.Columns(19).Width = 55
        dgv.Columns(20).Visible = False : dgv.Columns(21).Visible = False : dgv.Columns(22).Visible = False
        dgv.Columns(23).HeaderText = "DC.Val" : dgv.Columns(23).Width = 80

        ' dgv.Columns(5).HeaderText = "GST" : dgv.Columns(5).Width = 70


        'c0 = New DataGridViewTextBoxColumn()
        'c0.HeaderText = "GtNo"
        'c0.DataPropertyName = "gate_no"
        'c0.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        'c0.Width = 80
        'c0.ReadOnly = True
        'Me.dgv.Columns.Add(c0)
        'c3 = New DataGridViewTextBoxColumn()
        'c3.HeaderText = "GtDt"
        'c3.DataPropertyName = "gdate"
        'c3.Width = 95
        'c3.ReadOnly = True
        'Me.dgv.Columns.Add(c3)
        'c1 = New DataGridViewTextBoxColumn()
        'c1.HeaderText = "Supplier"
        'c1.DataPropertyName = "supplier_name"
        'c1.Width = 140
        'c1.ReadOnly = True
        'Me.dgv.Columns.Add(c1)
        'c2 = New DataGridViewTextBoxColumn()
        'c2.HeaderText = "Sup Site"
        'c2.DataPropertyName = "supplier_site"
        'c2.Width = 65
        'c2.ReadOnly = True
        'Me.dgv.Columns.Add(c2)
        'c2 = New DataGridViewTextBoxColumn()
        'c2.HeaderText = "GST"
        'c2.DataPropertyName = "gst"
        'c2.Width = 70
        'c2.ReadOnly = True
        'Me.dgv.Columns.Add(c2)
        'c4 = New DataGridViewTextBoxColumn()
        'c4.HeaderText = "DcNo"
        'c4.DataPropertyName = "dc_no"
        'c4.ReadOnly = True
        'c4.Width = 60
        'Me.dgv.Columns.Add(c4)
        'c5 = New DataGridViewTextBoxColumn()
        'c5.HeaderText = "DcDT"
        'c5.DataPropertyName = "dc_date"
        'c5.Width = 80
        'c5.ReadOnly = True
        'c5.ToolTipText = "date"
        'Me.dgv.Columns.Add(c5)
        'c6 = New DataGridViewTextBoxColumn()
        'c6.HeaderText = "Validated"
        'c6.DataPropertyName = "validated"
        'c6.Width = 100
        'c6.ReadOnly = True
        'c6.Visible = False
        'Me.dgv.Columns.Add(c6)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Type"
        'cc.DataPropertyName = "gtype"
        'cc.ReadOnly = True
        'cc.Width = 35
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Status"
        'cc.DataPropertyName = "STATUS"
        'cc.Width = 80
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Val.Dt"
        'cc.DataPropertyName = "rea_dt"
        'cc.Width = 75
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Org"
        'cc.DataPropertyName = "org"
        'cc.ReadOnly = True
        'cc.Width = 40
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "ADI"
        'cc.DataPropertyName = "adi_no"
        'cc.Width = 45
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "ADI.Dt"
        'cc.DataPropertyName = "adi_date"
        'cc.Width = 70
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "reason"
        'cc.DataPropertyName = "reason"
        'cc.Visible = False
        'cc.Width = 70
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Enterby"
        'cc.DataPropertyName = "uname"
        'cc.Width = 60
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Vehicle Details"
        'cc.DataPropertyName = "vehicle_Det"
        'cc.Width = 85
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        '' cc.Visible = False

        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Category"
        'cc.DataPropertyName = "inv_category"
        'cc.Width = 55
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "DCval"
        'cc.DataPropertyName = "dcval"
        'cc.Width = 80
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "Reason reference"
        'cc.DataPropertyName = "rearef"
        'cc.Width = 100
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "gcnt"
        'cc.DataPropertyName = "gcnt"
        'cc.Width = 0
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)
        'cc = New DataGridViewTextBoxColumn()
        'cc.HeaderText = "vendor_id"
        'cc.DataPropertyName = "vendor_id"
        'cc.Width = 0
        'cc.ReadOnly = True
        'Me.dgv.Columns.Add(cc)


        ' cc.Visible = False

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnitem.Click
        gt_checked.txtgate.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value
        gt_checked.Show()
    End Sub



    Private Sub LinkLabel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles linkpwd.Click
        Gate_Password.Show()
    End Sub

    Private Sub btnwop_Click(sender As Object, e As EventArgs) Handles btnwop.Click
        '
        sql = " select supplier_name,dc_no,dc_date,item,pono,supdcqty,podt,gh.gdate from jan_gate_lines GL,JAN_GATE_HEader gh where gh.gate_no=" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & "   And gh.gate_no=gl.gate_no  "
        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "wop")

        s = "<html> "
        If OP_ID = 204 Then s &= "<img src=F:\jiplnewexecutables\cp_map_prg\skyfast_logo.jpg>"

        If OP_ID = 584 Then s &= " <img src=F:\jiplnewexecutables\cp_map_prg\automation_wop.jpg width=80%>"

        If OP_ID = 103 Then s &= " <img src=F:\jiplnewexecutables\cp_map_prg\gate-wop.png width=80%>"



        s &= "<table cellpadding=8 cellspacing=0 border=1 ><tr align=center> <td colspan=3><font size=5 FONT FACE=VERDANA>Justification For Without Process</font></td></tr>"

        s &= " <tr> <td colspan=1><font size=2 FONT FACE=VERDANA><b>FROM :</b>Central Excise Dept</font></td> <td colspan=2><font size=2 FONT FACE=VERDANA><b>To:</b>Purchase Dept </font></td></tr>"


        s &= "  <tr> <td colspan=3><font size=2 FONT FACE=VERDANA><b>Supplier Name:</b>" & ds.Tables("wop").Rows(0).Item(0) & "   </font></td></tr>"

        s &= "  <tr> <td colspan=1><font size=2 FONT FACE=VERDANA><b>DC No:</b> " & ds.Tables("wop").Rows(0).Item(1) & " </font></td> <td colspan=2><font size=2 FONT FACE=VERDANA><b>DC Date :</b>" & ds.Tables("wop").Rows(0).Item(2) & " </font></td></tr>"

        s &= "  <tr> <td colspan=1><font size=2 FONT FACE=VERDANA><b>Gate No:</b>" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & "  </font></td> <td colspan=2><font size=2 FONT FACE=VERDANA><b>Gate Date:</b>" & ds.Tables("wop").Rows(0).Item(7) & "  </font></td></tr>"

        s &= "  <tr> <td colspan=3 ><font size=2 FONT FACE=VERDANA>The Following components are returned as RM /Semi finished components without doing any operations due to following reasons</font></td></tr> "

        s &= "  <tr><td colspan=3> <table border=1 cellpadding=5 cellspacing=0 width=100% > <tr><td> <font size=2 FONT FACE=VERDANA>PO No</font></td> <td><font size=2 FONT FACE=VERDANA>Po Dt </font></td> <td><font size=2 FONT FACE=VERDANA>Item No/Desc</font></td> <td><font size=2 FONT FACE=VERDANA>DC Qty </font></td><td><font size=2 FONT FACE=VERDANA>WOP Qty </font></td><td> <font size=2 FONT FACE=VERDANA>Job No</font></td><td> <font size=2 FONT FACE=VERDANA>Opns Not Done</font></td></tr>"

        For k = 0 To dgv1.Rows.Count - 1
            With dgv1.Rows(k)

                If .Cells(0).Value = True Then
                    s &= "<tr><td><font size=2 FONT FACE=VERDANA> " & .Cells(2).Value & " </font></td> <td><font size=2 FONT FACE=VERDANA>" & .Cells(3).Value & " </font></td> <td><font size=2 FONT FACE=VERDANA>" & .Cells(6).Value & "<br>" & .Cells(7).Value & " </font></td> <td><font size=2 FONT FACE=VERDANA>" & .Cells(10).Value & "  </font></td><td> <font size=2 FONT FACE=VERDANA>&nbsp;</font></td><td> <font size=2 FONT FACE=VERDANA>" & .Cells(18).Value & "</font></td><td> <font size=2 FONT FACE=VERDANA>&nbsp;</font></td></tr>"
                End If
            End With
        Next
        s &= "</table></td></ tr>"
        s &= "  <tr> <td colspan=3><font size=2 FONT FACE=VERDANA>Kindly verify the quantity and amend the Purchase order.</font></td></tr>"


        s &= "  <tr  height=50% valign=top > <td  width=30%><font size=2 FONT FACE=VERDANA>QA- Department<br><br><br> </font></td> <td  width=40%><font size=2 FONT FACE=VERDANA>Sub-contract Department <br><br><br></font></td> <td  ><font size=2 FONT FACE=VERDANA>Materials Planning  </font></td></tr>"

        s &= "  <tr> <td colspan=3><font size=2 FONT FACE=VERDANA><b>Code Details</b></font></td></tr>"

        sql = "select reason_name,description from mtl_transaction_reasons where reason_name  like 'OSP%' and ATTRIBUTE1='Without Process' union all select reason_name,description from mtl_transaction_reasons where reason_name='OSP-018' "

        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "wopcd")
        s &= "  <tr>"
        For j = 0 To ds.Tables("wopcd").Rows.Count - 1
            With ds.Tables("wopcd").Rows(j)
                s &= "  <tr> <td colspan=3><font size=2 FONT FACE=VERDANA>" & .Item(0) & "   " & .Item(1) & " </font></td></tr>"

            End With
        Next
        s &= "</tr>"
        s &= "  <tr valign=top height=10% > <td  colspan=2 width=20%><font size=2 FONT FACE=VERDANA>Po Amended by <br><br><br></font></td>  <td width=50%  ><font size=2 FONT FACE=VERDANA> Central Excise  </font></td></tr>"
        s = s & "</table></html>"
        x = "c:\gate\gate_wop.HTML"
        Dim fstrm As New FileStream(x, FileMode.Create, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)


    End Sub



    Private Sub btngacc_Click(sender As Object, e As EventArgs) Handles btngacc.Click
        gacc.TextBox1.Text = txtlog.Text
        gacc.txtrole.Text = txtrole.Text
        gacc.Show()
    End Sub

    Private Sub bprint_Click_1(sender As Object, e As EventArgs) Handles bprint.Click

    End Sub

    Private Sub dgv1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgv1.CellContentClick

    End Sub

    Private Sub mmcard_Click(sender As Object, e As EventArgs) Handles mmcard.Click
        inw_tag(dgv.CurrentRow.Cells(1).Value)

    End Sub
    Private Sub inw_tag(ByVal gate_no As Integer)
        Dim gt As String = ""
        For j = 0 To dgv.Rows.Count - 1
            If dgv.Rows(j).Cells(0).Value = True Then
                gt = String.Concat(dgv.Rows(j).Cells(1).Value, ",", gt)
            End If
        Next
        gt = gt.ToString.Substring(0, gt.Length - 1)

        sql = "select gh.gate_no,gh.gdate,substr(gh.supplier_name,0,30)supplier_name,gl.item,substr(jan_itemdesc(gl.item),0,20) it_Desc, sum(gl.supdcqty)qty,CASE WHEN (SELECT COUNT (*) FROM JAN_DIRECT_DELIVERY_SUPPLIER WHERE VID=GH.vendor_ID) >0 AND org_id <>384 THEN JAN_ORGCODE(org_id)|| '-DD'  WHEN (SELECT COUNT(*) FROM JAN_VENDOR_ITEM_MASTER_TEMP1 WHERE VENDOR_ID=gh.vendor_ID AND ORG_ID=gl.org_id AND INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND SOURCING_PERCENT>0 AND SPOT_INSPECTION=1) >0  THEN JAN_ORGCODE(gl.org_id)|| '-SI'WHEN NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )<3 THEN JAN_ORGCODE(gl.ORG_ID)|| '-1' when NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )=3 THEN JAN_ORGCODE(gl.ORG_ID)|| '-2' when  NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )>3 and  NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )<5 THEN JAN_ORGCODE(gl.ORG_ID)||'-3'when NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )>=5 and NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )<7 THEN JAN_ORGCODE(gl.ORG_ID)|| '-4' when NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )>=7 THEN JAN_ORGCODE(gl.ORG_ID)|| '-5' end insp_cat,gl.pack_type,gl.pack_qty   from jan_gate_header gh,jan_gate_lines gl where gh.gate_no=gl.gate_no and gh.gate_no in (" & gt & " ) group by gh.gate_no,gh.supplier_name,gl.item,gl.org_id,gh.gdate,GH.VENDOR_ID,gl.pack_type,gl.pack_qty"

        '" & head & "

        cl.orcmd = New OracleCommand(sql, cl.oracon)
        cl.oradap = New OracleDataAdapter(cl.orcmd)
        Dim d As New DataSet
        cl.oradap.Fill(d, "cnt")
        s = ""
        l = 0
        s = "<html> "

        s &= "<table cellspacing=0 cellpadding=5 border=0>"
        For Z = 0 To d.Tables("cnt").Rows.Count - 1
            With d.Tables("cnt").Rows(Z)
                k = Z + 1
                If (k Mod 2 = 0) Then
                    s &= "<td> "
                    GoTo tag_p
                    '   s &= "</td></tr>"
                Else
                    s &= "<tr><td> "
                    GoTo tag_p
                    s &= "</td>"
                End If

tag_p:
                s &= "<html> "
                s &= " <head> "
                s &= "  <style type='text/css'> "
                s &= " .tabs {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:7pT} "
                s &= " .tab {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:8pT} "
                s &= " .tab2 {color: black;  FONT-FAMILY:VERDANA; FONT-SIZE:8PT} "
                s &= " .thinB {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:7PT;font-weight :bold} "
                s &= " .thinN {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:7PT} "
                s &= " </STYLE> "
                s &= " </head> "
                s &= " <body>"
                s &= "<table cellspacing=0 cellpadding=8 border=1 class=tab2 width=100% height=100% top=0   >"
                s &= "<tr><td ><b>Gate No /Dt </b></td> <td colspan=5 >" & .Item("gate_no") & " &nbsp;&nbsp; " & .Item("gdate") & "</td></tr> "
                s &= "<tr><td><b>Supplier</b></td> <td colspan=5>" & .Item("supplier_name") & " </td></tr> "
                s &= "<tr><td><b>Item No</b></td><td colspan=5>" & .Item("item") & "   &nbsp;&nbsp;  ( " & .Item("it_desc") & " )</td></tr>"
                s &= "<tr><td><b>Qty</b></td><td>" & .Item("qty") & " </td> <td colspan=4><b>Location:</b> " & .Item("insp_cat") & " </td></tr>"

                s &= "<tr height=20%><td ><b>Pack Type</b></td><td>" & .Item("pack_type") & " </td><td width=20%><b>No Of Packs</b></td><td colspan=2>" & .Item("pack_qty") & " </td> </tr>"
                s &= "<tr height=20%> <td  colspan=5 ><b>Sign/Date:</b>&nbsp;</td> </tr>"
                ' s &= "<tr></tr>"
                s &= "</table>"
                s &= "</body></html>"

                If (k Mod 2 = 0) Then
                    If l Mod 5 = 0 And l <> 0 Then
                        s &= " <td colspan=2><p style=""page-break-before:always"">&nbsp;</p> </td>"

                        ' s &= "<P style=""page-break-before:always""/>"
                    End If
                    s &= "</td></tr> "
                    l += 1
                End If

            End With
        Next
        s &= "</table></html>"
        x = "c:\gate\inward_tag.HTML"
        Dim fstrm As New FileStream(x, FileMode.Create, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)



    End Sub

    Private Sub inw_tag_new(ByVal gate_no As Integer)
        Dim gt As String = ""
        For j = 0 To dgv.Rows.Count - 1
            If dgv.Rows(j).Cells(0).Value = True Then
                gt = String.Concat(dgv.Rows(j).Cells(1).Value, ",", gt)
            End If
        Next
        gt = gt.ToString.Substring(0, gt.Length - 1)

        sql = "select gh.gate_no,gh.gdate,substr(gh.supplier_name,0,30)supplier_name,gl.item,substr(jan_itemdesc(gl.item),0,20) it_Desc, sum(gl.supdcqty)qty,(select lot_no from jan_fifo_lotno_details where ref_id=gh.gate_no and organization_id = gl.org_id AND inventory_item_id= jan_itemno(gl.item) )lot_no,rowtocol('select     LOCATION FROM JAN_ITEM_VS_LOCATOR    WHERE organization_id = '||gl.org_id||' AND    item_no='''||gl.item||'''')loc,CASE WHEN (SELECT COUNT (*) FROM JAN_DIRECT_DELIVERY_SUPPLIER WHERE VID=GH.vendor_ID) >0 AND org_id <>384 THEN JAN_ORGCODE(org_id)|| '-DD'  WHEN (SELECT COUNT(*) FROM JAN_VENDOR_ITEM_MASTER_TEMP1 WHERE VENDOR_ID=gh.vendor_ID AND ORG_ID=gl.org_id AND INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND SOURCING_PERCENT>0 AND SPOT_INSPECTION=1) >0  THEN JAN_ORGCODE(gl.org_id)|| '-SI'WHEN NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )<3 THEN JAN_ORGCODE(gl.ORG_ID)|| '-1' when NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )=3 THEN JAN_ORGCODE(gl.ORG_ID)|| '-2' when  NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )>3 and  NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )<5 THEN JAN_ORGCODE(gl.ORG_ID)||'-3'when NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )>=5 and NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )<7 THEN JAN_ORGCODE(gl.ORG_ID)|| '-4' when NVL((select INSP_DAYS from jan_item_master_tab where INVENTORY_ITEM_ID=JAN_ITEMNO(gl.ITEM) AND insp_days is not null AND ROWNUM=1),case when gl.ORG_ID=505 then 10 else 3 end )>=7 THEN JAN_ORGCODE(gl.ORG_ID)|| '-5' end insp_cat ,(select weight from jan_lot_weight_master where organization_id = gl.org_id AND inventory_item_id= jan_itemno(gl.item) )wt  from jan_gate_header gh,jan_gate_lines gl where gh.gate_no=gl.gate_no and gh.gate_no in (" & gt & " ) group by gh.gate_no,gh.supplier_name,gl.item,gl.org_id,gh.gdate,GH.VENDOR_ID"

        '" & head & "

        cl.orcmd = New OracleCommand(sql, cl.oracon)
        cl.oradap = New OracleDataAdapter(cl.orcmd)
        Dim d As New DataSet
        cl.oradap.Fill(d, "cnt")
        s = ""
        l = 0
        s = "<html> "
        Dim loc_len As Integer

        Dim locloop, locop As Int16

        For Z = 0 To d.Tables("cnt").Rows.Count - 1
            With d.Tables("cnt").Rows(Z)
                If Not IsDBNull(.Item("loc")) Then
                    loc_len = Len(.Item("loc"))
                    locop = Math.Floor((loc_len / 160))
                End If

                k = Z + 1
                If k Mod 2 = 0 And k <> 0 Then
                    s &= " <td colspan=2><p style=""page-break-before:always"">&nbsp;</p> </td>"
                    ' s &= "<br style=page-break-before:always;>"
                End If

                GoTo tag_p

tag_p:
                s &= "<html> "
                s &= " <head> "
                s &= "  <style type='text/css'> "
                s &= " .tabs {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:7pT} "
                s &= " .tab {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:8pT} "
                s &= " .tab2 {color: black;  FONT-FAMILY:VERDANA; FONT-SIZE:10PT} "
                s &= " .thinB {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:7PT;font-weight :bold} "
                s &= " .thinN {color: NAVY;  FONT-FAMILY:VERDANA; FONT-SIZE:7PT} "
                s &= " </STYLE> "
                s &= " </head> "
                s &= " <body>"

                s &= "<table cellspacing=0 cellpadding=8 border=1 class=TAB2 width=100%  >"
                s &= "<tr><td width=2%><img src=F:\OA\logo2.jpg align=left></td><td colspan=2 align=center  ><font face=verdana size=4>Receipt Traveller Sheet</font></td></tr>"
                s &= "<tr><td width=2%><b>Gate No:</b>" & .Item("gate_no") & "</td> <td colspan=2><b>Gate Dt:</b>" & .Item("gdate") & "</td></tr> "
                s &= "<tr><td width=2% colspan=3><b>Supplier Name :</b>" & .Item("supplier_name") & " </td></tr> "
                s &= "<tr> <td width=2%><b>Item No:</b>" & .Item("item") & " </td><td><b>Desc:</b>" & .Item("it_desc") & "</td><td><b>Qty:</b>" & .Item("qty") & " </td></tr>"
                s &= "<tr><td width=2%><b>Pack Size:</b>&nbsp;</td><td colspan=2><b>No Of Packs /Bin:</b>&nbsp;</td></tr>"
                s &= "<tr><td width=2%><b>Weight:</b>" & .Item("wt") & "</td> <td colspan=2><b>QC Location:</b> " & .Item("insp_cat") & " </td></tr>"
                s &= "<tr><td width=2%><b>Receiving TL</td> <td colspan=2><b>Name/Sign:</b> &nbsp;</td></tr>"
                s &= "<tr><td width=2%><b>Lot No:</b>" & .Item("lot_no") & "</td> <td colspan=2><b>Additional Location:</b> &nbsp;</td></tr>"
                s &= "<tr><td width=2% colspan=3><b>Store Location:</b><br> "

                For locloop = 1 To locop
                    s &= .Item("loc").ToString.Substring(((locloop - 1) * 160), (locloop * 160) - ((locloop - 1) * 160)) & "<br>"
                Next
                If locop > 0 Then
                    If (loc_len Mod 160) > 0 Then
                        s &= .Item("loc").ToString.Substring((locop * 160), loc_len - ((locop * 160)))
                    End If
                Else
                    s &= .Item("loc").ToString
                End If

                s &= "</td></tr>"
                s &= "<tr><td width=2%><b>Put away TL &nbsp;</td> <td colspan=2><b>Name /Sign:</b>&nbsp;</td></tr>"
                s &= "<tr><td width=2%><b>Audit TL &nbsp;</td> <td colspan=2><b>Name /Sign:</b>&nbsp;</td></tr>"
                s &= "<tr><td width=2% colspan=3><b>Remarks if any:</b></td></tr>"

                s &= "</table></body></html><br> "



            End With
        Next

        x = "c:\gate\inward_tag.HTML"
        Dim fstrm As New FileStream(x, FileMode.Create, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
    End Sub

    Private Sub btntag_Click(sender As Object, e As EventArgs) Handles btntag.Click
        inw_tag_new(dgv.CurrentRow.Cells(1).Value)

    End Sub

    Private Sub Label41_Click(sender As Object, e As EventArgs) Handles Label41.Click, Label46.Click
        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " loc_ent> 0"
        '  If cmbsup.SelectedItem <> "" Then DV.RowFilter = " validated=0 AND   SUPPLIER_NAME='" & cmbsup.SelectedItem & "'"

        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub
    Sub colorcode()
        Dim c As Color

        For i = 0 To dgv.Rows.Count - 1
            With dgv.Rows(i)
                If .Cells(8).Value.ToString = "0" Then
                    c = Color.DarkKhaki
                    '   btnedit.Enabled = False
                ElseIf .Cells(8).Value.ToString = "1" And IsDBNull(.Cells(19).Value) Then
                    c = Color.White
                ElseIf .Cells(8).Value = "2" Then
                    c = Color.Peru
                ElseIf .Cells(8).Value = "3" Then
                    c = Color.CornflowerBlue
                ElseIf .Cells(8).Value = "4" Then
                    c = Color.Thistle
                ElseIf .Cells(8).Value = "5" Then
                    c = Color.Tomato
                ElseIf .Cells(8).Value = "6" Then
                    c = Color.Khaki
                ElseIf .Cells(8).Value = "1" And Not IsDBNull(.Cells(19).Value) Then
                    c = Color.Aquamarine
                End If

                If .Cells(21).Value.ToString > "0" Then
                    .Cells(1).Style.ForeColor = Color.DarkRed
                    .Cells(1).Style.Font = New Font("Tahoma", 10)
                End If
                If .Cells(24).Value.ToString > "0" Then
                    .Cells(2).Style.ForeColor = Color.MediumVioletRed
                    .Cells(2).Style.Font = New Font("Tahoma", 10)
                End If
                If .Cells(25).Value.ToString > "0" Then
                    .Cells(3).Style.ForeColor = Color.RoyalBlue
                    .Cells(3).Style.Font = New Font("Tahoma", 10)
                End If
                If .Cells(27).Value.ToString > "0" Then
                    .Cells(3).Style.BackColor = Color.HotPink
                    .Cells(3).Style.Font = New Font("Tahoma", 10)
                End If

                If .Cells(29).Value.ToString > "0" Then
                    .Cells(6).Style.BackColor = Color.Red
                    .Cells(6).Style.Font = New Font("Tahoma", 10)
                End If
                ' e.CellStyle.BackColor = c
                .DefaultCellStyle.BackColor = c

                If .Cells(38).Value > 0 Then
                    .DefaultCellStyle.BackColor = Color.LawnGreen
                End If
                If Not IsDBNull(.Cells(39).Value) Then
                    .Cells(39).Style.BackColor = Color.Goldenrod

                    .Cells(39).Style.Font = New Font("Tahoma", 10)
                End If
            End With
        Next
    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub btnreport_Click_1(sender As Object, e As EventArgs) Handles btnreport.Click
        Me.Cursor = Cursors.WaitCursor
        Dim st As New Status
        st.TextBox1.Text = txtlog.Text
        st.txtrole.Text = txtrole.Text
        st.Show()
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub Label43_Click(sender As Object, e As EventArgs) Handles Label43.Click
        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " wop>0"
        ' If cmbsup.SelectedItem <> "" Then DV.RowFilter = " validated=2 AND   SUPPLIER_NAME='" & cmbsup.SelectedItem & "'"

        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub dgv_CellBorderStyleChanged(sender As Object, e As EventArgs) Handles dgv.CellBorderStyleChanged

    End Sub

    Private Sub job_shrt_Click(sender As Object, e As EventArgs) Handles job_shrt.Click

        Dim sql As String
        Dim debit_val As Integer

        sql = "select count(*) from jan_gate_header where gate_no=" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & " and shortage_form_no is null"
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        If ds.Tables("resultab").Rows(0).Item(0) > 0 Then
            sql = "update jan_gate_header set shortage_form_no =JAN_JOBC_NO.nextval,shortage_form_dt=sysdate  where  gate_no=" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & ""

            cl.orcmd = New OracleCommand(sql, cl.oracon)
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd.ExecuteNonQuery()

        End If


        ' sql = "select  shortage_form_no , TO_CHAR(shortage_form_dt,'dd-mon-yyyy')form_dt, TO_CHAR(b.GDATE,'dd-mon-yyyy')GDATE,b.GATE_NO,JAN_FY(sysdate)FRDS_YEAR,ITEM, SUPPLIER_NAME ,a.DESCRIPTION,a.JOB,jan_orgcode(a.ORG_id)org ,SHORTAGE_QTY,  b.DC_NO , TO_CHAR(b.DC_DATE,'dd-mon-yyyy')  DC_DATE,a.pono,nvl( (select sum(stg_mtl_cost) from jan_wip_materials where entity_id=a.wip_entity_id) + nvl((select opn_Stage from jan_osp_Rate_backup where vendor_id=b.vendor_id and item_no=a.item and  (osp_no,rev) in (select jan_itemname(item_id),item_revision from po_lines_all where po_line_id=a.poline)   ),0), (select unit_price from po_lines_all where po_line_id=a.poline and rownum=1))debit_unit_price   from jan_gate_lines a ,jan_gate_header b  where b.gate_no=a.gate_no and b.GATE_NO=" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & " and a.shortage_qty is not null "

        sql = "select  shortage_form_no , TO_CHAR(shortage_form_dt,'dd-mon-yyyy')form_dt, TO_CHAR(b.GDATE,'dd-mon-yyyy')GDATE,b.GATE_NO,JAN_FY(sysdate)FRDS_YEAR,ITEM, SUPPLIER_NAME ,a.DESCRIPTION,(select wip_entity_name from wip_entities where wip_entity_id=a.wip_entity_id)JOB,jan_orgcode(a.ORG_id)org ,SHORTAGE_QTY,  b.DC_NO , TO_CHAR(b.DC_DATE,'dd-mon-yyyy')  DC_DATE,a.pono, case when b.gtype='OSP' then nvl((select sum(stg_mtl_cost) from jan_wip_materials where entity_id=a.wip_entity_id) ,0)
+ nvl((select  stage_cost from jan_osp_Rate_all_view x where vendor_id=b.vendor_id and part_no=a.item
and  (osp_no,bom_revision) in (select jan_itemname(item_id),(select bom_revision from wip_discrete_jobs where wip_entity_id= a.wip_entity_id )
from po_lines_all y where po_line_id=a.poline) and  (TRUNC(SYSDATE)<=TRUNC(TO_dATE(x.end_date_ACTIVE,'YYYY/MM/DD HH24:MI:SS '))
OR x.end_date_ACTIVE  IS NULL and  TRUNC(sysdate) >= TRUNC(TO_DATE(x.start_date_ACTIVE, 'YYYY/MM/DD HH24:MI:SS ')))    ),0) when b.gtype='PO' then 
(select unit_price from po_lines_all where po_line_id=a.poline and rownum=1)  end  debit_unit_price from jan_gate_lines a ,jan_gate_header b  where b.gate_no=a.gate_no and b.GATE_NO=" & dgv.Rows(dgv.CurrentRow.Index).Cells(1).Value & " and a.shortage_qty is not null "


        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        Dim dv As DataView
        dv = ds.Tables("resultab").DefaultView
        'dv.Sort = "ORG_ID,ITEM_NO asc"

        ds.Tables("resultab").AcceptChanges()
        Dim jobNo As String = ds.Tables("resultab").Rows(0)("shortage_form_no").ToString()

        Dim job1 As String = "<HTML><HEAD>"
        job1 &= "<style>"
        job1 &= " table {"
        job1 &= " font-family:verdana; size:1.5"
        job1 &= "  border-collapse: collapse;"
        job1 &= " border: 2px solid black;"
        job1 &= "  width: 100%;"
        job1 &= "   }"
        job1 &= " td, th {"
        job1 &= " border: 1 ;"
        job1 &= " border: 1 ;"
        job1 &= "  text-align: left;"
        job1 &= "  padding: 8px;"
        job1 &= " height:15px;"
        job1 &= "  }"
        job1 &= "</style>"
        job1 &= "<h4 align = center font face=verdana> <B>JOB CARD ITEM SHORTAGE ACCOUNTING"
        job1 &= " <img src=F:\jiplnewexecutables\cp_map_prg\janatics.png   align=right></h4>"
        'job1 &= "<img src='D:/projects/JCISA/jana.png' style='text-align:center;margin-left:1500px' />"
        job1 &= "<table border=1 cellpadding=3 cellspacing=0  width=100% size:1.5>"
        job1 &= "  <tr>"
        job1 &= " <td>Form No:</td><td>" & jobNo & "</td><td colspan=2>" & ds.Tables("resultab").Rows(0)("FRDS_YEAR").ToString() & "</td><td>Date:</td><td colspan=2>" & ds.Tables("resultab").Rows(0)("form_dt").ToString() & "</td>"
        job1 &= "  </tr>"
        job1 &= "  <tr>"
        job1 &= "    <td>Supplier Name:</td><td >" & ds.Tables("resultab").Rows(0)("SUPPLIER_NAME").ToString() & "</td><td>Gate No.</td><td >" & ds.Tables("resultab").Rows(0)("GATE_NO").ToString() & " (" & ds.Tables("resultab").Rows(0)("ORG").ToString() & ")</td><td>Dc No /Dt:</td><td>" & ds.Tables("resultab").Rows(0)("DC_NO").ToString() & " /" & ds.Tables("resultab").Rows(0)("DC_DATE").ToString() & " </td><td>"
        job1 &= "  </tr>"

        job1 &= "<tr><td>Item No </td><td>JC No</td><td>Shortage Qty</td><td  >PO No</td> <td colspan=3 >Debit Amount</td> </tr>"
        debit_val = 0
        For k = 0 To ds.Tables("resultab").Rows.Count - 1



            With ds.Tables("resultab").Rows(k)

                debit_val += .Item("shortage_qty") * .Item("debit_unit_price")

                job1 &= "<tr><td font size=1.5>" & .Item("Item") & " </td><td font size=1.5>" & .Item("job") & " </td><td font size=1.5>" & .Item("SHORTAGE_QTY") & " </td><td >" & .Item("pono") & " </td> <td colspan=3>" & .Item("shortage_qty") * .Item("debit_unit_price") & " </td></tr>"
            End With
        Next




        'job1 &= "  <tr>"
        'job1 &= "    <td>Part No:</td><td colspan=2>" & ds.Tables("resultab").Rows(0)("ITEM").ToString() & "</td><td>Description</td><td colspan=7>" & ds.Tables("resultab").Rows(0)("DESCRIPTION").ToString() & "</td>"
        'job1 &= "  </tr>"
        'job1 &= "  <tr>"
        'job1 &= "  <td>Job Card No.</td><td>" & ds.Tables("resultab").Rows(0)("JOB").ToString() & "</td><td>Shortage Qty.</td><td colspan=2>" & ds.Tables("resultab").Rows(0)("SHORTAGE_QTY").ToString() & "</td>"
        'job1 &= "  </tr>"
        job1 &= "  <tr>"
        job1 &= "    <td>Remarks</td><td colspan=2></td><td colspan=3>For Non-Debit/ For Debit</td><td colspan=4></td>"
        job1 &= "  </tr>"
        job1 &= "<tr>"
        job1 &= "<td colspan=2>&nbsp;</td><td colspan=2>&nbsp;</td><td colspan=2>&nbsp;</td><td colspan=2>&nbsp;</td>"
        job1 &= "</tr>"
        job1 &= "  <tr>"
        job1 &= "    <td colspan=2>Inward Incharge</td><td colspan=2>Materials</td><td colspan=2>Materials Head</td><td colspan=2>Variance moved by</td>"
        job1 &= "  </tr>"
        job1 &= "</table>"



        job1 &= "<h4 align=center >---------------------------------xxxxxx----------------------------------</h4>"
        '  job1 &= "</br>"


        job1 &= "To Planning Dept:"
        job1 &= "<h4  font face=verdana > Shortage Qty for vendor " & ds.Tables("resultab").Rows(0)("supplier_name") & " has been listed below ,amendment need to be done for the below purchase order</h4>"
        job1 &= " <h4>Form No: " & jobNo & " Date: " & Format(DateAdd(DateInterval.Day, 0, Date.Now), "dd-MMM-yyyy") & "</h4>"
        job1 &= "<table border=1 cellpadding=3 cellspacing=0 font-family:verdana; size:1.5>"

        job1 &= "<tr><td>Item No </td><td>JC No</td><td>Shortage Qty</td><td>PO No</td></tr>"

        For k = 0 To ds.Tables("resultab").Rows.Count - 1
            With ds.Tables("resultab").Rows(k)
                job1 &= "<tr><td font size=1.5>" & .Item("Item") & " </td><td font size=1.5>" & .Item("job") & " </td><td font size=1.5>" & .Item("SHORTAGE_QTY") & " </td><td>" & .Item("pono") & " </td></tr>"
            End With
        Next


        job1 &= "</table></br>"

        job1 &= "<table border=1 cellpadding=3 cellspacing=0 font-family:verdana;size:1.5>"

        job1 &= "<tr>"
        job1 &= "<td colspan=2 font size=1.5>Inward Incharge</td><td colspan=2 font size=1.5>Materials</td><td  colspan=2 font size=1.5>Po.Amend by</td>"
        job1 &= "</tr>"
        job1 &= "</table>"
        job1 &= "<h4 align=center>---------------------------------xxxxxx----------------------------------</h4>"
        ' job1 &= "</br>"
        job1 &= "To Accounts Dept:"

        job1 &= "<h4  font face=verdana > Shortage Qty for vendor " & ds.Tables("resultab").Rows(0)("supplier_name") & " has been listed below ,debit note to raised for amount Rs <u> " & debit_val & "  </u>, for the below items. </h4>"

        job1 &= " <h4>Form No: " & jobNo & " Date: " & Format(DateAdd(DateInterval.Day, 0, Date.Now), "dd-MMM-yyyy") & "</h4>"

        job1 &= "<table border=1 cellpadding=3 cellspacing=0 font-family:verdana;>"

        job1 &= "<tr><td font size=1.5>Item No </td><td font size=1.5>JC No</td><td font size=1.5>Shortage Qty</td><td>PO No</td font size=1.5></tr>"

        For k = 0 To ds.Tables("resultab").Rows.Count - 1
            With ds.Tables("resultab").Rows(k)
                job1 &= "<tr><td font size=1.5>" & .Item("Item") & " </td><td font size=1.5>" & .Item("job") & " </td><td font size=1.5>" & .Item("SHORTAGE_QTY") & " </td><td font size=1.5>" & .Item("pono") & " </td></tr>"
            End With
        Next


        job1 &= "</table></BR>"
        job1 &= "<table border=1 cellpadding=3 cellspacing=0 font-family:verdana;>"

        job1 &= "<tr>"
        job1 &= "<td colspan=2 font size=1.5>Inward Incharge</td><td colspan=2 font size=1.5>Materials</td><td  colspan=2 font size=1.5>Accounts</td>"
        job1 &= "</tr>"
        job1 &= "</table>"
        job1 &= "</html>"
        x = "D:\gate_shortage.HTML"
        Dim fstrm As New FileStream(x, FileMode.Create, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        sw.WriteLine(job1)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)



        'GeneratePdf()
    End Sub

    Private Sub Label38_Click(sender As Object, e As EventArgs) Handles Label38.Click
        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " shortage_form_no>0"
        ' If cmbsup.SelectedItem <> "" Then DV.RowFilter = " validated=2 AND   SUPPLIER_NAME='" & cmbsup.SelectedItem & "'"

        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub



    Private Sub Label48_Click(sender As Object, e As EventArgs) Handles Label48.Click
        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " open_challan_recpt>0"
        ' If cmbsup.SelectedItem <> "" Then DV.RowFilter = " validated=2 AND   SUPPLIER_NAME='" & cmbsup.SelectedItem & "'"

        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub dgv_DataError(sender As Object, e As DataGridViewDataErrorEventArgs) Handles dgv.DataError
        e.Cancel = True
    End Sub

    Private Sub bprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Report.TextBox1.Text = txtlog.Text
        Report.txtrole.Text = txtrole.Text
        Report.Show()
    End Sub

    Private Sub lbupdt_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lbupdt.LinkClicked
        GateUpdate.txtrole.Text = txtrole.Text
        GateUpdate.Show()

        ' If txtrole.Text = "UNIT2" Then GateUpdate.btndel.Enabled = False
    End Sub

    Private Sub btnreport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim re As New newreport
        re.Show()
    End Sub

    Private Sub btnsup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        suplist.Show()
    End Sub

    Private Sub btnrtv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If dgv.Rows(i).Cells(8).Value = "RTV" Then
            rtvreason.Show()
            rtvreason.txtgate.Text = dgv.Rows(i).Cells(0).Value
        End If
        cl.sql = "select * from jan_gate_rtv where gate_no='" & dgv.Rows(i).Cells(0).Value & "'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        cl.ds = New DataSet
        cl.oradap.Fill(cl.ds, "resultab")
        If cl.ds.Tables("resultab").Rows.Count > 0 Then
            With cl.ds.Tables("resultab").Rows(0)
                rtvreason.txttrans.Text = .Item("transport")
                rtvreason.txtdoc.Text = .Item("docno")
                rtvreason.txtqty.Text = .Item("qty")
                rtvreason.txtwt.Text = .Item("wt")
                rtvreason.txtterm.Text = .Item("terms")
                rtvreason.txtamt.Text = .Item("amt")
                rtvreason.txtremark.Text = .Item("remark")
            End With
        End If
    End Sub

    Private Sub but_val_adi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'If but_val_adi.Text = "ADI Enabled" Then
        '    cl.sql = "update jan_check_adi set adi_chk=1"
        '    but_val_adi.Text = "ADI Disabled"
        'Else
        '    cl.sql = "update jan_check_adi set adi_chk=0"
        '    but_val_adi.Text = "ADI Enabled"
        'End If

        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        cl.oracon.Close()
    End Sub

    Private Sub ADI_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADIbt.Click
        Dim sql1 As String

        sql1 = "F:\jiplnewexecutables\cp_map_prg\4153_all_adi.EXE " & SEQNO & "," & OP_ID & "," & unit & ""

        'If txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Then sql1 = "F:\jiplnewexecutables\cp_map_prg\4153_all_adi.EXE 1"
        'If txtrole.Text = "UNIT7" Or txtrole.Text = "U7_ADD" Then sql1 = "F:\jiplnewexecutables\cp_map_prg\4153_all_adi.EXE 7"
        'If txtrole.Text = "JAPL" Then sql1 = "F:\jiplnewexecutables\cp_map_prg\4153_all_adi.EXE 5"
        'If txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Then sql1 = "F:\jiplnewexecutables\cp_map_prg\4153_all_adi.EXE 6"
        'If txtrole.Text = "SPM_ADD1" Then sql1 = "F:\jiplnewexecutables\cp_map_prg\4153_all_adi.EXE 8"

        ' Shell(cl.sql)


        Shell(sql1, AppWinStyle.NormalFocus)
        'adi.txtrole.Text = txtrole.Text
        'adi.Show()


    End Sub

    Private Sub UNBLOCK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UNBLOCK.Click

        sql1 = "F:\jiplnewexecutables\cp_map_prg\4153_Unclosed_ADI.EXE"

        'Shell("F:\public\Unclosed_adi.BAT", AppWinStyle.Hide)
        'cl.sql = "c:\ADI\Unclosed_ADI.exe"
        ' Process.Start(cl.sql1)
        Shell(sql1, AppWinStyle.NormalFocus)
    End Sub



    Private Sub btncan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncan.Click
        cancelentry.Show()
    End Sub



    '    private void AddHeaderCheckBox()
    '{
    '    HeaderCheckBox = new CheckBox();

    '    HeaderCheckBox.Size = new Size(15, 15);

    '    //Add the CheckBox into the DataGridView
    '    this.dgvSelectAll.cl.oracontrols.Add(HeaderCheckBox);
    '}

    Private Sub AddHeaderCheckBox()
        Dim HeaderCheckBox As New CheckBox
        HeaderCheckBox.Size = New Size(15, 15)
        dgv1.Controls.Add(HeaderCheckBox)


        'HeaderCheckBox.KeyUp += New KeyEventHandler(HeaderCheckBox_KeyUp)
        '    HeaderCheckBox.MouseClick += new MouseEventHandler(HeaderCheckBox_MouseClick);
        '    dgvSelectAll.CellValueChanged += new DataGridViewCellEventHandler(dgvSelectAll_CellValueChanged);
        '    dgvSelectAll.CurrentCellDirtyStateChanged += new EventHandler(dgvSelectAll_CurrentCellDirtyStateChanged);
        '    dgvSelectAll.CellPainting += new DataGridViewCellPaintingEventHandler(dgvSelectAll_CellPainting);

    End Sub

    'Private Sub dgv_CellEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellEnter
    'End Sub
    Private Sub chkBox_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)
        'For i As Integer = 0 To Me.dgv1.RowCount - 1
        '    Me.dgv1(0, i).Value = Me.chkBox.Checked
        'Next
        'Me.dgv1.EndEdit()
    End Sub

    Private Sub Label16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label16.Click, Label9.Click

        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " validated=1 "
        ' If cmbsup.SelectedItem <> "" Then DV.RowFilter = " validated=1 AND SUPPLIER_NAME='" & cmbsup.SelectedItem & "'"
        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub Label15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label15.Click, Label10.Click, Label45.Click, Label44.Click
        '     DV.RowFilter = Nothing
        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " validated=2"
        ' If cmbsup.SelectedItem <> "" Then DV.RowFilter = " validated=2 AND   SUPPLIER_NAME='" & cmbsup.SelectedItem & "'"

        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub Label17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label17.Click, Label12.Click

        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " validated=0"
        If cmbsup.SelectedItem <> "" Then DV.RowFilter = " validated=0 AND   SUPPLIER_NAME='" & cmbsup.SelectedItem & "'"

        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub Label24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label24.Click, Label23.Click

        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " validated=4"
        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub Label28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label28.Click, Label27.Click

        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " validated=5"
        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub Label30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label30.Click, Label8.Click

        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " validated=6"
        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub Label19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label19.Click, Label20.Click

        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " validated=3"
        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub Label33_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label33.Click, Label32.Click
        DV = DSGATE.Tables("gt").DefaultView
        DV.RowFilter = ""
        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub btnrecpt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrecpt.Click
        receipt_prepared.Show()
    End Sub

    Private Sub btnxs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        excess_release.txtrole.Text = txtrole.Text
        excess_release.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        direct_delivery.Show()
    End Sub

    Private Sub dgv1_CellLeave(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv1.CellLeave

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        For i As Integer = 0 To Me.dgv1.RowCount - 1
            Me.dgv1(0, i).Value = Me.CheckBox1.Checked
        Next
        Me.dgv1.EndEdit()
    End Sub

    Private Sub cmbitem_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnnonpo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnonpo.Click
        non_po.txtrole.Text = txtrole.Text
        non_po.Show()

    End Sub

    Private Sub Label35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label35.Click
        DV = cl.ds.Tables("gt").DefaultView
        DV.RowFilter = ""
        DV.RowFilter = " inv_category is not null "
        dgv.DataSource = DV
        lblcnt.Text = DV.Count
        dgv1.Columns.Clear()
        colorcode()
    End Sub

    Private Sub btngtlot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        ' gate_lot_print.txtgno.Text = dgv.Rows(dgv.CurrentRow.Index).Cells(0).Value
        ' gate_lot_print.Show()
    End Sub

    Private Sub Gate_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        End
    End Sub

    Private Sub Gate_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        End
    End Sub
End Class