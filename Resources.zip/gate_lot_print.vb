Imports System.Data.OracleClient
Imports System.IO
Imports oracleclass

Public Class gate_lot_print
    Dim s1 As String
    Dim cl As New oracleclass.Class1
    Private Sub gate_lot_print_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "select organization_code  from org_organization_definitions where organization_id   in(" & orgid & " )order by organization_code"
        cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        s1 = ""
        For i = 0 To dgv.Rows.Count - 1

            If dgv.Rows(i).Cells(0).Value = True Then

                'If dgv.Rows(i).Cells(6).Value = "PO" Then

                For k = 0 To (Math.Ceiling(dgv.Rows(i).Cells(12).Value / 3)) - 1

                    s1 &= "CT~~CD,~CC^~CT~" & vbNewLine
                    s1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD15^JUS^LRN^CI0^XZ" & vbNewLine
                    s1 &= "^XA" & vbNewLine
                    s1 &= "^MMT" & vbNewLine
                    s1 &= "^PW791" & vbNewLine
                    s1 &= "^LL0160" & vbNewLine
                    s1 &= "^LS0" & vbNewLine
                    s1 &= "^FT565,131^BQN,2,4" & vbNewLine

                    s1 &= "^FH\^FDLA," & dgv.Rows(i).Cells(2).Value & "^FS" & vbNewLine '''''item

                    s1 &= "^FT283,129^BQN,2,4" & vbNewLine

                    s1 &= "^FH\^FDLA," & dgv.Rows(i).Cells(2).Value & "^FS" & vbNewLine '''''item

                    s1 &= "^FT681,109^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(9).Value & "^FS" & vbNewLine '''' yr

                    s1 &= "^FT565,146^A0N,25,24^FH\^FD" & dgv.Rows(i).Cells(5).Value & "^FS" & vbNewLine ''''lot

                    s1 &= "^FT690,61^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(10).Value & "^FS" & vbNewLine '''''month

                    s1 &= "^FT15,131^BQN,2,4" & vbNewLine

                    s1 &= "^FH\^FDLA," & dgv.Rows(i).Cells(2).Value & "^FS" & vbNewLine '''''item

                    s1 &= "^FT399,107^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(9).Value & "^FS" & vbNewLine '''' yr

                    s1 &= "^FT283,144^A0N,25,24^FH\^FD" & dgv.Rows(i).Cells(5).Value & "^FS" & vbNewLine ''''lot

                    s1 &= "^FT409,59^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(10).Value & "^FS" & vbNewLine '''''month

                    s1 &= "^FT140,62^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(10).Value & "^FS" & vbNewLine '''''month

                    s1 &= "^FT131,109^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(9).Value & "^FS" & vbNewLine '''' yr 

                    s1 &= "^FT15,146^A0N,25,24^FH\^FD" & dgv.Rows(i).Cells(5).Value & "^FS" & vbNewLine ''''lot

                    s1 &= "^PQ1,0,1,Y^XZ" & vbNewLine

                Next


            End If

            sql = "update jan_gate_lines set lot_no='" & dgv.Rows(i).Cells(5).Value & "',sticker_print_flag=1,no_of_box ='" & dgv.Rows(i).Cells(12).Value & "' where gate_no=" & dgv.Rows(i).Cells(8).Value & "  and item='" & dgv.Rows(i).Cells(2).Value & "'"

            func()


        Next
        x1 = "d:\lotsticker.txt"

        fstrm = New FileStream(x1, FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s1)
        sw.Close()
        fstrm.Close()

        sql = "select SYS_CONTEXT('USERENV','IP_ADDRESS') IP from DUAL"
        cl.oradap = New OracleClient.OracleDataAdapter(cl.sql,cl.oracon)
        Dim DSAP As New DataSet
        adap.Fill(DSAP, "RESULT")
        Dim IPAD As String = ""

        If DSAP.Tables("RESULT").Rows.Count > 0 Then
            IPAD = DSAP.Tables("RESULT").Rows(0).Item("IP")
        End If


        ''''NEW_STICKER(sender, e)

        fstrm = New FileStream("d:\lotprint.bat", FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine("COPY " & x1 & " \\" & IPAD & "\\Zebra")
        sw.Close()
        fstrm.Close()
        Shell("d:\lotprint.bat", AppWinStyle.Hide)



    End Sub
    Public Sub func()
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
    End Sub
    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            dgv.Columns.Clear()

            Dim cc As New DataGridViewCheckBoxColumn
            cc.Width = 30
            Me.dgv.Columns.Add(cc)
            sql = "select jan_orgcode(a.org_id)org, a.item,a.description,sum(a.supdcqty)qty,case when sticker_print_flag=1 then a.lot_no else JAN_fifo_LOTno(a.gate_no,a.Org_id,a.item_id,'PO') end lot_no,b.gtype,b.supplier_name ,b.gate_no,to_char(b.gdate,'yyyy')yr,to_char(b.gdate,'Mon')mth,  sticker_print_flag  from jan_gate_lines a ,jan_gatE_header b where b.gdate>=TO_DATE('" & Format(DateTimePicker1.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and b.gdAtE<=TO_DATE('" & Format(DateTimePicker2.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and b.unit='UNIT7' and a.gate_no=b.gate_no "

            If txtgno.Text <> "" Then sql &= " and  a.gate_no='" & txtgno.Text & "'"

            If cmbtype.SelectedItem <> "" Then sql &= " and gtype='" & cmbtype.Text & "'"

            If chkpend.Checked = True Then sql &= " and sticker_print_flag  IS NULL"

            If cmborg.SelectedItem <> "" Then sql &= " and  a.org_id=jan_orgid('" & cmborg.SelectedItem & "') "

            sql &= " group by a.item,a.description,a.Org_id,a.item_id,b.gtype,b.supplier_name,to_char(b.gdate,'yyyy') ,to_char(b.gdate,'Mon'),b.gate_no, sticker_print_flag  ,a.lot_no order by  b.gate_no"

            cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
            ds1 = New DataSet
            adap.Fill(ds1, "resultab")

            With dgv
                .DataSource = ds1.Tables("resultab")
                .Columns(1).HeaderText = "Org" : .Columns(1).Width = 40
                .Columns(2).HeaderText = "Item No" : .Columns(2).Width = 80
                .Columns(3).HeaderText = "Item Desc" : .Columns(3).Width = 150
                .Columns(4).HeaderText = "Qty" : .Columns(4).Width = 50
                .Columns(5).HeaderText = "Lot No" : .Columns(5).Width = 140
                .Columns(6).HeaderText = "Type" : .Columns(6).Width = 50
                .Columns(7).HeaderText = "Vendor" : .Columns(7).Width = 250
                .Columns(8).HeaderText = "Gate No" : .Columns(8).Width = 100
                .Columns(9).Visible = False
                .Columns(10).Visible = False
                .Columns(11).Visible = False


            End With


            Dim cc1 As New DataGridViewTextBoxColumn
            cc1.HeaderText = "No Of Packet"
            cc1.Width = 70
            Me.dgv.Columns.Add(cc1)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Me.Cursor = Cursors.Arrow

    End Sub

    'Private Sub dgv_CellFormatting(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv.CellFormatting

    '    If Not IsDBNull(dgv.Rows(e.RowIndex).Cells(11).Value) Then
    '        e.CellStyle.ForeColor = Color.MediumVioletRed
    '        e.CellStyle.Font = New Font("verdana", 8)
    '    Else
    '        e.CellStyle.ForeColor = Color.Black
    '    End If



    '  End Sub
End Class