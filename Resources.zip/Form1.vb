﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sql = "SELECT 0 gate1_Rating,round( JAN_individual_rate_summary ('122021',A.Last_name,'Rating',A.location,'AML',A.EMPloyee_NUMBER),2) month_Individual_Rating_Average ,A.* FROM JAN_EMP_MAST_V A WHERE  location='BANGALORE' AND level1 like 'AML%' ORDER BY LAST_NAME,REPORTING_TO_NAME"

        adap = New OracleClient.OracleDataAdapter(sql, CON)
        ds = New DataSet
        adap.Fill(ds, "val")

        s = "<html><body>"
        s &= "<table border=1 width=100%><tr><td>Emp</td><td>name</td></tr>"

        For k = 0 To ds.Tables("val").Rows.Count - 1

            If ds.Tables("val").Rows.Count - 1 Then

                With ds.Tables("val").Rows(k)


                    If .Item("reporting_to").ToString = "" Then
                        s &= "<tr><td colspan=2 >&nbsp;</td></tr> "
                    End If
                    s &= " <tr> <td> " & .Item("employee_number") & "</td> <td> " & .Item("employee_number") & "</td>  </tr> "
                End With
            End If


        Next

    End Sub
End Class