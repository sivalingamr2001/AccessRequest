Imports System.Data.OracleClient
Imports System.IO
Imports oracleclass
Public Class excess_release

    Dim cl As New oracleclass.Class1
    Dim ip As String
    Dim host As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName)
    Dim val, val1, val2 As Double


    Private Sub excess_release_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ip = host.AddressList.GetValue(0).ToString

        If txtrole.Text = "USER" And (ip = "192.168.12.157" Or ip = "192.168.0.178") Then

            btnsave.Enabled = True

        ElseIf txtrole.Text = "USER1" And (ip = "192.168.12.11" Or ip = "192.168.0.178") Then

            btnsave.Enabled = True

        Else

            btnsave.Visible = False

        End If
        '    If  And (Or ip = "192.168.0.178") Then btnsave.Enabled = True Else btnsave.Enabled = False Or ip = "192.168.13.11"

        sql = "SELECT distinct supplier_name  supplier From jan_gate_header"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "RESULTAB")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbsup.Items.Add(ds.Tables("resultab").Rows(i).Item("supplier").ToString.Replace("'", "''"))
        Next

        sql = "select organization_code  from org_organization_definitions where organization_code  not in('I08','I09')order by organization_code"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub



    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try
            If txtrem.Text <> "" Then


                sql = "update jan_gate_excess_qty set rel_remark='" & txtrem.Text & "',rel_dt=sysdate,last_updt=sysdate  where gate_no=" & dgv.CurrentRow.Cells(0).Value & " and line_no=" & dgv.CurrentRow.Cells(9).Value & " "

                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                cl.oracon.Close()


                sql = "update jan_gate_lines set validated=1 where gate_no=" & dgv.CurrentRow.Cells(0).Value & " and line_no=" & dgv.CurrentRow.Cells(9).Value & " "

                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                CON.Close()

                '  valnow()

                MessageBox.Show("Remark Saved", "Gate Register")
                txtrem.Text = ""

                '   sql = "select gatE_no,(select supplier_name from jan_gatE_header where gatE_no=a.gatE_no)sup,jan_orgcodE(org_id)org,req_qty,(select sum(supdcqty) from jan_gatE_lines where gate_no=a.gatE_no  )recpt_qty,(select unit_price from po_lines_all where po_line_id=(select poline from jan_gatE_lines where line_no=a.line_no and item_id=jan_itemno(a.item_no) and rownum=1))price  from jan_gate_excess_qty a  where rel_remark is not null  "


            Else
                MessageBox.Show("Enter Remark", "Gate Register")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Sub lastval()
        sql = "SELECT DISTINCT  item_no,gate_no, sum(req_qty)req_qty,  sum(gt)recpt_qty  ,     price      FROM (SELECT poline,item_no,gate_no, (recpt_qty - req_qty) diff, recpt_qty,  req_qty,  RECPT_QTY gt,    nvl((SELECT  unit_price     FROM po_lines_all  WHERE po_line_id = a.POLINE   and item_id=jan_itemno(a.item_no)) ,0)  price  FROM jan_gate_excess_qty a    WHERE(rel_remark Is Not NULL) and gdate<='31-mar-2011' AND vendor_id NOT IN (1961, 1895, 2103, 934327)) GROUP BY gate_no,price,item_no "

        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")

        lblastex.Text = 0

        val = 0
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            val += (ds.Tables("resultab").Rows(i).Item("recpt_qty") - ds.Tables("resultab").Rows(i).Item("req_qty")) * ds.Tables("resultab").Rows(i).Item("price")
        Next

        lblastex.Text = FormatNumber(Math.Round(val, 2))
    End Sub
    Public Sub valnow()

        ' sql = "select distinct gatE_no,req_qty,sum(gt)recpt_qty, price from  (select gate_no, (recpt_qty- req_qty )diff,	recpt_qty, req_qty,(select  supdcqty  from jan_gatE_lines where gate_no=a.gatE_no and line_no=a.line_no )  gt,       (SELECT unit_price FROM po_lines_all    WHERE po_line_id =   (SELECT poline     FROM jan_gate_lines  WHERE line_no = a.line_no   AND item_id = jan_itemno (a.item_no)   AND ROWNUM = 1)) price  FROM jan_gate_excess_qty a  WHERE rel_remark Is Not NULL AND VENDOR_ID NOT IN (1961,1895,2103,934327))   group by gatE_no ,req_qty, price"

        ' sql = "SELECT DISTINCT gate_no, req_qty, SUM (gt) recpt_qty,   PRICE      FROM (SELECT gate_no, (recpt_qty - req_qty) diff, recpt_qty,    req_qty,    (SELECT supdcqty    FROM(jan_gate_lines)  WHERE(gate_no = a.gate_no)  AND line_no = a.line_no) gt,  (SELECT unit_price     FROM(po_lines_all)  WHERE po_line_id =A.POLINE AND ROWNUM=1)    price  FROM jan_gate_excess_qty a   WHERE(rel_remark Is Not NULL)  AND vendor_id NOT IN (1961, 1895, 2103, 934327))  GROUP BY gate_no, req_qty,   PRICE "





        '  sql = "SELECT DISTINCT  item_no,gate_no, sum(req_qty)req_qty,  sum(gt)recpt_qty  , sum(allow_qty)allow_qty,    price,org_id, nvl((SELECT  sum(po_in_receiving+job_follow+po_follow+po_torele+job_torele) FROM jan_so_requirement_master_new where organization_id=x.org_id and INVENTORY_ITEM_ID=JAN_ITEMNO(x.item_NO)),0)m2o_qty ,(select supplier_name from jan_gate_header where gate_no=x.gate_no)vendor_name      FROM (SELECT poline,item_no,gate_no, (recpt_qty - req_qty) diff, recpt_qty,  req_qty,  RECPT_QTY gt, allow_qty ,  nvl((SELECT  unit_price     FROM po_lines_all  WHERE po_line_id = a.POLINE   and item_id=jan_itemno(a.item_no)) ,0)  price,org_id  FROM jan_gate_excess_qty a    WHERE(rel_remark Is Not NULL) and   trunc(gdate)>='" & Format(inwdtf.Value, "dd-MMM-yyyy") & "' AND TRUNC(GDATE)<='" & Format(INWDTTO.Value, "dd-MMM-yyyy") & "'   AND vendor_id NOT IN (1961, 1895, 2103, 934327)"



        sql = "SELECT distinct  gate_no, gdate,(select vendor_name from po_vendors where vendor_id=x.vendor_id)supplier,item_no,org_id,sum(req_qty)req_qty,sum(allow_qty)allow_qty,sum(gqty)recpt_qty,unit_price , nvl((SELECT  sum(po_in_receiving+job_follow+po_follow+po_torele+job_torele) FROM jan_so_requirement_master_new where organization_id=x.org_id and INVENTORY_ITEM_ID=JAN_ITEMNO(x.item_NO)),0)m2o_qty FROM (SELECT DISTINCT gate_no,  gdate,ITEM_NO,ORG_ID,vendor_id,sum(REQ_QTY)req_qty,sum(allow_qty)allow_qty,NVL((SELECT SUM(SUPDCQTY) FROM JAN_GATe_LINES        WHERE(TRUNC(GDATE) = TRUNC(a.GDATE) And FLAG = 1 And ITEM = a.ITEM_NO)),0) GQTY,(SELECT UNIT_PRICE FROM PO_LINES_ALL WHERE ITEM_ID=JAN_ITEMNO(A.ITEM_NO) AND PO_LINE_ID=A.POLINE)UNIT_PRICE  FROM JAN_GATe_EXCESS_qTY A WHERE trunc(gdate)>='" & Format(inwdtf.Value, "dd-MMM-yyyy") & "' AND TRUNC(GDATE)<='" & Format(INWDTTO.Value, "dd-MMM-yyyy") & "' and rel_remark Is Not NULL AND vendor_id NOT IN (1961, 1895, 2103, 934327)"

        If cmborg.Text <> "" Then sql &= " and org_id=jan_orgid('" & cmborg.Text & "')"

        If txtgate.Text <> "" Then sql &= " and gate_no=" & txtgate.Text & ""


        sql &= "  group by iTEM_NO,ORG_ID,GDATE,POLINE, gate_no, vendor_id )x group by iTEM_NO,ORG_ID,gdate,unit_price, gate_no, vendor_id"



        ' sql &= "  )x GROUP BY gate_no,price,org_id,item_no "

        Dim r As String = sql

        If cmbsup.Text <> "" Then sql = "select * from (" & r & ") where supplier='" & cmbsup.Text & "'"

        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")

        lbxs.Text = 0
        lbnext.Text = 0

        val1 = 0
        val2 = 0
        For i = 0 To ds.Tables("resultab").Rows.Count - 1

            If ds.Tables("resultab").Rows(i).Item("recpt_qty") < ds.Tables("resultab").Rows(i).Item("m2o_qty") = 0 Then
                val1 += (ds.Tables("resultab").Rows(i).Item("recpt_qty") - ds.Tables("resultab").Rows(i).Item("req_qty")) * ds.Tables("resultab").Rows(i).Item("unit_price")

            End If



            If ds.Tables("resultab").Rows(i).Item("allow_qty") = 0 And ds.Tables("resultab").Rows(i).Item("req_qty") = 0 Then
                val2 += (ds.Tables("resultab").Rows(i).Item("RECPT_qty") * ds.Tables("resultab").Rows(i).Item("unit_price"))
            End If

        Next

        lbxs.Text = FormatNumber(Math.Round(val1, 2))
        lbnext.Text = FormatNumber(Math.Round(val2, 2))

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            dgv.Columns.Clear()
            sql = "SELECT * FROM ( "
            sql &= "select gatE_no, trunc(gdate)gdate,(select gdate from jan_gatE_lines where gate_no=a.gatE_no and line_no=a.line_no)gdt,(select pono from jan_gatE_lines where gate_no=a.gatE_no and line_no=a.line_no)pono,(select podt from jan_gatE_lines where gate_no=a.gatE_no and line_no=a.line_no)podt,(select supplier_name from jan_gatE_header where gatE_no=a.gatE_no)sup,jan_orgcodE(org_id)org,item_no,(select description from mtl_system_items where segment1=a.item_No  and organization_id=105)descr,LINE_NO,req_qty,ALLOW_QTY,"

            sql &= "(SELECT SUM(REQ_4_ASSY-RSV_QTY) FROM JAN_TEST_SUB_ASSY_PEND4   WHERE COMPONENT_ITEM_ID=jan_itemno(a.item_no)  AND ORGANIZATION_ID=a.org_id)total_qty,"

            sql &= " (select supdcqty from jan_gatE_lines where gate_no=a.gatE_no and line_no=a.line_no)recpt_qty,"

            sql &= " round(((select supdcqty from jan_gatE_lines where gate_no=a.gatE_no and line_no=a.line_no)*(select unit_price from po_lines_all where po_line_id=A.POLINE)),2) price ,"

            sql &= " nvl((SELECT PO_PEND FROM JAN_PO_PENDING_BOUGHT_OUTS WHERE ITEM_NO=A.ITEM_NO AND SHIP_TO_ORGANIZATION_ID=A.ORG_ID AND LINE_LOCATION_ID =a.line_location_id),0)PO_PEND,"

            sql &= "nvl((SELECT  sum(po_in_receiving+job_follow+po_follow+po_torele+job_torele) FROM jan_so_requirement_master_new where organization_id=A.org_id and INVENTORY_ITEM_ID=JAN_ITEMNO(A.item_NO)),0)m20_qty,"

            sql &= " (SELECT NEED_BY_DATE FROM JAN_PO_PENDING_BOUGHT_OUTS WHERE ITEM_NO=A.ITEM_NO AND SHIP_TO_ORGANIZATION_ID=A.ORG_ID AND LINE_LOCATION_ID =(SELECT LOCATION_ID FROM JAN_GATe_LINES WHERE ITEM_NO=A.ITEM_NO AND LINE_NO=A.LINE_NO AND GATe_NO=A.GATe_NO))NEED,rel_dt ,rel_remark,"

            sql &= " (select validated from jan_gatE_header where gatE_no=a.gate_no)val ,nvl((SELECT  unit_price     FROM po_lines_all  WHERE po_line_id = a.POLINE   and item_id=jan_itemno(a.item_no)) ,0)  unit_price"



            sql &= "  from jan_gate_excess_qty a where 1=1 and trunc(gdate)>='" & Format(inwdtf.Value, "dd-MMM-yyyy") & "' AND TRUNC(GDATE)<='" & Format(INWDTTO.Value, "dd-MMM-yyyy") & "' "

            If cmborg.Text <> "" Then sql &= " and org_id=jan_orgid('" & cmborg.Text & "')"

            If txtgate.Text <> "" Then sql &= " and gate_no=" & txtgate.Text & ""

            Dim r As String



            If cmbsup.Text <> "" Then
                r = sql
                sql = "select * from (" & r & ") where sup='" & cmbsup.Text & "'"
            End If

            ' If CheckBox1.Checked = False Or CheckBox1.Checked = True Then COMMENTED ON 31-10-11 9.18 AM

            If CheckBox1.Checked = False Or CheckBox1.Checked = True Then
                r = sql
                sql = "select * from (" & r & ") where  VAL NOT IN (4,5,6)"
            End If


            sql &= " order by gatE_no,item_no"
            sql &= ") WHERE 1=1"

            If CheckBox1.Checked = False Then
                sql &= " AND  VAL>0"
            End If

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            With dgv

                .DataSource = ds.Tables("resultab")
                .Columns(0).HeaderText = "Gate No" : .Columns(0).Width = 70
                .Columns(1).HeaderText = "Gate Dt" : .Columns(1).Width = 80
                .Columns(2).HeaderText = "Gt Modified.Dt" : .Columns(2).Width = 70
                .Columns(3).HeaderText = "Po.No" : .Columns(3).Width = 85
                .Columns(4).HeaderText = "Po.Dt" : .Columns(4).Width = 80
                .Columns(5).HeaderText = "Vendor" : .Columns(5).Width = 150
                .Columns(6).HeaderText = "Org" : .Columns(6).Width = 30
                .Columns(7).HeaderText = "Item" : .Columns(7).Width = 80
                .Columns(8).HeaderText = "Desc" : .Columns(8).Width = 100
                .Columns(9).HeaderText = "Line.No" : .Columns(9).Width = 40
                .Columns(10).HeaderText = "Req Qty" : .Columns(10).Width = 40
                .Columns(11).HeaderText = "Allow.Qty" : .Columns(11).Width = 50
                .Columns(12).HeaderText = "Total.Qty" : .Columns(12).Width = 50
                .Columns(13).HeaderText = "Recpt.Qty" : .Columns(13).Width = 50
                .Columns(14).HeaderText = "Recpt Rt" : .Columns(14).Width = 60
                .Columns(15).HeaderText = "Po Pend" : .Columns(15).Width = 50
                .Columns(16).HeaderText = "M2O Qty" : .Columns(16).Width = 50
                .Columns(17).HeaderText = "Need.By.Dt" : .Columns(17).Width = 80
                .Columns(18).HeaderText = "Val.Dt" : .Columns(18).Width = 80
                .Columns(19).HeaderText = "Remarks" : .Columns(19).Visible = False

                .Columns(20).Visible = False

                If ip = "192.168.12.157" Or ip = "192.168.0.178" Or ip = "192.168.12.11 Then" Then
                    .Columns(21).HeaderText = "Unit.Price" : .Columns(21).Width = 60
                Else
                    .Columns(21).Visible = False
                End If
            End With
            lastval()
            valnow()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click

    End Sub

    Private Sub dgv_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellClick
        Try
            sql = "select rel_remark from jan_gate_exCEss_qty where gatE_no=" & dgv.CurrentRow.Cells(0).Value & " AND LINE_NO= " & dgv.CurrentRow.Cells(9).Value & " "
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            If ds.Tables("resultab").Rows.Count > 0 Then
                txtrem.Text = ds.Tables("resultab").Rows(0).Item("rel_remark").ToString
            Else
                txtrem.Text = ""
            End If




            sql = "SELECT GATe_NO,ITEM,SUPDCQTY FROM JAN_GATe_LINES WHERE TRUNC(GDATE)='" & Format(dgv.CurrentRow.Cells(1).Value, "dd-MMM-yyyy") & "' AND GATE_NO<>" & dgv.CurrentRow.Cells(0).Value & " and item='" & dgv.CurrentRow.Cells(7).Value & "' "
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")

            If ds.Tables("resultab").Rows.Count > 0 Then
                With DGVLINE

                    .DataSource = ds.Tables("RESULTAB")
                    .Columns(0).HeaderText = "Gate.No" : .Columns(0).Width = 80
                    .Columns(1).HeaderText = "Item.No" : .Columns(1).Width = 80
                    .Columns(2).HeaderText = "Dc.Qty" : .Columns(2).Width = 60 : .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                End With
            Else
                DGVLINE.Columns.Clear()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub dgv_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv.CellFormatting
        For i = 0 To dgv.Rows.Count - 1
            If dgv.Rows(i).Cells(20).Value = 0 Then
                dgv.Rows(i).DefaultCellStyle.ForeColor = Color.Green
            Else
                dgv.Rows(i).DefaultCellStyle.ForeColor = Color.Black
            End If
        Next
    End Sub


    Private Sub BTNPRINT_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BTNPRINT.Click
        Try
            s = ""
            s = "<html><body>"
            s = "<h4 align=center><font face=verdana size=2>Excess Qty List- From " & Format(inwdtf.Value, "dd-MMM-yyyy") & "To" & Format(INWDTTO.Value, "dd-MMM-yyyy") & " <br> "

            If cmborg.Text <> "" Then s &= " Org: " & cmborg.Text & " <br> "

            If cmbsup.Text <> "" Then s &= " Vendor: " & cmbsup.Text & " <br> "



            s &= "Report As On: " & Date.Now

            s &= "</font>"

            s &= "</h4>"
            s &= "<TABLE border=1 cellspacing=0 cellpadding=2><tr>"
            s &= " <td><FONT SIZE=1.5 font face=verdana>S.No</td> "
            For l1 = 0 To dgv.Columns.Count - 2
                With dgv.Columns(l1)
                    s &= " <td><FONT SIZE=1.5 font face=verdana>" & .HeaderText & "</td>  "
                End With

            Next

            s &= "</tr>"


            j = 0
            For k = 0 To dgv.Rows.Count - 1
                j += 1

                s &= "<tr>"
                s &= " <td><FONT SIZE=1.5 font face=verdana>" & j & " </td> "
                For l1 = 0 To dgv.Columns.Count - 2


                    With dgv.Rows(k)
                        s &= " <td><FONT SIZE=1.5 font face=verdana>" & .Cells(l1).Value & "  "
                    End With

                Next

                s &= "</tr>"

            Next
            s &= "</table></body></html>"

            x1 = "c:\excess qty.HTML "



            fstrm = New FileStream(x1, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            sw.WriteLine(s)
            fstrm.Flush()
            sw.Flush()
            sw.Close()
            fstrm.Close()
            System.Diagnostics.Process.Start(x1)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label10.Click

    End Sub

    Private Sub cmbsup_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbsup.SelectedIndexChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click, Label11.Click

    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        For i = 0 To dgv.Rows.Count - 1
            If dgv.Rows(i).DefaultCellStyle.ForeColor = Color.Green Then
                dgv.Rows(i).Visible = True
            Else
                dgv.Rows(i).Visible = False
            End If
        Next
    End Sub
End Class