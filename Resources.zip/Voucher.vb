Imports System.Data.OracleClient
Public Class Voucher

    Dim ds As New DataSet
    Dim sql As String
    Dim i As Integer
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            If txtvou.Text <> "" Then
                sql = "update jan_gate_header set voucher='" & txtvou.Text & "' where gate_no='" & txtgate.Text & "' and supplier_name ='" & txtsup.Text & "' and dc_no='" & txtdc.Text & "'"
                If cl.oracon.State = ConnectionState.Closed Then
                    cl.oracon.Open()
                End If
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                MessageBox.Show("Voucher No Added", "Gate Entry")
            Else
                MessageBox.Show("Enter Voucher Number", "Gate Entry")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cl.oracon.Close()
        End Try
    End Sub
    Private Sub Voucher_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.StartPosition = FormStartPosition.CenterParent
    End Sub
    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class