<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class non_po
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbcat = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtsup = New System.Windows.Forms.TextBox()
        Me.dtdc = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtdcno = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtveh = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.cmbsup = New System.Windows.Forms.ComboBox()
        Me.chknon = New System.Windows.Forms.CheckBox()
        Me.btnrep = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dtto = New System.Windows.Forms.DateTimePicker()
        Me.dtfm = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnprint = New System.Windows.Forms.Button()
        Me.txtgno = New System.Windows.Forms.TextBox()
        Me.chkogt = New System.Windows.Forms.CheckBox()
        Me.txtrole = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtogno = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtper = New System.Windows.Forms.TextBox()
        Me.cmbres = New System.Windows.Forms.ComboBox()
        Me.ddltranp = New System.Windows.Forms.ComboBox()
        Me.ddldept = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtjper = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtbin = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmbcat
        '
        Me.cmbcat.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcat.FormattingEnabled = True
        Me.cmbcat.Items.AddRange(New Object() {"BINS", "CASH PURCHASE", "COURIER - POD", "INTER UNIT TRANSFERS", "MAINTENANCE ITEMS", "OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "SALES RETURN", "TESTING", "DELIVERY CHALLAN", "END BIT"})
        Me.cmbcat.Location = New System.Drawing.Point(122, 6)
        Me.cmbcat.Name = "cmbcat"
        Me.cmbcat.Size = New System.Drawing.Size(226, 21)
        Me.cmbcat.TabIndex = 49
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(13, 6)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 20)
        Me.Label19.TabIndex = 56
        Me.Label19.Text = "Inward Category"
        '
        'txtsup
        '
        Me.txtsup.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsup.Location = New System.Drawing.Point(122, 38)
        Me.txtsup.Name = "txtsup"
        Me.txtsup.Size = New System.Drawing.Size(294, 21)
        Me.txtsup.TabIndex = 52
        Me.txtsup.Visible = False
        '
        'dtdc
        '
        Me.dtdc.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdc.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdc.Location = New System.Drawing.Point(583, 9)
        Me.dtdc.Name = "dtdc"
        Me.dtdc.Size = New System.Drawing.Size(99, 21)
        Me.dtdc.TabIndex = 51
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(537, 13)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 13)
        Me.Label7.TabIndex = 55
        Me.Label7.Text = "DC DT"
        '
        'txtdcno
        '
        Me.txtdcno.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdcno.Location = New System.Drawing.Point(420, 6)
        Me.txtdcno.Name = "txtdcno"
        Me.txtdcno.Size = New System.Drawing.Size(98, 21)
        Me.txtdcno.TabIndex = 50
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(351, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(68, 13)
        Me.Label6.TabIndex = 54
        Me.Label6.Text = "DC/Inv No"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 53
        Me.Label1.Text = "Supplier"
        '
        'txtveh
        '
        Me.txtveh.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtveh.Location = New System.Drawing.Point(122, 70)
        Me.txtveh.Multiline = True
        Me.txtveh.Name = "txtveh"
        Me.txtveh.Size = New System.Drawing.Size(143, 18)
        Me.txtveh.TabIndex = 91
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(13, 72)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(98, 25)
        Me.Label14.TabIndex = 92
        Me.Label14.Text = "Vehicle No"
        '
        'btnsave
        '
        Me.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsave.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(18, 184)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(55, 41)
        Me.btnsave.TabIndex = 90
        Me.btnsave.Text = "&Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'cmbsup
        '
        Me.cmbsup.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsup.FormattingEnabled = True
        Me.cmbsup.Items.AddRange(New Object() {"OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "INTER UNIT TRANSFERS ", "MAINTENANCE ITEMS", "CASH PURCHASE", "BINS", "SALES RETURN", "COURIER - POD"})
        Me.cmbsup.Location = New System.Drawing.Point(122, 38)
        Me.cmbsup.Name = "cmbsup"
        Me.cmbsup.Size = New System.Drawing.Size(396, 21)
        Me.cmbsup.TabIndex = 49
        '
        'chknon
        '
        Me.chknon.AutoSize = True
        Me.chknon.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chknon.Location = New System.Drawing.Point(535, 36)
        Me.chknon.Name = "chknon"
        Me.chknon.Size = New System.Drawing.Size(134, 17)
        Me.chknon.TabIndex = 93
        Me.chknon.Text = "Non Master Vendor"
        Me.chknon.UseVisualStyleBackColor = True
        '
        'btnrep
        '
        Me.btnrep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrep.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrep.Location = New System.Drawing.Point(78, 184)
        Me.btnrep.Name = "btnrep"
        Me.btnrep.Size = New System.Drawing.Size(57, 41)
        Me.btnrep.TabIndex = 90
        Me.btnrep.Text = "Report"
        Me.btnrep.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.dtto)
        Me.Panel1.Controls.Add(Me.dtfm)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.btnprint)
        Me.Panel1.Controls.Add(Me.txtgno)
        Me.Panel1.Location = New System.Drawing.Point(142, 184)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(553, 41)
        Me.Panel1.TabIndex = 94
        Me.Panel1.Visible = False
        '
        'dtto
        '
        Me.dtto.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtto.Location = New System.Drawing.Point(379, 8)
        Me.dtto.Name = "dtto"
        Me.dtto.Size = New System.Drawing.Size(93, 21)
        Me.dtto.TabIndex = 72
        '
        'dtfm
        '
        Me.dtfm.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtfm.Location = New System.Drawing.Point(261, 8)
        Me.dtfm.Name = "dtfm"
        Me.dtfm.Size = New System.Drawing.Size(93, 21)
        Me.dtfm.TabIndex = 73
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(356, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 13)
        Me.Label2.TabIndex = 74
        Me.Label2.Text = "To"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(3, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 75
        Me.Label4.Text = "Gate No"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(192, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 75
        Me.Label3.Text = "Gate Date"
        '
        'btnprint
        '
        Me.btnprint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnprint.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprint.Location = New System.Drawing.Point(478, 5)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(69, 26)
        Me.btnprint.TabIndex = 90
        Me.btnprint.Text = "Print"
        Me.btnprint.UseVisualStyleBackColor = True
        '
        'txtgno
        '
        Me.txtgno.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgno.Location = New System.Drawing.Point(62, 8)
        Me.txtgno.Name = "txtgno"
        Me.txtgno.Size = New System.Drawing.Size(124, 21)
        Me.txtgno.TabIndex = 50
        '
        'chkogt
        '
        Me.chkogt.AutoSize = True
        Me.chkogt.Location = New System.Drawing.Point(535, 68)
        Me.chkogt.Name = "chkogt"
        Me.chkogt.Size = New System.Drawing.Size(88, 17)
        Me.chkogt.TabIndex = 95
        Me.chkogt.Text = "Old Gate Ref"
        Me.chkogt.UseVisualStyleBackColor = True
        Me.chkogt.Visible = False
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(595, 139)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(100, 20)
        Me.txtrole.TabIndex = 96
        Me.txtrole.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(532, 107)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 54
        Me.Label5.Text = "Old G.No"
        Me.Label5.Visible = False
        '
        'txtogno
        '
        Me.txtogno.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtogno.Location = New System.Drawing.Point(595, 105)
        Me.txtogno.Name = "txtogno"
        Me.txtogno.Size = New System.Drawing.Size(117, 21)
        Me.txtogno.TabIndex = 50
        Me.txtogno.Visible = False
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(271, 70)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(98, 40)
        Me.Label8.TabIndex = 92
        Me.Label8.Text = "Responsible  Person"
        '
        'txtper
        '
        Me.txtper.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtper.Location = New System.Drawing.Point(346, 68)
        Me.txtper.Multiline = True
        Me.txtper.Name = "txtper"
        Me.txtper.Size = New System.Drawing.Size(172, 20)
        Me.txtper.TabIndex = 91
        '
        'cmbres
        '
        Me.cmbres.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbres.FormattingEnabled = True
        Me.cmbres.Items.AddRange(New Object() {"BINS", "CASH PURCHASE", "COURIER - POD", "INTER UNIT TRANSFERS", "MAINTENANCE ITEMS", "OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "SALES RETURN", "TESTING", "DELIVERY CHALLAN"})
        Me.cmbres.Location = New System.Drawing.Point(346, 68)
        Me.cmbres.Name = "cmbres"
        Me.cmbres.Size = New System.Drawing.Size(162, 21)
        Me.cmbres.TabIndex = 49
        '
        'ddltranp
        '
        Me.ddltranp.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ddltranp.FormattingEnabled = True
        Me.ddltranp.Location = New System.Drawing.Point(346, 103)
        Me.ddltranp.Name = "ddltranp"
        Me.ddltranp.Size = New System.Drawing.Size(172, 21)
        Me.ddltranp.TabIndex = 107
        '
        'ddldept
        '
        Me.ddldept.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ddldept.FormattingEnabled = True
        Me.ddldept.Location = New System.Drawing.Point(122, 105)
        Me.ddldept.Name = "ddldept"
        Me.ddldept.Size = New System.Drawing.Size(143, 21)
        Me.ddldept.TabIndex = 108
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(271, 105)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(76, 28)
        Me.Label26.TabIndex = 105
        Me.Label26.Text = "Transport Mode"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(13, 107)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(76, 13)
        Me.Label27.TabIndex = 106
        Me.Label27.Text = "Department"
        '
        'txtjper
        '
        Me.txtjper.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtjper.Location = New System.Drawing.Point(346, 142)
        Me.txtjper.Name = "txtjper"
        Me.txtjper.Size = New System.Drawing.Size(172, 20)
        Me.txtjper.TabIndex = 101
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(273, 142)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(67, 26)
        Me.Label28.TabIndex = 100
        Me.Label28.Text = "Person Name"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(13, 144)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 25)
        Me.Label9.TabIndex = 92
        Me.Label9.Text = "Bin Qty"
        '
        'txtbin
        '
        Me.txtbin.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbin.Location = New System.Drawing.Point(122, 142)
        Me.txtbin.Multiline = True
        Me.txtbin.Name = "txtbin"
        Me.txtbin.Size = New System.Drawing.Size(143, 18)
        Me.txtbin.TabIndex = 91
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(267, 288)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(81, 16)
        Me.Label10.TabIndex = 92
        Me.Label10.Text = "Scrap Qty"
        Me.Label10.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(346, 286)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(143, 18)
        Me.TextBox1.TabIndex = 91
        Me.TextBox1.Visible = False
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(13, 279)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 35)
        Me.Label11.TabIndex = 106
        Me.Label11.Text = "Scrap Category"
        Me.Label11.Visible = False
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Aluminum", "Brass", "Copper"})
        Me.ComboBox1.Location = New System.Drawing.Point(122, 286)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(143, 21)
        Me.ComboBox1.TabIndex = 108
        Me.ComboBox1.Visible = False
        '
        'non_po
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(747, 319)
        Me.Controls.Add(Me.txtjper)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.ddltranp)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.ddldept)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.chkogt)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.chknon)
        Me.Controls.Add(Me.txtper)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtbin)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtveh)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.btnrep)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.cmbsup)
        Me.Controls.Add(Me.cmbres)
        Me.Controls.Add(Me.cmbcat)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtsup)
        Me.Controls.Add(Me.dtdc)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtogno)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtdcno)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Name = "non_po"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Non PO Inward"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbcat As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtsup As System.Windows.Forms.TextBox
    Friend WithEvents dtdc As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtdcno As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtveh As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents cmbsup As System.Windows.Forms.ComboBox
    Friend WithEvents chknon As System.Windows.Forms.CheckBox
    Friend WithEvents btnrep As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtto As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnprint As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtgno As System.Windows.Forms.TextBox
    Friend WithEvents chkogt As CheckBox
    Friend WithEvents txtrole As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtogno As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtper As TextBox
    Friend WithEvents cmbres As ComboBox
    Friend WithEvents ddltranp As ComboBox
    Friend WithEvents ddldept As ComboBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents txtjper As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtbin As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents ComboBox1 As ComboBox
End Class
