﻿Imports System.Data
Imports System.Data.OracleClient
Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports oracleclass
Public Class gt_checked

    Dim cl As New oracleclass.Class1
    Dim idx, idx1, gqty, l As Integer
    Private Sub gt_checked_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        sql = "select organization_code  from MTL_PARAMETERS where organization_id in (select org_id from jan_gatE_lines where gate_no=" & txtgate.Text & " ) order by organization_code"
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next


        Dim arrayList = pack_met.Split(",")
        For Each value As String In arrayList
            cmbpack.Items.Add(value)
        Next


        If unit = "UNIT7" Then
            GroupBox3.Visible = True

            sql = "select  item,sum(supdcqty)qty  from jan_gate_lines where  gate_no=" & txtgate.Text & "  group by item "
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "items")

            For k = 0 To ds.Tables("items").Rows.Count - 1
                cmbpitem.Items.Add(String.Concat(ds.Tables("items").Rows(k).Item("item"), "*", ds.Tables("items").Rows(k).Item("qty")))
            Next

            arrayList = pack_met.Split(",")
            cmbpk.Items.Clear()

            For Each value As String In arrayList
                cmbpk.Items.Add(value.Trim())
            Next


            sql = "select count(*) from jan_gate_lines where  gate_no=" & txtgate.Text & "  and item_check_by is not null"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "chkcnt")
            If ds.Tables("chkcnt").Rows(0).Item(0) = 0 Then
                txtstby.Select()
            Else
                sql = "select item_check_by,CHECKED_BY   from jan_gate_lines where  gate_no=" & txtgate.Text & "  and rownum=1"
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "chkval")
                txtstby.Text = ds.Tables("chkval").Rows(0).Item(0)
                txtchk.Text = ds.Tables("chkval").Rows(0).Item(1)
                txtchk.Select()
            End If

            sql = "select ITEM_NO, GATE_QTY, PACK_METHOD, NO_OF_PACK, PACK_QTY, pack_qty total_qty , STATUS from jan_gate_pack_Details a where gate_no=" & txtgate.Text & " "
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "pack")
            If ds.Tables("pack").Rows.Count > 0 Then
                dgvpack.Columns(0).DataPropertyName = "item_no"
                dgvpack.Columns(1).DataPropertyName = "gate_qty"
                dgvpack.Columns(2).DataPropertyName = "pack_method"
                dgvpack.Columns(3).DataPropertyName = "no_of_pack"
                dgvpack.Columns(4).DataPropertyName = "pack_qty"
                dgvpack.Columns(5).DataPropertyName = "total_qty"
                dgvpack.Columns(6).DataPropertyName = "STATUS"
                dgvpack.DataSource = ds.Tables("pack")
                dgvpack.Columns(6).Visible = False
                For l = 0 To dgvpack.Rows.Count - 1
                    If dgvpack.Rows(l).Cells(0).Value <> "" Then
                        If dgvpack.Rows(l).Cells(6).Value.ToString() = "MISMATCH" Then
                            dgvpack.Rows(l).Cells(5).Style.BackColor = Color.Red
                        Else
                            dgvpack.Rows(l).Cells(5).Style.BackColor = Color.LightYellow
                        End If
                    End If
                Next
            End If

        Else
            Me.Width = 760
            Me.Height = 267
            Me.StartPosition = FormStartPosition.CenterScreen
        End If

    End Sub

    Private Sub btngo_Click(sender As Object, e As EventArgs) Handles btngo.Click

        If unit = "UNIT7" Then

            sql = "select count(*)  from jan_gate_lines where  gate_no=" & txtgate.Text & "  and item_check_by is not null"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "chkval")

            sql = "select count(*) from JAN_INSP_TRACEABILITY_T where DIVISION='INWARD' and ref_id= "

            If ds.Tables("chkval").Rows(0).Item(0) = 0 Then

                sql &= "  '" & txtstby.Text.ToUpper & "'"
            Else
                sql &= "  '" & txtchk.Text.ToUpper & "'"
            End If

            '" & txtchk.Text.ToUpper & "'"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "namecnt")

            If ds.Tables("namecnt").Rows(0).Item(0) = 0 Then
                MessageBox.Show("Invalid Name", "Gate Register")
                Exit Sub
            End If
        End If

        If unit = "UNIT7" Then
            sql = "select count(*) from jan_gate_lines where  gate_no=" & txtgate.Text & "  and item_check_by is not null"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "chkcnt")

            If ds.Tables("chkcnt").Rows(0).Item(0) = 0 Then

                sql = "update jan_gate_lines  Set  item_check_Start =sysdate, item_check_by = (Select measurement_name from JAN_INSP_TRACEABILITY_T where DIVISION='INWARD' and  ref_id='" & txtstby.Text.ToUpper & "')  where gate_no=" & txtgate.Text & " "
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                cl.oracon.Close()
                MessageBox.Show("Start time For Item Counting Saved", "Gate Register")
            End If
        End If

        If txtchk.Text <> "" Then



            If txtqty.Text <> "" Then
                ' (select measurement_name from JAN_INSP_TRACEABILITY_T where DIVISION='INWARD' and  ref_id='" & txtchk.Text & "'),

                sql = "update jan_gate_lines Set checked_by ="

                If unit = "UNIT7" Then

                    sql &= "     (Select measurement_name from JAN_INSP_TRACEABILITY_T where DIVISION='INWARD' and  ref_id='" & txtchk.Text.ToUpper & "') "

                Else

                    sql &= " '" & txtchk.Text & "'"

                End If

                sql &= " ,item_location='" & txtqty.Text & "',other_checked_by='" & txt_oth.Text & "',item_checked_Dt=sysdate  "

                If txtshtr.Text <> "" Then sql &= ",shortage_qty =" & txtshtr.Text & " "

                If txtpqty.Text <> "" Then sql &= " ,pack_type  ='" & cmbpack.Text & "',pack_qty=" & Math.Round(Val(txtpqty.Text), 2) & " "

                sql &= "  where gate_no=" & txtgate.Text & " And org_id=jan_orgid('" & cmborg.Text & "')"

                If txtshtr.Text <> "" Then

                    idx = cmbitem.SelectedItem.IndexOf("*") + 1

                    idx1 = cmbitem.Text.ToString.Length - (cmbitem.SelectedItem.IndexOf("*") + 1)

                    sql &= " and   line_no= '" & cmbitem.SelectedItem.ToString.Substring(idx, idx1) & "'"

                End If

                'cmbitem.SelectedItem.ToString.Substring(cmbitem.SelectedItem.IndexOf("-") + 1, 2)
                cl.orcmd = New OracleCommand(sql, cl.oracon)
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd.ExecuteNonQuery()
                MessageBox.Show("Item Checked Details Added", "Gate Entry")
                txtqty.Text = ""
                cmborg.SelectedIndex = 0
                cmbchk1.Text = ""
            Else
                MessageBox.Show("Enter location To proceed", "Gate Entry")
                Exit Sub
            End If





        End If
    End Sub
    Private Sub cmborg_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmborg.SelectedIndexChanged
        sql = "Select   item||'*'|| line_no list from jan_gate_lines where gate_no= " & txtgate.Text & " and org_id=jan_orgid('" & cmborg.Text & "')"
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbitem.Items.Add(ds.Tables("resultab").Rows(i).Item("list"))
        Next

        txtchk.Select()
        'txtchk.ReadOnly = True

    End Sub
    Private Sub txtchk_Leave(sender As Object, e As EventArgs) Handles txtchk.Leave, txtstby.Leave
        'If txtchk.Text.Contains("others").ToString.ToUpper = True Or txtchk.Text.Contains("direct").ToString.ToUpper = True Then
        '    txt_oth.Visible = True
        '    txt_oth.Select()
        'Else
        '    txt_oth.Visible = False
        'End If

    End Sub

    Private Sub txtshtr_Leave(sender As Object, e As EventArgs) Handles txtshtr.Leave
        If txtshtr.Text > gqty Then
            MessageBox.Show("Shortage Qty entered is more than received qty for the line,correct qty and proceed", "Gate Register")
            txtshtr.Text = ""
            Exit Sub
        End If
    End Sub

    Private Sub dgvpack_CellLeave(sender As Object, e As DataGridViewCellEventArgs) Handles dgvpack.CellLeave
        If dgvpack.CurrentCell.ColumnIndex = 5 Then
            dgvpack.CurrentRow.Cells(5).Value = Val(dgvpack.CurrentRow.Cells(3).Value) * Val(dgvpack.CurrentRow.Cells(4).Value)
        End If
    End Sub

    Private Sub btnpack_Click(sender As Object, e As EventArgs) Handles btnpack.Click
        If dgvpack.Rows.Count > 0 Then

            sql = "select count(*) from jan_gate_pack_Details where gate_no=" & txtgate.Text & " and status='MISMATCH'"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "packcnt")

            If ds1.Tables("packcnt").Rows(0).Item(0) = 0 Then
                For k = 0 To dgvpack.Rows.Count - 1
                    With dgvpack.Rows(k)
                        If dgvpack.Rows(k).Cells(0).Value <> "" Then
                            sql = "insert into jan_gate_pack_Details (gate_no,item_No,gate_qty,pack_method ,no_of_pack,pack_qty ) values (" & txtgate.Text & ",'" & .Cells(0).Value & "'," & .Cells(1).Value & ",'" & .Cells(2).Value & "'," & .Cells(3).Value & "," & .Cells(5).Value & ")"
                            cl.orcmd = New OracleCommand(sql, cl.oracon)
                            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                            cl.orcmd.ExecuteNonQuery()

                        End If
                    End With
                Next
            Else
                sql = "delete from jan_gate_pack_Details where gate_no=" & txtgate.Text & ""
                cl.orcmd = New OracleCommand(sql, cl.oracon)
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd.ExecuteNonQuery()

                For k = 0 To dgvpack.Rows.Count - 1
                    With dgvpack.Rows(k)
                        If dgvpack.Rows(k).Cells(0).Value <> Nothing Then
                            Try
                                sql = "insert into jan_gate_pack_Details (gate_no,item_No,gate_qty,pack_method ,no_of_pack,pack_qty ) values (" & txtgate.Text & ",'" & .Cells(0).Value & "'," & .Cells(1).Value & ",'" & .Cells(2).Value & "'," & .Cells(3).Value & "," & .Cells(5).Value & ")"
                                cl.orcmd = New OracleCommand(sql, cl.oracon)
                                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                                cl.orcmd.ExecuteNonQuery()
                            Catch ex As Exception
                                MessageBox.Show(ex.Message)
                            End Try


                        End If
                    End With
                Next
            End If

            sql = "select GATE_NO, iTEM_NO,
    CASE WHEN MAX(GATE_QTY) = SUM(pack_qty) THEN 'MATCH' ELSE 'MISMATCH' END AS STATUS FROM jan_gate_pack_Details where gate_no=" & txtgate.Text & " GROUP BY GATE_NO, ITEM_NO  "
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "packdet")
            Dim l As Integer

            For l = 0 To ds.Tables("packdet").Rows.Count - 1
                sql = "update jan_gate_pack_Details set status ='" & ds.Tables("packdet").Rows(l).Item(2) & "' where gate_no=" & txtgate.Text & " and item_no='" & ds.Tables("packdet").Rows(l).Item(1) & "' "
                cl.orcmd = New OracleCommand(sql, cl.oracon)
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd.ExecuteNonQuery()
            Next

            sql = "select  item_No,gate_qty,pack_method ,no_of_pack,pack_qty,no_of_pack*pack_qty total_qty ,status from jan_gate_pack_Details where gate_no=" & txtgate.Text & " "
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "packlist")
            If ds.Tables("packlist").Rows.Count > 0 Then
                dgvpack.Columns(0).DataPropertyName = "item_no"
                dgvpack.Columns(1).DataPropertyName = "gate_qty"
                dgvpack.Columns(2).DataPropertyName = "pack_method"
                dgvpack.Columns(3).DataPropertyName = "no_of_pack"
                dgvpack.Columns(4).DataPropertyName = "pack_qty"
                dgvpack.Columns(5).DataPropertyName = "total_qty"
                dgvpack.Columns(6).DataPropertyName = "STATUS"
                dgvpack.DataSource = ds.Tables("packlist")
                dgvpack.Columns(6).Visible = False
                For l = 0 To dgvpack.Rows.Count - 1
                    If dgvpack.Rows(l).Cells(0).Value <> "" Then
                        If dgvpack.Rows(l).Cells(6).Value.ToString() = "MISMATCH" Then
                            dgvpack.Rows(l).Cells(5).Style.BackColor = Color.Red
                        Else
                            dgvpack.Rows(l).Cells(5).Style.BackColor = Color.LightYellow
                        End If
                    End If
                Next
            End If
        End If
    End Sub

    Private Sub dgvpack_DataError(sender As Object, e As DataGridViewDataErrorEventArgs) Handles dgvpack.DataError
        e.Cancel = True
    End Sub

    Private Sub cmbpitem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbpitem.SelectedIndexChanged
        Dim arrayList = cmbpitem.Text.Split("*")
        dgvpack.Select()

        dgvpack.CurrentRow.Cells(0).Value = arrayList(0)
        dgvpack.CurrentRow.Cells(1).Value = arrayList(1)
        'dgvpack.Rows(0).Selected = True
    End Sub

    Private Sub cmbitem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbitem.SelectedIndexChanged
        idx = cmbitem.SelectedItem.IndexOf("*") + 1
        idx1 = cmbitem.Text.ToString.Length - (cmbitem.SelectedItem.IndexOf("*") + 1)


        sql = "select supdcqty from jan_gate_lines where gate_no=" & txtgate.Text & " "

        sql &= " And line_no = '" & cmbitem.SelectedItem.ToString.Substring(idx, idx1) & "'"

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")

        gqty = ds.Tables("resultab").Rows(0).Item(0)
    End Sub
End Class