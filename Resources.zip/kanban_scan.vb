﻿Imports System.IO
Imports oracleclass
Imports System.Data
Imports System.Data.OracleClient
Imports System.Drawing

Public Class kanban_scan

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        s = ""
        s = "<html><body><table><tr>"
        For k = 0 To dgv.Rows.Count - 1

            With dgv.Rows(k)

                If .Cells(7).Value = True Then

                    s &= "<td width=50%><table height=10% cellspacing=6>"
                    s &= " <tr><td><font face=verdana size=4> <B>KANBAN CARD </font></td> <td><img src=F:\jiplnewexecutables\cp_map_prg\janatics.png   align=right></td></tr>"
                    s &= ""

                    s &= " <tr> <td><font face=verdana size=3>Card No: " & .Cells(0).Value & " </font></td>"

                    s &= "  <td rowspan=7 align=center>  <img align=center src=https://api.qrserver.com/v1/create-qr-code/?data=" & .Cells(0).Value & "&amp;size=100x100 alt="" title="" /></td> </tr>"

                    If Not IsDBNull(.Cells(5).Value) Then
                        If .Cells(5).Value.ToString.Length > 10 Then
                            s &= " <tr> <td><font face=verdana size=3>" & .Cells(5).Value.ToString.Substring(0, 10) & " </font></td></tr>"
                        Else
                            s &= " <tr> <td><font face=verdana size=3>" & .Cells(5).Value & " </font></td></tr>"
                        End If
                    End If
                    s &= " <tr> <td><font face=verdana size=3>" & .Cells(1).Value & " </font></td></tr>"
                    s &= " <tr> <td><font face=verdana size=3>" & .Cells(2).Value.ToString.Substring(0, 10) & " </font></td></tr>"
                    s &= " <tr> <td><font face=verdana size=3>Pack Method: " & .Cells(3).Value & " </font></td></tr>"
                    s &= " <tr> <td><font face=verdana size=3>Pack Qty: " & .Cells(4).Value & " </font></td></tr>"

                    If k Mod 2 <> 0 Then
                        s &= "</table><tr> "
                    Else
                        s &= "</table></td> "
                    End If

                End If
            End With

        Next
        s &= "</table>"
        s &= "</html>"

        x = "d:\kanban_card.HTML"
        Dim fstrm As New FileStream(x, FileMode.Create, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)

    End Sub

    Private Sub kanban_scan_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sql = "select REPLACE(vendor_name,'''','''''')supplier,vendor_id from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' AND END_DATE_ACTIVE IS NULL "


        sql &= " AND VENDOR_ID IN (SELECT VENDOR_ID FROM PO_vENDOR_SITES_ALL WHERE ORG_ID=103 AND INACTIVE_DATE IS NULL ) ORDER BY VENDOR_NAME "

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        cl.ds = New DataSet
        cl.oradap.Fill(cl.ds, "resultab")
        For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
            cmbsup.Items.Add(cl.ds.Tables("resultab").Rows(i).Item("supplier"))
        Next
        cl.sql = "select organization_code  from jan_organization_list_view where unit_name='UNIT7' order by organization_code"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        cl.ds = New DataSet
        cl.oradap.Fill(cl.ds, "resultab")
        For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(cl.ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        dgv.Columns.Clear()
        sql = "select kanban_card_number,jan_itemname(inventory_item_id)item_no,jan_itemdesc(jan_itemname(inventory_item_id)) item_Desc, packing_method,packing_qty ,  (select vendor_name from po_Vendors where vendor_id=a.supplier_id)vendor,creation_Date    from jan_supplier_kanban_view A where 1=1 "

        If cmbsup.SelectedItem <> "" Then
            sql &= " and supplier_id=jan_vendorno('" & cmbsup.SelectedItem & "')"
        End If

        If cmborg.SelectedItem <> "" Then
            sql &= " and organization_id=jan_orgid('" & cmborg.SelectedItem & "')"
        End If

        If txtitem.Text <> "" Then
            sql &= " and inventory_item_id=jan_itemno('" & txtitem.Text & "')"
        End If

        If cmbcat.SelectedItem <> "" Then
            sql &= " and source_Type_meaning= '" & cmbcat.SelectedItem & "' "
        End If

        sql &= "   And creation_Date >=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and creation_date <=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        cl.ds = New DataSet
        cl.oradap.Fill(cl.ds, "resultab")
        With dgv
            .DataSource = cl.ds.Tables("resultab")
            .Columns(0).HeaderText = "Card No" : .Columns(0).Width = 100
            .Columns(1).HeaderText = "Item No" : .Columns(1).Width = 100
            .Columns(2).HeaderText = "Item Desc" : .Columns(2).Width = 250
            .Columns(3).HeaderText = "Packing Method" : .Columns(3).Width = 130
            .Columns(4).HeaderText = "Packing Qty" : .Columns(4).Width = 130
            .Columns(5).HeaderText = "Supplier" : .Columns(5).Width = 200 : .Columns(5).DisplayIndex = 1
            .Columns(6).HeaderText = "Date" : .Columns(6).Width = 100 : .Columns(6).DisplayIndex = 1
            Dim cc As New DataGridViewCheckBoxColumn
            cc.Width = 30
            'cc.Name = "Checkbox"
            Me.dgv.Columns.Add(cc)
            .Columns(7).DisplayIndex = 0

        End With
    End Sub


    'Dim qrcode As Zen.Barcode.CodeQrBarcodeDraw = Zen.Barcode.BarcodeDrawFactory.CodeQr
    '' PictureBox1.Image = 

    'Dim qrCodeImage As Bitmap = qrcode.Draw(.Item(0), 100)

    'Dim filePath As String = Path.Combine("d:\", "qrcode.png")
    'qrCodeImage.Save(filePath, System.Drawing.Imaging.ImageFormat.Png)
    'Dim ms As New MemoryStream()
    'qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
    'Dim base64Qr As String = Convert.ToBase64String(ms.ToArray())
    'Dim img As Image
    'img = PictureBox1.Image

    's &= " <td rowspan =7>  <img src='" & filePath & "' style='width:auto;'>   </td> "
End Class