
Imports System.Data.OracleClient
Imports oracleclass
Public Class Add
    Dim a, s, de, c As String
    Dim ds, dsad, ds1, dsITEM, PEND_PO_ds As New DataSet
    Dim i, j, line As Integer
    Dim head As Int64
    Dim dt2, dt1 As Date
    Dim lineno As Int32
    Dim dt As New DataTable
    Dim dr As DataRow
    Dim cl As New oracleclass.Class1


    Public Sub clear()
        cmbpo.SelectedIndex = -1 : cmbitem.SelectedIndex = -1 : cmbtype.SelectedIndex = -1 : txtsite.Text = "" : txtdcno.Text = "" : TextBox1.Text = "" : TextBox1.Visible = False
        cmbsup.Visible = True : txttype.Text = "" : txttype.Visible = False : cmbtype.Visible = True
        Label11.Text = "" : txtgno.Text = "" : bind() : txtinv.Text = "" : cmbsup.SelectedIndex = -1
        If txtadirea.Visible = True Then Label17.Visible = False : txtadirea.Visible = False
    End Sub

    Public Sub bind()
        dt = New DataTable("gate")
        Dim pon As DataColumn = New DataColumn("PoNo")
        dt.Columns.Add("PoNo")
        For i = 0 To 500
            dr = dt.NewRow
            dr.Item("PoNo") = ""
            dt.Rows.Add(dr)
        Next
        dsad.Tables.Clear()
        dsad.Tables.Add(dt)
        dgv1.DataSource = dsad.Tables("gate")
    End Sub

    Public Sub AD()

        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        dsITEM = New DataSet
        cl.oradap.Fill(dsITEM, "pend_item")
        Dim SDV As DataView
        SDV = dsITEM.Tables("PEND_ITEM").DefaultView
        SDV.Sort = "ITEM ASC"
        dsITEM.Tables("PEND_ITEM").AcceptChanges()
        If dsITEM.Tables("pend_item").Rows.Count > 0 Then
            For i = 0 To dsITEM.Tables("pend_item").Rows.Count - 1
                cmbitem.Items.Add(dsITEM.Tables("pend_item").Rows(i).Item("item"))
            Next
        End If
    End Sub

    Private Sub cmbsup_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbsup.SelectedIndexChanged

        cmbpo.Items.Clear()
        cmbitem.Items.Clear()

        txtrole.Text = userid
        ' If cmbsup.Text <> "" Then
        If cmbtype.SelectedItem <> "" Then

            If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then

                cl.sql = "select    (JAN_ITEMNAME(ITEM_ID) ||'|----|'|| JAN_ITEMDESC(JAN_ITEMNAME(ITEM_ID))) ITEM,PO_LINE_LOCATION_ID   from MTL_SUPPLY a where SUPPLY_TYPE_CODE='PO' And DESTINATION_TYPE_CODE in ('EXPENSE','INVENTORY')  "


                '  cl.sql = "SELECT    (item_no ||'|----|'|| description) item,LINE_LOCATION_ID   From JAN_PO_PENDING_BOUGHT_OUTS a where "

                'If txtrole.Text = "INWARD" Or txtrole.Text = "ADD1" Or txtrole.Text = "ADD2" Or txtrole.Text = "UNIT7" Or txtrole.Text = "U7_ADD" Then cl.sql &= "  a. to_organization_id   IN (444,464,504,484,524,505,384,664) "

                'If txtrole.Text = "UNIT2" Then cl.sql &= "   a. to_organization_id=104"

                'If txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Then cl.sql &= "a. to_organization_id in (113,111,110,304)"

                'If txtrole.Text = "UNIT4" Then cl.sql &= "   a. to_organization_id=144"

                'If txtrole.Text = "MIG" Then cl.sql &= "   a. to_organization_id in (104,106,107,108,109,444,464,504,484)"

                'If txtrole.Text = "SKYFAST" Then cl.sql &= "  a.to_organization_id in (224,225)"

                'If opid <> "" Then cl.sql &= "  a. to_organization_id in (select organization_id from org_organization_Definitions where operating_unit=" & opid & " )"

                cl.sql &= " and  a.to_organization_id in (" & orgid & ") "

                cl.sql &= " and   PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where vendor_id = " & cmbsup.SelectedValue & " ) order by JAN_ITEMNAME(ITEM_ID) "
                '  MessageBox.Show(cl.sql)
                AD()

            End If


            If cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                cl.sql = "select    (select JAN_ITEMNAME(PRIMARY_ITEM_ID) from WIP_ENTITIES where WIP_ENTITY_ID=a.WIP_ENTITY_ID)||'|----|'||
JAN_ITEMDESC((select JAN_ITEMNAME(PRIMARY_ITEM_ID) from WIP_ENTITIES where WIP_ENTITY_ID=a.WIP_ENTITY_ID)) ITEM,B.PO_LINE_LOCATION_ID   from MTL_SUPPLY B ,PO_DISTRIBUTIONS_ALL a where B.PO_HEADER_ID=B.PO_HEADER_ID AND A.PO_DISTRIBUTION_ID=B.PO_DISTRIBUTION_ID AND 
B.SUPPLY_TYPE_CODE='PO' and B.DESTINATION_TYPE_CODE in ('SHOP FLOOR')  "

                cl.sql &= "and b.to_organization_id in (" & orgid & ")"

                cl.sql &= " and  A.PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where vendor_id = " & cmbsup.SelectedValue & " ) "

                AD()

            End If


            cl.sql = "select vendor_site_code from po_vendor_sites_all where vendor_id= '" & cmbsup.SelectedValue & "' and inactive_Date is null AND  ORG_ID= " & OP_ID & " "

            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            txtsite.Text = ds.Tables("resultab").Rows(0).Item("vendor_site_code")

            TextBox1.Text = cmbsup.Text
            TextBox1.Visible = True
            cmbsup.Visible = False

            cl.sql = "select supplier_name from jan_gate_supplier where supplier_name='" & cmbsup.Text.ToString.Replace("'", "") & "' and type<>'URGENT'"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            If ds.Tables("resultab").Rows.Count > 0 Then
                Label15.Visible = True
                'COMMENTED ON 8TH FEB 2010
                ': Label12.Visible = True : Label18.Visible = True : txt_adi_no.Visible = True : dtadi.Visible = True
            Else
                Label15.Visible = False
                ': Label12.Visible = False : Label18.Visible = False : txt_adi_no.Visible = False : dtadi.Visible = False
            End If


        End If

    End Sub

    Private Sub cmbitem_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbitem.SelectedIndexChanged
        'cmbpo.Text = ""
        If cmbitem.SelectedItem <> "" Then
            cmbpo.Items.Clear()
            Dim e1 As String = cmbitem.SelectedItem

            Dim f As String = e1.Substring(0, e1.IndexOf("|"))
            '''''''''''' For PO
            If cmbtype.SelectedItem = "PO" Then

                cl.sql = "select ((SELECT SEGMENT1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=A.PO_HEADER_ID) || '|---|'|| a.PO_LINE_ID || '|:L-'||
(select line_num from po_lines_all where po_line_id=a.po_line_id) || '|S-'|| (select SHIPMENT_NUM from PO_LINE_LOCATIONS_ALL where LINE_LOCATION_ID = a.PO_LINE_LOCATION_ID))PONO,PO_LINE_LOCATION_ID,TO_ORGANIZATION_ID  from MTL_SUPPLY  a where SUPPLY_TYPE_CODE='PO' and DESTINATION_TYPE_CODE in ('EXPENSE','INVENTORY') and   PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where VENDOR_ID= " & cmbsup.SelectedValue & " )  and a.item_id = JAN_ITEMNO('" & f & "') "


                cl.sql &= "and a.to_organization_id   IN (" & orgid & " ) "

                'cl.sql = "select (a.pono || '|---|'|| a.po_line_id) pono,line_location_id,ship_to_organization_id   from jan_po_pending_bought_outs a where a.vendor_id =     "

                'If txtrole.Text = "UNIT7" Or txtrole.Text = "INWARD" Or txtrole.Text = "U7_ADD" Then cl.sql &= "and a.to_organization_id   IN (" & orgid & " ) "

                'If txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Then cl.sql &= " and a.to_organization_id   IN (" & orgid & ") "

                '' If txtrole.Text <> "UNIT2" Then cl.sql &= " and a.ship_to_organization_id in(106,107,108,109,110) union select  (a.pono ||'|---|'||a.po_line_id)  pono,line_location_id  from jan_po_pending_bought_outs a where   a.vendor_id =   " & cmbsup.SelectedValue & "  and a.item_id = JAN_ITEMNO('" & f & "')  and a.ship_to_organization_id in(111,113)"

                ''If txtrole.Text = "UNIT2" Then cl.sql &= " and a.to_organization_id=104"

                ''If txtrole.Text = "UNIT4" Then cl.sql &= " and a.to_organization_id=144"

                '' If opid <> "" Then cl.sql &= " and  a.to_organization_id in (select organization_id from org_organization_Definitions where operating_unit=" & opid & " )"
                'If TXTROLE.TEXT="JAPL" Then cl.sql &= " and A.to_organization_id  IN (" & orgid & ") "


                'If txtrole.Text = "SKYFAST" Then cl.sql &= " and a.to_organization_id in (" & orgid & ")"


                'cl.sql &= " ORDER BY line_location_id"

                ' cl.sql &= " and a.podt>='1-jan-2008'"

            ElseIf txttype.Text = "PO" Then

                cl.sql = "select ((SELECT SEGMENT1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=A.PO_HEADER_ID) || '|---|'|| a.PO_LINE_ID || '|L-'||
(select line_num from po_lines_all where po_line_id=a.po_line_id) || '|S-'|| (select SHIPMENT_NUM from PO_LINE_LOCATIONS_ALL where LINE_LOCATION_ID = a.PO_LINE_LOCATION_ID))PONO,PO_LINE_LOCATION_ID,TO_ORGANIZATION_ID  from MTL_SUPPLY  a where SUPPLY_TYPE_CODE='PO' and DESTINATION_TYPE_CODE in ('EXPENSE','INVENTORY') and   PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where VENDOR_ID=JAN_VENDORNO('" & TextBox1.Text.ToString.Replace("'", "''") & "'))  And a.item_id = JAN_ITEMNO('" & f & "') "


                cl.sql &= "and a.to_organization_id   IN (" & orgid & " ) "

                'If txtrole.Text = "UNIT7" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD1" Or txtrole.Text = "ADD2" Or txtrole.Text = "U7_ADD" Then cl.sql &= "and a.to_organization_id   IN (" & orgid & ") "


                'If txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Then cl.sql &= " and a.to_organization_id   IN (" & orgid & ") "

                '' If txtrole.Text <> "UNIT2" Then cl.sql &= " and a.ship_to_organization_id in(106,107,108,109,110)union select  (a.pono ||'|---|'||a.po_line_id)  pono ,line_location_id   from jan_po_pending_bought_outs a where    a.vendor_id = " & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(15).Value & " and a.item_id = JAN_ITEMNO('" & f & "') and a.ship_to_organization_id in(111,113) "
                'If TXTROLE.TEXT="JAPL" Then cl.sql &= " and A.to_organization_id  IN (" & orgid & ") "

                'If txtrole.Text = "UNIT2" Then cl.sql &= " and a.to_organization_id=104"

                'If txtrole.Text = "UNIT4" Then cl.sql &= " and a.to_organization_id=144"

                'If opid <> "" Then cl.sql &= " and  a.to_organization_id in (select organization_id from org_organization_Definitions where operating_unit=" & opid & " )"


                'If txtrole.Text = "SKYFAST" Then cl.sql &= " and a.to_organization_id in (" & orgid & ")"

                '' cl.sql &= " ORDER BY line_location_id"
                ' cl.sql &= " and a.podt>='1-jan-2008'"
            End If

            '''''''''''''' For OSP
            If cmbtype.SelectedItem = "OSP" Then

                cl.sql = "select ((select SEGMENT1 from PO_HEADERS_ALL where PO_HEADER_ID=B.PO_HEADER_ID) || '|---|'|| B.PO_LINE_ID) PONO,PO_LINE_LOCATION_ID,TO_ORGANIZATION_ID  from MTL_SUPPLY B ,PO_DISTRIBUTIONS_ALL a,wip_discrete_jobs c  where B.PO_HEADER_ID=B.PO_HEADER_ID and a.PO_DISTRIBUTION_ID=B.PO_DISTRIBUTION_ID AND B.SUPPLY_TYPE_CODE='PO' and B.DESTINATION_TYPE_CODE in ('SHOP FLOOR') and a.PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where  VENDOR_ID=" & cmbsup.SelectedValue & "   ) and A.WIP_ENTITY_id=c.wip_entity_id and c.primary_item_id=JAN_ITEMNO('" & f & "') "


                cl.sql &= "and b.to_organization_id   IN (" & orgid & " ) "

                '  cl.sql = "Select ((Select SEGMENT1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=B.PO_HEADER_ID) || '|---|'|| B.PO_LINE_ID) PONO,PO_LINE_LOCATION_ID,TO_ORGANIZATION_ID  from MTL_SUPPLY  B where SUPPLY_TYPE_CODE='PO' and DESTINATION_TYPE_CODE in ('SHOP FLOOR') and   PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where  VENDOR_ID=" & cmbsup.SelectedValue & " )  and B.item_id = JAN_ITEMNO('" & f & "') "

                'If txtrole.Text = "UNIT7" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD1" Or txtrole.Text = "ADD2" Or txtrole.Text = "U7_ADD" Then cl.sql &= "and b.to_organization_id   IN (" & orgid & ") "

                'If txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Then cl.sql &= " and b.to_organization_id  IN (110,111,113,304) "
                'If TXTROLE.TEXT="JAPL" Then cl.sql &= " and b.to_organization_id  IN (" & orgid & ") "


                '' If opid <> "" Then cl.sql &= " and   b.to_organization_id in (select organization_id from org_organization_Definitions where operating_unit=" & opid & " )"


                ''   If txtrole.Text <> "UNIT2" Then cl.sql &= " and b.ship_to_organization_id in(106,107,108,109,110) union select (B.pono ||'|---|'||B.po_line_id) pono ,line_location_id  from jan_po_pending_osp b  where  b.vendor_id = " & cmbsup.SelectedValue & "   and b.primary_item_id = JAN_ITEMNO('" & f & "')  and b.ship_to_organization_id in(111,113) "

                'If txtrole.Text = "UNIT2" Then cl.sql &= " and b.to_organization_id =104"

                'If txtrole.Text = "UNIT4" Then cl.sql &= " and b.to_organization_id=144"

                'If txtrole.Text = "SKYFAST" Then cl.sql &= " and b.to_organization_id in (" & orgid & ")"

                'cl.sql &= " ORDER BY line_location_id"

            ElseIf txttype.Text = "OSP" Then

                cl.sql = "select ((select SEGMENT1 from PO_HEADERS_ALL where PO_HEADER_ID=B.PO_HEADER_ID) || '|---|'|| B.PO_LINE_ID) PONO,PO_LINE_LOCATION_ID,TO_ORGANIZATION_ID  from MTL_SUPPLY B ,PO_DISTRIBUTIONS_ALL a,wip_discrete_jobs c  where B.PO_HEADER_ID=B.PO_HEADER_ID and a.PO_DISTRIBUTION_ID=B.PO_DISTRIBUTION_ID AND B.SUPPLY_TYPE_CODE='PO' and B.DESTINATION_TYPE_CODE in ('SHOP FLOOR') and a.PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where  vendor_id = JAN_VENDORNO('" & TextBox1.Text.ToString.Replace("'", "''") & "')) and   A.WIP_ENTITY_id=c.wip_entity_id and c.primary_item_id=JAN_ITEMNO('" & f & "') "

                cl.sql &= "and b.to_organization_id   IN (" & orgid & " ) "

                'If txtrole.Text = "UNIT7" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD1" Or txtrole.Text = "ADD2" Or txtrole.Text = "U7_ADD" Then cl.sql &= "and b.to_organization_id  in (" & orgid & ")"

                'If txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Then cl.sql &= " and b.to_organization_id  IN (" & orgid & ") "

                ''If txtrole.Text <> "UNIT2" Then cl.sql &= " and b.ship_to_organization_id in(106,107,108,109,110)union select (B.pono ||'|---|'||B.po_line_id) pono,line_location_id   from jan_po_pending_osp b WHERE   b.vendor_id = " & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(15).Value & " and b.primary_item_id = JAN_ITEMNO('" & f & "')  and b.ship_to_organization_id in(111,113)"

                '' If opid <> "" Then cl.sql &= " and   b.to_organization_id in (select organization_id from org_organization_Definitions where operating_unit=" & opid & " )"

                'If TXTROLE.TEXT="JAPL" Then cl.sql &= " and b.to_organization_id  IN (" & orgid & ") "

                'If txtrole.Text = "UNIT2" Then cl.sql &= " and b.to_organization_id =104"

                'If txtrole.Text = "UNIT4" Then cl.sql &= " and b.to_organization_id=144"

                'If txtrole.Text = "SKYFAST" Then cl.sql &= " and b.to_organization_id in (" & orgid & ")"
                '' cl.sql &= " ORDER BY line_location_id"


            End If

            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            PEND_PO_ds = New DataSet
            cl.oradap.Fill(PEND_PO_ds, "resultab")
            Dim RSDV As DataView
            RSDV = PEND_PO_ds.Tables("RESULTAB").DefaultView
            RSDV.Sort = "PO_line_location_id ASC"
            PEND_PO_ds.Tables("RESULTAB").AcceptChanges()
            'For i = 0 To PEND_PO_ds.Tables("resultab").Rows.Count - 1
            '    cmbpo.Items.Add(PEND_PO_ds.Tables("resultab").Rows(i).Item("pono"))
            'Next

            If FLG = False Then
                For i = 0 To PEND_PO_ds.Tables("resultab").Rows.Count - 1
                    cmbpo.Items.Add(PEND_PO_ds.Tables("resultab").Rows(i).Item("pono"))
                Next
            Else
                If txttype.Text = "PO" Then

                    If PEND_PO_ds.Tables("resultab").Rows.Count > 0 Then

                        If adi_allow = 1 Then

                            '  cl.sql = "SELECT TRUNC(TO_DATE(EXEMPTION_VALIDITY_TILL))-TRUNC(sysdate)cnt FROM jan_gate_adi_exempt WHERE VENDOR_ID=" & cmbsup.SelectedValue & ""  and TRUNC(TO_DATE(EXEMPTION_VALIDITY_TILL))>TRUNC(sysdate) 

                            cl.sql = "SELECT (TRUNC(EXEMPTION_VALIDITY_TILL)-TRUNC(sysdate))CNT  FROM jan_gate_adi_exempt WHERE VENDOR_ID=" & cmbsup.SelectedValue & " AND LIVE_FLAG=1"


                            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                            ds = New DataSet
                            cl.oradap.Fill(ds, "VALID")
                            ''st1
                            If ds.Tables("valid").Rows.Count > 0 Then

                                ''st
                                If ds.Tables("VALID").Rows(0).Item("cnt") >= 0 Then
                                    For i = 0 To PEND_PO_ds.Tables("resultab").Rows.Count - 1
                                        cmbpo.Items.Add(PEND_PO_ds.Tables("resultab").Rows(i).Item("pono"))
                                    Next
                                ElseIf ds.Tables("VALID").Rows(0).Item("cnt") < 0 Then
                                    MessageBox.Show("No Provision to add Manual Gate Entry ... ,ADI Required", "Gate Register")
                                    Exit Sub

                                Else


                                    MessageBox.Show("No Provision to add Manual Gate Entry ... ,ADI Required", "Gate Register")
                                    Exit Sub
                                End If
                                ''en
                            Else
                                MessageBox.Show("Vendor Not in Exempted list", "Gate Register")
                                Exit Sub
                                'For i = 0 To PEND_PO_ds.Tables("resultab").Rows.Count - 1
                                '    cmbpo.Items.Add(PEND_PO_ds.Tables("resultab").Rows(i).Item("pono"))
                                'Next
                            End If
                            ''en1

                        Else


                            ' MessageBox.Show("Vendor Not in Exempted list", "Gate Register")
                            For i = 0 To PEND_PO_ds.Tables("resultab").Rows.Count - 1
                                cmbpo.Items.Add(PEND_PO_ds.Tables("resultab").Rows(i).Item("pono"))
                            Next

                        End If
                    Else

                        For i = 0 To PEND_PO_ds.Tables("resultab").Rows.Count - 1
                            cmbpo.Items.Add(PEND_PO_ds.Tables("resultab").Rows(i).Item("pono"))
                        Next

                    End If
                Else
                    For i = 0 To PEND_PO_ds.Tables("resultab").Rows.Count - 1
                        cmbpo.Items.Add(PEND_PO_ds.Tables("resultab").Rows(i).Item("pono"))
                    Next
                End If

            End If
        End If
        '    lineno = PEND_PO_ds.Tables("resultab").Rows(cmbitem.SelectedIndex).Item("line_location_id")
    End Sub

    Private Sub cmbpo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbpo.SelectedIndexChanged


        If cmbpo.SelectedItem <> "" Then
            Dim e1 As String = cmbpo.SelectedItem
            Dim f As String = e1.Substring(0, e1.IndexOf("|"))
            'Dim r As String = e1.Substring(15)
            Dim r As String = e1.Substring(e1.IndexOf("|", e1.IndexOf("|") + 1) + 1)
            If r.ToString.Contains("L") = True Then r = r.Substring(0, r.IndexOf("|")) Else r = r
            Dim a, b, c, d As String
            a = cmbitem.SelectedItem
            b = a.Substring(0, a.IndexOf("|"))
            lineno = PEND_PO_ds.Tables("resultab").Rows(cmbpo.SelectedIndex).Item("PO_line_location_id")
            Dim a1, b1, c1, d1 As Double
            If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                cl.sql = "select nvl(sum(po_qty-recd),0) po from jan_po_pending_bought_outs where po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "') and item_id =JAN_ITEMNO('" & b & "') and po_line_id='" & r & "' AND LINE_LOCATION_ID=" & lineno & "    "
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "resultab")
                a1 = ds.Tables("resultab").Rows(0).Item("po")

                cl.sql = "select nvl(sum(supdcqty),0) po from jan_gate_lines  where pono='" & f & "'  and item ='" & b & "' and validated<>'4'  and flag<>0 and poline='" & r & "' and  LOCATION_ID=" & lineno & ""
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "resultab")
                b1 = ds.Tables("resultab").Rows(0).Item("po")

                cl.sql = "select nvl(sum(b.quantity_received),0) po from jan_gate_lines a,jan_pur_listing b where  a.item=b.item_no and a.gate_id=b.gate_no and b.item_id =JAN_ITEMNO('" & b & "') and a.flag<>0 and a.poline='" & r & "' AND A.POLINE=B.PO_LINE_ID AND B.po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "') and  LOCATION_ID=" & lineno & ""
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "resultab")
                c1 = ds.Tables("resultab").Rows(0).Item("po")

            ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                cl.sql = "select nvl(sum(po_qty-recd),0) po from jan_po_pending_osp where po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "')  and primary_item_id =JAN_ITEMNO('" & b & "') and po_line_id='" & r & "' AND LINE_LOCATION_ID=" & lineno & ""
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "resultab")
                a1 = ds.Tables("resultab").Rows(0).Item("po")

                cl.sql = "select nvl(sum(supdcqty),0) po from jan_gate_lines  where pono='" & f & "' and item ='" & b & "'  and validated<>'4'  and flag<>0 and poline='" & r & "' AND LOCATION_ID=" & lineno & " "
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "resultab")
                b1 = ds.Tables("resultab").Rows(0).Item("po")

                cl.sql = "select nvl(sum(b.quantity_received),0) po from jan_gate_lines a,jan_osp_listing b where  a.item=b.partno and a.gate_id=b.gate_no and b.primary_item_id =JAN_ITEMNO('" & b & "')  and a.flag<>0 and a.poline='" & r & "'  AND A.POLINE=B.PO_LINE_ID AND  B.po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "')  "
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "resultab")
                c1 = ds.Tables("resultab").Rows(0).Item("po")
            End If

            d1 = (a1 - (b1 - c1))



            ''''''''''''' for PO
            If cmbtype.SelectedItem = "PO" Then

                cl.sql = "select  a.po_line_id,a.po_header_id,a.line_location_id,a.po_qty,nvl(a.rev,'') rev, a.uom uom,'' osp_no,'' operations,'' job_no,(select organization_code from org_organization_definitions  where organization_id=a.ship_to_organization_id)org,a.price,A.DESCRIPTION,trunc(a.podt) podt,(SELECT CATEGORY FROM JAN_COUNTING_CATEGORY WHERE A.PRICE BETWEEN FROM_VALUE AND TO_VALUE AND ORGANIZATION_ID=A.SHIP_TO_ORGANIZATION_ID) CAT,DECODE(A.LINE_TYPE_ID,1021,'Services',A.LINE_TYPE)LINE_TYPE,need_by_Date  from jan_po_pending_bought_outs a where A.vendor_id =  " & cmbsup.SelectedValue & "   and a.item_id =JAN_ITEMNO('" & b & "') and a.po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "')  and a.po_line_id='" & r & "' AND LINE_LOCATION_ID=" & lineno & "  "

            ElseIf txttype.Text = "PO" Then
                cl.sql = "select  a.po_line_id,a.po_header_id,a.line_location_id,a.po_qty,nvl(a.rev,'') rev, a.uom uom,'' osp_no,'' operations,'' job_no,(select organization_code from org_organization_definitions  where organization_id=a.ship_to_organization_id)org,a.price,A.DESCRIPTION,trunc(a.podt) podt,(SELECT CATEGORY FROM JAN_COUNTING_CATEGORY WHERE A.PRICE BETWEEN FROM_VALUE AND TO_VALUE AND ORGANIZATION_ID=A.SHIP_TO_ORGANIZATION_ID) CAT,DECODE(A.LINE_TYPE_ID,1021,'Services',A.LINE_TYPE)LINE_TYPE,need_By_date from jan_po_pending_bought_outs a where A. vendor_id = JAN_VENDORNO('" & TextBox1.Text.ToString.Replace("'", "''") & "') and a.item_id =JAN_ITEMNO('" & b & "') and a.po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "')  and a.po_line_id='" & r & "' AND LINE_LOCATION_ID=" & lineno & "  "
            End If
            '''''''''''' For OSP
            If cmbtype.SelectedItem = "OSP" Then
                cl.sql = "select  b.po_line_id,b.po_header_id,b.line_location_id,b.po_qty,b.bom_revision, b.po_uom, b.osp_no,(select organization_code from org_organization_definitions  where organization_id=b.ship_to_organization_id)org ,b.price,B.PARTNAME,trunc(b.podt)podt,b.operations, b.job_no, "
                cl.sql &= "(SELECT CATEGORY  FROM(JAN_COUNTING_CATEGORY)  WHERE(organization_id = b.ship_to_organization_id) AND DECODE((SELECT ITEM_COST  FROM JAN_ITEMCOST B   WHERE(ITEM_NO = b.PARTNO) AND org_id = b.ship_to_organization_id  AND PO_LINE_ID=B.PO_LINE_ID),0,"
                cl.sql &= "  (SELECT STAGE_COST FROM JAN_PO_PENDING_OSP C WHERE(PARTNO = b.PARTNO)AND ship_to_organization_id = b.ship_to_organization_id AND PO_LINE_ID=B.PO_LINE_ID), (SELECT ITEM_COST  FROM JAN_ITEMCOST B WHERE(ITEM_NO = b.PARTNO) AND org_id = b.ship_to_organization_id AND PO_LINE_ID=B.PO_LINE_ID)) BETWEEN from_value and to_value) CAT,DECODE(B.LINE_TYPE_ID,1021,'Services',B.LINE_TYPE)LINE_TYPE,WIP_ENTITY_ID,OPN_sEQ,need_by_date from jan_po_pending_osp b "
                cl.sql &= "  where b.vendor_id =   " & cmbsup.SelectedValue & "     and B.po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "') and b.po_line_id='" & r & "' AND LINE_LOCATION_ID=" & lineno & "  "

            ElseIf txttype.Text = "OSP" Then
                cl.sql = "select  b.po_line_id,b.po_header_id,b.line_location_id,b.po_qty,b.bom_revision, b.po_uom, b.osp_no,(select organization_code from org_organization_definitions  where organization_id=b.ship_to_organization_id)org ,b.price,B.PARTNAME,trunc(b.podt)podt,b.operations, b.job_no, "
                cl.sql &= "(SELECT CATEGORY  FROM(JAN_COUNTING_CATEGORY)  WHERE(organization_id = b.ship_to_organization_id) AND DECODE((SELECT ITEM_COST  FROM JAN_ITEMCOST B   WHERE(ITEM_NO = b.PARTNO) AND org_id = b.ship_to_organization_id  AND PO_LINE_ID=B.PO_LINE_ID),0,"
                cl.sql &= "  (SELECT STAGE_COST FROM JAN_PO_PENDING_OSP C WHERE(PARTNO = b.PARTNO)AND ship_to_organization_id = b.ship_to_organization_id AND PO_LINE_ID=B.PO_LINE_ID), (SELECT ITEM_COST  FROM JAN_ITEMCOST B WHERE(ITEM_NO = b.PARTNO) AND org_id = b.ship_to_organization_id AND PO_LINE_ID=B.PO_LINE_ID)) BETWEEN from_value and to_value) CAT,DECODE(B.LINE_TYPE_ID,1021,'Services',B.LINE_TYPE)LINE_TYPE,WIP_ENTITY_ID,OPN_sEQ,need_by_date from jan_po_pending_osp b "
                cl.sql &= " where b. vendor_id = JAN_VENDORNO('" & TextBox1.Text.ToString.Replace("'", "''") & "') and B.po_header_id=(select po_header_id from po_headers_all where segment1='" & f & "')  and b.po_line_id='" & r & "' AND LINE_LOCATION_ID=" & lineno & "  "
            End If


            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            If dsad.Tables().Contains("resultab") Then
                dsad.Tables("resultab").Rows.Clear()
            End If
            cl.oradap.Fill(dsad, "resultab")

            c = cmbpo.SelectedItem
            d = c.Substring(0, c.IndexOf("|"))

            i = dgv1.CurrentRow.Index
            If dgv1.Rows(i).Cells(0).Value = "" Or dgv1.Rows(i).Cells(1).Value = "" Or dgv1.Rows(i).Cells(1).Value = "" Then
                '''''FOR BLOCKING PO +INV WISE 
                'If cmbtype.SelectedItem = "PO" Then
                '    Dim dt, dt1, dt2 As Date
                '    dt = CDate("27/11/2008")
                '    dt2 = CDate("12/01/2009")
                '    dt1 = CDate(Format(dsad.Tables("resultab").Rows(0).Item("PODT"), "dd-MMM-yyyy"))

                '    If DateDiff(DateInterval.Day, dt1, dt) > 0 And (dsad.Tables("resultab").Rows(0).Item("org") = "I01" Or dsad.Tables("resultab").Rows(0).Item("org") = "I02" Or dsad.Tables("resultab").Rows(0).Item("org") = "I03" Or dsad.Tables("resultab").Rows(0).Item("org") = "I04" Or dsad.Tables("resultab").Rows(0).Item("org") = "I05" Or dsad.Tables("resultab").Rows(0).Item("org") = "I06") Then

                '        MessageBox.Show("No Gate Entry is allowed for the PO " & f & " ", "Gate Register")
                '        Exit Sub
                '    ElseIf DateDiff(DateInterval.Day, dt1, dt2) > 0 And dsad.Tables("resultab").Rows(0).Item("org") = "COM" Then
                '        MessageBox.Show("No Gate Entry is allowed for the PO " & f & " ", "Gate Register")
                '        Exit Sub
                '    Else
                '        GoTo gateline
                '    End If
                'End If
                ' If dgv1.CurrentRow.Index = 0 Then
gateline:
                With dsad.Tables("resultab").Rows(0)
                    dgv1.Rows(i).Cells(0).Value = d
                    dgv1.Rows(i).Cells(1).Value = Format(.Item("podt"), "dd-MMM-yyyy")
                    dgv1.Rows(i).Cells(2).Value = b
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(3).Value = .Item("description").ToString.Replace("'", "''")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(3).Value = .Item("partname")
                    End If
                    dgv1.Rows(i).Cells(4).Value = .Item("org")
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(5).Value = .Item("rev")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(5).Value = .Item("bom_revision")
                    End If
                    If txttype.Text = "PO" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(6).Value = d1
                    End If
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(7).Value = .Item("uom")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(7).Value = .Item("po_uom")
                    End If
                    dgv1.Rows(i).Cells(10).Value = .Item("po_qty")
                    dgv1.Rows(i).Cells(11).Value = .Item("cat")
                    dgv1.Rows(i).Cells(12).Value = .Item("line_type")
                    If txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(13).Value = .Item("osp_no")
                        dgv1.Rows(i).Cells(14).Value = ""
                    ElseIf txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(13).Value = .Item("osp_no")
                        dgv1.Rows(i).Cells(14).Value = .Item("operations").ToString.Replace("'", "")
                        dgv1.Rows(i).Cells(15).Value = .Item("job_no")
                        dgv1.Rows(i).Cells(23).Value = .Item("WIP_ENTITY_ID")
                        dgv1.Rows(i).Cells(24).Value = .Item("OPN_SEQ")
                    End If
                    If cmbtype.SelectedItem = "PO" Or cmbtype.SelectedItem = "OSP" Then
                        dgv1.Rows(i).Cells(16).Value = cmbtype.SelectedItem
                    ElseIf txttype.Text = "PO" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(16).Value = txttype.Text
                    End If
                    dgv1.Rows(i).Cells(17).Value = .Item("po_line_id")
                    dgv1.Rows(i).Cells(18).Value = .Item("po_header_id")
                    dgv1.Rows(i).Cells(19).Value = "1"
                    dgv1.Rows(i).Cells(20).Value = .Item("price")
                    dgv1.Rows(i).Cells(21).Value = .Item("line_location_id")
                    dgv1.Rows(i).Cells(25).Value = .Item("need_by_date")
                End With
            Else
                MessageBox.Show("Select Next Row", "Gate Entry")
            End If
            'Else
            'With dsad.Tables("resultab").Rows(0)
            '    If dgv1.Rows(i).Cells(0).Value = "" Then
            '        dgv1.Rows(i).Cells(0).Value = d
            '        dgv1.Rows(i).Cells(1).Value = Format(.Item("podt"), "dd-MMM-yyyy")
            '        dgv1.Rows(i).Cells(2).Value = b
            '        If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
            '            dgv1.Rows(i).Cells(3).Value = .Item("description")
            '        ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
            '            dgv1.Rows(i).Cells(3).Value = .Item("partname").ToString.Replace("'", "''")
            '        End If
            '        dgv1.Rows(i).Cells(4).Value = .Item("org")
            '        If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
            '            dgv1.Rows(i).Cells(5).Value = .Item("rev")
            '        ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
            '            dgv1.Rows(i).Cells(5).Value = .Item("bom_revision")
            '        End If
            '        If txttype.Text = "PO" Or txttype.Text = "OSP" Then
            '            dgv1.Rows(i).Cells(6).Value = d1
            '        End If

            '        If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
            '            dgv1.Rows(i).Cells(7).Value = .Item("uom")
            '        ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
            '            dgv1.Rows(i).Cells(7).Value = .Item("po_uom")
            '        End If
            '        dgv1.Rows(i).Cells(10).Value = .Item("po_qty")
            '        dgv1.Rows(i).Cells(11).Value = .Item("cat")
            '        dgv1.Rows(i).Cells(12).Value = .Item("line_type")
            '        If txttype.Text = "PO" Then
            '            dgv1.Rows(i).Cells(13).Value = .Item("osp_no")
            '        ElseIf txttype.Text = "OSP" Then
            '            dgv1.Rows(i).Cells(13).Value = .Item("osp_no")
            '            dgv1.Rows(i).Cells(14).Value = .Item("operations")
            '            dgv1.Rows(i).Cells(15).Value = .Item("job_no")
            '        End If
            '        If cmbtype.SelectedItem = "PO" Or cmbtype.SelectedItem = "OSP" Then
            '            dgv1.Rows(i).Cells(16).Value = cmbtype.SelectedItem
            '        ElseIf txttype.Text = "PO" Or txttype.Text = "OSP" Then
            '            dgv1.Rows(i).Cells(16).Value = txttype.Text
            '        End If
            '        dgv1.Rows(i).Cells(17).Value = .Item("po_line_id")
            '        dgv1.Rows(i).Cells(18).Value = .Item("po_header_id")
            '        dgv1.Rows(i).Cells(19).Value = "1"
            '        dgv1.Rows(i).Cells(20).Value = .Item("price")
            '        dgv1.Rows(i).Cells(21).Value = .Item("line_location_id")
            '    Else
            '        MessageBox.Show("Select Next Row", "Gate Entry")
            '    End If
            'End With
        End If

    End Sub

    Private Sub cmbtype_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbtype.SelectedIndexChanged
        txttype.Text = cmbtype.SelectedItem
        txttype.Visible = True
        cmbtype.Visible = False
        If cmbtype.SelectedItem = "PO" Then Label16.Visible = True : txtinv.Visible = True
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Try

            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            '''''''gate no for unit2

            If INS = "ADD" Then
                Dim A, B As Boolean
                A = False
                B = False
                addnew()
            Else

                cl.sql = "select receipt_num from rcv_shipment_headers where packing_slip='" & txtgno.Text & "'"
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                Dim dar As OracleDataReader
                dar = (cl.orcmd).ExecuteReader
                updt()
                'If gtpur = "Entry" Then
                '    If (dar.HasRows = True) Then
                '        MessageBox.Show("Receipt Made,Gate Can't be updated", "Gate Register")
                '        Exit Sub
                '    Else
                '        updt()
                '    End If
                'Else
                '    updt()
                'End If
            End If




            ' Else
            ' B = True
            '  End If
            'If B = True Then
            '    MessageBox.Show("Enter Dcno,DCqty,Tariff No To Save Gate Values", "Gate Entry")
            'End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub
    Public Sub addnew()

        If TextBox1.Text <> "" And txtdcno.Text <> "" Then '' And dgv1.Rows(0).Cells(22).Value <> ""
            GoTo header
        Else
            MessageBox.Show("Enter Dcno /supplier To Save Gate Values", "Gate Entry")
            Exit Sub
        End If

header:
        If unit = "UNIT7" Then
            If chkogt.Checked = False Then
                cl.sql = "select jan_GATE_NO_SEQ.NEXTVAL FROM DUAL"
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")

                txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item(0)
            Else
                '    txtgno.Text = txtgno.Text = 700100001
            End If
        End If

        cl.sql = "SELECT TO_CHAR(JAN_FYR_DATE,'yyyy') FROM DUAL"
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.oradap = New OracleDataAdapter(cl.orcmd)
        ds = New DataSet
        cl.oradap.Fill(ds, "ID")
        Dim IDS As String = ds.Tables("ID").Rows(0).Item(0)

        If unit = "SKYFAST" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='SKYFAST'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    If txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Then ID = String.Concat(IDS, "9000", 1) Else ID = String.Concat(IDS, "000", 1)
                    txtgno.Text = ID
                End If
            End If
        End If

        If unit = "UNIT1" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='UNIT1'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    ID = String.Concat(IDS, "10000", 1)
                    txtgno.Text = ID
                End If
                txtrole.Text = "UNIT1"
            End If
        End If

        If unit = "COIL" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='COIL'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter(cl.orcmd)
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    If txtrole.Text = "JAPL" Then ID = String.Concat(IDS, "80000", 1) Else ID = String.Concat(IDS, "000", 1)
                    txtgno.Text = ID
                End If
            End If
        End If

        If unit = "POLYMER" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='POLYMER'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter(cl.orcmd)
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    ID = String.Concat(IDS, "13000", 1)
                    txtgno.Text = ID
                End If
            End If
        End If


        If unit = "SPM" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='SPM'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter(cl.orcmd)
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    Dim ID As String
                    ID = String.Concat(IDS, "17000", 1)
                    txtgno.Text = ID
                End If
            End If
        End If

        If unit = "Palathurai" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='Palathurai'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter(cl.orcmd)
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    Dim ID As String
                    ID = String.Concat(IDS, "34000", 1)


                    txtgno.Text = ID
                End If
            End If
        End If


        If unit = "GLOBAL" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='GLOBAL'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter(cl.orcmd)
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    Dim ID As String
                    ID = String.Concat(txtgno.Text, "000", 1)
                    txtgno.Text = ID
                End If
            End If
        End If

        ''''checking gate existence
        cl.sql = "select gate_no from jan_gate_header where gate_no='" & txtgno.Text & "' AND UNIT='" & unit & "'"
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.oradap = New OracleDataAdapter((cl.orcmd))
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "resultab")

        If ds1.Tables("resultab").Rows.Count <> 0 Then
            For i = 0 To ds1.Tables("resultab").Rows.Count - 1
                If IsNumeric(txtgno.Text) Then
                    If ds1.Tables("resultab").Rows(i).Item("gate_no") = txtgno.Text Then
                        MessageBox.Show("Gate Number Already Exists!", "Gate Entry")
                        Exit Sub
                    End If
                End If
            Next
        End If

        ''''checking dcno

        cl.sql = "select COUNT(*) CNT from jan_gate_header where supplier_name='" & cmbsup.Text.ToString.Replace("'", "''") & "'   and  gdate BETWEEN JAN_FYR_DATE AND JAN_FYR_END_DATE  AND DC_NO='" & txtdcno.Text & "' AND UNIT='" & unit & "' "
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        If ds.Tables("resultab").Rows.Count <> 0 Then
            ' For i = 0 To ds.Tables("resultab").Rows.Count - 1
            If ds.Tables("resultab").Rows(0).Item(0) > 0 Then
                MessageBox.Show("DCNo already available for the supplier", "Gate Entry")
                Exit Sub
            End If
            '  Next
        End If



        For i = 0 To dgv1.RowCount - 1
            If dgv1.Rows(i).Cells(0).Value <> "" And dgv1.Rows(i).Cells(8).Value = "" Then
                b = True
                Exit Sub
            End If
        Next
        ''''''''''' checking for dcqty > popend qty
        For i = 0 To dgv1.RowCount - 1
            If dgv1.Rows(i).Cells(8).Value = "" Then Exit For
            If dgv1.Rows(i).Cells(0).Value <> "" And txtdcno.Text <> "" And dgv1.Rows(i).Cells(8).Value <> "" And Convert.ToDecimal(dgv1.Rows(i).Cells(8).Value) > Convert.ToDecimal(dgv1.Rows(i).Cells(6).Value) Then
                MessageBox.Show("DcQty Greater Then Po Pend", "Gate Entry")
                Exit Sub
            End If
        Next
        '''''' checking conditions for po ,osp,servicesAnd txt_adi_no.Text <> "" 

        head = txtgno.Text

        '''''''''end for conditions

        Dim d As Date
        d = Date.Today
        cl.sql = "insert into jan_gate_header(gate_no,gate_id,supplier_name,vendor_id,supplier_site,dc_no,dc_date,validated,gtype,gdate,vehicle_det"

        cl.sql &= ",courier_name,pod_no ,no_of_box ,po_wt ,rec_Wt,eway_no "

        If chkref.Checked = True Then cl.sql &= " ,reason,rearef,org "

        cl.sql &= " ,unit,flag,invoice_val,UNAME"

        'COMMENTED ON 8TH FEB 2010
        '      If txt_adi_no.Text <> "" Then cl.sql &= ",adi_no,adi_date"

        If txtadirea.Visible = True Then cl.sql &= " ,adi_reason" ''''for manual ADI entry
        'COMMENTED ON 27TH SEP 2011
        ' cl.sql &= " ) values(" & head & ",'" & head & "','" & cmbsup.Text.ToString.Replace("'", "''") & "', " & cmbsup.SelectedValue & " ,'" & txtsite.Text & "','" & txtdcno.Text & "','" & Format(dtdc.Value, "dd-MMM-yyyy") & "',"


        cl.sql &= " , responsible_person,responsible_dept ,transport_mode,person_name  ) values(" & txtgno.Text & ",'" & txtgno.Text & "','" & cmbsup.Text & "', " & cmbsup.SelectedValue & " ,'" & txtsite.Text & "','" & txtdcno.Text & "','" & Format(dtdc.Value, "dd-MMM-yyyy") & "',"

        If chkref.Checked = False Then cl.sql &= " " & 1 & "," Else cl.sql &= " " & 6 & ","

        cl.sql &= " '" & cmbtype.SelectedItem & "'  "

        If chkogt.Checked = True Then

            cl.sql &= ",nvl((select gate_Dt from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header'),sysdate),nvl((select vehicle_Det from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header'),'') ,(select courier_name from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header'),(select pod_no from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header'),(select no_of_box from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header'),(select pod_wt from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header'),(select rec_wt from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header'),(select eway_bill from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_For='Header')"
        Else
            cl.sql &= ",sysdate, '" & txtveh.Text & "','" & cmbcr.Text & "','" & txtpod.Text & "','" & txtbox.Text & "','" & txtpodwt.Text & "','" & txtrwt.Text & "',''"
        End If

        If chkref.Checked = True Then cl.sql &= ", '" & chkref.Text & "','" & TXTREF.Text & "','" & txtnorg.Text & "'"

        cl.sql &= " ,'" & unit & "'  "

        cl.sql &= ",'" & 1 & "','" & txtinv.Text & "' "

        If per <> "" Then
            cl.sql &= ",'" & per & "'"
        Else
            cl.sql &= ",''"
        End If

        If txtadirea.Visible = True Then cl.sql &= " ,'" & txtadirea.Text & "'" ''''for manual ADI entry

        If txtper.Visible = True Then
            cl.sql &= " ,'" & txtper.Text & "'  "
        Else
            cl.sql &= " ,'" & cmbres.Text & "'  "
        End If
        cl.sql &= " ,'" & ddldept.Text & "','" & ddltranp.Text & "','" & txtjper.Text & "'"

        cl.sql &= " ) "

        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        ''''''on 12th dec to save gate without lines with reasons

        'MessageBox.Show("Saved Successfully !!-Gate Number is: " & head & "", "Gate Entry")
        '''''
        'Else
        '    B = True
        'End If
        '''''''''inserting line values
        line = 0
        For i = 0 To dgv1.RowCount - 1
            '  If B = False Then
            If dgv1.Rows(i).Cells(8).Value = "" And dgv1.Rows(i).Cells(9).Value = "" Then Exit For
            dt2 = dgv1.Item(1, i).Value
            line = line + 1
            de = dgv1.Item(3, i).Value.ToString.Replace("""", """")
            de = de.Replace("'", "''")
            cl.sql = "insert into jan_gate_lines (item_id,org_id,GDATE,line_no,gate_no,gate_id,pono,podt,item,description,rev,popend,supdcqty,uom,job,oper,osp,type,remark,status,validated,org,flag,poline,pohead,location_id,poqty,actval,ratecat,potype,tariff,WIP_ENTITY_ID,OPN_SEQ,need_by_dt,CAT_ID ,LAST_UPDT "


            If chkogt.Checked = True Then cl.sql &= " ,checked_by,item_location,item_checked_Dt  "

            cl.sql &= " )values(jan_itemno('" & dgv1.Item(2, i).Value & "'),jan_orgid('" & dgv1.Item(4, i).Value & "'), SYSDATE," & line & "," & txtgno.Text & ",'" & txtgno.Text & "','" & dgv1.Item(0, i).Value & "','" & Format(dt2, "dd-MMM-yyyy") & "','" & dgv1.Item(2, i).Value & "','" & de & "','" & dgv1.Item(5, i).Value & "'," & dgv1.Item(6, i).Value & ", '" & dgv1.Item(8, i).Value.ToString & "','" & dgv1.Item(7, i).Value & "','" & dgv1.Item(15, i).Value & "','" & dgv1.Item(14, i).Value & "'  ,'" & dgv1.Item(13, i).Value & "','" & dgv1.Item(16, i).Value & "','" & dgv1.Item(9, i).Value & "','" & 1 & "','" & dgv1.Item(19, i).Value & "','" & dgv1.Item(4, i).Value & "','" & 1 & "','" & dgv1.Item(17, i).Value & "','" & dgv1.Item(18, i).Value & "','" & dgv1.Item(21, i).Value & "' ,'" & dgv1.Item(10, i).Value & "','" & dgv1.Item(8, i).Value & "','" & dgv1.Item(11, i).Value & "','" & dgv1.Item(12, i).Value & "','" & dgv1.Item(22, i).Value & "','" & dgv1.Item(23, i).Value & "','" & dgv1.Item(24, i).Value & "',"
            If Not IsDBNull(dgv1.Item(25, i).Value) Then
                cl.sql &= "  '" & Format(dgv1.Item(25, i).Value, "dd-MMM-yyyy") & "' "
            Else
                cl.sql &= " ''"
            End If


            cl.sql &= ",(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=" & dgv1.Item(18, i).Value & "),SYSDATE "

            If chkogt.Checked = True Then

                cl.sql &= ", (select checked_by from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_for='Header'),
(select item_location from jan_gate_Del where gate_no=" & txtgno.Text & " and rownum=1 and del_for='Lines' and org_id=jan_orgid('" & dgv1.Item(4, i).Value & "')) ,(select item_checked_Dt from jan_gate_Del where gate_no=" & txtgno.Text & " and rownum=1 and del_for='Lines' and org_id=jan_orgid('" & dgv1.Item(4, i).Value & "')  ) "

            End If

            cl.sql &= "  )"
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            ' End If
            a = True
        Next
        If dgv1.Rows(0).Cells(8).Value <> "" Then
            cl.sql = "UPDATE JAN_GATE_HEADER SET ORG='" & dgv1.Item(4, 0).Value & "' WHERE GATE_NO=" & txtgno.Text & ""
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
        End If


        'For i = 0 To dgv1.Rows.Count - 1
        '    If dgv1.Rows(i).Cells(1).Value = "" Then
        '        Exit For
        '    Else
        '        cl.sql = "SELECT DISTINCT ITEM_NO FROM JAN_SO_REQUIREMENT_MASTER_NEW WHERE (REQUIREMENT-CANCELLED_QTY-RECEIVED_QUANTITY)>0 AND ITEM_NO='" & dgv1.Rows(i).Cells(2).Value & "'"
        '        cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
        '        Dim DSITEM As New DataSet
        '        cl.oradap.Fill(DSITEM, "RESULTAB")
        '        If DSITEM.Tables("RESULTAB").Rows.Count > 0 Then
        '            cl.sql = "SELECT ITEM_NO,GATe_NO,PO_LINE FROM JAN_INWARD_STATUS WHERE ITEM_NO='" & dgv1.Rows(i).Cells(2).Value & "' AND GATe_NO=" & head & " AND PO_LINE=" & dgv1.Rows(i).Cells(17).Value & ""
        '            cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
        '            Dim DSCHECK As New DataSet
        '            cl.oradap.Fill(DSCHECK, "RESULTAB")
        '            If DSCHECK.Tables("RESULTAB").Rows.Count <> 0 Then
        '                cl.sql = "SELECT MAX(PROCESS_ID)PROCESS_ID FROM JAN_INWARD_STATUS"
        '                cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
        '                ds = New DataSet
        '                cl.oradap.Fill(ds, "RESULTAB")
        '                Dim ID As Integer = ds.Tables("RESULTAB").Rows(0).Item("PROCESS_ID") + 1
        '                cl.sql = " INSERT INTO JAN_INWARD_STATUS (PROCESS_ID,PROCESS_DT,GATE_NO,ITEM_NO,ITEM_ID,PO_LINE,GTYPE) VALUES ( " & ID & ",SYSDATE," & head & ",'" & dgv1.Rows(i).Cells(2).Value & "',JAN_ITEMNO('" & dgv1.Rows(i).Cells(2).Value & "')," & dgv1.Rows(i).Cells(17).Value & ",'" & cmbtype.SelectedItem & "')"
        '                If CON.State = ConnectionState.Closed Then CON.Open()
        '                cl.or(cl.orcmd) = New oracleCommand(cl.sql, cl.oraCON)
        '                (cl.orcmd).ExecuteNonQuery()
        '                CON.Close()
        '            End If
        '        End If
        '    End If
        'Next




        MessageBox.Show("Saved Successfully !!-Gate Number is: " & txtgno.Text & "", "Gate Entry")
        clear()

    End Sub



    Private Sub btnmod_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmod.Click
        Try

            txttype.Visible = True
            TextBox1.Visible = True
            cmbtype.Visible = False
            ' cmbsup.Text = Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(15).Value
            cmbsup.Visible = False
            If txttype.Text = "PO" Then


                cl.sql = "select    (JAN_ITEMNAME(ITEM_ID) ||'|----|'|| JAN_ITEMDESC(JAN_ITEMNAME(ITEM_ID))) ITEM,PO_LINE_LOCATION_ID   from MTL_SUPPLY a where SUPPLY_TYPE_CODE='PO' And DESTINATION_TYPE_CODE in ('EXPENSE','INVENTORY')  "

                cl.sql &= " and  a.to_organization_id in (" & orgid & ") "

                cl.sql &= " and   PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where vendor_id = JAN_VENDORNO('" & TextBox1.Text.ToString.Replace("'", "''") & "')) order by JAN_ITEMNAME(ITEM_ID) "

                ' cl.sql = "SELECT  (a.item_no || '|----|' || a.description) item ,a.price From JAN_PO_PENDING_BOUGHT_OUTS a where A.VENDOR_ID=" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(16).Value & " order by a.item_no,a.po_line_id "
                'a.vendor_id=(SELECT vendor_id FROM po_vendors WHERE vendor_name='" & TextBox1.Text.ToString.Replace("'", "''") & "') order by a.item_no,a.po_line_id "
            ElseIf txttype.Text = "OSP" Then

                cl.sql = "select    (select JAN_ITEMNAME(PRIMARY_ITEM_ID) from WIP_ENTITIES where WIP_ENTITY_ID=a.WIP_ENTITY_ID)||'|----|'||
JAN_ITEMDESC((select JAN_ITEMNAME(PRIMARY_ITEM_ID) from WIP_ENTITIES where WIP_ENTITY_ID=a.WIP_ENTITY_ID)) ITEM,B.PO_LINE_LOCATION_ID   from MTL_SUPPLY B ,PO_DISTRIBUTIONS_ALL a where B.PO_HEADER_ID=B.PO_HEADER_ID AND A.PO_DISTRIBUTION_ID=B.PO_DISTRIBUTION_ID AND 
B.SUPPLY_TYPE_CODE='PO' and B.DESTINATION_TYPE_CODE in ('SHOP FLOOR')  "

                cl.sql &= "and b.to_organization_id in (" & orgid & ")"

                cl.sql &= " and  A.PO_HEADER_ID in (select PO_HEADER_ID from PO_HEADERS_ALL where vendor_id =  JAN_VENDORNO('" & TextBox1.Text.ToString.Replace("'", "''") & "')) "

                ' cl.sql = "select (b.partno||'|----|'||b.partname) item,b.price from jan_po_pending_osp b where B.VENDOR_ID=" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(16).Value & " order by B.PARTno,B.po_line_id"

                'where b.vendor_id=(SELECT vendor_id FROM po_vendors WHERE vendor_name='" & TextBox1.Text.ToString.Replace("'", "''") & "') ORDER BY b.partno,b.po_line_id"
            End If

            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            Dim dsITEM As New DataSet
            cl.oradap.Fill(dsITEM, "resultab")
            For i = 0 To dsITEM.Tables("resultab").Rows.Count - 1
                cmbitem.Items.Add(dsITEM.Tables("resultab").Rows(i).Item("item"))
            Next

            'If txttype.Text = "PO" Then
            '    cl.sql = "select distinct a.pono pono from jan_po_pending_bought_outs a where a.vendor_id=" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(15).Value & " and (a.item_no || '|----|' || a.description)='" & cmbitem.SelectedItem & "' "

            '    If txtrole.Text <> "UNIT2" Then cl.sql &= " and a.ship_to_organization_id in(106,107,108,109,110)"
            '    If txtrole.Text = "UNIT2" Then cl.sql &= " and a.ship_to_organization_id in(104)"
            'ElseIf txttype.Text = "OSP" Then
            '    cl.sql = " select distinct b.pono pono from jan_po_pending_osp b where  b.vendor_id= " & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(15).Value & " and (b.partno||'|----|'||b.partname)='" & cmbitem.SelectedItem & "'"

            '    If txtrole.Text <> "UNIT2" Then cl.sql &= " and b.ship_to_organization_id in(106,107,108,109,110)"
            '    If txtrole.Text = "UNIT2" Then cl.sql &= " and b.ship_to_organization_id in(104)"
            'End If

            'cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            'ds = New DataSet
            'cl.oradap.Fill(ds, "resultab")
            'If ds.Tables("resultab").Rows.Count > 0 Then
            '    For i = 0 To ds.Tables("resultab").Rows.Count - 1
            '        cmbpo.Items.Add(ds.Tables("resultab").Rows(i).Item("pono"))
            '    Next
            'End If
            '''''''''''TO DISPLAY XEROX VAL
            'cl.sql = "select xerox from jan_gatE_header where gate_no='" & txtgno.Text & "'"
            'cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            'ds = New DataSet
            'cl.oradap.Fill(ds, "resultab")
            'If ds.Tables("resultab").Rows(0).Item("xerox").ToString = "Yes" Then xerox.Checked = True Else xerox.Checked = False

            '''''''' to display no reference
            cl.sql = "select reason,rearef from jan_gatE_header where gate_no='" & txtgno.Text & "'"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            If ds.Tables("resultab").Rows(0).Item("reason").ToString = "No Reference" Then chkref.Checked = True : TXTREF.Text = ds.Tables("resultab").Rows(0).Item("rearef").ToString Else chkref.Checked = False : TXTREF.Text = ""


            '''''TO DISPlaY ADI REASON VAL
            cl.sql = "SELECT ADI_REASON,adi_no,adi_date,dc_no,dc_date  FROM JAN_GATe_HEADER WHERE GATe_NO='" & txtgno.Text & "'"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            If ds.Tables("resultab").Rows(0).Item("ADI_REASON").ToString <> "" Then Label17.Visible = True : txtadirea.Visible = True : txtadirea.Text = ds.Tables("resultab").Rows(0).Item("ADI_REASON")
            If ds.Tables("resultab").Rows(0).Item("adi_no").ToString <> "" Then txt_adi_no.Text = ds.Tables("resultab").Rows(0).Item("adi_no") : dtadi.Value = Format(ds.Tables("resultab").Rows(0).Item("adi_date"), "dd-MMM-yyyy")
            txtdcno.Text = ds.Tables("resultab").Rows(0).Item("dc_no") : dtdc.Value = Format(ds.Tables("resultab").Rows(0).Item("dc_date"), "dd-MMM-yyyy")


            ''''''binding line values
            cl.sql = "select pono,podt,item,description,org,rev,poqty,popend,supdcqty,remark,uom,job,oper,osp,type ,poline,pohead,VALIDATED,location_id ,ratecat,potype,tariff,WIP_ENTITY_ID,OPN_SEQ,need_by_dt,LAST_UPDT,lot_no    from jan_gate_lines where gate_no='" & txtgno.Text & "' and flag ='" & 1 & "'"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            For j = 0 To ds.Tables("Resultab").Rows.Count - 1
                With ds.Tables("resultab").Rows(j)
                    dgv1.Rows(j).Cells(0).Value = .Item("pono")
                    dgv1.Rows(j).Cells(1).Value = .Item("podt")
                    dgv1.Rows(j).Cells(2).Value = .Item("item")
                    dgv1.Rows(j).Cells(3).Value = .Item("description")
                    dgv1.Rows(j).Cells(4).Value = .Item("org")
                    dgv1.Rows(j).Cells(5).Value = .Item("rev").ToString
                    dgv1.Rows(j).Cells(6).Value = .Item("popend")
                    dgv1.Rows(j).Cells(7).Value = .Item("uom")
                    dgv1.Rows(j).Cells(8).Value = .Item("supdcqty")
                    dgv1.Rows(j).Cells(9).Value = .Item("remark").ToString
                    dgv1.Rows(j).Cells(10).Value = .Item("poqty").ToString
                    dgv1.Rows(j).Cells(11).Value = .Item("ratecat")
                    dgv1.Rows(j).Cells(12).Value = .Item("potype")
                    dgv1.Rows(j).Cells(13).Value = .Item("job")
                    dgv1.Rows(j).Cells(14).Value = .Item("oper")
                    dgv1.Rows(j).Cells(15).Value = .Item("osp")
                    dgv1.Rows(j).Cells(16).Value = .Item("type")
                    dgv1.Rows(j).Cells(17).Value = .Item("poline")
                    dgv1.Rows(j).Cells(18).Value = .Item("pohead")
                    dgv1.Rows(j).Cells(19).Value = .Item("validated")
                    dgv1.Rows(j).Cells(21).Value = .Item("location_id")
                    dgv1.Rows(j).Cells(22).Value = .Item("tariff").ToString
                    dgv1.Rows(j).Cells(23).Value = .Item("WIP_ENTITY_ID")
                    dgv1.Rows(j).Cells(24).Value = .Item("OPN_SEQ")
                    dgv1.Rows(j).Cells(25).Value = .Item("need_by_dt").ToString
                    dgv1.Rows(j).Cells(26).Value = .Item("LAST_UPDT").ToString
                    dgv1.Rows(j).Cells(27).Value = .Item("lot_no").ToString
                End With
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        'btnmod.Enabled = False
        'btnupdt.Visible = True
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Public Sub updt()
        Dim a, b As Boolean
        a = False : b = False

        Try
            sql = "select count(*) from jan_gate_lines where checked_by is not null  and gate_no=" & txtgno.Text & ""
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "cnt")

            If ds1.Tables("cnt").Rows(0).Item(0) > 0 Then

                cl.sql = "INSERT INTO jan_gate_del  (GATE_NO,org_id,item_location,del_For,item_checked_Dt,checked_by )  select distinct " & txtgno.Text & ",org_id,item_location,'Lines',item_checked_Dt,checked_by   from jan_gate_lines where gate_no= " & txtgno.Text & ""

                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                cl.oracon.Close()

            End If

            cl.sql = "DELETE FROM JAN_GATe_LINES WHERE GATe_NO='" & txtgno.Text & "' "
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()

            line = 0

            For i = 0 To dgv1.Rows.Count - 1
                If dgv1.Rows(i).Cells(8).Value = "" Then Exit For
                line = line + 1
                Dim dt As Date
                dt = dgv1.Rows(i).Cells(1).Value
                de = dgv1.Item(3, i).Value.ToString.Replace("""", """")
                de = de.Replace("'", "''")
                cl.sql = "insert into jan_gate_lines (item_id,org_id,GDATE,line_no,gate_no,gate_id,pono,podt,item,description,rev,popend,supdcqty,uom,job,oper,osp,type,remark,status,validated,org,flag,poline,pohead,location_id,poqty,actval,ratecat,potype,tariff,WIP_ENTITY_ID,OPN_SEQ,need_by_dt,CAT_ID,LAST_UPDT,lot_no"

                cl.sql &= " ,checked_by,item_location,item_checked_Dt  "


                cl.sql &= " )values(JAN_ITEMNO('" & dgv1.Item(2, i).Value & "'),JAN_ORGID('" & dgv1.Item(4, i).Value & "'),(SELECT GDATE FROM JAN_GATe_HEADER WHERE GATe_NO=" & txtgno.Text & ")," & line & "," & txtgno.Text & ",'" & txtgno.Text & "','" & dgv1.Item(0, i).Value & "','" & Format(dt, "dd-MMM-yyyy") & "','" & dgv1.Item(2, i).Value & "','" & de & "','" & dgv1.Item(5, i).Value & "'," & dgv1.Item(6, i).Value & ",'" & dgv1.Item(8, i).Value.ToString & "','" & dgv1.Item(7, i).Value & "','" & dgv1.Item(15, i).Value & "','" & dgv1.Item(14, i).Value.ToString.Replace("'", "") & "','" & dgv1.Item(13, i).Value & "','" & dgv1.Item(16, i).Value & "','" & dgv1.Item(9, i).Value & "','" & 1 & "','" & dgv1.Item(19, i).Value & "','" & dgv1.Item(4, i).Value & "','" & 1 & "','" & dgv1.Item(17, i).Value & "','" & dgv1.Item(18, i).Value & "','" & dgv1.Item(21, i).Value & "','" & dgv1.Item(10, i).Value & "','" & dgv1.Item(8, i).Value & "','" & dgv1.Item(11, i).Value & "','" & dgv1.Item(12, i).Value & "','" & dgv1.Item(22, i).Value & "','" & dgv1.Item(23, i).Value & "','" & dgv1.Item(24, i).Value & "', '" & Format(CDate(dgv1.Item(25, i).Value), "dd-MMM-yyyy") & "',(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=" & dgv1.Item(18, i).Value & "),'" & Format(CDate(dgv1.Item(26, i).Value), "dd-MMM-yyyy") & "','" & dgv1.Item(27, i).Value & "'"


                cl.sql &= ", (select checked_by from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1 and del_for='Lines'),
(select item_location from jan_gate_Del where gate_no=" & txtgno.Text & " and rownum=1 and del_for='Lines' and org_id=jan_orgid('" & dgv1.Item(4, i).Value & "')) ,(select item_checked_Dt from jan_gate_Del where gate_no=" & txtgno.Text & " and rownum=1 and del_for='Lines' and org_id=jan_orgid('" & dgv1.Item(4, i).Value & "')  ) "

                cl.sql &= " )"


                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                cl.oracon.Close()
            Next

            'cl.sql = "select nvl(max(line_no),0)line_no from jan_gate_lines where gate_no='" & txtgno.Text & "' and flag='1'"
            'cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            'ds = New DataSet
            'cl.oradap.Fill(ds, "resultab")

            'For i = 0 To dgv1.Rows.Count - 1
            '    If dgv1.Rows(i).Cells(8).Value = "" Then
            '        Exit For
            '    ElseIf dgv1.Rows(i).Cells(8).Value <> "" Then

            '        Dim dt As Date
            '        dt = dgv1.Rows(i).Cells(1).Value
            '        de = dgv1.Item(3, i).Value.ToString.Replace("""", """")
            '        de = de.Replace("'", "''")

            '        ''to add new values 

            '        cl.sql = "select line_no,VALIDATED from jan_gate_lines where gate_no='" & txtgno.Text & "' and flag='1' and line_no='" & line & "'"
            '        cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            '        Dim dsline As New DataSet
            '        cl.oradap.Fill(dsline, "resultab")
            '        line = dsline.Tables("resultab").Rows(0).Item("line_no")

            '        If dsline.Tables("resultab").Rows.Count <> 0 Then ''''''''updating already entered lines
            '            cl.sql = "update jan_gate_lines set line_no='" & line & "',pono='" & dgv1.Rows(i).Cells(0).Value & "',podt='" & Format(dt, "dd-MMM-yyyy") & "',item='" & dgv1.Rows(i).Cells(2).Value & "',description='" & de & "',org='" & dgv1.Rows(i).Cells(4).Value & "',rev='" & dgv1.Rows(i).Cells(5).Value.ToString & "',popend='" & dgv1.Rows(i).Cells(6).Value & "',uom='" & dgv1.Rows(i).Cells(7).Value & "',supdcqty='" & dgv1.Rows(i).Cells(8).Value & "',remark='" & dgv1.Rows(i).Cells(9).Value & "',job='" & dgv1.Rows(i).Cells(15).Value & "' ,oper='" & dgv1.Rows(i).Cells(14).Value & "',osp='" & dgv1.Rows(i).Cells(13).Value & "',type='" & dgv1.Rows(i).Cells(16).Value & "',poline='" & dgv1.Rows(i).Cells(17).Value & "' ,pohead='" & dgv1.Rows(i).Cells(18).Value & "' , flag='1' ,validated='" & dgv1.Rows(i).Cells(19).Value & "',location_id='" & dgv1.Rows(i).Cells(21).Value & "',poqty='" & dgv1.Rows(i).Cells(10).Value & "',ratecat='" & dgv1.Rows(i).Cells(11).Value & "',potype='" & dgv1.Rows(i).Cells(12).Value & "',tariff= '" & dgv1.Rows(i).Cells(22).Value & "',WIP_ENTITY_ID= '" & dgv1.Rows(i).Cells(23).Value & "',OPN_SEQ= '" & dgv1.Rows(i).Cells(24).Value & "'  where gate_no='" & txtgno.Text & "' and line_no='" & line & "'"
            '            If CON.State = ConnectionState.Closed Then CON.Open()
            '            cl.or(cl.orcmd) = New oracleCommand(cl.sql, cl.oraCON)
            '            (cl.orcmd).ExecuteNonQuery()
            '            CON.Close()
            '        Else '''''''adding new lines
            '            line = line + 1
            '            de = dgv1.Item(3, i).Value.ToString.Replace("""", """")
            '            de = de.Replace("'", "''")
            '            cl.sql = "insert into jan_gate_lines (item_id,org_id,GDATE,line_no,gate_no,gate_id,pono,podt,item,description,rev,popend,supdcqty,uom,job,oper,osp,type,remark,status,validated,org,flag,poline,pohead,location_id,poqty,actval,ratecat,potype,tariff,WIP_ENTITY_ID,OPN_SEQ,need_by_dt)values(JAN_ITEMNO('" & dgv1.Item(2, i).Value & "'),JAN_ORGID('" & dgv1.Item(4, i).Value & "'),sysdate," & line & "," & txtgno.Text & ",'" & txtgno.Text & "','" & dgv1.Item(0, i).Value & "','" & Format(dt, "dd-MMM-yyyy") & "','" & dgv1.Item(2, i).Value & "','" & de & "','" & dgv1.Item(5, i).Value & "'," & dgv1.Item(6, i).Value & ",'" & dgv1.Item(8, i).Value.ToString & "','" & dgv1.Item(7, i).Value & "','" & dgv1.Item(15, i).Value & "','" & dgv1.Item(14, i).Value & "','" & dgv1.Item(13, i).Value & "','" & dgv1.Item(16, i).Value & "','" & dgv1.Item(9, i).Value & "','" & 1 & "','" & dgv1.Item(19, i).Value & "','" & dgv1.Item(4, i).Value & "','" & 1 & "','" & dgv1.Item(17, i).Value & "','" & dgv1.Item(18, i).Value & "','" & dgv1.Item(21, i).Value & "','" & dgv1.Item(10, i).Value & "','" & dgv1.Item(8, i).Value & "','" & dgv1.Item(11, i).Value & "','" & dgv1.Item(12, i).Value & "','" & dgv1.Item(22, i).Value & "','" & dgv1.Item(23, i).Value & "','" & dgv1.Item(24, i).Value & "', '" & Format(CDate(dgv1.Item(25, i).Value), "dd-MMM-yyyy") & "' )"
            '            If CON.State = ConnectionState.Closed Then CON.Open()
            '            cl.or(cl.orcmd) = New oracleCommand(cl.sql, cl.oraCON)
            '            (cl.orcmd).ExecuteNonQuery()
            '            CON.Close()
            '        End If
            '        a = True
            '    End If
            'Next



            '''''' updating invoice value for po & xerox values
            cl.sql = "UPDATE JAN_GATE_HEADER SET INVOICE_VAL='" & txtinv.Text & "', dc_no='" & txtdcno.Text & "',dc_date='" & Format(dtdc.Value, "dd-MMM-yyyy") & "',  courier_name ='" & cmbcr.Text & "',pod_no='" & txtpod.Text & "',no_of_box ='" & txtbox.Text & "',po_wt ='" & txtpodwt.Text & "',rec_Wt='" & txtrwt.Text & "',"

            If chkref.Checked = True Then cl.sql &= " reason='" & chkref.Text & "',VALIDATED=6, rearef='" & TXTREF.Text & "', ORG='" & txtnorg.Text & "' " Else cl.sql &= " reason='',rearef='',validated =  1   "

            If txtadirea.Visible = True Then cl.sql &= " ,ADI_REASON= '" & txtadirea.Text & "'"

            cl.sql &= " WHERE GATE_NO = " & txtgno.Text & ""

            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()

            '''''''''updating org values to header
            If dgv1.Item(4, 0).Value <> Nothing Then


                cl.sql = "UPDATE JAN_GATE_HEADER SET ORG='" & dgv1.Item(4, 0).Value & "' WHERE GATE_NO=" & txtgno.Text & ""
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                cl.oracon.Close()
            End If


            'cl.sql = "SELECT VALIDATED FROM JAN_GATE_LINES WHERE GATE_NO='" & txtgno.Text & "' AND VALIDATED <>0 AND FLAG='1'"
            'cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            'ds = New DataSet
            'cl.oradap.Fill(ds, "RESULTAB")
            'If ds.Tables("RESULTAB").Rows.Count <> 0 Then

            '    cl.sql = "SELECT VALIDATED FROM JAN_GATE_LINES WHERE GATE_NO='" & txtgno.Text & "' AND VALIDATED='2' AND FLAG='1'"
            '    cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            '    ds = New DataSet
            '    cl.oradap.Fill(ds, "RESULTAB")
            '    If ds.Tables("RESULTAB").Rows.Count <> 0 Then
            '        cl.sql = "UPDATE JAN_GATE_HEADER SET  VALIDATED='2' WHERE GATE_NO='" & txtgno.Text & "'"
            '        If CON.State = ConnectionState.Closed Then CON.Open()
            '        cl.or(cl.orcmd) = New OracleCommand(cl.sql, cl.oraCON)
            '        (cl.orcmd).ExecuteNonQuery()
            '        CON.Close()
            '    Else
            '        'cl.sql = "UPDATE JAN_GATE_HEADER SET  VALIDATED='0' WHERE GATE_NO='" & txtgno.Text & "'"
            '        'cl.or(cl.orcmd) = New oracleCommand(cl.sql, cl.oraCON)
            '        '(cl.orcmd).ExecuteNonQuery()
            '        '''''ON 11TH DEC
            '        cl.sql = "SELECT VALIDATED FROM JAN_GATE_LINES WHERE GATE_NO='" & txtgno.Text & "' AND VALIDATED='1' AND FLAG='1'"
            '        cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            '        ds = New DataSet
            '        cl.oradap.Fill(ds, "RESULTAB")
            '        If ds.Tables("RESULTAB").Rows.Count <> 0 Then
            '            cl.sql = "UPDATE JAN_GATE_HEADER SET  VALIDATED='1' WHERE GATE_NO='" & txtgno.Text & "'"
            '            If CON.State = ConnectionState.Closed Then CON.Open()
            '            cl.or(cl.orcmd) = New OracleCommand(cl.sql, cl.oraCON)
            '            (cl.orcmd).ExecuteNonQuery()
            '            CON.Close()
            '        End If
            '    End If
            'End If

            'If chkref.Checked = True Then
            '    cl.sql = "UPDATE JAN_GATE_HEADER SET  VALIDATED='6' WHERE GATE_NO='" & txtgno.Text & "'"
            '    If CON.State = ConnectionState.Closed Then CON.Open()
            '    cl.or(cl.orcmd) = New OracleCommand(cl.sql, cl.oraCON)
            '    (cl.orcmd).ExecuteNonQuery()
            '    CON.Close()
            'Else
            '    cl.sql = "SELECT VALIDATED FROM JAN_GATE_LINES WHERE GATE_NO='" & txtgno.Text & "' AND VALIDATED='1' AND FLAG='1'"
            '    cl.oradap = New OracleDataAdapter(cl.sql, cl.oraCON)
            '    ds = New DataSet
            '    cl.oradap.Fill(ds, "RESULTAB")
            '    If ds.Tables("RESULTAB").Rows.Count <> 0 Then
            '        cl.sql = "UPDATE JAN_GATE_HEADER SET  VALIDATED=1 WHERE GATE_NO='" & txtgno.Text & "'"
            '        If CON.State = ConnectionState.Closed Then CON.Open()
            '        cl.or(cl.orcmd) = New OracleCommand(cl.sql, cl.oraCON)
            '        (cl.orcmd).ExecuteNonQuery()
            '        CON.Close()
            '    End If
            'End If
            MessageBox.Show("Gate Number is: " & txtgno.Text & " Updated", "Gate Entry")
            If b = True Then
                MessageBox.Show("Gate Validated,Can't Add New Values", "Gate Entry")
            End If
            Me.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cl.oracon.Close()
        End Try
    End Sub
    Private Sub txtdcno_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdcno.Leave
        cl.sql = "select supplier_name from jan_gate_supplier where supplier_name='" & cmbsup.Text.ToString.Replace("'", "''") & "' and type  LIKE 'ADI%'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "resultab")
        If ds1.Tables("resultab").Rows.Count > 0 Then Label17.Visible = True : txtadirea.Visible = True
        ''''commented on 2nd feb 2010 to enter manual adi no

        'If chk_adi.Checked = True Then
        '    chkadi()
        'End If
    End Sub

    Private Sub chkadi()
        cl.sql = "select * from jan_gate_header where SUPPLIER_ID=" & cmbsup.SelectedValue & " and DC_NO='" & txtdcno.Text & "'" ' and DEL_ASN is null"
        Dim cmdsql As New SqlClient.SqlCommand(sql, scmcon2)
        Dim adapsql As New SqlClient.SqlDataAdapter(cmdsql)
        Dim mds As New DataSet
        If mds.Tables.Contains("asn_det") = True Then
            mds.Tables.Remove("asn_det")
        End If
        If chk_adi.Checked = True Then
            Try
                If scmcon2.State = ConnectionState.Closed Then scmcon2.Open()
            Catch ex As Exception
                MessageBox.Show("No Internet Connection !...")
                Exit Sub
            End Try
            adapsql.Fill(mds, "asn_det")
            If scmcon2.State = ConnectionState.Open Then scmcon2.Close()
            If mds.Tables("asn_det").Rows.Count > 0 Then
                MessageBox.Show("ADI Entry Found for this DC No !..,")
                txt_adi_no.Text = mds.Tables("asn_det").Rows(0).Item("asn_no")
                If txt_adi_no.Text <> "" Then
                    Shell("F:\public\adi_2.BAT", AppWinStyle.Hide)
                    cl.sql = "c:\ADI.EXE " & txt_adi_no.Text
                    Shell(cl.sql, AppWinStyle.NormalFocus)
                End If
            End If
        End If

    End Sub

    Private Sub cmborg_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub txtref_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Label14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub Label13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub btnmod_CausesValidationChanged(sender As Object, e As EventArgs) Handles btnmod.CausesValidationChanged

    End Sub

    Private Sub Add_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

        cl.sql = "select * from jan_gate_courier"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "cr")
        For i = 0 To ds.Tables("cr").Rows.Count - 1
            cmbcr.Items.Add(ds.Tables("cr").Rows(i).Item("courier_name"))
        Next
        'If txtrole.Text = "UNIT7" Or txtrole.Text = "U7_ADD" Or txtrole.Text = "ADD" Or txtrole.Text = "U1_ADD" Then
        '    Label20.Visible = True : Label21.Visible = True : Label22.Visible = True : Label23.Visible = True : Label24.Visible = True : cmbcr.Visible = True : txtpod.Visible = True : txtpodwt.Visible = True : txtbox.Visible = True : txtrwt.Visible = True

        'Else
        '    Label20.Visible = False : Label21.Visible = False
        '    Label22.Visible = False : Label23.Visible = False : Label24.Visible = False : cmbcr.Visible = False : txtpod.Visible = False : txtpodwt.Visible = False : txtbox.Visible = False : txtrwt.Visible = False
        'End If

        If unit.Contains("SPM") = True Then
            cmbres.Visible = True
            txtper.Visible = False
            cl.sql = "select description from jan_open_challan_Category where CAT_FOR_GATE=1 and live_Flag=1"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "resultab")
            cmbres.DisplayMember = "description"
            cmbres.ValueMember = "description"
            cmbres.DataSource = ds1.Tables("resultab")
        Else
            cmbres.Visible = False
            txtper.Visible = True
        End If
        sql = "select description from jan_open_challan_Category where org_id=" & OP_ID & " and live_Flag=1"

        If unit = "UNIT7" Then sql &= " UNION ALL select  distinct  company_name  from jan_gate_login where unit_name not like '%UNIT7%' AND company_name  is not null "

        If OP_ID = 584 Then
            sql &= " and CAT_FOR_GATE=1 and unit_name='" & unit & "'"
        End If

        'sql &= "  order by cat_no"
        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        adap.Fill(ds, "resultab")

        Dim dv As New DataView
        dv = ds.Tables(0).DefaultView
        dv.Sort = "description asc"

        Dim dt As New DataTable
        dt = dv.ToTable
        ds.Tables.Clear()
        ds.Tables.Add(dt)
        ds.AcceptChanges()

        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            ddldept.Items.Add(ds.Tables("resultab").Rows(i).Item("description").ToString.Replace("'", "''"))
        Next

        Dim arrayList = tr_mode.Split(",")
        For Each value As String In arrayList
            ddltranp.Items.Add(value)
        Next

        cl.sql = "select REPLACE(vendor_name,'''','''''')VENDOR_NAME,vendor_id from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' AND END_DATE_ACTIVE IS NULL AND   VENDOR_ID IN (SELECT VENDOR_ID FROM PO_vENDOR_SITES_ALL WHERE ORG_ID=" & OP_ID & " )"

        cl.sql &= " order by vendor_name asc"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "resultab")
        cmbsup.DisplayMember = "vendor_name"
        cmbsup.ValueMember = "vendor_id"
        cmbsup.DataSource = ds1.Tables("resultab")

        cl.sql = "Select REA_NAME FROM JAN_GATE_REASON WHERE REA_CODE In (42,43,44,45,46)"

        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "resultab")
        TXTREF.DisplayMember = "REA_NAME"
        TXTREF.ValueMember = "REA_NAME"
        TXTREF.DataSource = ds1.Tables("resultab")

        'For i = 0 To ds.Tables("resultab").Rows.Count - 1
        '    cmbsup.Items.Add(ds.Tables("resultab").Rows(i).Item("vendor_name").ToString.Replace("'", "''"))
        'Next

        'If txtrole.Text = "UNIT7" Or txtrole.Text = "U7_ADD" Or txtrole.Text = "ADD" Or txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Or txtrole.Text = "JAPL" Then chkogt.Visible = True : Else chkogt.Visible = False

        bind()
        'dgv1.Columns(24).Visible = False
        If txtgno.Text <> "" Then
            btnmod_Click(sender, e)
            cl.sql = "select supplier_name from jan_gate_supplier where supplier_name='" & TextBox1.Text.ToString.Replace("'", "''") & "' and type  LIKE 'ADI%'"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "resultab")
            If ds1.Tables("resultab").Rows.Count > 0 Then
                For i = 0 To dgv1.Rows.Count - 1
                    If dgv1.Rows(i).Cells(8).Value <> "" Then
                        dgv1.Rows(i).Cells(8).ReadOnly = True
                    End If
                    ': MessageBox.Show("Can't update DC Value", "Gate Register")
                Next
            End If
        End If

        If FLG <> False Then
            cl.sql = "SELECT COUNT(*)CNT,TO_CHAR(JAN_FYR_DATE,'yyyy')|| " & SEQNO & " "

            cl.sql &= " YR FROM DUAL WHERE SYSDATE  BETWEEN JAN_FYR_DATE AND JAN_FYR_END_DATE"
            '  MessageBox.Show(cl.sql)
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "DT")



            If ds1.Tables("DT").Rows(0).Item(0) = 1 Then
                txtgno.Text = ds1.Tables("DT").Rows(0).Item(1)
            End If

        End If



        If txttype.Text = "PO" Then Label16.Visible = True : txtinv.Visible = True
        '    If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Then Label10.Visible = True : Label13.Visible = True : Label14.Visible = True : cmborg.Visible = True : txtref.Visible = True : cmbrea.Visible = True

    End Sub
End Class