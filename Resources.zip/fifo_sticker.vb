Imports System.Data.OracleClient
Imports System.IO
Imports System
Imports oracleclass

Public Class fifo_sticker
    Dim s1 As String
    Dim cl As New oracleclass.Class1
    Private Sub fifo_sticker_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
        End
    End Sub
    Private Sub fifo_sticker_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        orgid = Environment.GetCommandLineArgs(3)
        ' orgid = "I23"

        'sql = "select organization_code,organization_id  from org_organization_definitions where  organization_id in (" & orgid & ") "
        'cl.oradap = New OracleDataAdapter(sql,cl.oracon)
        'ds = New DataSet
        'cl.oradap.Fill(ds, "resultab")

        Me.Text = "Fifo For- " & orgid


        If orgid.Contains("I23") = True Then chkptc.Visible = True Else chkptc.Visible = False

        If orgid.Contains(",") = True Then
            Dim arrayList = orgid.Split(",")
            For Each value As String In arrayList
                cmborg.Items.Add(value)
                cmbjorg.Items.Add(value)
                cmbcorg.Items.Add(value)
                cmbsorg.Items.Add(value)
            Next

        Else
            cmborg.Items.Add(orgid)
            cmbjorg.Items.Add(orgid)
            cmbcorg.Items.Add(orgid)
            cmbsorg.Items.Add(orgid)
        End If

        'sql &= " order by organization_code"
        'cl.oradap = New OracleDataAdapter(sql,cl.oracon)
        'ds = New DataSet
        'cl.oradap.Fill(ds, "resultab")

        'With cmborg
        '    .DataSource = ds.Tables("resultab")
        '    .ValueMember = "organization_id"
        '    .DisplayMember = "organization_code"
        'End With

        'With cmbjorg
        '    .DataSource = ds.Tables("resultab")
        '    .ValueMember = "organization_id"
        '    .DisplayMember = "organization_code"
        'End With

        'With cmbcorg
        '    .DataSource = ds.Tables("resultab")
        '    .ValueMember = "organization_id"
        '    .DisplayMember = "organization_code"
        'End With


        If orgid.ToString() <> "" Then

            If category = "Po" Then TabControl1.TabPages.Remove(TabControl1.TabPages(1))

            If category = "Job" Then TabControl1.TabPages.Remove(TabControl1.TabPages(0))

        End If
    End Sub

    Public Sub func()
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
    End Sub


#Region "po"

    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        Try


            If cmborg.Text <> "" Then


                Me.Cursor = Cursors.WaitCursor
                dgv.Columns.Clear()

                Dim cc As New DataGridViewCheckBoxColumn
                cc.Width = 30
                Me.dgv.Columns.Add(cc)

                sql = " select ORG,GATE_NO,	ITEM,	ITEM_DESC	,SUPPLIER_NAME,	ACTUAL_LOT	,ITEM_ID	,QTY,	ORG_ID	,LOT_SUFFIX_CURRENT,	START_AUTO_LOT_NUMBER,	RANK	,ROW_ID	,YR, MTH,	PRINT_FLAG,NVL((SELECT lot_no  FROM JAN_FIFO_LOTNO_DETAILS WHERE ref_id=xx.gate_no  And organization_id  =xx.org_id  And inventory_item_id=xx.item_id And ref_source ='Po'), xx.item ||'_' ||TO_CHAR((select gdate from jan_gatE_header where gate_no=xx.gate_no),'iyyyiwdhh24miss'))LOT,	rECEIPT_NUM	,QTY_DLYD from (SELECT JAN_ORGCODE(ORG_ID)ORG,X.GATE_NO,X.ITEM,JAN_ITEMDESC(X.ITEM)ITEM_DESC,Y.SUPPLIER_NAME,''ACTUAL_LOT,ITEM_ID,SUM(SUPDCQTY)QTY,ORG_ID,lot_no LOT_SUFFIX_CURRENT,'' START_AUTO_LOT_NUMBER,'' RANK ,'' ROW_ID ,TO_CHAR(Y.GDATE,'yyyy')YR,TO_CHAR(Y.GDATE,'Mon')MTH, (SELECT COUNT(*) FROM JAN_FIFO_LOTNO_DETAILS WHERE REF_ID=X.GATE_NO AND ORGANIZATION_ID=X.ORG_ID AND INVENTORY_ITEM_ID=X.ITEM_ID AND REF_SOURCE='Po' and print_flag=1)PRINT_FLAG,(SELECT RECEIPT_NUM FROM RCV_SHIPMENT_HEADERS WHERE PACKING_SLIP=TO_CHAR(X.GATE_NO) AND SHIP_TO_ORG_ID=X.ORG_ID) RECEIPT_NUM,0 QTY_DLYD FROM JAN_GATE_LINES  X,JAN_GATE_HEADER Y WHERE Y.GDATE>=TO_DATE('" & Format(DateTimePicker1.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') AND Y.GDATE<=TO_DATE('" & Format(DateTimePicker2.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') AND  X.GATE_NO=Y.GATE_NO   AND Y.GTYPE='PO' "

                If txtgno.Text <> "" Then sql &= " and  x.gate_no='" & txtgno.Text & "'"

                If chkpend.Checked = True Then sql &= " and (select count(*) from JAN_FIFO_LOTNO_DETAILS where ref_id=x.gate_no and organization_id=x.org_id and inventory_item_id=x.item_id and ref_source='Po' and  print_flag =1)=0 "

                If txtitem.Text <> "" Then sql &= " and item='" & txtitem.Text & "'"

                If cmborg.Text <> "" Then sql &= " and  x.org_id=JAN_ORGID('" & cmborg.Text & "') "

                sql &= " group by x.GATE_NO,ITEM,ITEM_ID,ORG_ID,TRUNC(x.GDATE),y.supplier_name,to_char(y.gdate,'yyyy'),to_char(y.gdate,'Mon'),lot_no)xx "


                'sql = "select jan_orgcode(a.org_id)org, a.item,a.description,sum(a.supdcqty)qty,case when sticker_print_flag=1 then a.lot_no else JAN_fifo_LOTno(a.gate_no,a.Org_id,a.item_id,'PO') end lot_no,b.supplier_name ,b.gate_no,to_char(b.gdate,'yyyy')yr,to_char(b.gdate,'Mon')mth,  sticker_print_flag  from jan_gate_lines a ,jan_gatE_header b where b.gdate>=TO_DATE('" & Format(DateTimePicker1.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and b.gdAtE<=TO_DATE('" & Format(DateTimePicker2.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and b.unit='UNIT7' and a.gate_no=b.gate_no "


                'sql &= " group by a.item,a.description,a.Org_id,a.item_id,b.gtype,b.supplier_name,to_char(b.gdate,'yyyy') ,to_char(b.gdate,'Mon'),b.gate_no, sticker_print_flag  ,a.lot_no order by  b.gate_no"

                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                ds1 = New DataSet
                cl.oradap.Fill(ds1, "resultab")
                DV = ds1.Tables("resultab").DefaultView

                For i = 0 To DV.Count - 1
                    If Not IsDBNull(DV(i)("RECEIPT_NUM")) Then
                        DV(i)("QTY_DLYD") = RETVAL("SELECT SUM(QTY_DLYD) FROM JAN_PUR_LISTING WHERE GATE_NO= '" & DV(i)("GATE_NO") & "' And TO_ORGANIZATION_ID = " & DV(i)("ORG_ID") & " And ITEM_ID =" & DV(i)("ITEM_ID") & " AND RECEIPT_NUM='" & DV(i)("RECEIPT_NUM") & "'")
                    Else
                        DV(i)("QTY_DLYD") = DBNull.Value
                    End If
                Next

                With dgv
                    .DataSource = DV
                    .Columns(1).HeaderText = "Org" : .Columns(1).Width = 40
                    .Columns(2).HeaderText = "Gate No" : .Columns(2).Width = 80
                    .Columns(3).HeaderText = "Item No" : .Columns(3).Width = 80
                    .Columns(4).HeaderText = "Item Desc" : .Columns(4).Width = 100
                    .Columns(5).HeaderText = "Vendor" : .Columns(5).Width = 200

                    .Columns(8).HeaderText = "Qty" : .Columns(8).Width = 50
                    .Columns(17).HeaderText = "Lot No" : .Columns(17).Width = 140
                    .Columns(18).HeaderText = "Receipt No" : .Columns(18).Width = 100
                    .Columns(19).HeaderText = "Dlyd Qty" : .Columns(19).Width = 40



                    .Columns(6).Visible = False : .Columns(9).Visible = False : .Columns(10).Visible = False : .Columns(12).Visible = False : .Columns(13).Visible = False : .Columns(7).Visible = False : .Columns(14).Visible = False : .Columns(15).Visible = False : .Columns(11).Visible = False : .Columns(16).Visible = False


                End With

                For i = 0 To dgv.Rows.Count - 1
                    With dgv.Rows(i)
                        If .Cells(16).Value > 0 Then
                            .DefaultCellStyle.ForeColor = Color.MediumVioletRed
                        End If

                    End With

                Next



                Dim cc1 As New DataGridViewTextBoxColumn
                cc1.HeaderText = "No Of Packet"
                cc1.Width = 70
                Me.dgv.Columns.Add(cc1)
            Else
                MessageBox.Show("Select org", "FIFO")
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Me.Cursor = Cursors.Arrow


    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        s1 = ""
        For i = 0 To dgv.Rows.Count - 1

            If dgv.Rows(i).Cells(0).Value = True Then

                If dgv.Rows(i).Cells(20).Value > 0 Then

                    For k = 0 To dgv.Rows(i).Cells(20).Value - 1

                        s1 &= " CT~~CD,~CC^~CT~" & vbNewLine
                        s1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD20^JUS^LRN^CI0^XZ" & vbNewLine
                        s1 &= "^XA" & vbNewLine
                        s1 &= "^MMT" & vbNewLine
                        s1 &= "^PW400" & vbNewLine
                        s1 &= "^LL0201" & vbNewLine
                        s1 &= "^LS0" & vbNewLine
                        s1 &= "^FT54,149^BQN,2,4" & vbNewLine
                        s1 &= "^FH\^FDLA," & dgv.Rows(i).Cells(17).Value & "^FS" & vbNewLine
                        s1 &= "^FT53,178^A0N,25,24^FH\^FD" & dgv.Rows(i).Cells(17).Value & "^FS" & vbNewLine
                        s1 &= "^FT185,128^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(15).Value & "^FS" & vbNewLine
                        s1 &= "^FT186,86^A0N,39,38^FH\^FD" & dgv.Rows(i).Cells(14).Value & "^FS" & vbNewLine
                        s1 &= "^PQ1,0,1,Y^XZ" & vbNewLine

                    Next


                    sql = "select count(*) from JAN_FIFO_LOTNO_DETAILS where ORGANIZATION_ID=" & dgv.Rows(i).Cells(9).Value & " and item_no='" & dgv.Rows(i).Cells(3).Value & "'  and ref_id=" & dgv.Rows(i).Cells(2).Value & ""

                    cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
                    cl.oradap.Fill(ds, "RESULT")

                    If ds.Tables("RESULT").Rows(0).Item(0) = 0 Then
                        sql = "insert into JAN_FIFO_LOTNO_DETAILS (ORGANIZATION_ID ,INVENTORY_ITEM_ID ,ITEM_NO ,REF_ID ,REF_SOURCE ,LOT_NO ,LOT_QTY , NO_OF_box ,CREATION_DATE,print_flag ) values ( " & dgv.Rows(i).Cells(9).Value & ", jan_itemno('" & dgv.Rows(i).Cells(3).Value & "'),'" & dgv.Rows(i).Cells(3).Value & "'," & dgv.Rows(i).Cells(2).Value & ",'Po','" & dgv.Rows(i).Cells(17).Value & "'," & dgv.Rows(i).Cells(8).Value & "," & dgv.Rows(i).Cells(20).Value & ",sysdate,1 )"

                        func()
                    Else
                        sql = "UPDATE JAN_FIFO_LOTNO_DETAILS SET NO_OF_box=" & dgv.Rows(i).Cells(20).Value & ",PRINT_FLAG=1 WHERE REF_ID=" & dgv.Rows(i).Cells(2).Value & " AND  ORGANIZATION_ID=" & dgv.Rows(i).Cells(9).Value & "  and item_no='" & dgv.Rows(i).Cells(3).Value & "'"

                        func()
                    End If

                Else
                    MessageBox.Show("No of packet should be greater than 0")
                    Exit Sub
                End If

            End If

            'sql = "update JAN_FIFO_LOTNO_DETAILS set print_Flag=1 where ref_id=" & dgv.Rows(i).Cells(2).Value & "  and item_no='" & dgv.Rows(i).Cells(3).Value & "'"


            'func()


        Next
        x1 = "d:\lotsticker.txt"

        fstrm = New FileStream(x1, FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s1)
        sw.Close()
        fstrm.Close()

        sql = "select SYS_CONTEXT('USERENV','IP_ADDRESS') IP from DUAL"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        Dim DSAP As New DataSet
        cl.oradap.Fill(DSAP, "RESULT")
        Dim IPAD As String = ""

        If DSAP.Tables("RESULT").Rows.Count > 0 Then
            IPAD = DSAP.Tables("RESULT").Rows(0).Item("IP")
        End If


        ''''NEW_STICKER(sender, e)

        fstrm = New FileStream("d:\lotprint.bat", FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine("COPY " & x1 & " \\localhost\ZEBRA")
        sw.Close()
        fstrm.Close()
        Shell("d:\lotprint.bat", AppWinStyle.Hide)

    End Sub

#End Region

#Region "job"

    Private Sub bntjob_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bntjob.Click

        Try

            If cmbjorg.Text <> "" Then


                Me.Cursor = Cursors.WaitCursor
                dgvjob.Columns.Clear()

                Dim cc As New DataGridViewCheckBoxColumn
                cc.Width = 30
                Me.dgvjob.Columns.Add(cc)

                '' sql = "select Y.*, case when PRINT_FLAG >0 then (select lot_no from JAN_FIFO_LOTNO_DETAILS where ref_id=y.wip_entity_id and organization_id=y.organization_id and inventory_item_id=y.inventory_item_id  and ref_source='Job' and rownum=1)else ITEM_no ||'_'|| case when RID=1 then LOT_SUFFIX_CURRENT else   LOT_SUFFIX_CURRENT+(RID-1)   end end LOT  from( select JAN_ORGCODE(a.ORGANIZATION_ID) ORG,ITEM_NO,DESCRIPTION,JOB_NO,JOB_DT,OPN_SEQ,LOT_MOVE QUANTITY,COMP_DT,RES_CODE,RESOURC,OSP_ISP INHOUSE_OSP,JAN_AUTO_LOT(ORGANIZATION_ID,INVENTORY_ITEM_ID)new_lot,NVL((select LOT_SUFFIX_CURRENT from JAN_LOT_SEQUENCE_VIEW where INVENTORY_ITEM_ID=a.INVENTORY_ITEM_ID and ORGANIZATION_ID=a.ORGANIZATION_ID),1)LOT_SUFFIX_CURRENT,NVL((select LAST_LOT_NUMBER from JAN_LOT_SEQUENCE_VIEW where INVENTORY_ITEM_ID=a.INVENTORY_ITEM_ID and ORGANIZATION_ID=a.ORGANIZATION_ID),1)START_AUTO_LOT_NUMBER,SUM(1)over  (partition by  TRUNC(COMP_DT),INVENTORY_ITEM_ID   order by  TRUNC(COMP_DT),INVENTORY_ITEM_ID,WIP_ENTITY_ID   ) RID, to_char(a.COMP_DT,'yyyy')yr,to_char(a.COMP_DT,'Mon')mth,wip_entity_id, (select count(*) from JAN_FIFO_LOTNO_DETAILS where ref_id=a.wip_entity_id and organization_id=a.organization_id and inventory_item_id=a.inventory_item_id and ref_source='Job')print_flag, inventory_item_id ,organization_id  from JAN_FINAL_OPERATIONS a where 1=1 and  comp_Dt>=TO_DATE('" & Format(jfm.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and comp_dt<=TO_DATE('" & Format(jto.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"


                sql = " select y.*,case when PRINT_FLAG >0 then (select lot_no from JAN_FIFO_LOTNO_DETAILS where ref_id=y.wip_entity_id and organization_id=y.organization_id and inventory_item_id=y.inventory_item_id  and ref_source='Job' and  CREATION_DATE=(SELECT MAX(CREATION_DATE) FROM JAN_FIFO_LOTNO_DETAILS  WHERE REF_ID=y.wip_entity_id AND ORGANIZATION_ID=y.organization_id AND INVENTORY_ITEM_ID=y.INVENTORY_ITEM_ID AND REF_SOURCE='Job' ))  else new_lot end  LOT from (select JAN_ORGCODE(a.ORGANIZATION_ID) ORG,ITEM_NO,DESCRIPTION,JOB_NO,JOB_DT,OPN_SEQ,LOT_MOVE QUANTITY,COMP_DT,RES_CODE,RESOURC,OSP_ISP INHOUSE_OSP,item_no||'_'||to_char(comp_dt,'iyyyiwdhh24miss')new_lot,'' LOT_SUFFIX_CURRENT,''START_AUTO_LOT_NUMBER,'' RID, to_char(a.COMP_DT,'yyyy')yr,to_char(a.COMP_DT,'Mon')mth,wip_entity_id, (select count(*) from JAN_FIFO_LOTNO_DETAILS where ref_id=a.wip_entity_id and organization_id=a.organization_id and inventory_item_id=a.inventory_item_id and ref_source='Job' and print_Flag=1)print_flag, inventory_item_id ,organization_id  from JAN_FINAL_OPERATIONS a where 1=1 and  comp_Dt>=TO_DATE('" & Format(jfm.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and comp_dt<=TO_DATE('" & Format(jto.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') AND ITEM_TYPE<>'FG'"


                If cmbjorg.Text <> "" Then sql &= " and ORGANIZATION_ID=JAN_ORGID('" & cmbjorg.Text & "')"


                If chkjpend.Checked = True Then sql &= "and (select count(*) from JAN_FIFO_LOTNO_DETAILS where ref_id=a.wip_entity_id and organization_id=a.organization_id and inventory_item_id=a.inventory_item_id and ref_source='Job' and  print_flag =1)=0  "

                If txtjitem.Text <> "" Then sql &= " and item_no= '" & txtjitem.Text & "'"

                sql &= "  ) Y "
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                ds1 = New DataSet
                cl.oradap.Fill(ds1, "resultab")

                With dgvjob
                    .DataSource = ds1.Tables("resultab")
                    .Columns(1).HeaderText = "Org" : .Columns(1).Width = 40
                    .Columns(2).HeaderText = "Item No" : .Columns(2).Width = 100
                    .Columns(3).HeaderText = "Item Desc" : .Columns(3).Width = 100
                    .Columns(4).HeaderText = "Job" : .Columns(4).Width = 130
                    .Columns(5).HeaderText = "Job.Dt" : .Columns(5).Width = 70
                    .Columns(6).HeaderText = "Opn Seq" : .Columns(6).Width = 40
                    .Columns(7).HeaderText = "Qty" : .Columns(7).Width = 30
                    .Columns(8).HeaderText = "Comp.Dt" : .Columns(8).Width = 150

                    .Columns(9).HeaderText = "Res Code" : .Columns(9).Width = 40 : .Columns(9).Visible = False
                    .Columns(10).HeaderText = "Resource" : .Columns(10).Width = 250
                    .Columns(11).HeaderText = "Type" : .Columns(11).Width = 60

                    .Columns(12).Visible = False : .Columns(13).Visible = False : .Columns(14).Visible = False : .Columns(15).Visible = False : .Columns(16).Visible = False : .Columns(17).Visible = False : .Columns(18).Visible = False : .Columns(19).Visible = False : .Columns(20).Visible = False : .Columns(21).Visible = False

                    .Columns(22).HeaderText = "Lot No" : .Columns(19).Width = 140


                End With

                For i = 0 To dgvjob.Rows.Count - 1
                    With dgvjob.Rows(i)
                        If .Cells(19).Value > 0 Then
                            .DefaultCellStyle.ForeColor = Color.MediumVioletRed
                        End If

                    End With

                Next
                Dim cc1 As New DataGridViewTextBoxColumn
                cc1.HeaderText = "No Of Packet"
                cc1.Width = 70
                Me.dgvjob.Columns.Add(cc1)
            Else
                MessageBox.Show("Select org", "FIFO")
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub btn_jstk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_jstk.Click

        s1 = ""
        For i = 0 To dgvjob.Rows.Count - 1
            If dgvjob.Rows(i).Cells(0).Value = True Then
                If dgvjob.Rows(i).Cells(23).Value > 0 Then
                    For k = 0 To dgvjob.Rows(i).Cells(23).Value - 1




                        s1 &= " CT~~CD,~CC^~CT~" & vbNewLine
                        s1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD20^JUS^LRN^CI0^XZ" & vbNewLine
                        s1 &= "^XA" & vbNewLine
                        s1 &= "^MMT" & vbNewLine
                        s1 &= "^PW400" & vbNewLine
                        s1 &= "^LL0201" & vbNewLine
                        s1 &= "^LS0" & vbNewLine
                        s1 &= "^FT54,149^BQN,2,4" & vbNewLine
                        s1 &= "^FH\^FDLA," & dgvjob.Rows(i).Cells(22).Value & "^FS" & vbNewLine
                        s1 &= "^FT53,178^A0N,25,24^FH\^FD" & dgvjob.Rows(i).Cells(22).Value & "^FS" & vbNewLine
                        s1 &= "^FT185,128^A0N,39,38^FH\^FD" & dgvjob.Rows(i).Cells(17).Value & "^FS" & vbNewLine
                        s1 &= "^FT186,86^A0N,39,38^FH\^FD" & dgvjob.Rows(i).Cells(16).Value & "^FS" & vbNewLine
                        s1 &= "^PQ1,0,1,Y^XZ" & vbNewLine

                    Next
                    sql = "select count(*) from JAN_FIFO_LOTNO_DETAILS where ORGANIZATION_ID=" & dgvjob.Rows(i).Cells(21).Value & "  and item_no='" & dgvjob.Rows(i).Cells(2).Value & "'  and ref_id=" & dgvjob.Rows(i).Cells(18).Value & ""

                    cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
                    cl.oradap.Fill(ds, "RESULT")

                    If ds.Tables("RESULT").Rows(0).Item(0) = 0 Then

                        sql = "insert into JAN_FIFO_LOTNO_DETAILS (ORGANIZATION_ID ,INVENTORY_ITEM_ID ,ITEM_NO ,REF_ID ,REF_SOURCE ,LOT_NO ,LOT_QTY , NO_OF_box ,CREATION_DATE ,print_flag) values (" & dgvjob.Rows(i).Cells(21).Value & " , " & dgvjob.Rows(i).Cells(20).Value & " ,'" & dgvjob.Rows(i).Cells(2).Value & "'," & dgvjob.Rows(i).Cells(18).Value & ",'Job','" & dgvjob.Rows(i).Cells(22).Value & "'," & dgvjob.Rows(i).Cells(7).Value & "," & dgvjob.Rows(i).Cells(23).Value & ",sysdate,1 )"

                        func()
                    End If
                Else
                    MessageBox.Show("No of packet should be greater than 0")
                    Exit Sub
                End If
            End If

        Next
        x1 = "d:\lotsticker.txt"

        fstrm = New FileStream(x1, FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s1)
        sw.Close()
        fstrm.Close()

        sql = "select SYS_CONTEXT('USERENV','IP_ADDRESS') IP from DUAL"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        Dim DSAP As New DataSet
        cl.oradap.Fill(DSAP, "RESULT")
        Dim IPAD As String = ""

        If DSAP.Tables("RESULT").Rows.Count > 0 Then
            IPAD = DSAP.Tables("RESULT").Rows(0).Item("IP")
        End If


        ''''NEW_STICKER(sender, e)

        fstrm = New FileStream("d:\lotprint.bat", FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine("COPY " & x1 & " \\localhost\\ZEBRA")
        sw.Close()
        fstrm.Close()
        Shell("d:\lotprint.bat", AppWinStyle.Hide)
    End Sub

    Private Sub chkptc_CheckedChanged(sender As Object, e As EventArgs) Handles chkptc.CheckedChanged
        If chkptc.Checked = True Then


            For k = 0 To dgvjob.Rows.Count - 1

                If dgvjob.Rows(k).Cells(3).Value.ToString.ToUpper.Contains("CYLINDER") Or dgvjob.Rows(k).Cells(3).Value.ToString.ToUpper.Contains("PISTON") Or dgvjob.Rows(k).Cells(3).Value.ToString.ToUpper.Contains("TIE") Then

                    sql = "insert into JAN_FIFO_LOTNO_DETAILS (ORGANIZATION_ID ,INVENTORY_ITEM_ID ,ITEM_NO ,REF_ID ,REF_SOURCE ,LOT_NO ,LOT_QTY , CREATION_DATE ,print_flag) values (" & dgvjob.Rows(k).Cells(21).Value & " , " & dgvjob.Rows(k).Cells(20).Value & " ,'" & dgvjob.Rows(k).Cells(2).Value & "'," & dgvjob.Rows(k).Cells(18).Value & ",'Job','" & dgvjob.Rows(k).Cells(22).Value & "'," & dgvjob.Rows(k).Cells(7).Value & ",sysdate,1 )"
                    func()
                End If
            Next
            MessageBox.Show("Lot Generated For PTC items", "FIFO Sticker")
        End If
    End Sub

#End Region

#Region "current stk"

    Private Sub btncshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncshow.Click
        Try
            If cmbcorg.Text <> "" Then



                Me.Cursor = Cursors.WaitCursor
                dgvcstk.Columns.Clear()

                Dim cc As New DataGridViewCheckBoxColumn
                cc.Width = 30
                Me.dgvcstk.Columns.Add(cc)

                sql = "select jan_itemname(inventory_item_id)item_no,jan_itemdesc(jan_itemname(inventory_item_id))item_Desc,sum(transaction_quantity)qty,lot_number, to_char(date_received,'yyyy')yr,to_char(date_received,'Mon')mth, (select count(*) from JAN_FIFO_LOTNO_DETAILS where  organization_id=a.organization_id and inventory_item_id=a.inventory_item_id and ref_source='Stock' and lot_no=a.lot_number)print_flag ,(select SEGMENT3||'.'||SEGMENT4||'.'||SEGMENT5||'.'||SEGMENT6||'.'||SEGMENT7 from MTL_ITEM_LOCATIONS where ORGANIZATION_ID=a.ORGANIZATION_ID and INVENTORY_LOCATION_ID=a.LOCATOR_ID)LOC from mtl_onhand_quantities a where organization_id =JAN_ORGID('" & cmbcorg.Text & "') and subinventory_code='" & cmbsub.SelectedItem & "' "

                If txtcitem.Text <> "" Then sql &= " and inventory_item_id=jan_itemno('" & txtcitem.Text & "')"

                sql &= " group by inventory_item_id,lot_number, organization_id ,to_char(date_received,'yyyy') ,to_char(date_received,'Mon'),LOCATOR_ID  order by jan_itemname(inventory_item_id)"

                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                ds1 = New DataSet
                cl.oradap.Fill(ds1, "resultab")

                With dgvcstk

                    .DataSource = ds1.Tables("resultab")
                    .Columns(1).HeaderText = "Item No" : .Columns(1).Width = 100
                    .Columns(2).HeaderText = "Item Desc" : .Columns(2).Width = 300
                    .Columns(3).HeaderText = "Qty" : .Columns(3).Width = 100 : .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    .Columns(4).HeaderText = "Lot No" : .Columns(4).Width = 200
                    .Columns(5).Visible = False : .Columns(6).Visible = False : .Columns(7).Visible = False
                    .Columns(8).HeaderText = "Location"

                End With

                For i = 0 To dgvcstk.Rows.Count - 1
                    With dgvcstk.Rows(i)
                        If .Cells(7).Value > 0 Then
                            .DefaultCellStyle.ForeColor = Color.MediumVioletRed
                        End If

                    End With

                Next

                Dim cc1 As New DataGridViewTextBoxColumn
                cc1.HeaderText = "No Of Packet"
                cc1.Width = 70
                Me.dgvcstk.Columns.Add(cc1)

                Me.Cursor = Cursors.Arrow
            Else
                MessageBox.Show("Select org", "FIFO")
                Exit Sub
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub btncprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncprint.Click
        s1 = ""
        For i = 0 To dgvcstk.Rows.Count - 1

            If dgvcstk.Rows(i).Cells(0).Value = True Then

                'If dgv.Rows(i).Cells(6).Value = "PO" Then
                If dgvcstk.Rows(i).Cells(9).Value > 0 Then
                    For k = 0 To dgvcstk.Rows(i).Cells(9).Value - 1

                        's1 &= "CT~~CD,~CC^~CT~" & vbNewLine
                        's1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD15^JUS^LRN^CI0^XZ" & vbNewLine
                        's1 &= "^XA" & vbNewLine
                        's1 &= "^MMT" & vbNewLine
                        's1 &= "^PW791" & vbNewLine
                        's1 &= "^LL0160" & vbNewLine
                        's1 &= "^LS0" & vbNewLine
                        's1 &= "^FT565,131^BQN,2,4" & vbNewLine

                        's1 &= "^FH\^FDLA," & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine '''''item

                        's1 &= "^FT283,129^BQN,2,4" & vbNewLine

                        's1 &= "^FH\^FDLA," & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine '''''item

                        's1 &= "^FT681,109^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(5).Value & "^FS" & vbNewLine '''' yr

                        's1 &= "^FT565,146^A0N,25,24^FH\^FD" & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine ''''lot

                        's1 &= "^FT690,61^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(6).Value & "^FS" & vbNewLine '''''month

                        's1 &= "^FT15,131^BQN,2,4" & vbNewLine

                        's1 &= "^FH\^FDLA," & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine '''''item

                        's1 &= "^FT399,107^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(5).Value & "^FS" & vbNewLine '''' yr

                        's1 &= "^FT283,144^A0N,25,24^FH\^FD" & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine ''''lot

                        's1 &= "^FT409,59^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(6).Value & "^FS" & vbNewLine '''''month

                        's1 &= "^FT140,62^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(6).Value & "^FS" & vbNewLine '''''month

                        's1 &= "^FT131,109^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(5).Value & "^FS" & vbNewLine '''' yr 

                        's1 &= "^FT15,146^A0N,25,24^FH\^FD" & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine ''''lot

                        's1 &= "^PQ1,0,1,Y^XZ" & vbNewLine


                        s1 &= " CT~~CD,~CC^~CT~" & vbNewLine
                        s1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD20^JUS^LRN^CI0^XZ" & vbNewLine
                        s1 &= "^XA" & vbNewLine
                        s1 &= "^MMT" & vbNewLine
                        s1 &= "^PW400" & vbNewLine
                        s1 &= "^LL0201" & vbNewLine
                        s1 &= "^LS0" & vbNewLine
                        s1 &= "^FT54,149^BQN,2,4" & vbNewLine
                        s1 &= "^FH\^FDLA," & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine
                        s1 &= "^FT53,178^A0N,25,24^FH\^FD" & dgvcstk.Rows(i).Cells(4).Value & "^FS" & vbNewLine
                        s1 &= "^FT185,128^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(6).Value & "^FS" & vbNewLine
                        s1 &= "^FT186,86^A0N,39,38^FH\^FD" & dgvcstk.Rows(i).Cells(5).Value & "^FS" & vbNewLine
                        s1 &= "^PQ1,0,1,Y^XZ" & vbNewLine

                    Next

                End If

                sql = "insert into JAN_FIFO_LOTNO_DETAILS (ORGANIZATION_ID ,INVENTORY_ITEM_ID ,ITEM_NO ,REF_SOURCE ,LOT_NO ,LOT_QTY , NO_OF_box ,CREATION_DATE ) values (JAN_ORGID('" & cmbcorg.SelectedItem & "') , jan_itemno('" & dgvcstk.Rows(i).Cells(1).Value & "'),'" & dgvcstk.Rows(i).Cells(1).Value & "','Stock','" & dgvcstk.Rows(i).Cells(4).Value & "'," & dgvcstk.Rows(i).Cells(3).Value & "," & dgvcstk.Rows(i).Cells(9).Value & ",(select creation_Date from mtl_onhand_quantities where inventory_item_id=jan_itemno('" & dgvcstk.Rows(i).Cells(1).Value & "') and organization_id=JAN_ORGID('" & cmbcorg.SelectedItem & "') and lot_number= '" & dgvcstk.Rows(i).Cells(4).Value & "' and rownum=1 ) )"

                func()

            End If

            'sql = "update jan_gate_lines set lot_no='" & dgv.Rows(i).Cells(5).Value & "',sticker_print_flag=1,no_of_box ='" & dgv.Rows(i).Cells(12).Value & "' where gate_no=" & dgv.Rows(i).Cells(8).Value & "  and item='" & dgv.Rows(i).Cells(2).Value & "'"




        Next
        x1 = "d:\lotsticker.txt"

        fstrm = New FileStream(x1, FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s1)
        sw.Close()
        fstrm.Close()

        sql = "select SYS_CONTEXT('USERENV','IP_ADDRESS') IP from DUAL"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        Dim DSAP As New DataSet
        cl.oradap.Fill(DSAP, "RESULT")
        Dim IPAD As String = ""

        If DSAP.Tables("RESULT").Rows.Count > 0 Then
            IPAD = DSAP.Tables("RESULT").Rows(0).Item("IP")
        End If


        ''''NEW_STICKER(sender, e)
        '''






        fstrm = New FileStream("d:\lotprint.bat", FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine("COPY " & x1 & " \\localhost\ZEBRA")
        sw.Close()
        fstrm.Close()
        Shell("d:\lotprint.bat", AppWinStyle.Hide)
    End Sub



#End Region

#Region "others"

#End Region

#Region "shipment"
    Private Sub btnship_Click(sender As Object, e As EventArgs) Handles btnship.Click

        If cmbsorg.Text <> "" Then

            Me.Cursor = Cursors.WaitCursor
            dgvs.Columns.Clear()

            Dim cc As New DataGridViewCheckBoxColumn
            cc.Width = 30
            Me.dgvs.Columns.Add(cc)

            ''''sql = "select JAN_ORGCODE(a.ORGANIZATION_ID)ORG,a.SHIPMENT_NUMBER,JAN_ITEMNAME(a.INVENTORY_ITEM_ID)ITEM_NO,JAN_ITEMDESC(JAN_ITEMNAME(a.INVENTORY_ITEM_ID))ITEM_DESC,a.TRANSACTION_QUANTITY,a.SUBINVENTORY_CODE,  b.LOT_NUMBER ,jan_orgcode(a.transfer_organization_id  )transfer_from_org,to_char(a.creation_date,'yyyy')yr,to_char(a.creation_date,'Mon')mth, (select count(*) from JAN_FIFO_LOTNO_DETAILS where to_char(ref_id)=a.SHIPMENT_NUMBER and organization_id=a.organization_id and inventory_item_id=a.inventory_item_id and ref_source='Shipment')print_flag from MTL_MATERIAL_TRANSACTIONS a ,MTL_TRANSACTION_LOT_NUMBERS B    where a.SHIPMENT_NUMBER is not null and a.RCV_TRANSACTION_ID is not null and a.CREATION_DATE>= TO_DATE('" & Format(dtsfm.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and a.CREATION_DATE<=TO_DATE('" & Format(dtsto.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"


            sql = "select JAN_ORGCODE(a.ship_to_ORG_ID)ORG,a.SHIPMENT_NUM,JAN_ITEMNAME(b.ITEM_ID)ITEM_NO,JAN_ITEMDESC(JAN_ITEMNAME(b.ITEM_ID))ITEM_DESCription,b.QUANTITY_shipped,JAN_ITEMNAME(b.ITEM_ID)||'_'|| to_char(a.creation_date,'iyyyiwdhh24miss')LOT_NUMBER ,to_char(a.creation_date,'yyyy')yr,to_char(a.creation_date,'Mon')mth, (select count(*) from JAN_FIFO_LOTNO_DETAILS where to_char(ref_id)=a.SHIPMENT_NUM and organization_id=a.ship_to_ORG_ID and inventory_item_id=b.item_id and ref_source='Shipment' and print_Flag=1)print_flag from rcv_shipment_headers a ,rcv_shipment_lines B    where a.SHIPMENT_NUM  is not null and a.shipment_header_id=b.shipment_header_id  and a.CREATION_DATE>= TO_DATE('" & Format(dtsfm.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and a.CREATION_DATE<=TO_DATE('" & Format(dtsto.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            ''''''' sql &= " and b.TRANSACTION_ID=a.TRANSACTION_ID and a.ORGANIZATION_ID=b.ORGANIZATION_ID and a.INVENTORY_ITEM_ID=b.INVENTORY_ITEM_ID and  a.TRANSACTION_SOURCE_TYPE_ID=13 "

            If cmbsorg.Text <> "" Then sql &= " And a.ship_to_ORG_ID = jan_orgid('" & cmbsorg.Text & "')"


            If txtship.Text <> "" Then sql &= " and a.SHIPMENT_NUM ='" & txtship.Text & "'"

            If txtsitem.Text <> "" Then sql &= " and b.item_id=jan_itemno('" & txtsitem.Text & "')"

            If chkspend.Checked = True Then sql &= " and  (select count(*) from JAN_FIFO_LOTNO_DETAILS where to_char(ref_id)=a.SHIPMENT_NUM and organization_id=a.ship_to_org_id and inventory_item_id=b.item_id and ref_source='Shipment') =0 "

            sql &= " order by a.SHIPMENT_NUM"

            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "resultab")

            With dgvs
                .DataSource = ds1.Tables("resultab")
                .Columns(1).HeaderText = "Org" : .Columns(1).Width = 40
                .Columns(2).HeaderText = "Shipment No" : .Columns(2).Width = 120
                .Columns(3).HeaderText = "Item No" : .Columns(3).Width = 100
                .Columns(4).HeaderText = "Item Desc" : .Columns(4).Width = 250
                .Columns(5).HeaderText = "Qty" : .Columns(5).Width = 50
                '' .Columns(6).HeaderText = "Subinventory" : .Columns(6).Width = 100
                .Columns(6).HeaderText = "Lot No" : .Columns(6).Width = 150
                ''.Columns(7).HeaderText = "Transfer  From" : .Columns(7).Width = 80
                .Columns(7).Visible = False : .Columns(9).Visible = False : .Columns(8).Visible = False
            End With

            For i = 0 To dgvs.Rows.Count - 1
                With dgvs.Rows(i)
                    If .Cells(9).Value > 0 Then
                        .DefaultCellStyle.ForeColor = Color.MediumVioletRed
                    End If

                End With

            Next



            Dim cc1 As New DataGridViewTextBoxColumn
            cc1.HeaderText = "No Of Packet"
            cc1.Width = 70
            Me.dgvs.Columns.Add(cc1)
            Me.Cursor = Cursors.Arrow
        Else
            MessageBox.Show("Select Org")
            Exit Sub
        End If

    End Sub

    Private Sub btnslist_Click(sender As Object, e As EventArgs) Handles btnslist.Click
        s1 = ""
        For i = 0 To dgvs.Rows.Count - 1

            If dgvs.Rows(i).Cells(0).Value = True Then

                'If dgv.Rows(i).Cells(6).Value = "PO" Then

                For k = 0 To dgvs.Rows(i).Cells(10).Value - 1

                    's1 &= "CT~~CD,~CC^~CT~" & vbNewLine
                    's1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD15^JUS^LRN^CI0^XZ" & vbNewLine
                    's1 &= "^XA" & vbNewLine
                    's1 &= "^MMT" & vbNewLine
                    's1 &= "^PW791" & vbNewLine
                    's1 &= "^LL0160" & vbNewLine
                    's1 &= "^LS0" & vbNewLine
                    's1 &= "^FT565,131^BQN,2,4" & vbNewLine

                    's1 &= "^FH\^FDLA," & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine '''''lot

                    's1 &= "^FT283,129^BQN,2,4" & vbNewLine

                    's1 &= "^FH\^FDLA," & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine '''''lot

                    's1 &= "^FT681,109^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(7).Value & "^FS" & vbNewLine '''' yr

                    's1 &= "^FT565,146^A0N,25,24^FH\^FD" & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine ''''item

                    's1 &= "^FT690,61^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(8).Value & "^FS" & vbNewLine '''''month

                    's1 &= "^FT15,131^BQN,2,4" & vbNewLine

                    's1 &= "^FH\^FDLA," & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine '''''lot

                    's1 &= "^FT399,107^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(7).Value & "^FS" & vbNewLine '''' yr

                    's1 &= "^FT283,144^A0N,25,24^FH\^FD" & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine ''''item

                    's1 &= "^FT409,59^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(8).Value & "^FS" & vbNewLine '''''month

                    's1 &= "^FT140,62^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(8).Value & "^FS" & vbNewLine '''''month

                    's1 &= "^FT131,109^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(7).Value & "^FS" & vbNewLine '''' yr 

                    's1 &= "^FT15,146^A0N,25,24^FH\^FD" & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine ''''item

                    's1 &= "^PQ1,0,1,Y^XZ" & vbNewLine



                    's1 &= " CT~~CD,~CC^~CT~" & vbNewLine
                    's1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD20^JUS^LRN^CI0^XZ " & vbNewLine
                    's1 &= " ^ XA " & vbNewLine
                    's1 &= " ^ MMT " & vbNewLine
                    's1 &= " ^ PW807 " & vbNewLine
                    's1 &= " ^ LL0201  " & vbNewLine
                    's1 &= " ^ LS0 " & vbNewLine
                    's1 &= "^FT450,142^BQN,2,4 " & vbNewLine
                    's1 &= " ^ FH \^ FDLA," & dgvs.Rows(i).Cells(6).Value & "^FS " & vbNewLine
                    's1 &= "^FT54,142^BQN,2,4 " & vbNewLine
                    's1 &= " ^ FH \^ FDLA," & dgvs.Rows(i).Cells(6).Value & "^FS " & vbNewLine
                    's1 &= "^FT449,177^A0N,25,24^FH\^FD" & dgvs.Rows(i).Cells(6).Value & "^FS " & vbNewLine
                    's1 &= "^FT53,178^A0N,25,24^FH\^FD" & dgvs.Rows(i).Cells(6).Value & "^FS " & vbNewLine
                    's1 &= "^FT581,116^A0N,28,28^FH\^FD" & dgvs.Rows(i).Cells(7).Value & "^FS " & vbNewLine
                    's1 &= "^FT185,117^A0N,28,28^FH\^FD" & dgvs.Rows(i).Cells(7).Value & "^FS " & vbNewLine
                    's1 &= "^FT582,81^A0N,28,28^FH\^FD" & dgvs.Rows(i).Cells(8).Value & "^FS " & vbNewLine
                    's1 &= "^FT186,81^A0N,28,28^FH\^FD" & dgvs.Rows(i).Cells(8).Value & "^FS " & vbNewLine
                    's1 &= "^PQ1,0,1,Y^XZ " & vbNewLine


                    s1 &= " CT~~CD,~CC^~CT~" & vbNewLine
                    s1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD20^JUS^LRN^CI0^XZ" & vbNewLine
                    s1 &= "^XA" & vbNewLine
                    s1 &= "^MMT" & vbNewLine
                    s1 &= "^PW400" & vbNewLine
                    s1 &= "^LL0201" & vbNewLine
                    s1 &= "^LS0" & vbNewLine
                    s1 &= "^FT54,149^BQN,2,4" & vbNewLine
                    s1 &= "^FH\^FDLA," & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine
                    s1 &= "^FT53,178^A0N,25,24^FH\^FD" & dgvs.Rows(i).Cells(6).Value & "^FS" & vbNewLine
                    s1 &= "^FT185,128^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(8).Value & "^FS" & vbNewLine
                    s1 &= "^FT186,86^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(7).Value & "^FS" & vbNewLine
                    s1 &= "^PQ1,0,1,Y^XZ" & vbNewLine


                Next
                sql = "select count(*) from JAN_FIFO_LOTNO_DETAILS where ORGANIZATION_ID=JAN_ORGID('" & cmbsorg.SelectedItem & "') and item_no='" & dgvs.Rows(i).Cells(3).Value & "' and lot_no='" & dgvs.Rows(i).Cells(6).Value & "' and ref_id=" & dgvs.Rows(i).Cells(2).Value & ""

                cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
                cl.oradap.Fill(ds, "RESULT")

                If ds.Tables("RESULT").Rows(0).Item(0) = 0 Then

                    sql = "insert into JAN_FIFO_LOTNO_DETAILS (ORGANIZATION_ID ,INVENTORY_ITEM_ID ,ITEM_NO ,REF_ID ,REF_SOURCE ,LOT_NO ,LOT_QTY , NO_OF_box ,CREATION_DATE,prinT_flag ) values (JAN_ORGID('" & cmbsorg.SelectedItem & "') , jan_itemno('" & dgvs.Rows(i).Cells(3).Value & "'),'" & dgvs.Rows(i).Cells(3).Value & "'," & dgvs.Rows(i).Cells(2).Value & ",'Shipment','" & dgvs.Rows(i).Cells(6).Value & "'," & dgvs.Rows(i).Cells(5).Value & "," & dgvs.Rows(i).Cells(10).Value & ",sysdate,1 )"

                    func()
                End If

            End If

            ' sql = "update jan_gate_lines set lot_no='" & dgv.Rows(i).Cells(5).Value & "',sticker_print_flag=1,no_of_box ='" & dgv.Rows(i).Cells(12).Value & "' where gate_no=" & dgv.Rows(i).Cells(8).Value & "  and item='" & dgv.Rows(i).Cells(2).Value & "'"



            ' func()


        Next
        x1 = "d:\lotsticker.txt"

        fstrm = New FileStream(x1, FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s1)
        sw.Close()
        fstrm.Close()

        sql = "select SYS_CONTEXT('USERENV','IP_ADDRESS') IP from DUAL"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        Dim DSAP As New DataSet
        cl.oradap.Fill(DSAP, "RESULT")
        Dim IPAD As String = ""

        If DSAP.Tables("RESULT").Rows.Count > 0 Then
            IPAD = DSAP.Tables("RESULT").Rows(0).Item("IP")
        End If


        ''''NEW_STICKER(sender, e)

        fstrm = New FileStream("d:\lotprint.bat", FileMode.Create, FileAccess.ReadWrite)
        sw = New StreamWriter(fstrm)
        sw.WriteLine("COPY " & x1 & " \\localhost\\ZEBRA")
        sw.Close()
        fstrm.Close()
        Shell("d:\lotprint.bat", AppWinStyle.Hide)
    End Sub





#End Region

    '''''' Location Print

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        s1 = ""
        Try
            Dim diff As Integer = txtto.Text - txtfrm.Text
            Dim k As Integer
            Dim val As String

            For i = 0 To diff

                k = txtfrm.Text + i
                's1 &= " CT~~CD,~CC^~CT~" & vbNewLine
                's1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR5,5~SD20^JUS^LRN^CI0^XZ" & vbNewLine
                's1 &= "^XA" & vbNewLine
                's1 &= "^MMT" & vbNewLine
                's1 &= "^PW400" & vbNewLine
                's1 &= "^LL0201" & vbNewLine
                's1 &= "^LS0" & vbNewLine
                's1 &= "^FT54,149^BQN,2,4" & vbNewLine
                '' s1 &= "^FT53,178^A0N,39,38^FH\^FD" & TextBox1.Text & "^FS" & vbNewLine
                's1 &= "^FH\^FDLA," & txtlocation.Text & "^FS" & vbNewLine
                's1 &= "^FT53,178^A0N,25,24^FH\^FD" & DataGridView1.Rows(i).Cells(0).Value & "^FS" & vbNewLine
                ''s1 &= "^FT185,128^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(8).Value & "^FS" & vbNewLine
                ''s1 &= "^FT186,86^A0N,39,38^FH\^FD" & dgvs.Rows(i).Cells(7).Value & "^FS" & vbNewLine
                's1 &= "^PQ1,0,1,Y^XZ" & vbNewLine

                's1 &= " ^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR4,4~SD23^JUS^LRN^CI0^XZ" & vbNewLine
                's1 &= "^XA" & vbNewLine
                's1 &= "^MMT" & vbNewLine
                's1 &= "^PW591" & vbNewLine
                's1 &= "^LL0236" & vbNewLine
                's1 &= "^LS0" & vbNewLine
                's1 &= "^FT235,197^BQN,2,5" & vbNewLine
                's1 &= "^FH\^FDLA," & DataGridView1.Rows(i).Cells(0).Value & "^FS" & vbNewLine
                's1 &= "^FT170,194^A0N,25,24^FH\^FD" & DataGridView1.Rows(i).Cells(0).Value & "^FS"
                's1 &= "^PQ1,0,1,Y^XZ" & vbNewLine

                If k.ToString.Length = 1 Then val = String.Concat(0, k) Else val = k

                s1 &= " CT~~CD,~CC^~CT~" & vbNewLine
                s1 &= "^XA~TA000~JSN^LT0^MNW^MTT^PON^PMN^LH0,0^JMA^PR4,4~SD23^JUS^LRN^CI0^XZ" & vbNewLine
                s1 &= "^XA" & vbNewLine
                s1 &= "^MMT" & vbNewLine
                s1 &= "^PW591" & vbNewLine
                s1 &= "^LL0295" & vbNewLine
                s1 &= "^LS0" & vbNewLine
                s1 &= "^FT141,159^BQN,2,5" & vbNewLine
                s1 &= "^FH\^FDLA," & String.Concat(txtloc.Text, ".", val) & "^FS" & vbNewLine
                s1 &= "^FT142,180^A0N,25,24^FH\^FD" & String.Concat(txtloc.Text, ".", val) & "^FS" & vbNewLine
                s1 &= "^PQ1,0,1,Y^XZ" & vbNewLine


            Next
            ' DataGridView1.Rows.Clear()
            x1 = "d:\locsticker.txt"

            fstrm = New FileStream(x1, FileMode.Create, FileAccess.ReadWrite)
            sw = New StreamWriter(fstrm)
            sw.WriteLine(s1)
            sw.Close()
            fstrm.Close()

            sql = "select SYS_CONTEXT('USERENV','IP_ADDRESS') IP from DUAL"
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            Dim DSAP As New DataSet
            cl.oradap.Fill(DSAP, "RESULT")
            Dim IPAD As String = ""

            If DSAP.Tables("RESULT").Rows.Count > 0 Then
                IPAD = DSAP.Tables("RESULT").Rows(0).Item("IP")
            End If


            ''''NEW_STICKER(sender, e)
            '''




            fstrm = New FileStream("d:\locprint.bat", FileMode.Create, FileAccess.ReadWrite)
            sw = New StreamWriter(fstrm)
            sw.WriteLine("COPY " & x1 & " \\localhost\\ZEBRA")
            sw.Close()
            fstrm.Close()
            Shell("d:\locprint.bat", AppWinStyle.Hide)

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Label25_Click(sender As Object, e As EventArgs) Handles Label25.Click

    End Sub
End Class