<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class cancelentry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmborg = New System.Windows.Forms.ComboBox
        Me.cmbrea = New System.Windows.Forms.ComboBox
        Me.txtref = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.txtrole = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'cmborg
        '
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(303, 11)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(64, 21)
        Me.cmborg.TabIndex = 90
        '
        'cmbrea
        '
        Me.cmbrea.FormattingEnabled = True
        Me.cmbrea.Items.AddRange(New Object() {"Die DC", "PO Open Challan", "Rework Challan", "Item shortage", "Item Not Received", "Party's Sign not Available", "Double Entry", "Unit II Bill", "Unit I Bill", "Unit IV Bill", "RTV"})
        Me.cmbrea.Location = New System.Drawing.Point(67, 11)
        Me.cmbrea.Name = "cmbrea"
        Me.cmbrea.Size = New System.Drawing.Size(202, 21)
        Me.cmbrea.TabIndex = 89
        '
        'txtref
        '
        Me.txtref.Location = New System.Drawing.Point(67, 39)
        Me.txtref.Multiline = True
        Me.txtref.Name = "txtref"
        Me.txtref.Size = New System.Drawing.Size(300, 43)
        Me.txtref.TabIndex = 85
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(14, 54)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 13)
        Me.Label14.TabIndex = 88
        Me.Label14.Text = "Remarks"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(14, 15)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(44, 13)
        Me.Label13.TabIndex = 87
        Me.Label13.Text = "Reason"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(273, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(24, 13)
        Me.Label10.TabIndex = 91
        Me.Label10.Text = "Org"
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(142, 90)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(98, 29)
        Me.Button1.TabIndex = 92
        Me.Button1.Text = "Save"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(329, 127)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(35, 20)
        Me.txtrole.TabIndex = 93
        Me.txtrole.Visible = False
        '
        'cancelentry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(376, 148)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cmborg)
        Me.Controls.Add(Me.cmbrea)
        Me.Controls.Add(Me.txtref)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Name = "cancelentry"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cancel Entry-Gate Register"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents cmbrea As System.Windows.Forms.ComboBox
    Friend WithEvents txtref As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtrole As System.Windows.Forms.TextBox
End Class
