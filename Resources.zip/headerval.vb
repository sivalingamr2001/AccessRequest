Imports System.Data.OracleClient
Imports oracleclass
Public Class headerval
    Dim cl As New oracleclass.Class1
    Private Sub headerval_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(7).Value = "PO" Then
            Label1.Text = "Original for Buyer copy"
            Label2.Text = "Duplicate for transport copy"
        ElseIf Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(7).Value = "OSP" Then
            Label1.Text = "Supplier�s Delivery Challan"
            Label2.Text = "Materials In-Out Challan"
        End If
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        sql = "update jan_gate_header set check1='" & rea1.SelectedItem & "' and check2='" & rea2.SelectedItem & "' where gate_no='" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(0).Value & "'"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        CON.Close()
        MessageBox.Show("Validate Values Saved", "Gate Register")
    End Sub
End Class