<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CycleCount
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.txtitem = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.adjto = New System.Windows.Forms.DateTimePicker
        Me.appto = New System.Windows.Forms.DateTimePicker
        Me.adjfm = New System.Windows.Forms.DateTimePicker
        Me.appfm = New System.Windows.Forms.DateTimePicker
        Me.cmbitem = New System.Windows.Forms.ComboBox
        Me.cmbinv = New System.Windows.Forms.ComboBox
        Me.cmbmb = New System.Windows.Forms.ComboBox
        Me.cmborg = New System.Windows.Forms.ComboBox
        Me.dgcycle = New System.Windows.Forms.DataGridView
        Me.btnpri = New System.Windows.Forms.Button
        Me.btngo = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lbex = New System.Windows.Forms.Label
        Me.lbst = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        CType(Me.dgcycle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(3, 515)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(100, 17)
        Me.ProgressBar1.TabIndex = 24
        Me.ProgressBar1.Visible = False
        '
        'txtitem
        '
        Me.txtitem.Location = New System.Drawing.Point(635, 5)
        Me.txtitem.Name = "txtitem"
        Me.txtitem.Size = New System.Drawing.Size(100, 20)
        Me.txtitem.TabIndex = 23
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(437, 9)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 13)
        Me.Label19.TabIndex = 19
        Me.Label19.Text = "Subinventory"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(298, 9)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(57, 13)
        Me.Label20.TabIndex = 18
        Me.Label20.Text = "Make/Buy"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(142, 9)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 13)
        Me.Label18.TabIndex = 20
        Me.Label18.Text = "Item Type"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(606, 9)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(27, 13)
        Me.Label17.TabIndex = 22
        Me.Label17.Text = "Item"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(0, 9)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(24, 13)
        Me.Label16.TabIndex = 21
        Me.Label16.Text = "Org"
        '
        'adjto
        '
        Me.adjto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.adjto.Location = New System.Drawing.Point(197, 29)
        Me.adjto.Name = "adjto"
        Me.adjto.Size = New System.Drawing.Size(95, 20)
        Me.adjto.TabIndex = 16
        '
        'appto
        '
        Me.appto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.appto.Location = New System.Drawing.Point(506, 29)
        Me.appto.Name = "appto"
        Me.appto.Size = New System.Drawing.Size(100, 20)
        Me.appto.TabIndex = 17
        '
        'adjfm
        '
        Me.adjfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.adjfm.Location = New System.Drawing.Point(40, 29)
        Me.adjfm.Name = "adjfm"
        Me.adjfm.Size = New System.Drawing.Size(96, 20)
        Me.adjfm.TabIndex = 14
        '
        'appfm
        '
        Me.appfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.appfm.Location = New System.Drawing.Point(350, 29)
        Me.appfm.Name = "appfm"
        Me.appfm.Size = New System.Drawing.Size(91, 20)
        Me.appfm.TabIndex = 15
        '
        'cmbitem
        '
        Me.cmbitem.FormattingEnabled = True
        Me.cmbitem.Items.AddRange(New Object() {"COMP", "FG", "RM"})
        Me.cmbitem.Location = New System.Drawing.Point(197, 5)
        Me.cmbitem.Name = "cmbitem"
        Me.cmbitem.Size = New System.Drawing.Size(100, 21)
        Me.cmbitem.TabIndex = 11
        '
        'cmbinv
        '
        Me.cmbinv.FormattingEnabled = True
        Me.cmbinv.Location = New System.Drawing.Point(506, 5)
        Me.cmbinv.Name = "cmbinv"
        Me.cmbinv.Size = New System.Drawing.Size(100, 21)
        Me.cmbinv.TabIndex = 10
        '
        'cmbmb
        '
        Me.cmbmb.FormattingEnabled = True
        Me.cmbmb.Items.AddRange(New Object() {"MAKE", "BUY"})
        Me.cmbmb.Location = New System.Drawing.Point(355, 5)
        Me.cmbmb.Name = "cmbmb"
        Me.cmbmb.Size = New System.Drawing.Size(81, 21)
        Me.cmbmb.TabIndex = 13
        '
        'cmborg
        '
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(40, 4)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(96, 21)
        Me.cmborg.TabIndex = 12
        '
        'dgcycle
        '
        Me.dgcycle.AllowUserToAddRows = False
        Me.dgcycle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgcycle.Location = New System.Drawing.Point(7, 54)
        Me.dgcycle.Name = "dgcycle"
        Me.dgcycle.ReadOnly = True
        Me.dgcycle.Size = New System.Drawing.Size(894, 348)
        Me.dgcycle.TabIndex = 9
        '
        'btnpri
        '
        Me.btnpri.Location = New System.Drawing.Point(791, 5)
        Me.btnpri.Name = "btnpri"
        Me.btnpri.Size = New System.Drawing.Size(45, 23)
        Me.btnpri.TabIndex = 7
        Me.btnpri.Text = "Print"
        Me.btnpri.UseVisualStyleBackColor = True
        '
        'btngo
        '
        Me.btngo.Location = New System.Drawing.Point(740, 5)
        Me.btngo.Name = "btngo"
        Me.btngo.Size = New System.Drawing.Size(45, 23)
        Me.btngo.TabIndex = 8
        Me.btngo.Text = "Go"
        Me.btngo.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Adj Fm"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(142, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Adj To"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(298, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "App fm"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(447, 33)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "App To"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(7, 408)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(244, 101)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(72, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 13)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "Org"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(72, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 13)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Org"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(71, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Excess Value"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Short Value"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox2.Controls.Add(Me.lbex)
        Me.GroupBox2.Controls.Add(Me.lbst)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Location = New System.Drawing.Point(7, 408)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(244, 101)
        Me.GroupBox2.TabIndex = 25
        Me.GroupBox2.TabStop = False
        '
        'lbex
        '
        Me.lbex.AutoSize = True
        Me.lbex.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbex.ForeColor = System.Drawing.Color.Crimson
        Me.lbex.Location = New System.Drawing.Point(101, 64)
        Me.lbex.Name = "lbex"
        Me.lbex.Size = New System.Drawing.Size(15, 13)
        Me.lbex.TabIndex = 21
        Me.lbex.Text = "0"
        '
        'lbst
        '
        Me.lbst.AutoSize = True
        Me.lbst.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbst.ForeColor = System.Drawing.Color.Crimson
        Me.lbst.Location = New System.Drawing.Point(102, 16)
        Me.lbst.Name = "lbst"
        Me.lbst.Size = New System.Drawing.Size(15, 13)
        Me.lbst.TabIndex = 21
        Me.lbst.Text = "0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(8, 64)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(82, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Excess Value"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(8, 16)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(74, 13)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Short Value"
        '
        'CycleCount
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(913, 534)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.txtitem)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.adjto)
        Me.Controls.Add(Me.appto)
        Me.Controls.Add(Me.adjfm)
        Me.Controls.Add(Me.appfm)
        Me.Controls.Add(Me.cmbitem)
        Me.Controls.Add(Me.cmbinv)
        Me.Controls.Add(Me.cmbmb)
        Me.Controls.Add(Me.cmborg)
        Me.Controls.Add(Me.dgcycle)
        Me.Controls.Add(Me.btnpri)
        Me.Controls.Add(Me.btngo)
        Me.Name = "CycleCount"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "CycleCount-MIS"
        CType(Me.dgcycle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents txtitem As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents adjto As System.Windows.Forms.DateTimePicker
    Friend WithEvents appto As System.Windows.Forms.DateTimePicker
    Friend WithEvents adjfm As System.Windows.Forms.DateTimePicker
    Friend WithEvents appfm As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbitem As System.Windows.Forms.ComboBox
    Friend WithEvents cmbinv As System.Windows.Forms.ComboBox
    Friend WithEvents cmbmb As System.Windows.Forms.ComboBox
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents dgcycle As System.Windows.Forms.DataGridView
    Friend WithEvents btnpri As System.Windows.Forms.Button
    Friend WithEvents btngo As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lbex As System.Windows.Forms.Label
    Friend WithEvents lbst As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
End Class
