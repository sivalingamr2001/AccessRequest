Imports PO_Preparation.WinControl
Imports System.Data.OracleClient

Public Class prblc
    Dim C1 As New WinControl
    Dim T_INV, slashpos As Integer
    Dim ORG, username, GT, GT1, orgcode As String

    Private Sub PO_BLOCK_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        slashpos = My.User.Name.LastIndexOf("\")
        username = My.User.Name.Substring(slashpos + 1)

        sql = "SELECT * FROM JAN_PO_BLOCK_IP WHERE IP_ADDR=(select SYS_CONTEXT('USERENV', 'IP_ADDRESS') ipaddr from dual) AND UPPER(UNAME) ='" & username.ToUpper & "'  AND FLAG='Y'"
        ' MessageBox.Show(sql)
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        ADAP.Fill(ds, "result")
        If ds.Tables("RESULT").Rows.Count > 0 Then
            'MessageBox.Show(ds.Tables("RESULT").Rows.Count)
            Label3.Text = ds.Tables("RESULT").Rows(0).Item("COUNT_DOWN")
            T_INV = ds.Tables("RESULT").Rows(0).Item("T_INTERVAL")
            ORG = ds.Tables("RESULT").Rows(0).Item("ORG")
            orgcode = ds.Tables("RESULT").Rows(0).Item("ORG_code")
            ' sql = "select JAN_FP_COMMON_FUNCTION('POXPOEPO'," & ORG & ",'-','-','GATE_NO','')ITEM_COUNT from DUAL "

            sql = "select COUNT(*) ITEM_COUNT FROM JAN_FP_bLOCK_LINES WHERE ORGANIZATION_ID IN (" & ORG & " )AND BLOCK_FORM_NAME='POXPOEPO'  AND BLOCK_END_DATE IS NULL  AND TRUNC(BLOCK_START_DATE)=TRUNC(SYSDATE) "

            '  sql = "SELECT NVL(SUM(ITEM_COUNT),0)ITEM_COUNT FROM JAN_PO_RELEASE_PENDING WHERE ORGANIZATION_ID IN (" & ORG & ")"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds1 = New DataSet
            adap.Fill(ds1, "result")
            If ds1.Tables("RESULT").Rows(0).Item("ITEM_COUNT") > 0 Then

                'sql = "select JAN_FP_COMMON_FUNCTION_MSG('POXPOEPO'," & ORG & ",'-','-','GATE_NO','')MSG from DUAL "
                'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                'ds = New DataSet
                'adap.Fill(ds, "MSG")

                Label1.Text = "Validation Pending"

                sql = "select DISTINCT GATe_NO ,(SELECT GDATE FROM JAN_GATE_HEADER WHERE GATE_NO=A.GATE_NO) GDATE,jan_orgcode(ORGanization_ID) org,(SELECT SUPPLIER_NAME FROM JAN_GATE_HEADER WHERE GATE_NO=A.GATE_NO) SUPPLIER from JAN_FP_BLOCK_LINES_V a WHERE ORGANIZATION_ID in (" & ORG & ") AND BLOCK_FORM_NAME='POXPOEPO' AND BLOCK_END_DATE IS NULL AND TRUNC(BLOCK_START_DATE)=TRUNC(SYSDATE)"
                cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                DSGATE = New DataSet
                adap.Fill(DSGATE, "GT")
                With dgvlist
                    .DataSource = DSGATE.Tables("gt")
                    .Columns(0).HeaderText = "Gate No" : .Columns(0).Width = 200
                    .Columns(1).HeaderText = "Gate Dt" : .Columns(1).Width = 200
                    .Columns(2).HeaderText = "Org" : .Columns(2).Width = 70
                    .Columns(3).HeaderText = "Supplier" : .Columns(3).Width = 400

                End With


                '  Label1.Text = "Purchase Orders(M2O) yet to be released for " & ds1.Tables("result").Rows(0).Item("ITEM_COUNT") & " Items. " & vbNewLine & " Org:" & ds.Tables("RESULT").Rows(0).Item("org_code")
                Timer1.Start()
                ' tJolt.Start()
            Else
                End
            End If
        Else
            End
        End If
    End Sub

    'Private Sub tJolt_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tJolt.Tick
    '    If tJolt.Tag = True Then
    '        tJolt.Tag = False
    '    Else
    '    End If

    '    If tJolt.Tag = False Then
    '        WinControl.Wait2Send("Calculator", "22*22{ENTER}", 30)
    '        tJolt.Stop()
    '    End If
    '    'Me.Focus() ' when form object loses focus (another form, control, or program - form always has focus)
    '    'Me.BringToFront()
    '    'Me.Show()
    '    'Me.WindowState = FormWindowState.Maximized
    '    'top in zorder, other apps move to the back
    '    'For Each selProcess As Process In Process.GetProcesses
    '    '    If selProcess.ProcessName.Contains("PO_Preparation") Then
    '    '        selProcess.Kill()
    '    '        Exit For
    '    '    End If
    '    'Next
    'End Sub

    Private Sub PO_BLOCK_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If Not e.KeyCode = Keys.A Then
            e.Handled = True
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Val(Label3.Text) > 0 Then Label3.Text = Val(Label3.Text) - 1
        If Val(Label3.Text) = 1 Then
            Label5.Text = "Second"
        Else
            Label5.Text = "Seconds"
        End If

        If Val(Label3.Text) = 0 Then
            Me.Hide()
            Timer1.Stop()
            ' tJolt.Start()
            Label6.Text = 0
            End
        End If

    End Sub

    Private Sub tJolt_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tJolt.Tick
        Label6.Text = Val(Label6.Text) + 1
        If Val(Label6.Text) Mod T_INV = 0 Then
            sql = "SELECT * FROM JAN_PO_BLOCK_IP WHERE IP_ADDR=(select SYS_CONTEXT('USERENV', 'IP_ADDRESS') ipaddr from dual) AND UPPER(UNAME) ='" & username.ToUpper & "'  AND FLAG='Y'"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            ADAP.Fill(ds, "result")
            If ds.Tables("RESULT").Rows.Count > 0 Then
                Label3.Text = ds.Tables("RESULT").Rows(0).Item("COUNT_DOWN")
                T_INV = ds.Tables("RESULT").Rows(0).Item("T_INTERVAL")
                ORG = ds.Tables("RESULT").Rows(0).Item("ORG")

                ' sql = "select JAN_FP_COMMON_FUNCTION('POXPOEPO'," & ORG & ",'-','-','GATE_NO','')ITEM_COUNT from DUAL"

                sql = "select COUNT(*) ITEM_COUNT FROM JAN_FP_bLOCK_LINES WHERE ORGANIZATION_ID IN (" & ORG & " )AND BLOCK_FORM_NAME='POXPOEPO'  AND BLOCK_END_DATE IS NULL AND TRUNC(BLOCK_START_DATE)=TRUNC(SYSDATE)  "

                'sql = "SELECT NVL(SUM(ITEM_COUNT),0)ITEM_COUNT FROM JAN_PO_RELEASE_PENDING WHERE ORGANIZATION_ID IN (" & ORG & ")"
                cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                ds1 = New DataSet
                adap.Fill(ds1, "result")
                If ds1.Tables("RESULT").Rows(0).Item("ITEM_COUNT") > 0 Then
                    'sql = "select JAN_FP_COMMON_FUNCTION_MSG('POXPOEPO'," & ORG & ",'-','-','GATE_NO','')MSG from DUAL "
                    'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                    'ds = New DataSet
                    'adap.Fill(ds, "MSG")

                    Label1.Text = "Validation Pending"

                    sql = "select DISTINCT GATe_NO ,(SELECT GDATE FROM JAN_GATE_HEADER WHERE GATE_NO=A.GATE_NO) GDATE, jan_orgcode(ORGanization_ID)org,(SELECT SUPPLIER_NAME FROM JAN_GATE_HEADER WHERE GATE_NO=A.GATE_NO) SUPPLIER from JAN_FP_BLOCK_LINES_V a WHERE ORGANIZATION_ID in (" & ORG & ") AND BLOCK_FORM_NAME='POXPOEPO' AND BLOCK_END_DATE IS NULL AND TRUNC(BLOCK_START_DATE)=TRUNC(SYSDATE)"
                    cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                    DSGATE = New DataSet
                    adap.Fill(DSGATE, "GT")
                    With dgvlist
                        .DataSource = DSGATE.Tables("gt")
                        .Columns(0).HeaderText = "Gate No" : .Columns(0).Width = 200
                        .Columns(1).HeaderText = "Gate Dt" : .Columns(1).Width = 200
                        .Columns(2).HeaderText = "Org" : .Columns(2).Width = 70
                        .Columns(3).HeaderText = "Supplier" : .Columns(3).Width = 400

                    End With
                    Me.Show()
                    Timer1.Start()
                    Label6.Text = 0
                    '  tJolt.Stop()
                Else
                    End
                End If
            Else
                End
            End If
        End If
    End Sub
End Class