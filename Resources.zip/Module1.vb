Imports System.IO
Imports System.Data.OracleClient
Imports oracleclass
Module Module1
    ' Public CON As New Odbc.OdbcConnection("driver=Microsoft ODBC for Oracle;uid=jan_it;pwd=janapps;server=PROD")
    Public CON As New OracleConnection("Data Source=prod;User Id=jan_it;Password=janapps;Integrated Security=no;")
    Public CON1 As New OracleConnection("Data Source=prod;User Id=jan_it;Password=janapps;Integrated Security=no;")
    Public sql, a, b, c, per, s, x, l, sql1, x1, unit, role, tr_mode As String
    Public adap As New OracleDataAdapter
    Public ds, ds1, ds2, dsrep, DSGATE As New DataSet
    Public i, j, k, l1, OP_ID, SEQNO, adi_allow, modify_Flag As Integer
    Public fstrm As FileStream
    Public sw As StreamWriter
    Public INS, opid As String
    Public DV As DataView
    Public FLG As Boolean
    Public source1 As New BindingSource()
    Public scmadap As New SqlClient.SqlDataAdapter
    Public drr As OracleDataReader
    Public category, org, userid, swid, control, VALBY, gtpur, unames, pack_met As String
    Public orgid, ORG_ID As String
    Public scmcmd As New SqlClient.SqlCommand
    Public cl As New oracleclass.Class1
    Public scmcon2 As New SqlClient.SqlConnection("Data Source=13.235.195.146;Initial Catalog=scm;User ID=scm;Password=scm#$sql2007")

    Public scmcon As New SqlClient.SqlConnection("Data Source=13.235.195.146;Initial Catalog=scm;User ID=scm;Password=scm#$sql2007")
    Public Function SCMRETVAL(ByVal qry As String)
        Dim tds As New DataSet
        Try

            scmcmd = New SqlClient.SqlCommand(qry, scmcon)
            If CON.State = ConnectionState.Closed Then
                CON.Open()
            End If
            scmadap = New SqlClient.SqlDataAdapter(scmcmd)
            scmadap.Fill(tds, "ret")
            If CON.State = ConnectionState.Open Then
                CON.Close()
            End If

        Catch ex As Exception

        End Try
        If tds.Tables("ret").Rows.Count > 0 Then
            If Not IsDBNull(tds.Tables("ret").Rows(0).Item(0).ToString) Then
                sql = tds.Tables("ret").Rows(0).Item(0).ToString
            Else
                sql = "0"
            End If
        Else
            sql = "0"
        End If

        Return sql

    End Function


    Public Function RETVAL(ByVal qry As String)
        Dim tds As New DataSet
        Try

            cl.orcmd = New OracleCommand(qry, cl.oracon)
            If cl.oracon.State = ConnectionState.Closed Then
                cl.oracon.Open()
            End If
            cl.oradap = New OracleDataAdapter(cl.orcmd)
            cl.oradap.Fill(tds, "ret")
            If cl.oracon.State = ConnectionState.Open Then
                cl.oracon.Close()
            End If

        Catch ex As Exception

        End Try
        If tds.Tables("ret").Rows.Count > 0 Then
            If Not IsDBNull(tds.Tables("ret").Rows(0).Item(0).ToString) Then
                sql = tds.Tables("ret").Rows(0).Item(0).ToString
            Else
                sql = "0"
            End If
        Else
            sql = "0"
        End If

        Return sql

    End Function

End Module
