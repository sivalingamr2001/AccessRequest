<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Gate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Gate))
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.btnsta = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.btnrecpt = New System.Windows.Forms.Button()
        Me.btnnonpo = New System.Windows.Forms.Button()
        Me.btncan = New System.Windows.Forms.Button()
        Me.ADIbt = New System.Windows.Forms.Button()
        Me.lbupdt = New System.Windows.Forms.LinkLabel()
        Me.glist = New System.Windows.Forms.Button()
        Me.btnmod = New System.Windows.Forms.Button()
        Me.btnval = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.txtrole = New System.Windows.Forms.TextBox()
        Me.txtlog = New System.Windows.Forms.TextBox()
        Me.linkpwd = New System.Windows.Forms.LinkLabel()
        Me.inwdtto = New System.Windows.Forms.DateTimePicker()
        Me.txtinw = New System.Windows.Forms.TextBox()
        Me.inwdtf = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btngo = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.cmbsup = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.cmbval = New System.Windows.Forms.ComboBox()
        Me.cmborg = New System.Windows.Forms.ComboBox()
        Me.gtype = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.TXTREF = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnxs = New System.Windows.Forms.Button()
        Me.lbvehicle = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.UNBLOCK = New System.Windows.Forms.Button()
        Me.btnreport = New System.Windows.Forms.Button()
        Me.mmcard = New System.Windows.Forms.Button()
        Me.bprint = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblcnt = New System.Windows.Forms.Label()
        Me.btnview = New System.Windows.Forms.Button()
        Me.btndel = New System.Windows.Forms.Button()
        Me.btnitem = New System.Windows.Forms.Button()
        Me.dgvcr = New System.Windows.Forms.DataGridView()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.btnwop = New System.Windows.Forms.Button()
        Me.btngacc = New System.Windows.Forms.Button()
        Me.dgvr = New System.Windows.Forms.DataGridView()
        Me.btntag = New System.Windows.Forms.Button()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.job_shrt = New System.Windows.Forms.Button()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dgvcr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvr, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv1.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgv1.Location = New System.Drawing.Point(7, 3)
        Me.dgv1.Name = "dgv1"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv1.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgv1.RowHeadersWidth = 30
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.dgv1.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgv1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgv1.Size = New System.Drawing.Size(1342, 186)
        Me.dgv1.TabIndex = 13
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CheckBox1)
        Me.GroupBox1.Controls.Add(Me.dgv1)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 367)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1349, 192)
        Me.GroupBox1.TabIndex = 67
        Me.GroupBox1.TabStop = False
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(45, 8)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(15, 14)
        Me.CheckBox1.TabIndex = 87
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'btnsta
        '
        Me.btnsta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsta.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsta.Location = New System.Drawing.Point(697, 339)
        Me.btnsta.Name = "btnsta"
        Me.btnsta.Size = New System.Drawing.Size(59, 23)
        Me.btnsta.TabIndex = 17
        Me.btnsta.Text = "&Status Report"
        Me.btnsta.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label48)
        Me.GroupBox2.Controls.Add(Me.Label41)
        Me.GroupBox2.Controls.Add(Me.Label38)
        Me.GroupBox2.Controls.Add(Me.Label29)
        Me.GroupBox2.Controls.Add(Me.Label47)
        Me.GroupBox2.Controls.Add(Me.Label40)
        Me.GroupBox2.Controls.Add(Me.Label39)
        Me.GroupBox2.Controls.Add(Me.Label37)
        Me.GroupBox2.Controls.Add(Me.dgv)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label30)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.Label24)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label33)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label34)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label32)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Location = New System.Drawing.Point(2, 56)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1351, 277)
        Me.GroupBox2.TabIndex = 68
        Me.GroupBox2.TabStop = False
        '
        'Label48
        '
        Me.Label48.BackColor = System.Drawing.Color.LawnGreen
        Me.Label48.ForeColor = System.Drawing.Color.LawnGreen
        Me.Label48.Location = New System.Drawing.Point(1162, 255)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(19, 11)
        Me.Label48.TabIndex = 103
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.HotPink
        Me.Label41.ForeColor = System.Drawing.Color.HotPink
        Me.Label41.Location = New System.Drawing.Point(1042, 255)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(19, 11)
        Me.Label41.TabIndex = 103
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.MediumVioletRed
        Me.Label38.ForeColor = System.Drawing.Color.MediumVioletRed
        Me.Label38.Location = New System.Drawing.Point(938, 255)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(19, 11)
        Me.Label38.TabIndex = 103
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.DarkGreen
        Me.Label29.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label29.Location = New System.Drawing.Point(829, 254)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(21, 13)
        Me.Label29.TabIndex = 64
        Me.Label29.Text = "Ro"
        '
        'Label47
        '
        Me.Label47.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(1181, 253)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(109, 15)
        Me.Label47.TabIndex = 104
        Me.Label47.Text = "Rec Open Challan"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(1064, 255)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(58, 13)
        Me.Label40.TabIndex = 104
        Me.Label40.Text = "Location "
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(959, 255)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(90, 13)
        Me.Label39.TabIndex = 104
        Me.Label39.Text = "Shortage Item"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(848, 254)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(93, 13)
        Me.Label37.TabIndex = 65
        Me.Label37.Text = "Green Channel"
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgv.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgv.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgv.Location = New System.Drawing.Point(6, 11)
        Me.dgv.Name = "dgv"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgv.RowHeadersVisible = False
        Me.dgv.RowHeadersWidth = 20
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black
        Me.dgv.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.dgv.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgv.Size = New System.Drawing.Size(1345, 240)
        Me.dgv.TabIndex = 10
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(315, 254)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(82, 13)
        Me.Label20.TabIndex = 63
        Me.Label20.Text = "No E-way Bill"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(231, 254)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(59, 13)
        Me.Label12.TabIndex = 63
        Me.Label12.Text = "Validated"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.RoyalBlue
        Me.Label19.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Label19.Location = New System.Drawing.Point(292, 254)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(21, 13)
        Me.Label19.TabIndex = 63
        Me.Label19.Text = "Ro"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Khaki
        Me.Label30.ForeColor = System.Drawing.Color.Khaki
        Me.Label30.Location = New System.Drawing.Point(551, 254)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(21, 13)
        Me.Label30.TabIndex = 63
        Me.Label30.Text = "Ro"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Tomato
        Me.Label28.ForeColor = System.Drawing.Color.Tomato
        Me.Label28.Location = New System.Drawing.Point(451, 254)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(21, 13)
        Me.Label28.TabIndex = 63
        Me.Label28.Text = "Ro"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Thistle
        Me.Label24.ForeColor = System.Drawing.Color.Thistle
        Me.Label24.Location = New System.Drawing.Point(397, 254)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(21, 13)
        Me.Label24.TabIndex = 63
        Me.Label24.Text = "Ro"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.DarkRed
        Me.Label5.ForeColor = System.Drawing.Color.DarkRed
        Me.Label5.Location = New System.Drawing.Point(777, 254)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(21, 13)
        Me.Label5.TabIndex = 63
        Me.Label5.Text = "Ro"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Aquamarine
        Me.Label35.ForeColor = System.Drawing.Color.Aquamarine
        Me.Label35.Location = New System.Drawing.Point(711, 254)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(21, 13)
        Me.Label35.TabIndex = 63
        Me.Label35.Text = "Ro"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.LightGray
        Me.Label18.ForeColor = System.Drawing.Color.LightGray
        Me.Label18.Location = New System.Drawing.Point(621, 254)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(21, 13)
        Me.Label18.TabIndex = 63
        Me.Label18.Text = "Ro"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label17.ForeColor = System.Drawing.Color.DarkKhaki
        Me.Label17.Location = New System.Drawing.Point(208, 254)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(21, 13)
        Me.Label17.TabIndex = 63
        Me.Label17.Text = "Ro"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Purple
        Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label33.ForeColor = System.Drawing.Color.Purple
        Me.Label33.Location = New System.Drawing.Point(4, 254)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(23, 15)
        Me.Label33.TabIndex = 63
        Me.Label33.Text = "Ro"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.White
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(47, 253)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(23, 15)
        Me.Label16.TabIndex = 63
        Me.Label16.Text = "Ro"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Peru
        Me.Label15.ForeColor = System.Drawing.Color.Peru
        Me.Label15.Location = New System.Drawing.Point(103, 254)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(21, 13)
        Me.Label15.TabIndex = 63
        Me.Label15.Text = "Ro"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(575, 254)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "No Ref"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(474, 254)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(80, 13)
        Me.Label27.TabIndex = 63
        Me.Label27.Text = "Cancel Entry"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(421, 254)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(30, 13)
        Me.Label23.TabIndex = 63
        Me.Label23.Text = "RTV"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(800, 254)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 63
        Me.Label3.Text = "DDS"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(733, 254)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(47, 13)
        Me.Label11.TabIndex = 63
        Me.Label11.Text = "Non Po"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(643, 254)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(70, 13)
        Me.Label34.TabIndex = 63
        Me.Label34.Text = "Row Select"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(126, 254)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(82, 13)
        Me.Label10.TabIndex = 63
        Me.Label10.Text = "Not Validated"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(27, 255)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(21, 13)
        Me.Label32.TabIndex = 63
        Me.Label32.Text = "All"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(67, 254)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 13)
        Me.Label9.TabIndex = 63
        Me.Label9.Text = "Gate"
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.Color.Teal
        Me.Label46.ForeColor = System.Drawing.Color.Teal
        Me.Label46.Location = New System.Drawing.Point(1245, 340)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(19, 11)
        Me.Label46.TabIndex = 103
        Me.Label46.Visible = False
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(1267, 339)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(50, 13)
        Me.Label36.TabIndex = 104
        Me.Label36.Text = "Kanban"
        Me.Label36.Visible = False
        '
        'btnrecpt
        '
        Me.btnrecpt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrecpt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrecpt.Location = New System.Drawing.Point(504, 619)
        Me.btnrecpt.Name = "btnrecpt"
        Me.btnrecpt.Size = New System.Drawing.Size(143, 23)
        Me.btnrecpt.TabIndex = 86
        Me.btnrecpt.Text = "Receipt Prepared List"
        Me.btnrecpt.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnrecpt.UseVisualStyleBackColor = True
        Me.btnrecpt.Visible = False
        '
        'btnnonpo
        '
        Me.btnnonpo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnnonpo.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnonpo.Location = New System.Drawing.Point(135, 339)
        Me.btnnonpo.Name = "btnnonpo"
        Me.btnnonpo.Size = New System.Drawing.Size(113, 23)
        Me.btnnonpo.TabIndex = 82
        Me.btnnonpo.Text = "Non Po Inward"
        Me.btnnonpo.UseVisualStyleBackColor = True
        Me.btnnonpo.Visible = False
        '
        'btncan
        '
        Me.btncan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncan.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncan.Location = New System.Drawing.Point(609, 339)
        Me.btncan.Name = "btncan"
        Me.btncan.Size = New System.Drawing.Size(87, 23)
        Me.btncan.TabIndex = 86
        Me.btncan.Text = "Cancel Gate"
        Me.btncan.UseVisualStyleBackColor = True
        '
        'ADIbt
        '
        Me.ADIbt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ADIbt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ADIbt.Location = New System.Drawing.Point(250, 339)
        Me.ADIbt.Name = "ADIbt"
        Me.ADIbt.Size = New System.Drawing.Size(95, 23)
        Me.ADIbt.TabIndex = 84
        Me.ADIbt.Text = "Add New ADI"
        Me.ADIbt.UseVisualStyleBackColor = True
        Me.ADIbt.Visible = False
        '
        'lbupdt
        '
        Me.lbupdt.AutoSize = True
        Me.lbupdt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbupdt.LinkColor = System.Drawing.Color.Maroon
        Me.lbupdt.Location = New System.Drawing.Point(6, 336)
        Me.lbupdt.Name = "lbupdt"
        Me.lbupdt.Size = New System.Drawing.Size(89, 13)
        Me.lbupdt.TabIndex = 78
        Me.lbupdt.TabStop = True
        Me.lbupdt.Text = "Update Po Qty"
        Me.lbupdt.Visible = False
        '
        'glist
        '
        Me.glist.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.glist.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.glist.Location = New System.Drawing.Point(757, 339)
        Me.glist.Name = "glist"
        Me.glist.Size = New System.Drawing.Size(147, 23)
        Me.glist.TabIndex = 75
        Me.glist.Text = "&Inwarded Item Status"
        Me.glist.UseVisualStyleBackColor = True
        '
        'btnmod
        '
        Me.btnmod.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnmod.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmod.Location = New System.Drawing.Point(509, 339)
        Me.btnmod.Name = "btnmod"
        Me.btnmod.Size = New System.Drawing.Size(98, 23)
        Me.btnmod.TabIndex = 73
        Me.btnmod.Text = "&Modify / View"
        Me.btnmod.UseVisualStyleBackColor = True
        '
        'btnval
        '
        Me.btnval.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnval.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnval.Location = New System.Drawing.Point(429, 339)
        Me.btnval.Name = "btnval"
        Me.btnval.Size = New System.Drawing.Size(79, 23)
        Me.btnval.TabIndex = 12
        Me.btnval.Text = "&Validate"
        Me.btnval.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnadd.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(349, 339)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(79, 23)
        Me.btnadd.TabIndex = 11
        Me.btnadd.Text = "Add &New"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(1211, 349)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(33, 20)
        Me.txtrole.TabIndex = 76
        Me.txtrole.Visible = False
        '
        'txtlog
        '
        Me.txtlog.Location = New System.Drawing.Point(1152, 349)
        Me.txtlog.Name = "txtlog"
        Me.txtlog.Size = New System.Drawing.Size(53, 20)
        Me.txtlog.TabIndex = 69
        Me.txtlog.Visible = False
        '
        'linkpwd
        '
        Me.linkpwd.AutoSize = True
        Me.linkpwd.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.linkpwd.LinkColor = System.Drawing.Color.Maroon
        Me.linkpwd.Location = New System.Drawing.Point(4, 352)
        Me.linkpwd.Name = "linkpwd"
        Me.linkpwd.Size = New System.Drawing.Size(109, 13)
        Me.linkpwd.TabIndex = 71
        Me.linkpwd.TabStop = True
        Me.linkpwd.Text = "Change Password"
        Me.linkpwd.Visible = False
        '
        'inwdtto
        '
        Me.inwdtto.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inwdtto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.inwdtto.Location = New System.Drawing.Point(1096, 10)
        Me.inwdtto.Name = "inwdtto"
        Me.inwdtto.Size = New System.Drawing.Size(93, 21)
        Me.inwdtto.TabIndex = 8
        '
        'txtinw
        '
        Me.txtinw.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtinw.Location = New System.Drawing.Point(594, 10)
        Me.txtinw.Name = "txtinw"
        Me.txtinw.Size = New System.Drawing.Size(110, 21)
        Me.txtinw.TabIndex = 4
        '
        'inwdtf
        '
        Me.inwdtf.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.inwdtf.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.inwdtf.Location = New System.Drawing.Point(963, 10)
        Me.inwdtf.Name = "inwdtf"
        Me.inwdtf.Size = New System.Drawing.Size(90, 21)
        Me.inwdtf.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(1056, 14)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 13)
        Me.Label7.TabIndex = 52
        Me.Label7.Text = "GtTo"
        '
        'btngo
        '
        Me.btngo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btngo.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngo.Location = New System.Drawing.Point(1195, 10)
        Me.btngo.Name = "btngo"
        Me.btngo.Size = New System.Drawing.Size(35, 21)
        Me.btngo.TabIndex = 9
        Me.btngo.Text = "&Go"
        Me.btngo.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(928, 14)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 13)
        Me.Label6.TabIndex = 51
        Me.Label6.Text = "GtDt"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(539, 14)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 50
        Me.Label4.Text = "Gate No"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(707, 14)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(28, 13)
        Me.Label25.TabIndex = 50
        Me.Label25.Text = "Org"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(797, 14)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(41, 13)
        Me.Label26.TabIndex = 50
        Me.Label26.Text = "Gtype"
        '
        'cmbsup
        '
        Me.cmbsup.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsup.FormattingEnabled = True
        Me.cmbsup.Location = New System.Drawing.Point(75, 10)
        Me.cmbsup.Name = "cmbsup"
        Me.cmbsup.Size = New System.Drawing.Size(334, 21)
        Me.cmbsup.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "Supplier"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(408, 14)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(50, 13)
        Me.Label13.TabIndex = 63
        Me.Label13.Text = "Criteria"
        '
        'cmbval
        '
        Me.cmbval.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbval.FormattingEnabled = True
        Me.cmbval.Items.AddRange(New Object() {"All", "Gate", "Not Validated", "Action Taken", "Validated", "RTV", "Cancel Entry", "No Reference"})
        Me.cmbval.Location = New System.Drawing.Point(455, 10)
        Me.cmbval.Name = "cmbval"
        Me.cmbval.Size = New System.Drawing.Size(85, 21)
        Me.cmbval.TabIndex = 6
        '
        'cmborg
        '
        Me.cmborg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(733, 10)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(64, 21)
        Me.cmborg.TabIndex = 70
        '
        'gtype
        '
        Me.gtype.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gtype.FormattingEnabled = True
        Me.gtype.Items.AddRange(New Object() {"OSP", "PO", "Service Po", "Non Po Inward"})
        Me.gtype.Location = New System.Drawing.Point(837, 10)
        Me.gtype.Name = "gtype"
        Me.gtype.Size = New System.Drawing.Size(95, 21)
        Me.gtype.TabIndex = 71
        '
        'GroupBox3
        '
        Me.GroupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GroupBox3.Controls.Add(Me.TXTREF)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.gtype)
        Me.GroupBox3.Controls.Add(Me.cmborg)
        Me.GroupBox3.Controls.Add(Me.cmbval)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.cmbsup)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.Label25)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.btngo)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.inwdtf)
        Me.GroupBox3.Controls.Add(Me.txtinw)
        Me.GroupBox3.Controls.Add(Me.inwdtto)
        Me.GroupBox3.Location = New System.Drawing.Point(3, -2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1350, 60)
        Me.GroupBox3.TabIndex = 72
        Me.GroupBox3.TabStop = False
        '
        'TXTREF
        '
        Me.TXTREF.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTREF.FormattingEnabled = True
        Me.TXTREF.Location = New System.Drawing.Point(75, 37)
        Me.TXTREF.Name = "TXTREF"
        Me.TXTREF.Size = New System.Drawing.Size(334, 21)
        Me.TXTREF.TabIndex = 89
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(1, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 26)
        Me.Label2.TabIndex = 88
        Me.Label2.Text = "No Reference"
        '
        'btnxs
        '
        Me.btnxs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnxs.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnxs.Location = New System.Drawing.Point(349, 603)
        Me.btnxs.Name = "btnxs"
        Me.btnxs.Size = New System.Drawing.Size(120, 23)
        Me.btnxs.TabIndex = 100
        Me.btnxs.Text = "Excess Validation"
        Me.btnxs.UseVisualStyleBackColor = True
        Me.btnxs.Visible = False
        '
        'lbvehicle
        '
        Me.lbvehicle.AutoSize = True
        Me.lbvehicle.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbvehicle.ForeColor = System.Drawing.Color.Crimson
        Me.lbvehicle.Location = New System.Drawing.Point(163, 606)
        Me.lbvehicle.Name = "lbvehicle"
        Me.lbvehicle.Size = New System.Drawing.Size(0, 18)
        Me.lbvehicle.TabIndex = 97
        Me.lbvehicle.Visible = False
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(524, 632)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 23)
        Me.Button1.TabIndex = 94
        Me.Button1.Text = "Direct Delivery List"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(9, 606)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(147, 18)
        Me.Label31.TabIndex = 99
        Me.Label31.Text = "Checked Details"
        Me.Label31.Visible = False
        '
        'UNBLOCK
        '
        Me.UNBLOCK.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UNBLOCK.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UNBLOCK.Location = New System.Drawing.Point(221, 562)
        Me.UNBLOCK.Name = "UNBLOCK"
        Me.UNBLOCK.Size = New System.Drawing.Size(131, 23)
        Me.UNBLOCK.TabIndex = 95
        Me.UNBLOCK.Text = "View UnClosed  ADI"
        Me.UNBLOCK.UseVisualStyleBackColor = True
        Me.UNBLOCK.Visible = False
        '
        'btnreport
        '
        Me.btnreport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnreport.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreport.Location = New System.Drawing.Point(460, 632)
        Me.btnreport.Name = "btnreport"
        Me.btnreport.Size = New System.Drawing.Size(59, 23)
        Me.btnreport.TabIndex = 93
        Me.btnreport.Text = "Rep&ort"
        Me.btnreport.UseVisualStyleBackColor = True
        Me.btnreport.Visible = False
        '
        'mmcard
        '
        Me.mmcard.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.mmcard.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mmcard.Location = New System.Drawing.Point(572, 564)
        Me.mmcard.Name = "mmcard"
        Me.mmcard.Size = New System.Drawing.Size(78, 23)
        Me.mmcard.TabIndex = 91
        Me.mmcard.Text = "Inward Tag"
        Me.mmcard.UseVisualStyleBackColor = True
        Me.mmcard.Visible = False
        '
        'bprint
        '
        Me.bprint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bprint.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bprint.Location = New System.Drawing.Point(401, 632)
        Me.bprint.Name = "bprint"
        Me.bprint.Size = New System.Drawing.Size(55, 23)
        Me.bprint.TabIndex = 92
        Me.bprint.Text = "P&rint"
        Me.bprint.UseVisualStyleBackColor = True
        Me.bprint.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(6, 562)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 13)
        Me.Label14.TabIndex = 89
        Me.Label14.Text = "Gate Count"
        '
        'lblcnt
        '
        Me.lblcnt.AutoSize = True
        Me.lblcnt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcnt.ForeColor = System.Drawing.Color.DarkMagenta
        Me.lblcnt.Location = New System.Drawing.Point(75, 562)
        Me.lblcnt.Name = "lblcnt"
        Me.lblcnt.Size = New System.Drawing.Size(27, 13)
        Me.lblcnt.TabIndex = 90
        Me.lblcnt.Text = " oo"
        '
        'btnview
        '
        Me.btnview.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnview.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnview.Location = New System.Drawing.Point(355, 562)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(72, 23)
        Me.btnview.TabIndex = 87
        Me.btnview.Text = "&Po View"
        Me.btnview.UseVisualStyleBackColor = True
        '
        'btndel
        '
        Me.btndel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndel.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndel.Location = New System.Drawing.Point(430, 562)
        Me.btndel.Name = "btndel"
        Me.btndel.Size = New System.Drawing.Size(63, 23)
        Me.btndel.TabIndex = 88
        Me.btndel.Text = "&Delete"
        Me.btndel.UseVisualStyleBackColor = True
        '
        'btnitem
        '
        Me.btnitem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnitem.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnitem.Location = New System.Drawing.Point(905, 339)
        Me.btnitem.Name = "btnitem"
        Me.btnitem.Size = New System.Drawing.Size(149, 23)
        Me.btnitem.TabIndex = 75
        Me.btnitem.Text = "&Item Checked Details"
        Me.btnitem.UseVisualStyleBackColor = True
        '
        'dgvcr
        '
        Me.dgvcr.AllowUserToAddRows = False
        Me.dgvcr.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvcr.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgvcr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvcr.DefaultCellStyle = DataGridViewCellStyle10
        Me.dgvcr.Location = New System.Drawing.Point(873, 564)
        Me.dgvcr.Name = "dgvcr"
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvcr.RowHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.dgvcr.RowHeadersVisible = False
        Me.dgvcr.RowHeadersWidth = 30
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvcr.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.dgvcr.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgvcr.Size = New System.Drawing.Size(380, 61)
        Me.dgvcr.TabIndex = 88
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label21.Location = New System.Drawing.Point(75, 579)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(27, 13)
        Me.Label21.TabIndex = 90
        Me.Label21.Text = " oo"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(8, 580)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(68, 13)
        Me.Label22.TabIndex = 89
        Me.Label22.Text = "Line Count"
        '
        'btnwop
        '
        Me.btnwop.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnwop.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnwop.Location = New System.Drawing.Point(496, 563)
        Me.btnwop.Name = "btnwop"
        Me.btnwop.Size = New System.Drawing.Size(73, 23)
        Me.btnwop.TabIndex = 93
        Me.btnwop.Text = "WOP Print"
        Me.btnwop.UseVisualStyleBackColor = True
        '
        'btngacc
        '
        Me.btngacc.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btngacc.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngacc.Location = New System.Drawing.Point(1057, 339)
        Me.btngacc.Name = "btngacc"
        Me.btngacc.Size = New System.Drawing.Size(113, 23)
        Me.btngacc.TabIndex = 17
        Me.btngacc.Text = "Gate /Acc Report"
        Me.btngacc.UseVisualStyleBackColor = True
        '
        'dgvr
        '
        Me.dgvr.AllowUserToAddRows = False
        Me.dgvr.BackgroundColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvr.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.dgvr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvr.DefaultCellStyle = DataGridViewCellStyle14
        Me.dgvr.Location = New System.Drawing.Point(652, 558)
        Me.dgvr.Name = "dgvr"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvr.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.dgvr.RowHeadersVisible = False
        Me.dgvr.RowHeadersWidth = 30
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.LightGray
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black
        Me.dgvr.RowsDefaultCellStyle = DataGridViewCellStyle16
        Me.dgvr.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgvr.Size = New System.Drawing.Size(217, 92)
        Me.dgvr.TabIndex = 88
        '
        'btntag
        '
        Me.btntag.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntag.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntag.Location = New System.Drawing.Point(286, 629)
        Me.btntag.Name = "btntag"
        Me.btntag.Size = New System.Drawing.Size(110, 23)
        Me.btntag.TabIndex = 91
        Me.btntag.Text = "Receipt Traveller Sheet"
        Me.btntag.UseVisualStyleBackColor = True
        Me.btntag.Visible = False
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(1133, 311)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(34, 13)
        Me.Label42.TabIndex = 63
        Me.Label42.Text = "WOP"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.BackColor = System.Drawing.Color.Red
        Me.Label43.ForeColor = System.Drawing.Color.Red
        Me.Label43.Location = New System.Drawing.Point(1117, 311)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(21, 13)
        Me.Label43.TabIndex = 63
        Me.Label43.Text = "Ro"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(139, 564)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(83, 13)
        Me.Label44.TabIndex = 63
        Me.Label44.Text = "Shortage Qty"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.BackColor = System.Drawing.Color.Crimson
        Me.Label45.ForeColor = System.Drawing.Color.Crimson
        Me.Label45.Location = New System.Drawing.Point(116, 564)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(21, 13)
        Me.Label45.TabIndex = 63
        Me.Label45.Text = "Ro"
        '
        'job_shrt
        '
        Me.job_shrt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.job_shrt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.job_shrt.Location = New System.Drawing.Point(496, 590)
        Me.job_shrt.Name = "job_shrt"
        Me.job_shrt.Size = New System.Drawing.Size(154, 23)
        Me.job_shrt.TabIndex = 93
        Me.job_shrt.Text = "Job Shortage Print"
        Me.job_shrt.UseVisualStyleBackColor = True
        '
        'Gate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1370, 649)
        Me.Controls.Add(Me.dgvr)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.dgvcr)
        Me.Controls.Add(Me.linkpwd)
        Me.Controls.Add(Me.btnxs)
        Me.Controls.Add(Me.lbvehicle)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.UNBLOCK)
        Me.Controls.Add(Me.job_shrt)
        Me.Controls.Add(Me.btnwop)
        Me.Controls.Add(Me.btnreport)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.btntag)
        Me.Controls.Add(Me.mmcard)
        Me.Controls.Add(Me.bprint)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.lblcnt)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.btndel)
        Me.Controls.Add(Me.btnrecpt)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.btnnonpo)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.btncan)
        Me.Controls.Add(Me.ADIbt)
        Me.Controls.Add(Me.lbupdt)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnitem)
        Me.Controls.Add(Me.glist)
        Me.Controls.Add(Me.btnmod)
        Me.Controls.Add(Me.txtlog)
        Me.Controls.Add(Me.btngacc)
        Me.Controls.Add(Me.btnsta)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.btnval)
        Me.Name = "Gate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gate Register"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.dgvcr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvr, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents btnval As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtlog As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents btnmod As System.Windows.Forms.Button
    Friend WithEvents btnsta As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents glist As System.Windows.Forms.Button
    Friend WithEvents txtrole As System.Windows.Forms.TextBox
    Friend WithEvents linkpwd As System.Windows.Forms.LinkLabel
    Friend WithEvents lbupdt As System.Windows.Forms.LinkLabel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents ADIbt As System.Windows.Forms.Button
    Friend WithEvents btncan As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents btnrecpt As System.Windows.Forms.Button
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents btnnonpo As System.Windows.Forms.Button
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents inwdtto As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtinw As System.Windows.Forms.TextBox
    Friend WithEvents inwdtf As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btngo As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents cmbsup As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cmbval As System.Windows.Forms.ComboBox
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents gtype As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnxs As System.Windows.Forms.Button
    Friend WithEvents lbvehicle As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents UNBLOCK As System.Windows.Forms.Button
    Friend WithEvents btnreport As System.Windows.Forms.Button
    Friend WithEvents mmcard As System.Windows.Forms.Button
    Friend WithEvents bprint As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblcnt As System.Windows.Forms.Label
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents btndel As System.Windows.Forms.Button
    Friend WithEvents TXTREF As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnitem As Button
    Friend WithEvents dgvcr As DataGridView
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents btnwop As Button
    Friend WithEvents Label29 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents btngacc As Button
    Friend WithEvents dgvr As DataGridView
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents btntag As Button
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents job_shrt As Button
    Friend WithEvents Label46 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label47 As Label
End Class
