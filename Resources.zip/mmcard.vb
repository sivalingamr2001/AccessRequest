Imports System.IO
Imports System.Data.OracleClient
Imports oracleclass
Public Class mmcard
    Dim c, item, gate, osp As String
    Dim sp, le, poqty, L As Integer
    Dim cl As New oracleclass.Class1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            ds.Clear()
            ds.Dispose()
            
            sql = "select a.item,a.rev,a.description,b.org,b.supplier_name,a.pono,a.oper,a.supdcqty, a.podt,b.gdate,b.gate_no,a.job,b.dc_no,b.dc_date from jan_gate_lines a,jan_gate_header b where a.gate_no=b.gate_no and b.gate_no>='" & txtgfm.Text & "' and b.gate_No<='" & txtgto.Text & "' and a.flag<>0 and b.validated=0"
            If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Then
                sql &= " and b.unit='UNIT1' "
                'and b.org not in ('COM','I01','I06','I07')"
            ElseIf txtrole.Text = "UNIT7" Then
                sql &= " and b.unit='UNIT7' "
            ElseIf txtrole.Text = "UNIT4" Then
                sql &= " and b.unit='SKYFAST' "
            ElseIf txtrole.Text = "UNIT4" Then
                sql &= " and b.unit='UNIT4' "
                'AND B.ORG IN('I01')"
            End If

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            printing()
        Catch ex As Exception
            MessageBox.Show(ex.Message, " GATE")
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub
    Private Sub printing()

        x = "c:\gate\gate\print.HTML"
        Dim fstrm As New FileStream(x, FileMode.OpenOrCreate, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        j = 0
        s = "<html><head>"
        s &= "<style type='text/css'>"
        s &= ".cl {color: black;  FONT-FAMILY:VERDANA; FONT-SIZE:8PT ;}"
        s &= ""
        s &= ""
        s &= "</style>"
        If ds.Tables("resultab").Rows.Count > 0 Then
            head()
            sw.WriteLine(s)
            fstrm.Flush()
            sw.Flush()
            sw.Close()
            fstrm.Close()
            System.Diagnostics.Process.Start(x)
        End If
    End Sub
    Public Sub mhead()
        s &= "<table border=1 width=700 cellspacing=0 cellpadding=4>"

        s &= " <tr><td rowspan=3  colspan=1 width=150 ><img src=f:\oa\logo2.jpg></td><td rowspan=3  colspan=3 align=center ><B><font face=verdana size=4>MATERIAL MOVEMENT CARD</font></B></td><td colspan=2><font face=verdana size=2>Doc No: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Page No:</font></td></td></tr>"

        s &= " <tr><td colspan=2><font face=verdana size=2>Date:" & ds.Tables("resultab").Rows(0).Item("gdate") & "</font></td></tr><tr><td colspan=2><font face=verdana size=2>Issue No:</font></td></tr>"
    End Sub
    Public Sub head()
        j = 0
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            k = ds.Tables("resultab").Rows.Count - 2
            Dim item, gate, osp As String
            Dim l As Integer
            item = ds.Tables("resultab").Rows(i).Item("item")
            gate = ds.Tables("resultab").Rows(i).Item("gate_no")

            If i <> 0 Then
                If (j Mod 2 <> 0 And j <> 0) Then
                    s &= "<br>"
                ElseIf (j Mod 2 = 0 And j <> 0) Then
                    s &= "<br style=page-break-before:always;>"
                End If
            End If

            sql = "select count(item)icnt from jan_gatE_lines where item='" & item & "' and gate_no='" & gate & "'"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds2 = New DataSet
            cl.oradap.Fill(ds2, "resultab")
            l = ds2.Tables("resultab").Rows(0).Item("icnt") - 1

            If i > 0 Then
                If item = ds.Tables("resultab").Rows(i - 1).Item("item") And gate = ds.Tables("resultab").Rows(i - 1).Item("gate_no") Then
                    If k = i Then
                        Exit For
                    Else
                        i = l - i
                        GoTo sslp
                    End If
                End If
            End If
sslp:
            mhead()

            With ds.Tables("resultab").Rows(i)
                If .Item("job").ToString = "" Then osp = "-"
                If .Item("job").ToString <> "" Then osp = .Item("job")

                s &= "<tr><td width=170><font face=verdana size=2> Item No/Rev</font></td> <td width=150><font face=verdana size=2>" & .Item("item") & "/" & .Item("rev") & "</font></td> "

                s &= "<td width=200><FONT SIZE=2 font face=verdana>Operation:</font><FONT SIZE=1 font face=verdana><br>"

                If .Item("oper").ToString <> "" Then
                    le = Len(.Item("oper"))
                    Dim lenop, oploop As Int16
                    lenop = Math.Floor((le / 10))
                    For oploop = 1 To lenop
                        s &= .Item("oper").ToString.Substring(((oploop - 1) * 10), (oploop * 10) - ((oploop - 1) * 10)) & "<br>"
                    Next
                    If lenop > 0 Then
                        If (le Mod 10) > 0 Then
                            s &= .Item("oper").ToString.Substring((lenop * 10), le - ((lenop * 10)))
                        End If
                    Else
                        s &= .Item("oper").ToString
                    End If
                    s &= "</font></td>"
                Else
                    s &= "-"
                End If

                s &= "  <td width=150><font face=verdana size=2>Purchase Order No</font> </td> "

                If i + 1 <= ds.Tables("resultab").Rows.Count - 1 Then

                    If item = ds.Tables("resultab").Rows(i + 1).Item("item") And gate = ds.Tables("resultab").Rows(i + 1).Item("gate_no") Then

                        sql = "SELECT pono,supdcqty from jan_gate_lines where item='" & item & "' and gate_no='" & gate & "' "
                        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                        ds1 = New DataSet
                        cl.oradap.Fill(ds1, "resultab")
                        s &= "<td width=150><table>"
                        For sp = 0 To ds1.Tables("resultab").Rows.Count - 1
                            s &= " <font face=verdana size=2>" & ds1.Tables("resultab").Rows(sp).Item("pono") & " </font>"
                        Next
                        s &= "</table></td>"
                    Else
                        s &= "<td width=150><font face=verdana size=2>" & .Item("pono") & "</font></td>"
                    End If
                Else
                    s &= "<td width=150><font face=verdana size=2>" & .Item("pono") & "</font></td>"
                End If

                s &= "<td width=150><font face=verdana size=2>" & .Item("podt") & "</font></td></tr>"

                s &= "<tr><td ><font face=verdana size=2>Description</font></td><td width=150  colspan=2><font face=verdana size=2>" & .Item("description") & "</font></td> <td colspan=1 width=150><font face=verdana size=2> Jobcard<br>Challan</font></td><td><font face=verdana size=2>" & osp & "</font></td></td><td>-</td></tr>"

                s &= "<tr> <td width=150> <font face=verdana size=2>Division</font></td><td colspan=2 width=150><font face=verdana size=2>" & .Item("org") & "</font></td><td> <font face=verdana size=2>GateEntry<br>Inv </font></td><td><font face=verdana size=2>" & .Item("gate_no") & "<br>" & .Item("dc_no") & "</font></td><td><font face=verdana size=2>" & .Item("gdate") & "<br>" & .Item("dc_date") & "</font></td></tr>"

                s &= "<tr><td width=150> <font face=verdana size=2>Supplier</font></td><td colspan=2 width=150><font face=verdana size=2>" & .Item("supplier_name") & "</font></td><td><font face=verdana size=2>Receipt</font></td><td>-</td><td>-</td></tr>"

                s &= "<tr><td><font face=verdana size=2>Qty as Per Dc/Inv</font></td>"
                If i + 1 <= ds.Tables("resultab").Rows.Count - 1 Then
                    If item = ds.Tables("resultab").Rows(i + 1).Item("item") And gate = ds.Tables("resultab").Rows(i + 1).Item("gate_no") Then

                        s &= "<td width=150><table>"
                        For sp = 0 To ds1.Tables("resultab").Rows.Count - 1
                            s &= " <font face=verdana size=2>" & ds1.Tables("resultab").Rows(sp).Item("supdcqty") & " </font>"
                        Next
                        s &= "</table></td>"
                    Else
                        s &= "<td width=150><font face=verdana size=2>" & .Item("supdcqty") & "</font></td>"
                    End If
                Else
                    s &= "<td width=150><font face=verdana size=2>" & .Item("supdcqty") & "</font></td>"
                End If
                s &= " <td rowspan=7 align=center><font face=verdana size=2> Number of Packs</font></td><td>-</td><td  rowspan=2> <font face=verdana size=2>Inward Dept Sign & Dt</font></td><td rowspan=2>-</td></tr>"


                s &= "<tr><td><font face=verdana size=2>Qty Received</font></td><td>-</td><td>-</td></tr>"

                s &= "<tr><td><font face=verdana size=2>Qty Accepted</font></td><td>-</td><td>-</td><td rowspan=3><font face=verdana size=2>QA Dept Sign & Dt</font></td><td rowspan=3>-</td></tr>"

                s &= "<tr><td><font face=verdana size=2>Qty Rejected</font></td><td>-</td><td>-</td></tr>"

                s &= "<tr><td><font face=verdana size=2>Qty Received at stores</font></td><td>-</td><td >-</td></tr>"

                s &= " <tr><td><font face=verdana size=2>Received in short</font></td><td>-</td><td>-</td><td rowspan=2><font face=verdana size=2>Stores Incharge Sign & Dt</font></td><td rowspan=2>-</td></tr>"

                s &= "<tr><td><font face=verdana size=2>Received in Excess </font></td><td>-</td><td>-</td></tr>"
                s &= " </table>"
                j += 1
            End With
        Next
    End Sub



    Private Sub mmcard_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        sql = "select vendor_name from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' order by vendor_name asc"
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbven.Items.Add(ds.Tables("resultab").Rows(i).Item("vendor_name").ToString.Replace("'", "''"))
        Next
        sql = "select organization_code  from org_organization_definitions where organization_id not in(105,112 )order by organization_code"
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Dim WB As New WebBrowser
        'WB()
        'WB.Print()

        For i = 0 To dgv1.Rows.Count - 1
            If dgv1.Rows(i).Cells(0).Value = True Then
                sql = "update jan_gatE_header set mmcard=0 where gatE_No=" & dgv1.Rows(i).Cells(1).Value & ""
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
            End If
        Next
        s = ""
        L = 0

        'If txtrole.Text = "UNIT2" Or txtrole.Text = "UNIT2VIEW" Then
        '    x1 = "c:\gate\gate.txt"
        '    fstrm = New FileStream(x1, FileMode.Create, FileAccess.Write)
        '    sw = New StreamWriter(fstrm)
        '    printval()
        '    Dim F As FileStream
        '    Dim sr As StreamWriter
        '    F = New FileStream("c:\gate\gate.bat", FileMode.Create, FileAccess.ReadWrite)
        '    sr = New StreamWriter(F)
        '    sr.WriteLine("type " & x1 & " >prn")
        '    sr.Close()
        '    F.Close()
        '    Shell("c:\gate\gate.bat", AppWinStyle.Hide)
        'Else
        printval1()
        'End If
        For i = 0 To dgv1.Rows.Count - 1
            dgv1.Rows(i).Cells(0).Value = False
        Next
    End Sub
    Public Sub printval()
        For i = 0 To dgv1.Rows.Count - 1
            If (i + 1) <= dgv1.Rows.Count - 1 Then
                If dgv1.Rows(i).Cells(0).Value = True Then 'And dgv1.Rows(i + 1).Cells(0).Value = False 
                    j = i + 1
                End If
            End If
        Next
        Dim po, item, org, GT As String

        po = ""
        For i = 0 To dgv1.Rows.Count - 1
            If dgv1.Rows(i).Cells(0).Value = True Then
                With dgv1.Rows(i)
                    GT = .Cells(1).Value
                    org = .Cells(2).Value
                    item = .Cells(3).Value
                    po = String.Concat(po, ",", .Cells(5).Value)
                    poqty = poqty + .Cells(7).Value
                    If i + 1 <= j - 1 Then
                        If item <> dgv1.Rows(i + 1).Cells(3).Value Or GT <> dgv1.Rows(i + 1).Cells(1).Value Then
                            For k = i To j - 1
                                If dgv1.Rows(i).Cells(0).Value = True Then
                                    If k + 1 <= j - 1 Then
                                        If k = dgv1.CurrentRow.Index Then

                                            If item <> dgv1.Rows(k + 1).Cells(3).Value Or GT <> dgv1.Rows(i + 1).Cells(1).Value Then
                                                value()
                                                s = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                                                sw.WriteLine(s)
                                                po = ""
                                                GoTo poline
                                                ' Exit Do
                                            End If

                                        ElseIf item <> dgv1.Rows(k + 1).Cells(2).Value Or GT <> dgv1.Rows(i + 1).Cells(1).Value Then
                                            value()
                                            s = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                                            sw.WriteLine(s)
                                            po = ""
                                            GoTo poline
                                        End If
                                    End If
                                End If
                            Next

poline:
                            s = Space(1) & "Recpt.Qty" & Space(1) & ":" & poqty.ToString.PadRight(10, " ") & "H" & "No Of Bundles" & Space(1) & ":" & vbNewLine
                            poqty = 0
                            sw.WriteLine(s)


                            ' Dim NM As String



                            s = Space(1) & "Checked By:" & Space(1) & "G" & dgv1.Rows(i).Cells(14).Value & "H"
                            sw.WriteLine(s)
                            s = ""
                            sw.WriteLine(s)
                            s = ""
                            sw.WriteLine(s)
                            s = ""
                            sw.WriteLine(s)
                            s = ""
                            L += 1
                            If (L Mod 3 = 0 And L > 0) Then s = Chr(12) : sw.WriteLine(s)


                        End If
                    ElseIf i = j - 1 Or i = j + 1 Or i - 1 = j - 1 Then
                        value()
                        s = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                        sw.WriteLine(s)
                        po = ""
                        GoTo poline

                    ElseIf i = 0 Or i = i Then
                        value()
                        s = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                        sw.WriteLine(s)
                        po = ""
                        GoTo poline
                    End If
                End With
            End If
            '     po = ""
        Next

        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()

        ' System.Diagnostics.Process.Start(x)
    End Sub
    Public Sub printval1()
        For i = 0 To dgv1.Rows.Count - 1
            If (i + 1) <= dgv1.Rows.Count - 1 Then
                If dgv1.Rows(i).Cells(0).Value = True Then 'And dgv1.Rows(i + 1).Cells(0).Value = False 
                    j = i + 1
                End If
            End If
        Next
        Dim po, item, org, GT As String
        Dim polen As Integer
        po = ""
        For i = 0 To dgv1.Rows.Count - 1
            If dgv1.Rows(i).Cells(0).Value = True Then
                With dgv1.Rows(i)
                    GT = .Cells(1).Value
                    org = .Cells(2).Value
                    item = .Cells(3).Value
                    po = String.Concat(po, ",", .Cells(5).Value)
                    poqty = poqty + .Cells(7).Value
                    polen = po.Length
                    If i + 1 <= j - 1 Then
                        If item <> dgv1.Rows(i + 1).Cells(3).Value Or GT <> dgv1.Rows(i + 1).Cells(1).Value Then
                            For k = i To j - 1
                                If dgv1.Rows(i).Cells(0).Value = True Then
                                    If k + 1 <= j - 1 Then
                                        If k = dgv1.CurrentRow.Index Then

                                            If item <> dgv1.Rows(k + 1).Cells(3).Value Or GT <> dgv1.Rows(i + 1).Cells(1).Value Then
                                                value1()
                                                '  s = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                                                ''If polen > 10 Then
                                                ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1).Substring(0, 10) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                                                ''Else
                                                ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                                                ''End If
                                                ' '' sw.WriteLine(s)
                                                ''po = ""
                                                GoTo poline
                                                ' Exit Do
                                            End If

                                        ElseIf item <> dgv1.Rows(k + 1).Cells(2).Value Or GT <> dgv1.Rows(i + 1).Cells(1).Value Then
                                            value1()
                                            ' s = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                                            ''If polen > 10 Then
                                            ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1).Substring(0, 10) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                                            ''Else
                                            ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                                            ''End If
                                            ' '' sw.WriteLine(s)
                                            ''po = ""
                                            GoTo poline
                                        End If
                                    End If
                                End If
                            Next

poline:
                            ' s = Space(1) & "Recpt.Qty" & Space(1) & ":" & poqty.ToString.PadRight(10, " ") & "H" & "No Of Bundles" & Space(1) & ":" & vbNewLine
                            s &= "<TR><TD><FONT FACE=VERDANA FONT SIZE=2> Recpt.Qty :" & poqty.ToString.PadRight(10, " ") & "</FONT></TD><TD><FONT FACE=VERDANA FONT SIZE=2>No Of Bundles:</FONT><TD>  </TR>"


                            poqty = 0
                            '  sw.WriteLine(s)


                            ' Dim NM As String

                            s &= "<TR><TD><FONT FACE=VERDANA FONT SIZE=2> Checked By:<B>" & dgv1.Rows(i).Cells(14).Value & " </B></FONT><TD>  </TR>"

                            s &= "<TR><TD ><FONT FACE=VERDANA FONT SIZE=2>Sample Reqd  Qty :</FONT></TD></TR>"

                            s &= "<TR><TD><FONT FACE=VERDANA FONT SIZE=2>Sample Return Qty:</FONT></TD></TR>"
                            s &= "<BR><BR>"
                            ' s = Space(1) & "Checked By:" & Space(1) & "G" & dgv1.Rows(i).Cells(14).Value & "H"
                            'sw.WriteLine(s)
                            's = ""
                            'sw.WriteLine(s)
                            's = ""
                            'sw.WriteLine(s)
                            's = ""
                            'sw.WriteLine(s)
                            's = ""
                            '  s &= "<BR>"

                            ' If (L Mod 3 = 0 And L > 0) Then s = Chr(12) : sw.WriteLine(s)

                            If (L Mod 3 = 0 And L > 0) Then
                                ' s &= "-----------"
                                ' s &= " <br style=page-break-after:always;>"
                                s &= "<BR>"


                                s &= "<span style=""display: block;     break-before: always; page-break-before: always;"">&nbsp;</span>"
                                ' s &= "-----------"
                                's &= "<BR>"
                            End If
                            L += 1

                        End If
                    ElseIf i = j - 1 Or i = j + 1 Or i - 1 = j - 1 Then
                        value1()
                        's = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                        'sw.WriteLine(s)
                        ''If polen > 10 Then
                        ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1).Substring(0, 10) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                        ''Else
                        ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                        ''End If
                        ''po = ""
                        GoTo poline

                    ElseIf i = 0 Or i = i Then
                        value1()
                        's = Space(1) & "PO/JC No" & Space(1) & ":" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & vbNewLine
                        'sw.WriteLine(s)
                        ''If polen > 20 Then
                        ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1).Substring(0, 10) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                        ''Else
                        ''    s &= "<TR><TD COLSPAN=3><FONT FACE=VERDANA FONT SIZE=2>  PO/JC No :" & po.Substring(1, po.Length - 1) & "/" & .Cells(10).Value & "</FONT></TD></TR>"
                        ''End If
                        po = ""
                        GoTo poline
                    End If
                End With
            End If
            '     po = ""
        Next
        x1 = "c:\gate\gate.html"
        fstrm = New FileStream(x1, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x1)
    End Sub
    Private Sub value()
        With dgv1.Rows(i)
            s = ""
            sw.WriteLine(s)
            s = ""
            sw.WriteLine(s)
            s = ""
            sw.WriteLine(s)
            s = ""
            sw.WriteLine(s)

            's = "GW1      MATERIAL INWARD        "

            'sw.WriteLine(s)

            'If .Cells(16).Value = 1 Then s = Space(1) & vbNewLine & " SPOT INSPECTION" & vbNewLine : sw.WriteLine(s)
            'If .Cells(17).Value = 1 Then s = Space(1) & vbNewLine & " SELF CERTIFY" & vbNewLine : sw.WriteLine(s)


            If .Cells(16).Value = 1 Then
                s = "GW1    MATERIAL INWARD   (SPOT INSPECTION)" : sw.WriteLine(s)

            ElseIf .Cells(17).Value = 1 Then

                s = "GW1   MATERIAL INWARD   (SELF CERTIFY)" : sw.WriteLine(s)
            Else
                s = "GW1      MATERIAL INWARD        "

                sw.WriteLine(s)
            End If






            s = Space(1) & "Gate No" & Space(1) & ":" & "G" & .Cells(1).Value & "H" & Space(5) & "Recpt.No" & ":" & .Cells(8).Value
            sw.WriteLine(s)




            s = Space(1) & "Dc.No" & Space(1) & ":" & .Cells(12).Value & Space(12) & .Cells(9).Value & vbNewLine
            sw.WriteLine(s)

            s = Space(1) & "Supplier" & Space(1) & ":" & .Cells(6).Value.ToString.PadRight(10, " ") & vbNewLine
            sw.WriteLine(s)

            s = Space(1) & "G" & "Item No" & Space(1) & ":" & .Cells(3).Value.ToString.PadRight(10, " ") & "H" & Space(3) & "Rev" & ":" & .Cells(15).Value & Space(3) & "Org" & ":" & .Cells(2).Value & vbNewLine
            sw.WriteLine(s)

            s = Space(1) & "Desc" & Space(1) & ":" & .Cells(4).Value.ToString.Replace("�", "") & vbNewLine
            sw.WriteLine(s)
        End With
    End Sub


    Private Sub value1()
        With dgv1.Rows(i)
            's = ""
            's &= "<BR>"


            's = "GW1      MATERIAL INWARD        "

            'sw.WriteLine(s)

            'If .Cells(16).Value = 1 Then s = Space(1) & vbNewLine & " SPOT INSPECTION" & vbNewLine : sw.WriteLine(s)
            'If .Cells(17).Value = 1 Then s = Space(1) & vbNewLine & " SELF CERTIFY" & vbNewLine : sw.WriteLine(s)

            s &= "<TABLE BORDER=0 CELLPADDING=4 ALIGN=CENTER >"
            s &= "<TR>"
            If .Cells(16).Value = 1 Then
                s &= " <TD ALIGN=CENTER  COLSPAN=3><FONT FACE=VERDANA FONT SIZE=3><B>MATERIAL INWARD(SPOT INSPECTION)<BR></FONT></TD>"

            ElseIf .Cells(17).Value = 1 Then

                s &= "<TD ALIGN=CENTER COLSPAN=3><FONT FACE=VERDANA FONT SIZE=3> <B>MATERIAL INWARD(SELF CERTIFY)<BR></FONT></TD>"
            Else
                s &= "<TD ALIGN=CENTER COLSPAN=3><FONT FACE=VERDANA FONT SIZE=3> <B>MATERIAL INWARD</FONT><BR></FONT></TD>"
            End If

            s &= "</TR>"

            's &= "</table>"


            s &= "<TR><TD><FONT FACE=VERDANA FONT SIZE=2> Gate No:<B>" & .Cells(1).Value & "</B></TD><TD><FONT FACE=VERDANA FONT SIZE=2>Recpt.No:" & .Cells(8).Value & "</TD></TR>"

            s &= "<TR><TD><FONT FACE=VERDANA FONT SIZE=2>Dc.No:" & .Cells(12).Value & "</TD><TD><FONT FACE=VERDANA FONT SIZE=2> " & .Cells(9).Value & "</TD></TR>"

            s &= "<TR><TD COLSPAN=2><FONT FACE=VERDANA FONT SIZE=2>Supplier:" & .Cells(6).Value.ToString.PadRight(10, " ") & "</TD></TR>"


            s &= "<TR><TD><FONT FACE=VERDANA FONT SIZE=2>Item No:<B>" & .Cells(3).Value.ToString.PadRight(10, " ") & " </B></TD><TD><FONT FACE=VERDANA FONT SIZE=2>Rev:" & .Cells(15).Value & " &nbsp;&nbsp; Org :" & .Cells(2).Value & "</TD></TR>"


            If .Cells(4).Value.ToString.Length > 15 Then

                s &= "<TR><TD colspan=2><FONT FACE=VERDANA FONT SIZE=2>Desc:" & .Cells(4).Value.ToString.Replace("�", "") & "</TD></TR>"
            Else


                s &= "<TR><TD colspan=2><FONT FACE=VERDANA FONT SIZE=2>Desc:" & .Cells(4).Value.ToString.Replace("�", "") & "</TD></TR>"

            End If

        End With
    End Sub
    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click

        dgv1.Columns.Clear()
        Dim cc As New DataGridViewCheckBoxColumn
        cc.Width = 30
        Me.dgv1.Columns.Add(cc) 'and a.line_no=1
        Me.Cursor = Cursors.WaitCursor
        'sql = " select * from (select    a.gate_no,a.ORG, a.item,substr(a.description,0,30)description,a.pono,substr(supplier_name,0,30)sup, "

        'sql &= "(ROUND (NVL ((SELECT SUM (quantity)FROM rcv_transactions WHERE po_line_id = A.POLINE and organization_id=jan_orgid(a.org)and shipment_header_id=(select shipment_header_id from 								  rcv_shipment_headers where PACKING_SLIP=a.gate_id AND  rownum=1 and SHIP_TO_ORG_ID= jan_orgid (a.org))  AND transaction_type in ('RECEIVE')  ), 0),2))+ (ROUND (NVL ((SELECT SUM (quantity)  FROM rcv_transactions WHERE po_line_id =   A.POLINE and shipment_header_id=(select shipment_header_id from   rcv_shipment_headers where PACKING_SLIP=a.gate_id AND rownum=1 and  SHIP_TO_ORG_ID= jan_orgid (a.org)) and organization_id=jan_orgid(a.org)  AND transaction_type = 'CORRECT' AND inspection_status_code = 'NOT INSPECTED'),0),2))   quantity_received, "

        'sql &= "   (SELECT receipt_num   FROM rcv_shipment_headers  WHERE packing_slip = b.gate_id   AND shipment_header_id =(select shipment_header_id from rcv_shipment_headers where PACKING_SLIP=a.gate_id  AND  rownum=1 and  	  SHIP_TO_ORG_ID= jan_orgid (a.org))) receipt_num, "

        'sql &= "  (SELECT creation_date   FROM rcv_shipment_headers WHERE packing_slip = b.gate_id  AND shipment_header_id =(select shipment_header_id from rcv_shipment_headers where PACKING_SLIP=a.gate_id AND rownum=1 and      SHIP_TO_ORG_ID= jan_orgid (a.org))) receipt_date, "

        'sql &= "  (SELECT wip_entity_name   FROM WIP_ENTITIES WHERE WIP_ENTITY_ID =(SELECT WIP_ENTITY_ID FROM po_distributions_all WHERE  po_line_id=A.POLINE and rownum=1)) jobno"

        'sql &= " ,b.mmcard,B.DC_NO    from jan_gate_lines a,jan_gatE_header b where a.gatE_no=b.gatE_no AND A.FLAG=1  "


        'If txtrole.Text.ToString.Contains("UNIT2") Then sql &= " AND UNIT='UNIT2'" Else sql &= " AND UNIT='UNIT1'"
        'If txtgate.Text <> "" Then sql &= " and a.gate_no='" & txtgate.Text & "'"
        ''If txtrole.Text = "UNIT2" Then sql &= " AND B.UNIT='UNIT2'"
        ''If txtrole.Text <> "UNIT2" Then sql &= " AND B.UNIT='UNIT1'"
        'If cmbven.SelectedItem <> "" Then sql &= " and B.vendor_id=jan_vendorno('" & cmbven.SelectedItem & "') "
        'sql &= " )"
        'sql &= "  where receipt_dAtE>=TO_DATE('" & Format(DateTimePicker1.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  receipt_dAtE<=TO_DATE('" & Format(DateTimePicker2.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "




        sql = "(select   a.gate_no,a.ORG, C.item_NO,C.ITEM_description description,C.pono,substr(supplier_name,0,30)sup ,SUM(c.quantity_received)QTY,C. receipt_num , C.receipt_date,'' JOBNO,b.mmcard,B.DC_NO,0,decode(Checked_By,'OTHERS',other_name,checked_by)Checked_By,A.REV,nvl(A.SPOT_INSPECTION,0)SPOT_INSPECTION,nvl(A.SELF_CERTIFY,0) SELF_CERTIFY  from jan_gate_lines a,jan_gatE_header b,jan_pur_listing c   where a.gatE_no=b.gatE_no and b.gate_id=c.gatE_no  and a.poline=c.po_line_id and a.flag=1  AND A.LOCATION_ID=C.LINE_LOCATION_ID  and   C.receipt_dAtE >=TO_DATE('" & Format(DateTimePicker1.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and C.receipt_dAtE<=TO_DATE('" & Format(DateTimePicker2.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and c.quantity_received>0 "

        If txtgate.Text <> "" Then sql &= " and a.gate_no='" & txtgate.Text & "'"

        If txtrole.Text.ToString.Contains("UNIT2") Then
            sql &= " AND UNIT='UNIT2'"

        ElseIf txtrole.Text = "UNIT4" Then

            sql &= " AND UNIT='UNIT4'"

        ElseIf txtrole.Text = "SKYFAST" Then

            sql &= " AND UNIT='SKYFAST'"

        ElseIf txtrole.Text = "UNIT7" Then
            sql &= " AND UNIT='UNIT7'"
        Else
            sql &= " AND UNIT='UNIT1'"
        End If

        If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "' "
        If cmbven.SelectedItem <> "" Then sql &= " and c.vendor_id=jan_vendorno('" & cmbven.SelectedItem & "') "

        sql &= "GROUP BY a.gate_no,  a.ORG,  C.item_NO,  C.ITEM_description,  C.pono,  SUBSTR(supplier_name,0,30),  C. receipt_num,  C.receipt_date,   b.mmcard,  B.DC_NO,  DECODE(Checked_By,'OTHERS',other_name,checked_by),  A.REV,   A.SPOT_INSPECTION ,        a.SELF_CERTIFY "
        sql &= " )"

        sql &= "UNION ALL"
        sql &= " (select    a.gate_no,a.ORG, D.PARTNO,D.PARTNAME description,D.pono,substr(VENDOR_name,0,30)sup ,SUM(D.quantity_received) QTY,D. receipt_num , D.receipt_date ,D.JOBNO ,b.mmcard,B.DC_NO,0,decode(Checked_By,'OTHERS',other_name,checked_by)Checked_By,a.rev, nvl(A.SPOT_INSPECTION,0)SPOT_INSPECTION,nvl(A.SELF_CERTIFY,0) SELF_CERTIFY  from jan_gate_lines a,jan_gatE_header b,jan_OSP_listing D where a.gatE_no=b.gatE_no and  a.poline=d.po_line_id and b.gate_id=D.gatE_no  and a.flag=1    and   D.receipt_dAtE>=TO_DATE('" & Format(DateTimePicker1.Value, "dd-MMM-yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and D.receipt_dAtE<=TO_DATE('" & Format(DateTimePicker2.Value, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and  D.quantity_received>0"

        If txtgate.Text <> "" Then sql &= " and a.gate_no='" & txtgate.Text & "'"

        If txtrole.Text.ToString.Contains("UNIT2") Then
            sql &= " AND UNIT='UNIT2'"

        ElseIf txtrole.Text = "UNIT4" Then

            sql &= " AND UNIT='UNIT4'"

        ElseIf txtrole.Text = "SKYFAST" Then

            sql &= " AND UNIT='SKYFAST'"
        Else
            sql &= " AND UNIT='UNIT1'"
        End If

        If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "' "
        If cmbven.SelectedItem <> "" Then sql &= " and d.vendor_id=jan_vendorno('" & cmbven.SelectedItem & "') "

        sql &= "GROUP BY a.gate_no,    a.ORG,    D.PARTNO,    D.PARTNAME,    D.pono,    SUBSTR(VENDOR_name,0,30),    D. receipt_num,    D.receipt_date,    D.JOBNO,    b.mmcard,    B.DC_NO,    DECODE(Checked_By,'OTHERS',other_name,checked_by),    a.rev,     A.SPOT_INSPECTION ,       a.SELF_CERTIFY      "

        sql &= " )"


        '   sql &= " ORDER BY   GATe_NO"

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        dgv1.DataSource = ds.Tables("resultab")
        dgv1.Columns(1).HeaderText = "Gate"
        dgv1.Columns(1).Width = 70
        dgv1.Columns(2).HeaderText = "Org"
        dgv1.Columns(2).Width = 40
        dgv1.Columns(3).HeaderText = "Item"
        dgv1.Columns(3).Width = 80
        dgv1.Columns(6).HeaderText = "Supplier"
        dgv1.Columns(6).Width = 160
        dgv1.Columns(7).HeaderText = "Qty"
        dgv1.Columns(7).Width = 55
        dgv1.Columns(8).HeaderText = "Receipt "
        dgv1.Columns(8).Width = 90
        dgv1.Columns(9).HeaderText = "Receipt.DT"
        dgv1.Columns(9).Width = 100
        dgv1.Columns(12).HeaderText = "Dc.No"
        dgv1.Columns(12).Width = 70
        ' dgv1.Columns(3).Visible = False
        dgv1.Columns(4).Visible = False
        dgv1.Columns(11).Visible = False
        dgv1.Columns(10).Visible = False
        dgv1.Columns(13).Visible = False
        dgv1.Columns(14).HeaderText = "Checked.By"
        dgv1.Columns(15).Visible = False

        dgv1.Columns(16).Visible = False
        dgv1.Columns(17).Visible = False

        dgv1.Columns(14).Width = 100
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub dgv1_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv1.CellFormatting
        If dgv1.Columns.Count > 9 Then
            If Not IsDBNull(dgv1.Rows(e.RowIndex).Cells(11).Value) Then
                e.CellStyle.ForeColor = Color.MediumVioletRed
                e.CellStyle.Font = New Font("verdana", 8)

            ElseIf dgv1.Rows(e.RowIndex).Cells(16).Value > 0 Or dgv1.Rows(e.RowIndex).Cells(17).Value > 0 Then

                dgv1.Rows(e.RowIndex).Cells(1).Style.BackColor = Color.Goldenrod



 
            Else

                e.CellStyle.ForeColor = Color.Black
            End If


        End If
    End Sub

    Private Sub dgv1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv1.CellClick
        'For k = 0 To dgv1.Rows.Count - 1
        '    dgv1.Rows(k).Cells(0).Value = False

        'Next
        j = dgv1.CurrentRow.Index
        If dgv1.CurrentCell.ColumnIndex <= 1 Then
            For i = j To dgv1.Rows.Count - 1
                ' dgv1.Rows(j).Cells(0).Value = True
                If i + 1 <= dgv1.Rows.Count - 1 Then
                    If dgv1.Rows(j).Cells(1).Value <> dgv1.Rows(i + 1).Cells(1).Value Then
                        dgv1.Rows(i).Cells(0).Value = True
                        Exit For
                    ElseIf dgv1.Rows(j).Cells(1).Value = dgv1.Rows(i + 1).Cells(1).Value And i + 1 <= dgv1.Rows.Count - 1 Then
                        dgv1.Rows(i).Cells(0).Value = True

                    End If

                End If

                If i = dgv1.Rows.Count - 1 Then dgv1.Rows(i).Cells(0).Value = True : Exit For
            Next
        End If
    End Sub
End Class