Imports System.Data.OracleClient
Public Class valreason
    Dim adap As New OracleDataAdapter
    Dim sql As String

    Private Sub save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles save.Click
        Try
            If CON.State = ConnectionState.Closed Then CON.Open()
            If reason.Text <> "" Then
                sql = "update jan_gatE_nval_Reason set action='" & reason.Text & "' ,action_dt='" & Format(Date.Today, "dd-MMM-yyyy") & "' where gate_no='" & gate.Text & "' and line_no='" & line.Text & "' "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                MessageBox.Show("Reason Saved", "Gate Entry")
            Else
                MessageBox.Show("Enter Reason", "Gate Entry")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cancel.Click
        Me.Close()
    End Sub

    Private Sub valreason_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.BringToFront()
    End Sub
End Class