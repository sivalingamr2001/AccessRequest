Imports System.Data.OracleClient
Imports oracleclass
Public Class del
    Dim sql As String
    
    Dim ds As New DataSet
    Dim lineno As String
    Dim cl As New oracleclass.Class1


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            lineno = String.Concat(Date.Today.Year, TextBox2.Text)

            sql = "SELECT  *  FROM JAN_INWARD_STATUS WHERE  GATE_NO=" & TextBox1.Text & " AND ITEM_NO='" & TextBox5.Text & "' AND PO_LINE= " & TextBox6.Text & " "
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            Dim DSITEM As New DataSet
            adap.Fill(DSITEM, "RESULTAB")
            If DSITEM.Tables("RESULTAB").Rows.Count > 0 Then
                sql = "DELETE FROM JAN_INWARD_STATUS WHERE GATE_NO=" & TextBox1.Text & " AND ITEM_NO='" & TextBox5.Text & "' AND PO_LINE= " & TextBox6.Text & " "
                If CON.State = ConnectionState.Closed Then CON.Open()
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                CON.Close()
            End If


            sql = "insert into jan_gate_del (gate_no,line_no,reason,deldate) values('" & TextBox1.Text & "','" & lineno & "','" & TextBox3.Text & "','" & Format(Date.Today, "dd-MMM-yyyy") & "')"
            If CON.State = ConnectionState.Closed Then
                CON.Open()
            End If
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            'MessageBox.Show("Delete Reason Saved", "Gate Entry")
            'Me.Hide()
            'sql = "delete from  jan_gate_lines where gate_no=" & TextBox1.Text & " and line_no=" & TextBox2.Text & ""
            'cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
            '(cl.orcmd).ExecuteNonQuery()
            'sql = "update jan_gate_header set flag='0' where GATE_NO=" & TextBox1.Text & ""
            'cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
            '(cl.orcmd).ExecuteNonQuery()

            'sql = "delete from jan_gate_nval_reason where  gate_no=" & TextBox1.Text & " and line_no=" & TextBox2.Text & ""
            'cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
            '(cl.orcmd).ExecuteNonQuery()


            sql = "update jan_gate_lines set flag='0',line_no='" & lineno & "' ,supdcqty='0',VALIDATED=1 where gate_no=" & TextBox1.Text & " and line_no=" & TextBox2.Text & ""
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            'sql = "update jan_gate_header set flag='0' where GATE_NO=" & TextBox1.Text & ""
            'cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
            '(cl.orcmd).ExecuteNonQuery()

            sql = "update jan_gate_nval_reason set flag='0',line_no='" & lineno & "' where  gate_no=" & TextBox1.Text & " and line_no=" & TextBox2.Text & ""
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub del_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.StartPosition = FormStartPosition.CenterParent
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class