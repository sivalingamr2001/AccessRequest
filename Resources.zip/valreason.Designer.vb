<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class valreason
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.gate = New System.Windows.Forms.TextBox
        Me.save = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.line = New System.Windows.Forms.TextBox
        Me.reason = New System.Windows.Forms.TextBox
        Me.cancel = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Gate No"
        '
        'gate
        '
        Me.gate.Location = New System.Drawing.Point(95, 27)
        Me.gate.Name = "gate"
        Me.gate.ReadOnly = True
        Me.gate.Size = New System.Drawing.Size(100, 20)
        Me.gate.TabIndex = 1
        '
        'save
        '
        Me.save.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.save.Location = New System.Drawing.Point(95, 137)
        Me.save.Name = "save"
        Me.save.Size = New System.Drawing.Size(75, 23)
        Me.save.TabIndex = 2
        Me.save.Text = "Save"
        Me.save.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Line No"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(35, 99)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Reason  "
        '
        'line
        '
        Me.line.Location = New System.Drawing.Point(95, 61)
        Me.line.Name = "line"
        Me.line.ReadOnly = True
        Me.line.Size = New System.Drawing.Size(100, 20)
        Me.line.TabIndex = 1
        '
        'reason
        '
        Me.reason.Location = New System.Drawing.Point(95, 96)
        Me.reason.Multiline = True
        Me.reason.Name = "reason"
        Me.reason.Size = New System.Drawing.Size(266, 20)
        Me.reason.TabIndex = 1
        '
        'cancel
        '
        Me.cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cancel.Location = New System.Drawing.Point(176, 137)
        Me.cancel.Name = "cancel"
        Me.cancel.Size = New System.Drawing.Size(75, 23)
        Me.cancel.TabIndex = 2
        Me.cancel.Text = "Cancel"
        Me.cancel.UseVisualStyleBackColor = True
        '
        'valreason
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(373, 184)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.save)
        Me.Controls.Add(Me.reason)
        Me.Controls.Add(Me.line)
        Me.Controls.Add(Me.gate)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "valreason"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gate Register-Reason"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents gate As System.Windows.Forms.TextBox
    Friend WithEvents save As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents line As System.Windows.Forms.TextBox
    Friend WithEvents reason As System.Windows.Forms.TextBox
    Friend WithEvents cancel As System.Windows.Forms.Button
End Class
