Imports System.IO
Imports System.Data.OracleClient
Imports oracleclass
Public Class newreport
    Dim fstrm As FileStream
    Dim sw As StreamWriter
    Dim d, dcval, pf, pfper, bed, bedper, cess, cessper, scess, scessper, vat, vatper, cst, cstper, ot, ttax, freight, rate, totval As Integer
    Dim dv As DataView
    Dim VEN As String


    Private Sub calfm_DateSelected(ByVal sender As Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles calfm.DateSelected
        Dim dt As Date = e.Start.ToShortDateString
        txtfm.Text = Format(dt, "dd-MMM-yyyy")
        GroupBox4.Visible = False

    End Sub



    Private Sub calto_DateSelected(ByVal sender As Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles calto.DateSelected
        Dim dt As Date = e.Start.ToShortDateString
        txtto.Text = Format(dt, "dd-MMM-yyyy")
        GroupBox5.Visible = False
    End Sub

    Private Sub btnconsolidate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnconsolidate.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select distinct a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-')org,nvl(b.rea_name,'-')rea_name,nvl(b.rea_remark,'-')rea_remark"

            If rdpo.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='PO' AND ROWNUM=1))),'-')DIV"
            ElseIf rdosp.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='OSP' AND ROWNUM=1))),'-')DIV"
            ElseIf rdser.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO   AND ROWNUM=1))),'-')DIV"
            ElseIf RDALL.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND ROWNUM=1))),'-')DIV"



            End If

            sql &= "  ,DECODE(c.CAT_ID,NULL, (SELECT trunc(MAX(C_FROM_TIME)) FROM jan_per_company_Calendar where c_id=1    and trunc(C_FROM_TIME)>(TRUNC( A.GdATE)) and c_hrs>0 and rownum<4), (SELECT trunc(MAX(C_FROM_TIME)) FROM jan_per_company_Calendar where c_id=1   and trunc(C_FROM_TIME)>(TRUNC(a.GdATE)) and c_hrs>0 and rownum<(SELECT RECEIPT_BLOCK_DAYS FROM JAN_PUR_CAT  	WHERE CAT_NO=c.CAT_ID)+1))  next_date  "

            sql &= " from jan_gate_header a,jan_gate_nval_reason b,jan_gate_lines c  where a.gatE_no=b.gate_no and a.gate_no=c.gatE_no and a.validated='2'and b.rea_code<>28 AND a.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            If UNIT7.Checked = True Then sql &= " AND A.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND A.UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND A.UNIT='UNIT4'"
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='Services'"
            If RDALL.Checked = True Then sql &= ""

            sql &= " order by a.gate_no"

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")

            j = 0

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Entry Consolidated Pending List<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " | Gate Type: "
            If rdpo.Checked = True Then s &= " " & rdpo.Text & ""
            If rdosp.Checked = True Then s &= " " & rdosp.Text & ""
            If rdser.Checked = True Then s &= " " & rdser.Text & ""
            If RDALL.Checked = True Then s &= " " & RDALL.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DIVISION</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA CODE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA REMARK</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>TARGET DATE</FONT></TH></TR>"

            For i = 0 To dsrep.Tables("RESULTAB").Rows.Count - 1
                With dsrep.Tables("RESULTAB").Rows(i)

                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("div") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("rea_remark") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("NEXT_DATE") & "</FONT></TD></TR>"
                End With
            Next
            x = "c:\gate\gate pending consolidate.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub

    Private Sub btndaily_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndaily.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            If UNIT7.Checked = True Then
                sql = "truncate table jan_gatE_daily"
            ElseIf UNIT2.Checked = True Then
                sql = "truncate table jan_gatE_daily1"
            End If

            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            If UNIT7.Checked = True Then
                daily1()
            ElseIf UNIT2.Checked = True Then
                daily()
            End If
            ' TextBox1.Text = sql
            If UNIT7.Checked = True Then
                sql = "select * from jan_gatE_daily "
            ElseIf UNIT2.Checked = True Then
                sql = "select * from jan_gatE_daily1"
            End If
            sql &= " where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') order by extract(month from gdate) "
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            j = 0
            x = "c:\gate\gate daily report.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Daily Report<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " </FONT></H2>"
            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>Gate.Date</FONT></TH>"

            s &= "<TH><FONT SIZE=1 FONT FACE=VERDANA>Total Invoice Received</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Total Invoice Cleared</FONT></TH><TH COLSPAN=10><FONT SIZE=1 FONT FACE=VERDANA>No of  problem Invoice including cleared and not cleared</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Total Problem Invoice</FONT></TH><TH colspan=7 width=200 align=center><FONT SIZE=1 FONT FACE=VERDANA>Org</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>No.Of Invoice Cleared</FONT></TH><TH ><FONT SIZE=1 FONT FACE=VERDANA>No.Of Invoice to clear</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>No.Of ADI</FONT></TH><TH ><FONT SIZE=1 FONT FACE=VERDANA>No.Of Manual Gate</FONT></TH> </TR>"

            s &= " <TR><TH COLSPAN=3>&nbsp;</TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PO ISSUES</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>TARIFF</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>TAX</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SECOND STAGE DEALER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>OSPRATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>WOP</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>EXQTY</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PORATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SERVICE BILL</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>OTHERS</FONT></TH><th colspan=1>&nbsp;</th>"
            If UNIT7.Checked = True Then
                s &= "<th width=50><FONT SIZE=1 FONT FACE=VERDANA>I02</FONT></th><th width=50><FONT SIZE=1 FONT FACE=VERDANA>I03</FONT></th><th width=50><FONT SIZE=1 FONT FACE=VERDANA>I04</FONT></th><th width=50><FONT SIZE=1 FONT FACE=VERDANA>I05</FONT></th><th width=50><FONT SIZE=1 FONT FACE=VERDANA>I06</FONT></th><th width=50><FONT SIZE=1 FONT FACE=VERDANA>I07</FONT></th><th width=50> <FONT SIZE=1 FONT FACE=VERDANA>COM</FONT></th><th colspan=4>&nbsp;</th>"
            ElseIf UNIT2.Checked = True Then
                s &= "<th width=50 colspan=7><FONT SIZE=1 FONT FACE=VERDANA>I01</FONT></th><th colspan=2>&nbsp;</th>"
            End If
            s &= "</TR> "
            Dim a, a1, b, c, d, f, adi, gate As Double
            a = 0 : a1 = 0 : b = 0 : c = 0 : d = 0 : f = 0 : adi = 0 : gate = 0
            Dim po, po1, tr, tr1, tax, tax1, amend, amend1, osp, osp1, wop, wop1, ex, ex1, por, por1, ser, ser1, ot, ot1, grec, grec1, gcl, gcl1, gpr, gpr1, i02, i03, i04, i05, i06, i07, com, i01 As Double
            po = 0 And tr = 0 And tax = 0 And amend = 0 And osp = 0 And wop = 0 And ex = 0 And por = 0 And ser = 0 And ot = 0 And grec = 0 And gcl = 0 And gpr = 0 And i02 = 0 And i03 = 0 And i04 = 0 And i05 = 0 And i06 = 0 And i07 = 0 And com = 0 And i01 = 0

            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1
                With dsrep.Tables("resultab").Rows(i)
                    a = .Item("poissue") + .Item("tariff") + .Item("tax") + .Item("amend") + .Item("osprate") + .Item("wop") + .Item("exqty") + .Item("porate") + .Item("service") + .Item("others")
                    a1 = .Item("gate_no") - a
                    If a - (.Item("gate_no") - .Item("gclear")) < 0 Then
                        b = 0 : c = a
                    Else
                        b = a - (.Item("gate_no") - .Item("gclear")) : c = (.Item("gate_no") - .Item("gclear"))
                    End If
                    grec = .Item("gate_no") : grec1 = grec + grec1
                    gcl = a1 : gcl1 = gcl + gcl1
                    gpr = a : gpr1 = gpr + gpr1
                    po = .Item("poissue") : po1 = po + po1
                    tr = .Item("tariff") : tr1 = tr + tr1
                    tax = .Item("tax") : tax1 = tax + tax1
                    amend = .Item("amend") : amend1 = amend + amend1
                    osp = .Item("osprate") : osp1 = osp + osp1
                    wop = .Item("wop") : wop1 = wop + wop1
                    ex = .Item("exqty") : ex1 = ex + ex1
                    por = .Item("porate") : por1 = por1 + por
                    ser = .Item("service") : ser1 = ser1 + ser
                    ot = .Item("others") : ot1 = ot + ot1
                    If UNIT7.Checked = True Then
                        i02 = .Item("i02") + i02
                        i03 = .Item("i03") + i03
                        i04 = .Item("i04") + i04
                        i05 = .Item("i05") + i05
                        i06 = .Item("i06") + i06
                        i07 = .Item("i07") + i07
                        com = .Item("com") + com
                    ElseIf UNIT2.Checked = True Then
                        i01 = .Item("i01") + i01
                    End If
                    d = b + d : f = c + f : adi = .Item("adi") + adi : gate = .Item("gatE_no") - .Item("adi")
                    s &= "<TR><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gdate") & "</FONT></TD>"
                    s &= "<TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gate_no") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gclear") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("poissue") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("tariff") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("tax") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("amend") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("osprate") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("wop") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("exqty") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("porate") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("service") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("others") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & a & "</FONT></TD>"
                    If UNIT7.Checked = True Then
                        s &= " <TD align=right width=50><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("i02") & "</FONT></TD><TD width=50 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("i03") & "</FONT></TD><TD width=50 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("i04") & "</FONT></TD><TD align=right width=50><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("i05") & "</FONT></TD><TD width=50 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("i06") & "</FONT></TD><TD width=50 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("i07") & "</FONT></TD><TD width=50 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("com") & "</FONT></TD>"
                    ElseIf UNIT2.Checked = True Then
                        s &= " <TD align=right width=50 colspan=7><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("i01") & "</FONT></TD>"
                    End If
                    s &= "<TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & b & "</FONT></TD><TD width=50 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & c & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("adi") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gatE_no") - .Item("adi") & "</FONT></TD></TR>"
                End With
            Next
            s &= "<tr><td colspan=1 align=center> <font face=verdana size=2> <b>Total</b></font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & grec1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & gcl1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & po1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & tr1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & tax1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & amend1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & osp1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & wop1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & ex1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & por1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & ser1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & ot1 & "</FONT></TD><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & gpr1 & "</FONT></TD>"
            If UNIT7.Checked = True Then
                s &= "<td align=right width=70><FONT SIZE=2 FONT FACE=VERDANA>" & i02 & "</FONT></TD><td  width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & i03 & "</FONT></TD><td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & i04 & "</FONT></TD><td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & i05 & "</FONT></TD><td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & i06 & "</FONT></TD><td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & i07 & "</FONT></TD><td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & com & "</FONT></TD>"
            ElseIf UNIT2.Checked = True Then
                s &= "<td align=right width=70 colspan=7><FONT SIZE=2 FONT FACE=VERDANA>" & i01 & "</FONT>"
            End If

            s &= " <td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & d & "</FONT></TD><td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & f & "</FONT></TD> <td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & adi & "</FONT></TD><td width=70 align=right><FONT SIZE=2 FONT FACE=VERDANA>" & (grec1 - adi) & "</FONT></TD></TR>"
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cl.oracon.Close()
        End Try
    End Sub

    Private Sub btncancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancel.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select distinct a.gate_no,a.gdate,a.supplier_name,a.supplier_site,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,NVL(A.ORG,'-')ORG,a.reason,NVL(A.REAREF,'-')REAREF from jan_gate_header a,jan_gate_nval_reason b where a.gatE_no=b.gate_no and a.validated='5'and b.rea_code<>8 AND a.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            If UNIT7.Checked = True Then sql &= " AND A.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND A.UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & ""
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='Services'"
            If RDALL.Checked = True Then sql &= ""
            sql &= " and a.reason is not null"

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")

            j = 0
            x = "c:\gate\gate cancel entry.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Cancel Entries<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " <br> Supplier: " & cmbsup.SelectedItem & " | Org :" & cmborg.SelectedItem & " | Gate Type: "
            If rdpo.Checked = True Then s &= " " & rdpo.Text & ""
            If rdosp.Checked = True Then s &= " " & rdosp.Text & ""
            If rdser.Checked = True Then s &= " " & rdser.Text & ""
            If RDALL.Checked = True Then s &= " " & RDALL.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER SITE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REASON</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REASON REMARK</FONT></TH></TR>"

            For i = 0 To dsrep.Tables("RESULTAB").Rows.Count - 1
                With dsrep.Tables("RESULTAB").Rows(i)
                    If .Item("reason").ToString <> "" Then a = .Item("reason") Else a = "-"
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_site") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & a & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REAREF") & "</FONT></TD></TR>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub

    Private Sub btnrtv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrtv.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select distinct a.gate_no,a.gdate,a.supplier_name,a.supplier_site,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-')org,nvl(c.transport,'-')transport,nvl(c.docno,'-') docno,nvl(c.qty,0)qty,nvl(c.wt,0)wt,nvl(c.terms,'-')terms,nvl(c.amt,0)amt,nvl(c.remark,'-')remark from jan_gate_header a,jan_gate_nval_reason b ,jan_gate_rtv c where a.gate_no=c.gatE_no and a.gatE_no=b.gate_no and a.validated='4'and b.rea_code<>8 AND a.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and c.flag <> 0"

            If UNIT7.Checked = True Then sql &= " AND A.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND A.UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='Services'"
            If RDALL.Checked = True Then sql &= ""
            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            j = 0
            x = "c:\gate\Gate  RTV Report.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate (RTV) Entries<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " <br> Supplier:" & cmbsup.SelectedItem & " | Org:" & cmborg.SelectedItem & " | Gate Type: "
            If rdpo.Checked = True Then s &= " " & rdpo.Text & ""
            If rdosp.Checked = True Then s &= " " & rdosp.Text & ""
            If rdser.Checked = True Then s &= " " & rdser.Text & ""
            If RDALL.Checked = True Then s &= " " & RDALL.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=900><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER SITE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>MODE OF TRANSPORT</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DOCKET NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>NO OF BOX</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>WT(KGS)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>TERMS</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REMARK</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>TOTAL AMOUNT</FONT></TH></TR>"
            Dim a As Double = 0
            For i = 0 To dsrep.Tables("RESULTAB").Rows.Count - 1
                With dsrep.Tables("RESULTAB").Rows(i)
                    a = .Item("amt") + a
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("supplier_site") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD ><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD width=100><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("transport") & "</FONT></TD><TD width=100><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("docno") & "</FONT></TD><TD width=70 align=right><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("qty") & "</FONT></TD><TD width=70 align=right><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("wt") & "</FONT></TD><TD width=100><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("terms") & "</FONT></TD><TD width=100><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("remark") & "</FONT></TD><TD width=100 align=right><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("amt") & "</FONT></TD></TR>"
                End With
            Next
            s &= "<tr><td colspan=15 align=right><font size=2 FONT FACE=VERDANA><b>TOTAL</b></td><td align=right><font size=2 FONT FACE=VERDANA><b>" & a & "</b></td></tr>"
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub

    Private Sub btnpoamend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpoamend.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            amend1()
            x = "c:\gate\gate amendment status .HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)


            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Invoice Amendment Status<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " </FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>Month</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Total No of Invoice Received</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>No of Invoice given for Amendments</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>No of  Invoice Rectified</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>No of Invoice Pending</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>% of Amendment</FONT></TH></TR>"
            Dim a, b, c, d, f As Double
            a = 0 And b = 0 And c = 0 And d = 0 And f = 0
            For i = 0 To dsrep.Tables("RESULTAB").Rows.Count - 1
                With dsrep.Tables("RESULTAB").Rows(i)
                    a = .Item("gate") + a
                    b = .Item("amend") + b
                    c = Math.Abs(.Item("amend") - .Item("clear")) + c
                    d = .Item("clear") + d
                    f = Math.Round((.Item("amend") / .Item("gate")) * 100, 2) + f
                    s &= "<TR><TD><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("month") & "," & .Item("yr") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gate") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("amend") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("clear") & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Abs(.Item("amend") - .Item("clear")) & "</FONT></TD><TD align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round((.Item("amend") / .Item("gate")) * 100, 2) & "</FONT></TD></TD></TR>"
                End With
            Next
            s &= "<tr><Td>&nbsp;</td><td align=right><font face=verdana size=2> " & a & "</font></td><td align=right><font face=verdana size=2> " & b & "</font></td><td align=right><font face=verdana size=2> " & d & "</font></td><td align=right><font face=verdana size=2> " & c & "</font></td><td align=right><font face=verdana size=2> " & Math.Round((b / a) * 100, 2) & "</font></td></tr>"
            tail()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub btninward_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninward.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            Dim d As Date = DateAdd("d", -1, txtto.Text)

            sql = " select w.*,(select count(*) from jan_gatE_header where VALIDATED=0 AND trunc(gdate)='" & txtto.Text & "' AND"
            If UNIT7.Checked = True Then sql &= " UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"
            sql &= ") inreceived,"

            sql &= "(select count(*) from jan_gatE_header where trunc(gdate)='" & txtto.Text & "'AND "
            If UNIT7.Checked = True Then sql &= " UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            sql &= "and validated=2)inpending ,"

            sql &= "(select count(*) from jan_gatE_header where   VALIDATED NOT IN (5,4)AND trunc(gdate)='" & txtto.Text & "' AND"
            If UNIT7.Checked = True Then sql &= " UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"
            sql &= ")invaltot ,"

            sql &= "(select count(*)  from jan_gate_header where VALIDATED NOT IN (5,4)AND gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') AND "
            If UNIT7.Checked = True Then sql &= "UNIT='UNIT7' "
            If UNIT2.Checked = True Then sql &= "UNIT='UNIT2' "
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            sql &= "  AND gdate<=TO_DATE('" & Format(d, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS'))invaltot1,"


            sql &= " (select count(*)inpendingtot from jan_gate_header where validated=2 and gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') AND "
            If UNIT7.Checked = True Then sql &= " UNIT='UNIT7'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If UNIT2.Checked = True Then sql &= " UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            sql &= "and gdate<=TO_DATE('" & Format(d, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS'))inpendingtot, "

            sql &= "(SELECT COUNT(DISTINCT GATE_NO) FROM JAN_PUR_LISTING_BACKUP WHERE TRUNC(gDATE)='" & txtto.Text & "' AND"
            If UNIT7.Checked = True Then sql &= " TO_ORGANIZATION_ID    in (444,464,484,504,524,505)"
            If UNIT2.Checked = True Then sql &= " TO_ORGANIZATION_ID=104"
            If RD3.Checked = True Then sql &= " TO_ORGANIZATION_ID =144"
            If RDSKY.Checked = True Then sql &= " TO_ORGANIZATION_ID   IN (224,225)"
            sql &= ") ACRECEIVED ,"

            sql &= "(SELECT COUNT(DISTINCT GATE_NO) FROM JAN_PUR_LISTING_BACKUP WHERE gdATE>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') AND "
            If UNIT7.Checked = True Then sql &= " TO_ORGANIZATION_ID    in (444,464,484,504,524,505) "
            If UNIT2.Checked = True Then sql &= " TO_ORGANIZATION_ID=104"
            If RD3.Checked = True Then sql &= " TO_ORGANIZATION_ID =144"
            If RDSKY.Checked = True Then sql &= " TO_ORGANIZATION_ID   IN (224,225)"
            sql &= " and gDATE<=TO_DATE('" & Format(d, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') ) ACreceivedtot, "

            sql &= "(SELECT COUNT(DISTINCT GATE_NO) FROM JAN_osp_LISTING_BACKUP WHERE TRUNC(gDATE)='" & txtto.Text & "' AND "
            If UNIT7.Checked = True Then sql &= "TO_ORGANIZATION_ID    in (444,464,484,504,524,505)"
            If UNIT2.Checked = True Then sql &= "TO_ORGANIZATION_ID=104"
            If RD3.Checked = True Then sql &= " TO_ORGANIZATION_ID =144"
            If RDSKY.Checked = True Then sql &= " TO_ORGANIZATION_ID  IN (224,225)"

            sql &= ") ACRECEIVED1 ,"

            sql &= " (SELECT COUNT(DISTINCT GATE_NO) FROM JAN_osp_LISTING_BACKUP WHERE gdATE>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') AND "
            If UNIT7.Checked = True Then sql &= "TO_ORGANIZATION_ID    in (444,464,484,504,524,505) "
            If UNIT2.Checked = True Then sql &= "TO_ORGANIZATION_ID=104 "
            If RD3.Checked = True Then sql &= " TO_ORGANIZATION_ID =144"
            If RDSKY.Checked = True Then sql &= " TO_ORGANIZATION_ID  IN (224,225)"

            sql &= " and gDATE<=TO_DATE('" & Format(d, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') ) ACreceivedtot1 "

            sql &= "  from (select count(*)inreceivedtot from jan_gate_header where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') AND "
            If UNIT7.Checked = True Then sql &= "UNIT='UNIT7' "
            If UNIT2.Checked = True Then sql &= "UNIT='UNIT2' "
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            sql &= "  AND VALIDATED=0 and gdate<=TO_DATE('" & Format(d, "dd-MMM-yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')) w "
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            j = 0
            x = "c:\gate\Gate Inward Status Report.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Inward Status Report<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " "
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=600><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>Particulars</FONT></TH><TH colspan=2 ><FONT SIZE=2 FONT FACE=VERDANA>Accounts</FONT></TH><TH colspan=2 width=200><FONT SIZE=2 FONT FACE=VERDANA>Central Excise(Inward)</FONT></TH></TR>"
            s &= "<tr><th>&nbsp;</th> <th width=120><FONT SIZE=1.5 FONT FACE=VERDANA>From " & txtfm.Text & " <br>to " & Format(DateAdd("d", -1, txtto.Text), "dd-MMM-yyyy") & "</FONT></TH><th width=120><FONT SIZE=1.5 FONT FACE=VERDANA>On " & txtto.Text & "</FONT></TH><th width=120><FONT SIZE=1.5 FONT FACE=VERDANA>From " & txtfm.Text & " <br>to " & Format(DateAdd("d", -1, txtto.Text), "dd-MMM-yyyy") & "</FONT></TH><th width=120><FONT SIZE=1.5 FONT FACE=VERDANA>On " & txtto.Text & "</FONT></TH></tr>"
            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1
                With dsrep.Tables("resultab").Rows(i)
                    s &= "<tr><td width=150><FONT SIZE=2 FONT FACE=VERDANA>Total No of Invoice Received(Nos)</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("invaltot1") & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("invaltot") & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & (.Item("inVALtot1") - .Item("inpendingtot")) & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & (.Item("inVALTOT") - .Item("inpending")) & "</font></td></tr>"

                    '  s &= "<tr><td width=150><FONT SIZE=2 FONT FACE=VERDANA>Total No of Invoice Pending(Nos)</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("inpendingtot") & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("inpending") & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & ((.Item("inreceivedtot") - .Item("inpendingtot")) - (.Item("ACreceivedtot") + .Item("acreceivedtot1"))) & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & ((.Item("inpendingtot") - .Item("inpending")) - (.Item("ACreceived") + .Item("acreceived1"))) & "</font></td></tr> "

                    s &= "<tr><td width=150><FONT SIZE=2 FONT FACE=VERDANA>Total No of Invoice Pending(Nos)</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("inpendingtot") & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("inpending") & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & (.Item("INRECEIVEDTOT") - (.Item("acreceivedtot") + .Item("acreceivedtot1"))) & "</font></td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & (.Item("inreceived") - (.Item("acreceived") + .Item("acreceived1"))) & "</font></td></tr> "
                    '((.Item("inreceivedtot") - (.Item("acreceivedtot") + .Item("acreceivedtot1"))) - .Item()
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub

    Public Sub tail()
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
    End Sub

    Private Sub newreport_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtrole.Text = Gate.txtrole.Text
        sql = "SELECT distinct supplier_name From jan_gate_header order by supplier_name "
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        Dim dsup As New DataSet
        adap.Fill(dsup, "RESULTAB")
        For i = 0 To dsup.Tables("resultab").Rows.Count - 1
            cmbsup.Items.Add(dsup.Tables("resultab").Rows(i).Item("supplier_name").ToString.Replace("'", "''"))
        Next
        'If txtrole.Text = "UNIT4" Then
        '    RD3.Checked = True
        '    UNIT2.Enabled = False
        '    UNIT7.Enabled = False

        'ElseIf txtrole.Text.Contains("UNIT2") Then
        '    UNIT2.Checked = True
        '    RD3.Enabled = False
        '    UNIT7.Enabled = False

        'Else
        '    UNIT7.Checked = True
        '    UNIT2.Enabled = False
        '    RD3.Enabled = False

        'End If
        sql = "select organization_code  from org_organization_definitions where organization_code  not in('I08','I09')order by organization_code"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        Dim d1 As New DataSet
        adap.Fill(d1, "resultab")
        For i = 0 To d1.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(d1.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntime.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "SELECT GATE_ID, (select GDATE from jan_gate_header where gate_id=a.gate_id)gdate,SUPPLIER_NAME,(select supplier_Site from jan_gate_header where supplier_name=a.supplier_name and rownum=1)site,"
            sql &= " (case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_ID and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_ID and rownum=1 and flag<>0)  else (SELECT gtype FROM JAN_GATE_HEADER WHERE  GATE_NO=A.GATE_ID ) end ) gtype,ORG,"
            sql &= " (select dc_no from jan_gate_header where gate_id=a.gate_id) dc,(select dc_date from jan_gate_header where gate_id=a.gate_id)dcdate,(Select  MAX(reaSON_dAtE) from jan_gatE_nval_reason where gate_no=a.gate_id and rea_name in ('NO PROBLEM'))VALIDATE_DATE,nvl(RECEIPT_NOS,'-')RECEIPT_NOS,receipt_date,insp_date, delivered_Date,"
            sql &= "nvl((select VOUCHER_NUM||''/''||TO_CHAR(INVOICE_DATE) FROM ap_invoices_all where attribute4=a.gate_id and rownum=1),'-') VOUCHER_NOS"
            sql &= ",nvl(PAY_VOUCHER_NOS,'-')PAY_VOUCHER_NOS,(select pay_date from jan_pur_listing where gate_no=a.gate_id and rownum=1)paydt"
            sql &= "  FROM JAN_PROCURE_TO_PAY a where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and dc_qty>0  "
            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7' "
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2' "
            If RDSKY.Checked = True Then sql &= " AND UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "

            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem & "'"
            If txtgfm.Text <> "" And txtgto.Text <> "" Then sql &= " and gate_id>='" & txtgfm.Text & "' and gate_id<='" & txtgto.Text & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_ID=A.GATE_ID and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_ID=A.GATE_ID and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_ID=A.GATE_ID and rownum=1)='Services'"
            If RDALL.Checked = True Then sql &= ""
            sql &= "order by gate_id"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracontest)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            j = 0
            x = "c:\gate\Time Study Report.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Time Study Gate Report<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & "<br> Supplier: " & cmbsup.SelectedItem & "| Org:" & cmborg.SelectedItem & "  <br> Gate No: " & txtgfm.Text & " | " & txtgto.Text & "  | Gate Type: "
            If rdpo.Checked = True Then s &= " " & rdpo.Text & ""
            If rdosp.Checked = True Then s &= " " & rdosp.Text & ""
            If rdser.Checked = True Then s &= " " & rdser.Text & ""
            If RDALL.Checked = True Then s &= " " & RDALL.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SITE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GTYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC.NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>VALIDATE DT</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>MRIR NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>MRIR DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>INSP DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DEL DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>VOUCHER NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PAY NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PAY DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Invoice Arrival Time(In Hrs)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Time Of Gt.Validation(In Hrs)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Time Of Receipt(In Hrs)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Time Of Insp(In Hrs)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Time Of Dlyd(In Hrs)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Time Of Pay(In Days)</FONT></TH></TR>"

            Dim recpt, val, del, inspt, payd, g, f, H, gate, insp, pay, dc, dcdiff As String

            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1
                With dsrep.Tables("resultab").Rows(i)
                    j += 1
                    gate = .Item("gdate")
                    If .Item("receipt_date").ToString = "" Then H = "-" Else H = .Item("receipt_date")
                    If .Item("validate_date").ToString = "" Then g = "-" Else g = .Item("validate_date")
                    If .Item("delivered_date").ToString = "" Then f = "-" Else f = .Item("delivered_date")
                    If .Item("insp_date").ToString = "" Then insp = "-" Else insp = .Item("insp_date")
                    If .Item("paydt").ToString = "" Then pay = "-" Else pay = .Item("paydt")
                    If .Item("dcdate").ToString = "" Then dc = "-" Else dc = String.Concat(Format(.Item("dcdate"), "dd-MMM-yyyy"), " 9:00:00 AM")

                    If g = "-" Then recpt = "-" Else If H = "-" Then recpt = "-" Else recpt = DateDiff("h", g, H)
                    If g = "-" Then val = "-" Else val = DateDiff("h", gate, g)
                    If insp = "-" Then del = "-" Else If f = "-" Then del = "-" Else del = DateDiff("h", insp, f)
                    If H = "-" Then inspt = "-" Else If insp = "-" Then inspt = "-" Else inspt = DateDiff("h", H, insp)
                    If pay = "-" Then payd = "-" Else payd = DateDiff("d", gate, pay)
                    dcdiff = DateDiff("h", dc, gate)

                    s &= "<TR><Td><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_ID") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("ORG") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SITE") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("dc") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("dcdate") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & g & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("RECEIPT_NOS") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & H & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & insp & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & f & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("VOUCHER_NOS") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("PAY_VOUCHER_NOS") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & pay & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & dcdiff & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & val & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & recpt & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & inspt & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & del & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & payd & " </FONT></Td></TR>"
                End With
            Next
            tail()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub

    Public Sub daily()
        Dim dt As Integer = DateDiff("d", txtfm.Text, txtto.Text)
        For i = 0 To dt
            sql = "insert into jan_Gate_daily1 (gate_no,gdate,poissue,tariff,tax,amend,osprate,wop,exqty,porate,service,others,gclear,i01)values((select count(*) from jan_gatE_header where gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2')"

            sql &= ",  '" & Format(DateAdd("d", i, txtfm.Text), "dd-MMM-yyyy") & "'"

            sql &= ", (select count(*) from jan_gate_nval_reason where rea_code=1 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2' and flag is null ) "

            sql &= " ,(select count(*) from jan_gate_nval_reason where rea_code=2 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and unit='UNIT2' and flag is null ) "

            sql &= ",(select  count(*) from jan_gate_nval_reason where rea_code=3 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and unit='UNIT2' and flag is null )"

            sql &= ", (select  count(*) from jan_gate_nval_reason where rea_code=5 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and unit='UNIT2' and flag is null ) ,"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=6 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2' and flag is null )  ,"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=10 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=11 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and unit='UNIT2' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=12 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=19 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code not in(1,2,3,5,6,10,11,12,19,8) and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2' and flag is null and org='I01'),"

            sql &= "(select  count(*) from jan_gate_header where  validated<>2 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT2')"
            sql &= ")"
            If cl.oracon.State = ConnectionState.Closed Then CON.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
        Next
    End Sub

    Public Sub daily1()
        Dim dt As Integer = DateDiff("d", txtfm.Text, txtto.Text)
        For i = 0 To dt
            sql = "insert into jan_Gate_daily (gate_no,gdate,poissue,tariff,tax,amend,osprate,wop,exqty,porate,service,others,i03,i04,i05,i06,i07,com,i02,gclear,ADI,GATE)values((select count(*) from jan_gatE_header where gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT7')"

            sql &= ",  '" & Format(DateAdd("d", i, txtfm.Text), "dd-MMM-yyyy") & "'"

            sql &= ", (select count(*) from jan_gate_nval_reason where rea_code=1 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null ) "

            sql &= " ,(select count(*) from jan_gate_nval_reason where rea_code=2 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and UNIT='UNIT7' and flag is null ) "

            sql &= ",(select  count(*) from jan_gate_nval_reason where rea_code=3 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and UNIT='UNIT7' and flag is null )"

            sql &= ", (select  count(*) from jan_gate_nval_reason where rea_code=5 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and UNIT='UNIT7' and flag is null ) ,"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=6 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null )  ,"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=10 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=11 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and UNIT='UNIT7' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=12 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=19 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code not in(1,2,3,5,6,10,11,12,19,8) and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null ),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null and org='I03'),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null and org='I04'),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null and org='I05'),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null and org='I06'),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null and org='I07'),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null and org='COM'),"

            sql &= "(select  count(*) from jan_gate_nval_reason where rea_code <>8 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and UNIT='UNIT7' and flag is null and org='I02'),"

            sql &= "(select  count(*) from jan_gate_header where  validated<>2 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT7'),"

            sql &= "(select  count(*) from jan_gate_header where  ADI_NO IS NOT NULL and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT7'),"

            sql &= "(select  count(*) from jan_gate_header where  ADI_REASON IS NOT NULL and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT7')"


            sql &= ")"
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
        Next
    End Sub

    Private Sub btnadi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadi.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select DISTINCT w.*, "

            sql &= "(select count(*) from jan_gatE_header where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')AND ORG=G.ORG   and adi_no is not null and supplier_name=w.supplier_name  "
            If UNIT7.Checked = True Then sql &= " AND  UNIT='UNIT7'  "
            If UNIT2.Checked = True Then sql &= " AND  UNIT='UNIT2'  "
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            sql &= ")adi ,"

            sql &= " (select count(*)  from jan_gatE_header where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and ORG=G.ORG AND supplier_name=w.supplier_name  and validated in ('0','1')  "
            If UNIT7.Checked = True Then sql &= " AND  UNIT='UNIT7' "
            If UNIT2.Checked = True Then sql &= " AND  UNIT='UNIT2' "
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"

            sql &= ") gate ,G.ORG"

            sql &= " from  (select supplier_name from jan_gatE_supplier where type='ADI' order by supplier_name)w,jan_gatE_header G WHERE G.SUPPLIER_NAME=W.SUPPLIER_NAME AND G.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and G.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"
            If UNIT7.Checked = True Then sql &= " AND  UNIT='UNIT7' "
            If UNIT2.Checked = True Then sql &= " AND  UNIT='UNIT2' "
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")

            i06 = 0 : i02 = 0 : i03 = 0 : i04 = 0 : i05 = 0 : i066 = 0 : i022 = 0 : i033 = 0 : i044 = 0 : i055 = 0 : I07 = 0 : I077 = 0 : COM = 0 : COM1 = 0 : a = 0 : f = 0 : g = 0 : h = 0 : m = 0 : n = 0 : re5 = 0 : re1 = 0 : re2 = 0 : re3 = 0 : re4 = 0 : re6 = 0 : re7 = 0 : o = 0 : p = 0
            j = 1
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Inward-ADI Vendor Report <BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=650><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA width=80>Vendor Name</FONT></TH><TH COLSPAN=3><FONT SIZE=2 FONT FACE=VERDANA>I02</FONT></TH><TH COLSPAN=3><FONT SIZE=2 FONT FACE=VERDANA>I03</FONT></TH><TH COLSPAN=3><FONT SIZE=2 FONT FACE=VERDANA>I04</FONT></TH><TH COLSPAN=3><FONT SIZE=2 FONT FACE=VERDANA>I05</FONT></TH><TH COLSPAN=3><FONT SIZE=2 FONT FACE=VERDANA>I06</FONT></TH><TH COLSPAN=3><FONT SIZE=2 FONT FACE=VERDANA>I07</FONT></TH><TH COLSPAN=3><FONT SIZE=2 FONT FACE=VERDANA>COM</FONT></TH></TR>"

            s &= "<TR><TD COLSPAN=2>&nbsp;</td><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>Gate</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI(%)</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>Gate</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI(%)</FONT></TD> <TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>Gate</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI(%)</FONT></TD> <TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>Gate</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI(%)</FONT></TD> <TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>Gate</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI(%)</FONT></TD> <TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>Gate</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI(%)</FONT></TD> <TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>Gate</FONT></TD><TD width=40><FONT SIZE=2 FONT FACE=VERDANA><b>ADI(%)</FONT></TD></tr><TR>"


            Dim b, c As Double
            b = 0 : c = 0
            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1

                With dsrep.Tables("resultab").Rows(i)
                    VEN = .Item("supplier_name")
                    If i + 1 <= dsrep.Tables("resultab").Rows.Count - 1 Then
                        If i = 0 Then
                            s &= "<TD><font face=verdana size=2>" & 1 & "</font></TD><td width=50><font face=verdana size=2>" & .Item("supplier_name") & "</font></td>"
                            If i <> 0 And VEN <> dsrep.Tables("resultab").Rows(i + 1).Item("supplier_name") Then
                                s &= "<TD><font face=verdana size=2>" & j & "</font></TD><td width=50><font face=verdana size=2>" & .Item("supplier_name") & "</font></td>"
                                po()
                            Else
                                po()
                            End If
                        Else
                            po()
                        End If
                    Else
                        po()
                    End If
                End With
            Next
            s &= "<tr><td colspan=2>&nbsp;</td><TD WIDTH=70 align=right><font face=verdana size=2>" & Math.Round((f), 0) & "</font></TD><TD WIDTH=50 align=right><font face=verdana size=2>" & Math.Round((re1), 0) & "</font></td>"
            If f = 0 And re1 = 0 Then b = 0 Else b = Math.Round((f / re1) * 100, 2)
            s &= "<td width=50 align=right><font face=verdana size=2> <b>" & b & "</b> </font></td>"

            s &= "<TD WIDTH=70 align=right><font face=verdana size=2>" & Math.Round((g), 0) & "</font></TD><TD WIDTH=50 align=right><font face=verdana size=2>" & Math.Round((re2), 0) & "</font></td>"
            If g = 0 And re2 = 0 Then b = 0 Else b = Math.Round((g / re2) * 100, 2)
            s &= "<td width=50 align=right><font face=verdana size=2> <b>" & b & "</b> </font></td>"

            s &= "<TD WIDTH=70 align=right><font face=verdana size=2>" & Math.Round((h), 0) & "</font></TD><TD WIDTH=50 align=right><font face=verdana size=2>" & Math.Round((re3), 0) & "</font></td>"
            If h = 0 And re3 = 0 Then b = 0 Else b = Math.Round((h / re3) * 100, 2)
            s &= "<td width=50 align=right><font face=verdana size=2> <b>" & b & "</b> </font></td>"

            s &= " <TD WIDTH=70 align=right><font face=verdana size=2>" & Math.Round((m), 0) & "</font></TD><TD WIDTH=50 align=right><font face=verdana size=2>" & Math.Round((re4), 0) & "</font></td>"
            If m = 0 And re4 = 0 Then b = 0 Else b = Math.Round((m / re4) * 100, 2)
            s &= "<td width=50 align=right><font face=verdana size=2> <b>" & b & "</b> </font></td>"

            s &= " <TD WIDTH=70 align=right><font face=verdana size=2>" & Math.Round((n), 0) & "</font></TD><TD WIDTH=50 align=right><font face=verdana size=2>" & Math.Round((re5), 0) & "</font></td>"
            If n = 0 And re5 = 0 Then b = 0 Else b = Math.Round((n / re5) * 100, 2)
            s &= "<td width=50 align=right><font face=verdana size=2> <b>" & b & "</b> </font></td>"

            s &= "<TD WIDTH=70 align=right><font face=verdana size=2>" & Math.Round((o), 0) & "</font></TD><TD WIDTH=50 align=right><font face=verdana size=2>" & Math.Round((re6), 0) & "</font></td>"
            If o = 0 And re6 = 0 Then b = 0 Else b = Math.Round((o / re6) * 100, 2)
            s &= "<td width=50 align=right><font face=verdana size=2> <b>" & b & "</b> </font></td>"

            s &= " <TD WIDTH=70 align=right><font face=verdana size=2>" & Math.Round((p), 0) & "</font></TD><TD WIDTH=50 align=right><font face=verdana size=2>" & Math.Round((re7), 0) & "</font></td>"
            If p = 0 And re7 = 0 Then b = 0 Else b = Math.Round((p / re7) * 100, 2)
            s &= "<td width=50 align=right><font face=verdana size=2> <b>" & b & "</b> </font></td></tr></table>"
            s &= "<table><font face=verdana size=2>Over- All Total ADI:<b>" & Math.Round((f + g + h + m + n + o + p), 0) & "</b></font> <br>"

            s &= "<font face=verdana size=2>Over- All Total Gate:<b>" & Math.Round((re1 + re2 + re3 + re4 + re5 + re6 + re7), 0) & "</b></font><br>"

            s &= " <font face=verdana size=2>Over- All ADI(%):<b>" & Math.Round(((((f + g + h + m + n + o + p) / (re1 + re2 + re3 + re4 + re5 + re6 + re7))) * 100), 2) & "</b></font><br>"
            x = "c:\gate\ADI Vendor List.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            '   MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub
    Dim i06, i02, i03, i04, i05, I07, COM, i066, i022, i033, i044, i055, I077, COM1, a As Integer
    Dim f, g, h, m, n, o, p, re5, re1, re2, re3, re4, re6, re7 As Double
#Region "For adi"

    Public Sub po()

        With dsrep.Tables("resultab").Rows(i)

            If .Item("org") = "I02" Then
                i02 = .Item("ADI")
                i022 = .Item("GATE")
                f = .Item("adi") + f
                re1 = .Item("gate") + re1

            End If
            If .Item("org") = "I03" Then
                i03 = .Item("ADI")
                i033 = .Item("GATE")
                g = .Item("adi") + g
                re2 = .Item("gate") + re2
            End If
            If .Item("org") = "I04" Then
                i04 = .Item("ADI")
                i044 = .Item("GATE")
                h = .Item("adi") + h
                re3 = .Item("gate") + re3
            End If
            If .Item("org") = "I05" Then
                i05 = .Item("ADI")
                i055 = .Item("GATE")
                m = .Item("adi") + m
                re4 = .Item("gate") + re4
            End If
            If .Item("org") = "I06" Then
                i06 = .Item("ADI")
                i066 = .Item("GATE")
                n = .Item("adi") + n
                re5 = .Item("gate") + re5
            End If
            If .Item("org") = "I07" Then
                I07 = .Item("ADI")
                I077 = .Item("GATE")
                o = .Item("adi") + o
                re6 = .Item("gate") + re6
            End If
            If .Item("org") = "COM" Then
                COM = .Item("ADI")
                COM1 = .Item("GATE")
                p = .Item("adi") + p
                re7 = .Item("gate") + re7
            End If

            If i + 1 <= dsrep.Tables("resultab").Rows.Count - 1 Then
                If VEN <> dsrep.Tables("resultab").Rows(i + 1).Item("SUPPLIER_NAME") Then
                    print()
                    j += 1
                    s &= "<tr><font face=verdana size=2><TD>" & j & "</font></TD><td width=80><font face=verdana size=2>" & dsrep.Tables("resultab").Rows(i + 1).Item("SUPPLIER_NAME") & "</font></td>"
                End If
            Else
                print()
            End If
        End With
    End Sub
    Public Sub print()

        s &= " <td width=50 align=right><font face=verdana size=2>" & i02 & "</font></td><td width=50 align=right><font face=verdana size=2>" & i022 & "</font></td>"
        If i022 = 0 Or i02 = 0 Then a = 0 Else a = Math.Round((i02 / i022) * 100, 2)
        s &= "<td width=50 align=right><font face=verdana size=2> <b>" & a & "</b> </font></td>"

        s &= " <td width=50 align=right><font face=verdana size=2>" & i03 & "</font></td><td width=50 align=right><font face=verdana size=2>" & i033 & "</font></td> "
        If i033 = 0 Or i03 = 0 Then a = 0 Else a = Math.Round((i03 / i033) * 100, 2)
        s &= "<td width=50 align=right><font face=verdana size=2> <b>" & a & "</b> </font></td>"

        s &= " <td width=50 align=right><font face=verdana size=2>" & i04 & "</font></td><td width=50 align=right><font face=verdana size=2>" & i044 & "</font></td> "
        If i044 = 0 Or i04 = 0 Then a = 0 Else a = Math.Round((i04 / i044) * 100, 2)
        s &= "<td width=50 align=right><font face=verdana size=2> <b>" & a & "</b> </font></td>"

        s &= " <td width=50 align=right><font face=verdana size=2>" & i05 & "</font></td><td width=50 align=right><font face=verdana size=2>" & i055 & "</font></td> "
        If i055 = 0 Or i05 = 0 Then a = 0 Else a = Math.Round((i05 / i055) * 100, 2)
        s &= "<td width=50 align=right><font face=verdana size=2> <b>" & a & "</b> </font></td>"

        s &= " <td width=50 align=right><font face=verdana size=2>" & i06 & "</font></td><td width=50 align=right><font face=verdana size=2>" & i066 & "</font></td> "
        If i066 = 0 Or i06 = 0 Then a = 0 Else a = Math.Round((i06 / i066) * 100, 2)
        s &= "<td width=50 align=right><font face=verdana size=2> <b>" & a & "</b> </font></td>"

        s &= " <td width=50 align=right><font face=verdana size=2>" & I07 & "</font></td><td width=50 align=right><font face=verdana size=2>" & I077 & "</font></td> "
        If I077 = 0 Or I07 = 0 Then a = 0 Else a = Math.Round((I07 / I077) * 100, 2)
        s &= "<td width=50 align=right><font face=verdana size=2><b> " & a & " </b></font></td>"

        s &= " <td width=50 align=right><font face=verdana size=2>" & COM & "</font></td><td width=50 align=right><font face=verdana size=2>" & COM1 & "</font></td> "
        If COM1 = 0 Or COM = 0 Then a = 0 Else a = Math.Round((COM / COM1) * 100, 2)
        s &= "<td width=50 align=right><font face=verdana size=2> <b>" & a & "</b> </font></td></tr>"

        i06 = 0 : i02 = 0 : i03 = 0 : i04 = 0 : i05 = 0 : i066 = 0 : i022 = 0 : i033 = 0 : i044 = 0 : i055 = 0 : I07 = 0 : I077 = 0 : COM = 0 : COM1 = 0 : a = 0
    End Sub

#End Region

    Private Sub btnurg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnurg.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            'sql = "select distinct  a.supplier_name,a.item,a.dt,a.dt1, b.gate_no, c.gdate ,c.supplier_name,b.item,nvl((select receipt_num from jan_pur_listing where vendor_name=a.supplier_name and gate_no=c.gate_no and item_no=a.item and rownum=1),'-') receipt,"

            'sql &= "(select receipt_date from jan_pur_listing where vendor_name=a.supplier_name and gate_no=c.gate_no and item_no=a.item and rownum=1) receiptdt,"

            'sql &= "(Select max(rea_dT) from jan_gatE_nval_reason where gate_no=c.gate_no and rea_name in ('NO PROBLEM') and flag is null) rea_dt from jan_gate_supplier a ,jan_gate_lines b,jan_gate_header c  where a.item=b.item  and a.supplier_name=c.supplier_name  and b.gatE_no=c.gate_no  "
            'sql &= " AND trunc(edate)>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and trunc(edate)<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            '    sql &= " and c.gdate between dt and dt1",b.gatE_no

            sql = "select substr(a.supplier_name,0, 30)supplier_name,a.item,a.dt,A.DT1,nvl(a.fname,'-')fname,EDATE,"

            sql &= " NVL((SELECT MAX(GATe_NO) FROM JAN_GATE_LINES b WHERE ITEM=A.ITEM AND ORG<>'I01' and     gatE_no=(select gatE_no from jan_gatE_header where gatE_no=b.gaTE_no and supplier_name=a.supplier_name and trunc(gdate) >= a.dt)),0)GATE_NO ,"

            sql &= "  (SELECT gdate FROM jan_gate_header b WHERE org <> 'I01' AND ROWNUM = 1 AND supplier_name = a.supplier_name AND TRUNC (gdate) >= a.dt AND gate_no = (SELECT max(gate_no) FROM jan_gate_lines WHERE gate_no = b.gate_no AND item = a.item)) gatedt,"

            sql &= " nvl((select   org from jan_gatE_lines b where  ITEM=A.ITEM AND ORG<>'I01' and rownum=1 and    gatE_no=(select gatE_no from jan_gatE_header where gatE_no=b.gaTE_no and supplier_name=a.supplier_name and trunc(gdate)>= a.dt)),'-')org "

            '  sql &= " ,(select receipt_num from jan_pur_listing c where gate_no=(select gatE_no from jan_gatE_lines where item=c.item_no and trunc(receipt_date)=(select trunc(gdate) from jan_gatE_header where   gatE_no=c.gate_no) and rownum=1 union select receipt_num from jan_osp_listing c where gate_no=(select gatE_no from jan_gatE_lines where item=c.partno and trunc(receipt_date)=(select trunc(gdate) from jan_gatE_header where   gatE_no=c.gate_no) and rownum=1 ) "

            sql &= " from jan_gate_supplier a where EDATE>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and EDATE<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and a.type='URGENT' order by dt "
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            x = "c:\gate\Urgent Inward Report.HTML"
            Dim d As String
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            j = 0
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Urgent Inward Report <BR>ENTERED DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " </FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=450><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Vendor Name</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Org</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Item.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>From.Dt<BR>To.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Entered.On</FONT></th><TH><FONT SIZE=2 FONT FACE=VERDANA>Entered.By</FONT></th><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate/Dt</FONT></th><TH><FONT SIZE=2 FONT FACE=VERDANA>CE</FONT></th><TH><FONT SIZE=2 FONT FACE=VERDANA>QC</FONT</th><TH><FONT SIZE=2 FONT FACE=VERDANA>Store</FONT></TH></tr>"
            '<TH><FONT SIZE=2 FONT FACE=VERDANA>Val.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Recpt.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Recpt.Dt</FONT></TH></TR>"<TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.No</FONT></TH>"
            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1
                j += 1
                With dsrep.Tables("resultab").Rows(i)
                    'If .Item("dt") = Format(Date.Now, "dd-MMM-yyyy") And .Item("gatE_no") Then
                    '    If .Item("GATE_NO") = 0 Then d = 0 Else d = .Item("gatE_no")


                    'Else
                    If .Item("GATE_NO") = 0 Then d = "Mat hasn't arrived on committed.dt" Else d = .Item("gate_no")
                    '  End If
                    Dim gdt As String
                    If .Item("gatedt").ToString = "" Then gdt = "-" Else gdt = .Item("gatedt")
                    s &= "<tr><td align=right><FONT SIZE=2 FONT FACE=VERDANA> " & j & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & .Item("supplier_name") & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & .Item("org") & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & .Item("item") & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & .Item("dt") & "<br>" & .Item("dt1") & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & .Item("edate") & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & .Item("fname") & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & d & "<Br> " & gdt & "</font></td><td width=45><FONT SIZE=2 FONT FACE=VERDANA>&nbsp;</font></td><td width=45><FONT SIZE=2 FONT FACE=VERDANA>&nbsp;</font></td><td><FONT SIZE=2 FONT FACE=VERDANA>&nbsp;</font></td></tr>"
                    '<td><FONT SIZE=1.5 FONT FACE=VERDANA> " & .Item("gdate") & "</font></td><td><FONT SIZE=1.5 FONT FACE=VERDANA> " & d & "</font></td><td><FONT SIZE=1.5 FONT FACE=VERDANA> " & .Item("receipt") & "</font></td><td><FONT SIZE=1.5 FONT FACE=VERDANA> " & d1 & "</font></td></tr>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub

    Private Sub btnskip_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnskip.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select gatE_no from jan_gate_header where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and direct_dlyd_flag  is null and GATE_NO NOT IN (SELECT GATE_NO FROM JAN_GATE_INWARD_EXEMPT) AND "
            If UNIT7.Checked = True Then sql &= "unit='UNIT7' "
            If UNIT2.Checked = True Then sql &= "unit='UNIT2' "
            If RD3.Checked = True Then sql &= "  UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " UNIT='SKYFAST'"
            If rdu1.Checked = True Then sql &= " unit='UNIT1'"
            sql &= " order by gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            Dim d As New DataSet
            adap.Fill(d, "resultab")
            Dim cnt As Integer = d.Tables("resultab").Rows.Count
            Dim a As Int64 = d.Tables("resultab").Rows(0).Item("gate_no")
            Dim b As Int64 = d.Tables("resultab").Rows(cnt - 1).Item("gate_no")
            sql = "select gate_no from jan_gatE_header where gate_no between " & a & " and " & b & ""
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            cl.oradap.Fill(dsrep, "resultab")
            dv = dsrep.Tables("resultab").DefaultView
            Dim ICNT As Int64
            x = "c:\gate\Non-Accounting GateNumber.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            j = 0
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Non Accounting Gate Report <BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=350><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate No</FONT></TH></TR>"
            For ICNT = a To b
                dv.RowFilter = "gate_no=" & ICNT
                If dv.Count = 0 Then
                    txt_miss.Text &= vbNewLine & ICNT
                    j += 1
                    s &= "<tr><td align=right><FONT SIZE=2 FONT FACE=VERDANA> " & j & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & ICNT & "</font></td></tr>"
                End If
                dv.RowFilter = ""
                dsrep.Tables("resultab").RejectChanges()
            Next
            tail()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            'Me.Cursor = Cursors.WaitCursor
            'sql = "select substr(vendor_name,0,23) ,substr(vendor_name,23) ,vendor_type_lookup_code  from po_vendors where vendor_type_lookup_code<>'EMPLOYEE'"
            'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            'ds = New DataSet
            'adap.Fill(ds, "resultab")


            'sql = "select org ,gate_no from jan_gate_header a where a.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"
            'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            'ds = New DataSet
            'adap.Fill(ds, "resultab")
            'For i = 0 To ds.Tables("resultab").Rows.Count - 1
            '    Dim d As String = ds.Tables("resultab").Rows(i).Item("org").ToString
            '    Dim g As Integer = ds.Tables("resultab").Rows(i).Item("gate_no")
            '    sql = "update jan_gatE_nval_reason set org='" & d & "' where gate_no=" & g & ""
            '    If CON.State = ConnectionState.Closed Then CON.Open()
            '    cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
            '    (cl.orcmd).ExecuteNonQuery()
            'Next
            ''Application.Exit()
            'MessageBox.Show("inserted")

            'Dim dt, dt1 As String
            'Dim dt2 As Date
            'dt = txtfm.Text.ToString.Substring(3, 3)
            'dt1 = txtfm.Text.ToString.ToString.Substring(7)

            'sql = "select ginvoice,greceipt,poamend from jan_gate_report where sdate>='" & txtfm.Text & "' and edate<='" & txtto.Text & "' "

            'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            'ds = New DataSet
            'adap.Fill(ds, "resultab")
            'If ds.Tables("resultab").Rows(0).Item("ginvoice").ToString = "" Then
            '    sql = "select months_between (('" & txtto.Text & "'),('" & txtfm.Text & "'))diff from dual"
            '    cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            '    ds = New DataSet
            '    adap.Fill(ds, "resultab")
            '    Dim df As Integer = Math.Round(ds.Tables("resultab").Rows(0).Item("diff"))
            '    For i = 0 To df - 1
            '        sql = "SELECT to_char(to_date('" & txtfm.Text & "') + numtoyminterval(" & i & " ,'month'))dt  fROM dual"
            '        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            '        ds = New DataSet
            '        adap.Fill(ds, "resultab")
            '        dt2 = ds.Tables("resultab").Rows(0).Item("dt")
            '        ' dt2 = Format(DateAdd("d", 30, dt2), "dd-MMM-yyyy")
            '        dt = dt2.ToString.Substring(3, 2)
            '        sql = "update jan_gate_report set ginvoice =(select count(*) gateinvoice from jan_gate_header where extract(month from gdate)=" & dt & " and extract(year from gdate)=" & dt1 & " and unit='UNIT7'),"

            '        sql &= "poamend =(select count(*) poamend from jan_gate_nval_reason where extract(month from gdate)=" & dt & " and extract(year from gdate)=" & dt1 & " and gate_no not like '700%' and rea_code not in('8','7','21')),"

            '        sql &= "greceipt =(select count(*) greceipt from jan_gate_header where extract(month from gdate)=" & dt & " and extract(year from gdate)=" & dt1 & " and unit='UNIT7' and validated='0' )"

            '        sql &= "where month=" & dt & " and year= " & dt1 & ""
            '        If CON.State = ConnectionState.Closed Then CON.Open()
            '        cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
            '        (cl.orcmd).ExecuteNonQuery()
            '        CON.Close()

            '    Next
            '----------------------*Poamend--------------------------
            '    sql = "select mth,ginvoice,greceipt,poamend from jan_gate_report where sdate>='" & txtfm.Text & "' and edate<='" & txtto.Text & "' "

            '    cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            '    ds = New DataSet
            '    adap.Fill(ds, "resultab")
            'Else
            '    sql = "select mth,ginvoice,greceipt,poamend from jan_gate_report where sdate>='" & txtfm.Text & "' and edate<='" & txtto.Text & "' "

            'sql = "select * from jan_gate_daily where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "
            'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            'ds = New DataSet
            'adap.Fill(ds, "resultab")
            'If ds.Tables("resultab").Rows.Count = 0 Then
            '    Dim dt As Integer = DateDiff("d", txtfm.Text, txtto.Text)
            '    For i = 0 To dt
            '        sql = "insert into jan_Gate_daily (gate_no,gdate,poissue,tariff,tax,amend,osprate,wop,exqty,porate,service,others)values((select count(*) from jan_gatE_header where gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT7')"

            '        sql &= ",  '" & Format(DateAdd("d", i, txtfm.Text), "dd-MMM-yyyy") & "'"

            '        sql &= ", (select count(*) from jan_gate_nval_reason where rea_code=1 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and gate_no not like '700%' and flag is null ) "

            '        sql &= " ,(select count(*) from jan_gate_nval_reason where rea_code=2 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and gate_no not like '700%' and flag is null ) "

            '        sql &= ",(select  count(*) from jan_gate_nval_reason where rea_code=3 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and gate_no not like '700%' and flag is null )"

            '        sql &= ", (select  count(*) from jan_gate_nval_reason where rea_code=5 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and gate_no not like '700%' and flag is null ) ,"

            '        sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=6 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and gate_no not like '700%' and flag is null )  ,"

            '        sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=10 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and gate_no not like '700%' and flag is null ),"

            '        sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=11 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and gate_no not like '700%' and flag is null ),"

            '        sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=12 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and gate_no not like '700%' and flag is null ),"

            '        sql &= "(select  count(*) from jan_gate_nval_reason where rea_code=19 and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and gate_no not like '700%' and flag is null ),"

            '        sql &= "(select  count(*) from jan_gate_nval_reason where rea_code not in(1,2,3,5,6,10,11,12,19,8) and gdate>=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & DateAdd("d", i, txtfm.Text) & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and gate_no not like '700%' and flag is null )"
            '        sql &= ")"

            '        If CON.State = ConnectionState.Closed Then CON.Open()
            '        cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
            '        (cl.orcmd).ExecuteNonQuery()
            '        CON.Close()
            '    Next

            'End If

            'sql = "select gatE_no from jan_gate_header where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='UNIT7' order by gate_no"
            'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            'ds = New DataSet
            'adap.Fill(ds, "resultab")
            'Dim c As Integer = ds.Tables("resultab").Rows.Count
            'Dim a As Integer = ds.Tables("resultab").Rows(0).Item("gate_no")
            'Dim b As Integer = ds.Tables("resultab").Rows(c - 1).Item("gate_no")
            'sql = "select gate_no from jan_gatE_header where gate_no between " & a & " and " & b & ""
            'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            'ds1 = New DataSet
            'adap.Fill(ds1, "resultab")
            'dv = ds1.Tables("resultab").DefaultView
            'x = "c:\gate\Skipped GateNumber.HTML"
            'fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            'sw = New StreamWriter(fstrm)
            'j = 0
            's = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate- Skipped Number Report <BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & "</FONT></H2>"

            's &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=350><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate No</FONT></TH></TR>"
            'For i = a To b
            '    dv.RowFilter = "gate_no=" & i
            '    If dv.Count = 0 Then
            '        txt_miss.Text &= vbNewLine & i
            '        j += 1
            '        s &= "<tr><td align=right><FONT SIZE=2 FONT FACE=VERDANA> " & j & "</font></td><td><FONT SIZE=2 FONT FACE=VERDANA> " & i & "</font></td></tr>"

            '    End If
            '    dv.RowFilter = ""
            '    ds1.Tables("resultab").RejectChanges()
            'Next
            'tail()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub txtgfm_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtgfm.TextChanged
        txtgto.Text = txtgfm.Text
    End Sub

    Private Sub btngt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngt.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select a.gate_no,a.gdate,a.supplier_name,a.supplier_site,a.org,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,a.dc_no,DECODE(A.VALIDATED,'0','VALIDATED','1','GATE','2','NOT VALIDATED','3','ACTION TAKEN','4','RTV','5','CANCEL ENTRY')STATUS,a.dc_date,nvl(b.freight,0)freight,nvl(b.rate,0)rate,b.pono,b.podt,b.item,b.description,b.supdcqty, "

            sql &= "c.unit_price,(b.supdcqty*c.unit_price) dcval,nvl(c.p_f_per,0)p_f_per,nvl(c.p_f,0)p_f,round(decode(c.bed_per,0,c.srv_per,c.bed_per),2)bed_per,round(decode(c.bed,0,c.service,c.bed),2)bed,round(decode(c.cess_per,0,c.stx_cess_per,c.cess_per),2)cess_per,round(decode(c.cess,0,c.srv_cess,c.cess),2)cess,round(decode(c.scess_per,0,c.stx_scess_per,c.scess_per),2)scess_per,round(decode(c.scess,0,c.srv_cess,c.scess),2)scess,"
            sql &= " nvl(c.vat,0)vat,nvl(c.cst,0)cst,nvl(c.vat_per,0)vat_per,nvl(c.cst_per,0)cst_per,nvl(c.others,0)others,round(nvl(c.total_tax,0),2)total_tax,c.line_qty,c.service,c.srv_cess,c.srv_scess"

            sql &= " from jan_gate_header a,jan_gate_lines b,jan_purchase_2 c where a.gate_no=b.gate_no and b.poline=c.po_line_id and b.location_id=c.line_location_id  and b.pono=c.pono"

            sql &= " and a.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and b.flag<>0"

            If cmbsup.SelectedItem <> "" Then sql &= " and a.supplier_name='" & cmbsup.SelectedItem & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"
            If txtgfm.Text <> "" And txtgto.Text <> "" Then sql &= " and a.gate_no>='" & txtgfm.Text & "' and a.gate_no<='" & txtgto.Text & "'"
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='Services'"
            If RDALL.Checked = True Then sql &= ""

            If UNIT7.Checked = True Then sql &= " AND A.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND A.UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND UNIT='SKYFAST'"
            sql &= " order  by a.gatE_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            x = "c:\gate\Gate Register Report.HTML"
            Dim d, dcval, pf, pfper, bed, bedper, cess, cessper, scess, scessper, vat, vatper, cst, cstper, ot, ttax, freight, rate, totval As Integer
            vanish()
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            j = 1
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Register Report <BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " <br> Supplier:" & cmbsup.SelectedItem & " | Org:" & cmborg.SelectedItem & " <br> Gate From: " & txtgfm.Text & " To :" & txtgto.Text & " | Gate Type: "
            If rdpo.Checked = True Then s &= " " & rdpo.Text & ""
            If rdosp.Checked = True Then s &= " " & rdosp.Text & ""
            If rdser.Checked = True Then s &= " " & rdser.Text & ""
            If RDALL.Checked = True Then s &= " " & RDALL.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=450><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Gt.No<br>Gt.Dt</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Supplier<br>Site</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Org/GType</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Status</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Dc.No/Dt</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Po.No<br>Po.Dt</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Item/Desc</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Qty</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Price</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Val</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PF(%)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PF</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>BED(%)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>BED</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>CESS(%)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>CESS</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SCESS(%)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SCESS</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>VAT(%)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>VAT</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>CST(%)</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>CST</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Others</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Tot.Tax</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Freight</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Rate.Diff</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Tot.Inv.Val</FONT></TH></TR>"
            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1
                With dsrep.Tables("resultab").Rows(i)
                    d = .Item("gate_no")
                    dcval = .Item("dcval") + dcval
                    pfper = .Item("p_f_per") + pfper
                    pf = ((.Item("p_f") / .Item("line_qty")) * .Item("supdcqty")) + pf
                    bedper = .Item("bed_per") + bedper
                    bed = (((.Item("bed") + .Item("service")) / .Item("line_qty")) * .Item("supdcqty")) + bed
                    cessper = .Item("cess_per") + cessper
                    cess = (((.Item("cess") + .Item("srv_cess")) / .Item("line_qty")) * .Item("supdcqty")) + cess
                    scessper = .Item("scess_per") + scessper
                    scess = (((.Item("scess") + .Item("srv_scess")) / .Item("line_qty")) * .Item("supdcqty")) + scess
                    vatper = .Item("vat_per") + vatper
                    vat = ((.Item("vat") / .Item("line_qty")) * .Item("supdcqty")) + vat
                    cstper = .Item("cst_per") + cstper
                    cst = ((.Item("cst") / .Item("line_qty")) * .Item("supdcqty")) + cst
                    ot = .Item("others") + ot
                    ttax = .Item("total_tax") + ttax
                    freight = .Item("freight") + freight
                    rate = .Item("rate") + rate
                    totval = (dcval + pf + bed + cess + scess + vat + cst + ot + freight + rate)

                    s &= "<tr><td align=right><font face=verdana size=1>" & j & "</font></td><td><font face=verdana size=1>" & .Item("gatE_no") & "<br>" & .Item("gdate") & "</font></td><td><font face=verdana size=1>" & .Item("supplier_name") & "<br>" & .Item("supplier_site") & "</font></td><td><font face=verdana size=1>" & .Item("org") & "<br>" & .Item("gtype") & "</font></td><td><font face=verdana size=1>" & .Item("status") & "</font></td><td><font face=verdana size=1>" & .Item("dc_no") & "<br>" & .Item("dc_date") & "</font></td><td><font face=verdana size=1>" & .Item("pono") & "<br>" & .Item("podt") & "</font></td><td><font face=verdana size=1>" & .Item("item") & "<br>" & .Item("description") & "</font></td><td align=right><font face=verdana size=1>" & .Item("supdcqty") & "</font></td><td align=right><font face=verdana size=1>" & .Item("unit_price") & "</font></td><td align=right><font face=verdana size=1>" & .Item("dcval") & "</font></td><td align=right><font face=verdana size=1>" & .Item("p_f_per") & "</font></td><td align=right><font face=verdana size=1>" & .Item("p_f") & "</font></td><td align=right><font face=verdana size=1>" & .Item("bed_per") & "</font></td><td align=right><font face=verdana size=1>" & .Item("bed") & "</font></td><td align=right><font face=verdana size=1>" & .Item("cess_per") & "</font></td><td align=right><font face=verdana size=1>" & .Item("cess") & "</font></td><td align=right><font face=verdana size=1>" & .Item("scess_per") & "</font></td><td align=right><font face=verdana size=1>" & .Item("scess") & "</font></td><td align=right><font face=verdana size=1>" & .Item("vat_per") & "</font></td><td align=right><font face=verdana size=1>" & .Item("vat") & "</font></td><td align=right><font face=verdana size=1>" & .Item("cst_per") & "</font></td><td align=right><font face=verdana size=1>" & .Item("cst") & "</font></td><td align=right><font face=verdana size=1>" & .Item("others") & "</font></td><td align=right><font face=verdana size=1>" & .Item("total_tax") & "</font></td><td align=right><font face=verdana size=1>" & .Item("freight") & "</font></td><td align=right><font face=verdana size=1>" & .Item("rate") & "</font></td><td align=right><font face=verdana size=1>&nbsp;</font></td></tr>"
                    If i + 1 <= dsrep.Tables("resultab").Rows.Count - 1 Then
                        If i = 0 Then
                            j += 1
                            Do Until d = dsrep.Tables("resultab").Rows(i + 1).Item("gate_no")
                                s &= "<tr> <td colspan=10>&nbsp;</td><td align=right> <FONT SIZE=1 font face=verdana><b>" & dcval & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & pfper & "</b></font></td>  <td align=right> <FONT SIZE=1 font face=verdana><b>" & pf & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & bedper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & bed & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cessper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cess & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & scessper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & scess & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & vatper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & vat & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cstper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cst & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & ot & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & (pf + bed + cess + scess + vat + cst + ot + freight + rate) & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & freight & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & rate & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & totval & "</b></font></td></tr>"
                                dcval = 0
                                pf = 0
                                pfper = 0
                                bed = 0
                                bedper = 0
                                cess = 0
                                cessper = 0
                                scess = 0
                                scessper = 0
                                vat = 0
                                vatper = 0
                                cst = 0
                                cstper = 0
                                ot = 0
                                ttax = 0
                                freight = 0
                                rate = 0
                                totval = 0
                                Exit Do
                            Loop
                        Else
                            Do Until d = dsrep.Tables("resultab").Rows(i + 1).Item("gate_no")
                                j += 1
                                s &= "<tr> <td colspan=10>&nbsp;</td><td align=right> <FONT SIZE=1 font face=verdana><b>" & dcval & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & pfper & "</b></font></td>  <td align=right> <FONT SIZE=1 font face=verdana><b>" & pf & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & bedper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & bed & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cessper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cess & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & scessper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & scess & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & vatper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & vat & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cstper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cst & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & ot & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & (pf + bed + cess + scess + vat + cst + ot + freight + rate) & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & freight & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & rate & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & totval & "</b></font></td></tr>"
                                dcval = 0
                                pf = 0
                                pfper = 0
                                bed = 0
                                bedper = 0
                                cess = 0
                                cessper = 0
                                scess = 0
                                scessper = 0
                                vat = 0
                                vatper = 0
                                cst = 0
                                cstper = 0
                                ot = 0
                                ttax = 0
                                freight = 0
                                rate = 0
                                totval = 0
                                Exit Do
                            Loop
                        End If
                    Else
                        j += 1
                        s &= "<tr> <td colspan=10>&nbsp;</td><td align=right> <FONT SIZE=1 font face=verdana><b>" & dcval & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & pfper & "</b></font></td>  <td align=right> <FONT SIZE=1 font face=verdana><b>" & pf & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & bedper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & bed & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cessper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cess & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & scessper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & scess & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & vatper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & vat & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cstper & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & cst & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & ot & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & (pf + bed + cess + scess + vat + cst + ot + freight + rate) & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & freight & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & rate & "</b></font></td><td align=right> <FONT SIZE=1 font face=verdana><b>" & totval & "</b></font></td></tr>"
                        dcval = 0
                        pf = 0
                        pfper = 0
                        bed = 0
                        bedper = 0
                        cess = 0
                        cessper = 0
                        scess = 0
                        scessper = 0
                        vat = 0
                        vatper = 0
                        cst = 0
                        cstper = 0
                        ot = 0
                        ttax = 0
                        freight = 0
                        rate = 0
                        totval = 0
                    End If
                End With
            Next
            tail()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub
    Public Sub vanish()
        dcval = 0
        pf = 0
        pfper = 0
        bed = 0
        bedper = 0
        cess = 0
        cessper = 0
        scess = 0
        scessper = 0
        vat = 0
        vatper = 0
        cst = 0
        cstper = 0
        ot = 0
        ttax = 0
        freight = 0
        rate = 0
        totval = 0
    End Sub

    Private Sub btnlong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlong.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select distinct a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-')org,nvl(b.rea_name,'-')rea_name,nvl(b.rea_remark,'-')rea_remark  "
            If rdpo.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='PO' AND ROWNUM=1))),'-')DIV"
            ElseIf rdosp.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='OSP' AND ROWNUM=1))),'-')DIV"
            ElseIf rdser.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='Services' AND ROWNUM=1))),'-')DIV"
            ElseIf RDALL.Checked = True Then
                sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND ROWNUM=1))),'-')DIV"
            End If

            sql &= " from jan_gate_header a,jan_gate_nval_reason b where a.gatE_no=b.gate_no and a.validated='2'and b.rea_code<>8 AND a.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            sql &= " and (sysdate-a.gdate)>=15"

            If UNIT7.Checked = True Then sql &= " AND A.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND A.UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"

            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='Services'"
            If RDALL.Checked = True Then sql &= ""

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")

            j = 0


            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Entry Long Pending List(more then 15 days)<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & " <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " | Gate Type: "
            If rdpo.Checked = True Then s &= " " & rdpo.Text & ""
            If rdosp.Checked = True Then s &= " " & rdosp.Text & ""
            If rdser.Checked = True Then s &= " " & rdser.Text & ""
            If RDALL.Checked = True Then s &= " " & RDALL.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DIVISION</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA CODE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA REMARK</FONT></TH></TR>"

            For i = 0 To dsrep.Tables("RESULTAB").Rows.Count - 1
                With dsrep.Tables("RESULTAB").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("div") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("rea_remark") & "</FONT></TD></TR>"
                End With
            Next
            x = "c:\gate\gate pending consolidate.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub

    Private Sub btnper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnper.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select  count(distinct gate_no),max(rea_dt1),gdate   from jan_gate_nval_reason where  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and rea_code=8 "
            If UNIT7.Checked = True Then sql &= " and unit='UNIT7'"
            If UNIT2.Checked = True Then sql &= " and unit='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"
            sql &= " group  by gatE_no,gdate having (max(rea_dt1)-gdate)>1"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            Dim rs As Integer = dsrep.Tables("resultab").Rows.Count


            amend1()
            Dim am As Integer = dsrep.Tables("resultab").Rows(0).Item("amend")

            sql = " select w.*, (select count(*) from jan_gate_header where validated=5 and  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "
            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"
            sql &= " ) cancel,"

            sql &= "(select count(*) from jan_gate_header where  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and  validated not in ('0','4','5')and (sysdate-gdate>15)"
            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"
            sql &= " )longpend,"

            sql &= "(select count(*) from jan_gate_nval_reason a,jan_gatE_header b where  b.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  b.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and a.rea_code<>8 and a.gatE_no=b.gatE_no and b.validated=2"
            If UNIT7.Checked = True Then sql &= " AND B.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND B.UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"
            sql &= " )pendinvoice,"

            sql &= "(select count(distinct gate_no) from jan_pur_listing  where  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and (receipt_date-gdate>1)"
            If UNIT7.Checked = True Then sql &= " AND gate_no not like '700%'"
            If UNIT2.Checked = True Then sql &= " AND gate_no like '700%'"
            sql &= " )delayreceiptpo,"

            sql &= "(select count(distinct gate_no) from jan_osp_listing  where  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and (receipt_date-gdate>1)"
            If UNIT7.Checked = True Then sql &= " AND gate_no not like '700%'"
            If UNIT2.Checked = True Then sql &= " AND gate_no like '700%'"
            sql &= " )delayreceiptosp,"

            sql &= "(select count(*) from jan_gatE_header a,jan_gatE_supplier b where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and adi_no is not null and a.supplier_name=b.supplier_name and b.type='ADI'  "
            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"
            sql &= ")withadi ,"

            sql &= " (select count(*)  from jan_gatE_header a,jan_gatE_supplier b  where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and a.supplier_name=b.supplier_name  and b.type='ADI'"
            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"

            sql &= ") withoutadi,"

            sql &= " (select count(*) from jan_gate_header where validated=4 and  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "
            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"
            sql &= ")rtv"

            sql &= " from (select count(*)gate from jan_gate_header where  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND  UNIT='UNIT4'"
            sql &= ")w"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")

            j = 0
            x = "c:\gate\gate register performance report.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Register Performance Report<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & ""
            ' <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " "
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=500><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>Particulars</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Values</FONT></TH></TR>"
            Dim delayval, longpend, delayrecpt, cancel, rtv, adi, tot, pendinvoice, amend As Double

            With dsrep.Tables("resultab").Rows(0)
                delayval = (rs / .Item("gate")) * 100
                longpend = (.Item("longpend") / .Item("gate")) * 100
                delayrecpt = ((.Item("delayreceiptpo") + .Item("delayreceiptosp")) / .Item("gate")) * 100
                cancel = (.Item("cancel") / .Item("gate")) * 100
                rtv = (.Item("rtv") / .Item("gate")) * 100
                If .Item("withoutadi") = 0 Then
                    adi = 0
                Else
                    adi = ((.Item("withoutadi") - .Item("withadi")) / .Item("withoutadi")) * 100
                End If

                pendinvoice = (.Item("pendinvoice") / .Item("gate")) * 100
                amend = (am / .Item("gate")) * 100

                tot = (delayval + longpend + delayrecpt + cancel + rtv + adi + pendinvoice + amend) / 8


                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of  Delay Validation More Than One Day</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round((rs / .Item("gate")) * 100, 2) & "</FONT></Td></TR>"

                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of  Long Pending More Than One Month</FONT></Td><td  align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round((.Item("longpend") / .Item("gate")) * 100, 2) & "</FONT></Td></TR>"

                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of Delay Receipt Entry More Than One Day</FONT></Td><td  align=right><FONT SIZE=2 FONT FACE=VERDANA> " & Math.Round(((.Item("delayreceiptpo") + .Item("delayreceiptosp")) / .Item("gate")) * 100, 2) & "</FONT></Td></TR>"

                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of Pending To Be Invoiced</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA></FONT>" & Math.Round((.Item("pendinvoice") / .Item("gate")) * 100, 2) & "</Td></TR>"

                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of  Cancel Entries</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round((.Item("cancel") / .Item("gate")) * 100, 2) & "</FONT></Td></TR>"

                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of  RTV Entries</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round((.Item("rtv") / .Item("gate")) * 100, 2) & "</FONT></Td></TR>"

                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of Invoice Amendments</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round((am / .Item("gate")) * 100, 2) & "</FONT></Td></TR>"
                If .Item("withoutadi") = 0 Then
                    s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of Without ADI</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & 0 & "</FONT></Td></TR>"
                Else
                    s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA>% Of Without ADI</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round(((.Item("withoutadi") - .Item("withadi")) / .Item("withoutadi")) * 100, 2) & "</FONT></Td></TR>"
                End If
                '  s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA><b>% Of Average</b></FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round(tot, 2) & "</FONT></Td></TR>"

                s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA><b>% Of Total Performance Completed</b></FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Round((100 - tot), 2) & "</FONT></Td></TR>"
            End With
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub
    Public Sub amend1()
        If UNIT7.Checked = True Then sql = "truncate table jan_gate_daily"
        If UNIT2.Checked = True Then sql = "truncate table jan_gate_daily1"

        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd.ExecuteNonQuery()
        If UNIT7.Checked = True Then daily1()
        If UNIT2.Checked = True Then daily()
        sql = "select to_char(gdate,'Month')month,extract(year from gdate)yr,sum(gate_no)gate,sum(poissue+tariff+tax+amend+osprate+wop+exqty+porate+service+others)amend,"
        sql &= "sum((poissue+tariff+tax+amend+osprate+wop+exqty+porate+service+others)-(gate_no-gclear))clear from "
        If UNIT7.Checked = True Then sql &= "jan_gate_daily"
        If UNIT2.Checked = True Then sql &= "jan_gate_daily1"

        sql &= " where gdate >=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "

        sql &= " group by to_char(gdate,'Month'),extract(year from gdate) order by  to_char(gdate,'Month') desc"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        dsrep = New DataSet
        adap.Fill(dsrep, "resultab")
    End Sub

    Private Sub xerox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles xerox.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select distinct a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-')org from jan_gate_header a where xerox='Yes'"
            sql &= " and gdate >=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')  "

            If UNIT7.Checked = True Then sql &= " AND UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"
            sql &= " order by gatE_no "
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            cl.oradap.Fill(dsrep, "resultab")
            j = 0
            x = "c:\gate\gate register -Xerox Bill.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Register -Xerox Bill Received List<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & ""
            s &= "  <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " "
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=700><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Supplier</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.Type</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Org</FONT></TH></TR>"
            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1
                j += 1
                With dsrep.Tables("resultab").Rows(i)
                    s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA> " & j & "</FONT></Td><td  ><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gate_no") & "</FONT></Td><td  ><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gdate") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("supplier_name") & "</FONT></Td><td  ><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dc_no") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dc_date") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gtype") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("org") & "</FONT></Td></TR>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try

    End Sub

    Private Sub delayaccount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delayaccount.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = " select * from (select distinct a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-')org ,(select reason_date from jan_gate_nval_reason where rea_code in (18,19,4) and gate_no=a.gate_no) duplicate,(select max(reason_date) from jan_gate_nval_reason where rea_code=8 and gate_no=a.gate_no) original from jan_gate_header a  where rownum>0 "
            If UNIT7.Checked = True Then sql &= " AND A.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND A.UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            sql &= " and gdate >=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')) where duplicate is not null  "
            sql &= " order by gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            j = 0
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Register -Duplicate Invoice Copy Received List<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & ""
            '  s &= "  <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " "
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=700><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Supplier</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.Type</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Org</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Service DC/Duplicate Copy Received Date</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Rate approved/Original Copy received Date</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Time Delay(In Days)</FONT></TH></TR>"
            For i = 0 To dsrep.Tables("resultab").Rows.Count - 1
                j += 1
                With dsrep.Tables("resultab").Rows(i)
                    Dim delay As Integer
                    Dim d, d1 As String
                    If .Item("original").ToString = "" Then d = "-" Else d = .Item("original")
                    d1 = .Item("duplicate")
                    If d = "-" Then delay = 0 Else delay = DateDiff("d", d, d1)
                    s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA> " & j & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gate_no") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gdate") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("supplier_name") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dc_no") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dc_date") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gtype") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("org") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("duplicate") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & d & "</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & Math.Abs(delay) & "</FONT></Td></TR>"
                End With
            Next
            x = "c:\gate\gate register delay accounting.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try

    End Sub

    Private Sub adimanual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles adimanual.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select gatE_no,gdate,supplier_name,dc_no,dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-')org ,adi_reason from jan_gatE_header a where gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and adi_reason is not null"
            If UNIT7.Checked = True Then sql &= " and unit='UNIT7'"
            If UNIT2.Checked = True Then sql &= " and unit='UNIT2'"
            If RDSKY.Checked = True Then sql &= " AND  UNIT='SKYFAST'"
            If RD3.Checked = True Then sql &= " AND UNIT='UNIT4' "
            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem & "'"
            If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"
            sql &= " order by gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            j = 0
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Register -Manual ADI Entry<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & ""
            s &= "  <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " "
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=700><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Supplier</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.Type</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Org</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Reason</FONT></TH></TR>"
            For i = 0 To dsrep.Tables("Resultab").Rows.Count - 1
                j += 1
                With dsrep.Tables("resultab").Rows(i)
                    s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA> " & j & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gate_no") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gdate") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("supplier_name") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dc_no") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dc_date") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gtype") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("org") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("adi_reason") & "</FONT></Td></TR>"
                End With
            Next
            x = "c:\gate\gate register manual ADI.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub

    Private Sub btninv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninv.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "SELECT a.gate_no, a.gdate, a.supplier_name, a.dc_no,a.dc_date ,a.dcval, b.voucher_num,trunc(b.CREATION_DATE)voucher_dt, (select vendor_name from po_vendors where vendor_id=b.vendor_id)vendor, invoice_num,invoice_date, invoice_amount FROM jan_gate_header a, ap_invoices_all b "

            sql &= " where  gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')  "

            sql &= " and  a.gate_id = b.attribute4 AND a.gtype = 'PO' and a.org<>'I01' and dcval>0"

            sql &= " order by gatE_no"

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            dsrep = New DataSet
            adap.Fill(dsrep, "resultab")
            j = 0
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Gate Register -Invoice Booking Details<BR>GATE DATE FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & ""
            ' s &= "  <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " "
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=500>"
            s &= "<tr><Th colspan=6 align=center><FONT SIZE=2 FONT FACE=VERDANA>As Per Gate Register</FONT></th> <th colspan=4 align=center><FONT SIZE=2 FONT FACE=VERDANA>As Per Invoice Booking</FONT></th></tr> "
            s &= "<TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Supplier</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.No/Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.Val</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>SI.No</TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Supplier</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Dc.Val</FONT></TH></TR>"
            For i = 0 To dsrep.Tables("Resultab").Rows.Count - 1
                j += 1
                With dsrep.Tables("resultab").Rows(i)
                    s &= "<tr><Td><FONT SIZE=2 FONT FACE=VERDANA> " & j & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gate_no") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gdate") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("supplier_name") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dc_no") & "/" & .Item("dc_date") & "</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("dcval") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("voucher_num") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("vendor") & "</FONT></Td><td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("invoice_num") & "</FONT></Td><td align=right><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("invoice_amount") & "</FONT></Td></TR>"
                End With
            Next
            x = "c:\gate\Invoice booking.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Me.Cursor = Cursors.Arrow
        End Try
    End Sub

    Private Sub btnprep_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprep.Click
        Try
            sql = "SELECT count(distinct gate_no)cnt,uname FROM JAN_GATe_NVAL_REASON a WHERE   gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            If UNIT7.Checked = True Then sql &= " AND A.UNIT='UNIT7'"
            If UNIT2.Checked = True Then sql &= " AND A.UNIT='UNIT2'"
            If RD3.Checked = True Then sql &= " AND A.UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " AND A.UNIT='SKYFAST'"

            sql &= "group by  uname"
            cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            Dim X As String
            X = "c:\gate\Gate Prepared List.HTML"
            Dim fstrm As New FileStream(X, FileMode.Create, FileAccess.Write)
            Dim sw As New StreamWriter(fstrm)
            s = "<html><body>"
            s &= "<table border=1 cellspacing=0 cellpadding=7 align=CENTER width=500><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>S.NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Person Name</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>No.Of entries</FONT></TH> </TR>"
            j = 0
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                j = j + 1
                With ds.Tables("resultab").Rows(i)
                    s &= "<TR><Td><FONT SIZE=1 FONT FACE=VERDANA>" & j & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("uname") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("cnt") & "</FONT></Td> </TR>"
                End With
            Next
            s = s & "</table></html>"
            sw.WriteLine(s)
            fstrm.Flush()
            sw.Flush()
            sw.Close()
            fstrm.Close()
            System.Diagnostics.Process.Start(X)


        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub

    Private Sub btnfm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfm.Click
        GroupBox4.Visible = True
    End Sub

    Private Sub btnto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnto.Click
        GroupBox5.Visible = True
    End Sub

    Private Sub btnm2o_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnm2o.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select organization_code from org_organization_definitions where organization_id not in (110,105,111,113,112) order by organization_code"
            cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")

            Dim _gt, _gt1, _gt2, _gt3, _gt4, _igt, _igt1, _igt2, _igt3, _igt4 As Integer
            Dim _re, _re1, _re2, _re3, _re4, _ire, _ire1, _ire2, _ire3, _ire4 As Integer
            Dim _insp, _insp1, _insp2, _insp3, _insp4, _iinsp, _iinsp1, _iinsp2, _iinsp3, _iinsp4 As Integer
            Dim _dlyd, _dlyd1, _dlyd2, _dlyd3, _dlyd4, _idlyd, _idlyd1, _idlyd2, _idlyd3, _idlyd4 As Integer
            Dim _for, _for1, _for2, _for3 As String

            s = "<html><body>"

            s &= "<h4 align=center><font face=verdana size=2>M20-Inward Status Analysis for:"
            If rdpo.Checked = True Then s &= " " & rdpo.Text & ""
            If rdosp.Checked = True Then s &= " " & rdosp.Text & ""
            If RDALL.Checked = True Then s &= " PO & OSP "
            s &= "<br>"
            s &= " FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & "<BR>"

            s &= " Report run time: " & Date.Now & "</font></h4>"

            s &= "<table border=1 cellspacing=0 align=top cellpadding=5 ><TR bgcolor=silver><Td><FONT SIZE=2 FONT FACE=VERDANA>Org</FONT></Td><Td><FONT SIZE=2 FONT FACE=VERDANA>For</FONT></Td><Td colspan=2><FONT SIZE=2 FONT FACE=VERDANA>Recd</FONT></Td><Td colspan=2><FONT SIZE=2 FONT FACE=VERDANA>Completed</FONT></Td><Td colspan=2><FONT SIZE=2 FONT FACE=VERDANA>Completed In 1(Hr)</FONT></Td><Td colspan=2><FONT SIZE=2 FONT FACE=VERDANA>Completed      After 1(Hr)</FONT></Td><Td colspan=2><FONT SIZE=2 FONT FACE=VERDANA>Pending</FONT></Td><Td colspan=2><FONT SIZE=2 FONT FACE=VERDANA>Success(%)</FONT></Td> </TR>"

            s &= "<TR width=30><td colspan=2>&nbsp;</td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Lines</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Items</FONT></Td> <Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Lines</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Items</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Lines</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of Items</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Lines</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Items</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Lines</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Items</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Lines</FONT></Td><Td width=30><FONT SIZE=2 FONT FACE=VERDANA>No.Of  Items</FONT></Td> </TR>"


            For i = 0 To ds.Tables("resultab").Rows.Count - 1


                sql = "SELECT  DISTINCT PROCESS_DT,   A.org,COUNT (DISTINCT A.GATE_NO)GATE_NO ,  COUNT (DISTINCT item_no) item,round((VALIDATE_DT-GATE_DT) ,2)gate ,"
                sql &= " round((receipt_dt-VALIDATE_DT ) ,2)receipt,"
                sql &= "round(( insp_dt-receipt_dt ) ,2)insp,"
                sql &= "round((dlyd_dt-insp_dt  ) ,2)dlyd"
                sql &= "    FROM jan_inward_status a, JAN_GATE_DELIVERY_STATUS_V B "
                sql &= " WHERE a.GATe_NO = b.GATE_NO AND  A.org='" & ds.Tables("resultab").Rows(i).Item("organization_code") & "'"

                sql &= " AND PROCESS_DT>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and PROCESS_DT<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

                If rdpo.Checked = True Then sql &= " AND A.GTYPE='PO'"

                If rdosp.Checked = True Then sql &= " AND A.GTYPE='OSP'"

                sql &= " GROUP BY A.org,VALIDATE_DT,GATE_DT,A.GATE_NO,receipt_dt, insp_dt,dlyd_dt,PROCESS_DT   "

                cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
                dsrep = New DataSet
                adap.Fill(dsrep, "resultab")

                Dim dv As DataView
                dv = dsrep.Tables("resultab").DefaultView

                _for = "Validation"
                _for1 = "Receipt"
                _for2 = "Inspection"
                _for3 = "Delivery"

                ''''''''''' For gate values
                ''''' for gate 
                dv.RowFilter = ""
                _gt = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "gate  IS NOT NULL"
                _gt1 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "gate <.6"
                _gt2 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "gate >=.6"
                _gt3 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "gate IS NULL"
                _gt4 = dv.Count
                dv.RowFilter = ""

                ''''' for receipt
                dv.RowFilter = "GATE IS NOT NULL"
                _re = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "receipt  IS NOT NULL"
                _re1 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "receipt <.6"
                _re2 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "receipt >=.6"
                _re3 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "receipt is null AND GATE IS NOT NULL"
                _re4 = dv.Count
                dv.RowFilter = ""


                ''''' for insp

                dv.RowFilter = "RECEIPT IS NOT NULL "
                _insp = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "insp IS NOT NULL"
                _insp1 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "insp <.6"
                _insp2 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "insp >=.6"
                _insp3 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "insp is null AND RECEIPT IS NOT NULL"
                _insp4 = dv.Count
                dv.RowFilter = ""


                ''''''''''for dlyd

                dv.RowFilter = "INSP IS NOT NULL"
                _dlyd = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "dlyd IS NOT NULL"
                _dlyd1 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "dlyd <.6"
                _dlyd2 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "dlyd >=.6"
                _dlyd3 = dv.Count
                dv.RowFilter = ""

                dv.RowFilter = "dlyd is null AND INSP IS NOT NULL"
                _dlyd4 = dv.Count
                dv.RowFilter = ""

                '''' end of gate values

                Dim drv As DataRowView
                Dim mySum As Integer

                ''''''' for item values
                ''''' for gate 

                dv.RowFilter = ""
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _igt = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "item  IS NOT NULL and  gate  IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _igt1 = mySum

                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "gate < .6 and  gate  IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _igt2 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "gate >=.6 and  gate  IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _igt3 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "   gate  IS   NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _igt4 = mySum
                dv.RowFilter = ""
                mySum = 0




                ''''' for receipt
                dv.RowFilter = "item IS NOT NULL and  gate  IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _ire = mySum
                dv.RowFilter = ""
                mySum = 0


                dv.RowFilter = "receipt  IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _ire1 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "receipt <.6"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _ire2 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "receipt >=.6"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _ire3 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "receipt is null AND GATE IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _ire4 = mySum
                dv.RowFilter = ""
                mySum = 0



                ''''' for insp

                dv.RowFilter = "RECEIPT IS NOT NULL "
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _iinsp = mySum
                dv.RowFilter = ""
                mySum = 0


                dv.RowFilter = "insp IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _iinsp1 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "insp <.6"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _iinsp2 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "insp >=.6"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _iinsp3 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "insp is null AND RECEIPT IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _iinsp4 = mySum
                dv.RowFilter = ""
                mySum = 0


                ''''''''''for dlyd

                dv.RowFilter = "INSP IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next

                _idlyd = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "dlyd IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _idlyd1 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "dlyd <.6"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _idlyd2 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "dlyd >=.6"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _idlyd3 = mySum
                dv.RowFilter = ""
                mySum = 0

                dv.RowFilter = "dlyd is null AND INSP IS NOT NULL"
                For Each drv In dv
                    If IsDBNull(drv("item")) Then
                        Exit For
                    Else
                        mySum += CType(drv("item"), Integer)
                    End If
                Next
                _idlyd4 = mySum
                dv.RowFilter = ""
                mySum = 0



                ''''''' end of item values
                s &= "<TR BGCOLOR=SILVER><Td rowspan=4><FONT SIZE=2 FONT FACE=VERDANA>" & ds.Tables("resultab").Rows(i).Item("organization_code") & " </FONT></Td><Td><FONT SIZE=2 FONT FACE=VERDANA> " & _for & " </FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _gt & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _igt & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _gt1 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _igt1 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _gt2 & "</FONT></Td>"

                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _igt2 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _gt3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _igt3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _gt4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _igt4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"

                If _gt = 0 Then s &= 0 Else s &= "" & Math.Round((_gt2 / _gt) * 100, 2) & "</FONT></Td>"

                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"

                If _igt = 0 Then s &= 0 Else s &= "" & Math.Round((_igt2 / _igt) * 100, 2) & "</FONT></Td>"

                s &= " </TR>"

                s &= "<TR> <Td><FONT SIZE=2 FONT FACE=VERDANA>" & _for1 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _re & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _ire & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _re1 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _ire1 & "</FONT></Td>"

                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _re2 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _ire2 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _re3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _ire3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _re4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _ire4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"

                If _re = 0 Then s &= "0" Else s &= " " & Math.Round((_re2 / _re) * 100, 2) & "</FONT></Td>  "
                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"
                If _ire = 0 Then s &= "0" Else s &= " " & Math.Round((_ire2 / _ire) * 100, 2) & "</FONT></Td>  "

                s &= " </TR>"

                s &= "<TR  BGCOLOR=SILVER> <Td><FONT SIZE=2 FONT FACE=VERDANA>" & _for2 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _insp & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _iinsp & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _insp1 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _iinsp1 & "</FONT></Td>"

                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _insp2 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _iinsp2 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _insp3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _iinsp3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _insp4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _iinsp4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"

                If _insp = 0 Then s &= "0" Else s &= "" & Math.Round((_insp2 / _insp) * 100, 2) & "</FONT></Td> "
                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"
                If _iinsp = 0 Then s &= "0" Else s &= "" & Math.Round((_iinsp2 / _iinsp) * 100, 2) & "</FONT></Td>"

                s &= " </TR>"

                s &= "<TR> <Td><FONT SIZE=2 FONT FACE=VERDANA>" & _for3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _dlyd & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _idlyd & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _dlyd1 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _idlyd1 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _dlyd2 & "</FONT></Td>"

                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _idlyd2 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _dlyd3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _idlyd3 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _dlyd4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>" & _idlyd4 & "</FONT></Td><Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"

                If _dlyd = 0 Then s &= " 0" Else s &= " " & Math.Round((_dlyd2 / _dlyd) * 100, 2) & "</FONT></Td> "
                s &= " <Td ALIGN=RIGHT><FONT SIZE=1.5 FONT FACE=VERDANA>"
                If _idlyd = 0 Then s &= " 0" Else s &= " " & Math.Round((_idlyd2 / _idlyd) * 100, 2) & "</FONT></Td> "

                s &= " </TR>"

            Next
            Dim X As String
            X = "c:\gate\M20-inward status analysis.HTML"
            Dim fstrm As New FileStream(X, FileMode.Create, FileAccess.Write)
            Dim sw As New StreamWriter(fstrm)

            s = s & "</table></html>"
            sw.WriteLine(s)
            fstrm.Flush()
            sw.Flush()
            sw.Close()
            fstrm.Close()
            System.Diagnostics.Process.Start(X)
            Me.Cursor = Cursors.Arrow

        Catch ex As Exception
            Me.Cursor = Cursors.Arrow
            MessageBox.Show(ex.ToString)
        End Try
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub btnvallist_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnvallist.Click
        Try

            Me.Cursor = Cursors.WaitCursor
            sql = "SELECT  distinct jan_orgcode(c.org_id) org, a.gate_no,a.gdate,dc_no,dc_date ,A.SUPPLIER_NAME,B.REA_NAME   FROM JAN_GATE_HEADER A,JAN_GATE_NVAL_REASON B    ,JAN_GATE_LINES C where a.GATE_NO=B.GATE_NO and    c.GATE_NO = a.GATE_NO And a.GATE_NO = b.GATE_NO and c.org_id in (106,107,108,109)    and a.gdate>=TO_DATE('" & txtfm.Text & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and a.gdate<=TO_DATE('" & txtto.Text & " 23:59:00','DD/MM/YYYY HH24:MI:SS')and B.REA_CODE<>28  and B.REA_NAME is not null  "

            If UNIT7.Checked = True Then sql &= " and a.unit='UNIT7' "
            If UNIT2.Checked = True Then sql &= " and a.unit='UNIT2' "
            If RD3.Checked = True Then sql &= "  and  a.UNIT='UNIT4' "
            If RDSKY.Checked = True Then sql &= " and  a.UNIT='SKYFAST'"

            If rdpo.Checked = True Then sql &= "AND GTYPE='" & rdpo.Text & "'"
            If rdosp.Checked = True Then sql &= "AND GTYPE='" & rdosp.Text & "'"



            cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
            Dim d As New DataSet
            adap.Fill(d, "resultab")

            s = "<html><body>"

            s &= "<h4 align=center><font face=verdana size=2>Not Validate List "
            s &= " FROM :" & txtfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtto.Text & "<BR>"

            'If rdpo.Checked = True Then s &= " & RDPO.Text "
            'If rdosp.Checked = True Then sql &= "AND GTYPE='" & rdpo.Text & "'"

            s &= " Report run time: " & Date.Now & "</font></h4>"

            s &= "<table border=1 cellspacing=0 align=top cellpadding=5 ><TR bgcolor=silver><Td ><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></Td><Td><FONT SIZE=2 FONT FACE=VERDANA>Org</FONT></Td> <Td><FONT SIZE=2 FONT FACE=VERDANA>Gate No</FONT></Td><Td><FONT SIZE=2 FONT FACE=VERDANA>Gate Dt</FONT></Td><Td ><FONT SIZE=2 FONT FACE=VERDANA>Dc No</FONT></Td><Td ><FONT SIZE=2 FONT FACE=VERDANA>Dc Dt</FONT></Td><Td  ><FONT SIZE=2 FONT FACE=VERDANA>Supplier</FONT></Td><Td ><FONT SIZE=2 FONT FACE=VERDANA>Reason</FONT></Td>  </TR>"

            j = 0

            For i = 0 To d.Tables("resultab").Rows.Count - 1
                With d.Tables("resultab").Rows(i)
                    j += 1
                    s &= "<TR><Td ><FONT SIZE=2 FONT FACE=VERDANA>" & j & "</FONT></Td>  <Td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("org") & "</FONT></Td><Td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("gate_No") & "</FONT></Td><Td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("Gdate") & "</FONT></Td><Td><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("Dc_No") & "</FONT></Td><Td ><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("Dc_Date") & "</FONT></Td><Td  ><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("Supplier_name") & "</FONT></Td><Td ><FONT SIZE=2 FONT FACE=VERDANA>" & .Item("Rea_name") & "</FONT></Td > </TR>"
                End With
            Next

            Dim X As String
            X = "c:\gate\not validate list.HTML"
            Dim fstrm As New FileStream(X, FileMode.Create, FileAccess.Write)
            Dim sw As New StreamWriter(fstrm)

            s = s & "</table></html>"
            sw.WriteLine(s)
            fstrm.Flush()
            sw.Flush()
            sw.Close()
            fstrm.Close()
            System.Diagnostics.Process.Start(X)
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
End Class