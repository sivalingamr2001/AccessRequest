
Imports System.Data.OracleClient
Imports oracleclass

Public Class Class2
    'Public con As New Odbc.OdbcConnection("Driver=Microsoft ODBC For Oracle;uid=apps;pwd=apps;server=prod")
    'Dim (cl.orcmd) As New oracleCommand
    Dim prm As New Odbc.OdbcParameter
    Dim str As String
    Dim cl As New oracleclass.Class1

    Public Sub dataacs(ByVal name_sp As String, ByVal para_sp As Hashtable)
        Try

            cl.orcmd = New OracleCommand(name_sp, CON)
            cl.orcmd.CommandType = CommandType.StoredProcedure
            For Each str As String In para_sp.Keys
                prm = New Odbc.OdbcParameter(str.ToString, para_sp(str).ToString)
                cl.orcmd.Parameters.Add(prm)
            Next
            ' connect()
            cl.orcmd.ExecuteNonQuery()
            'sqlconn.Close()
        Catch ex As Exception
            '  MsgBox(ex.Message)
        End Try
    End Sub
End Class
