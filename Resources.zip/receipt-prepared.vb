Imports System.Data.OracleClient
Imports System.io
Public Class receipt_prepared

    Dim x1 As String
    Private Sub receipt_prepared_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            sql = "SELECT   name From jan_recpt_users"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "RESULTAB")
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                gtype.Items.Add(ds.Tables("resultab").Rows(i).Item("name"))
            Next
            sql = "select organization_code  from org_organization_definitions where organization_code  not in('I08','I09')order by organization_code"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Try
            dgv.Columns.Clear()
            Me.Cursor = Cursors.WaitCursor
            sql = " SELECT jan_orgcode(to_organization_id)org,receipt_num,checked_by,sum(quantity_received)qty,"
            If rdpo.Checked = True Then sql &= " count(item_no)item "
            If rdosp.Checked = True Then sql &= " count(partno)item "

            sql &= " FROM"

            If rdpo.Checked = True Then sql &= "   jan_pur_listing "
            If rdosp.Checked = True Then sql &= " jan_osp_listing"
            sql &= " where to_organization_id not in (104,144)"

            If gtype.Text <> "" Then sql &= " and checked_by='" & gtype.Text & "'"

            If cmborg.SelectedItem <> "" Then sql &= " and to_organization_id=jan_orgid('" & cmborg.SelectedItem & "' ) "

            sql &= "and receipt_date >=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and receipt_date <=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            sql &= "   group by to_organization_id,receipt_num,checked_by "

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            With dgv
                .DataSource = ds.Tables("resultab")
                .Columns(0).HeaderText = "Org" : .Columns(0).Width = 50
                .Columns(1).HeaderText = "Receipt Num" : .Columns(1).Width = 200
                .Columns(2).HeaderText = "Checked By" : .Columns(2).Width = 200
                .Columns(3).HeaderText = "Qty" : .Columns(3).Width = 50 : .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns(4).HeaderText = "No.Of items" : .Columns(4).Width = 80 : .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End With


            sql = " SELECT  checked_by,count(receipt_num),sum(quantity_received)qty,"
            If rdpo.Checked = True Then sql &= " count(distinct item_no)item "
            If rdosp.Checked = True Then sql &= " count(distinct partno)item "

            sql &= " FROM"

            If rdpo.Checked = True Then sql &= "   jan_pur_listing "
            If rdosp.Checked = True Then sql &= " jan_osp_listing"
            sql &= " where to_organization_id not in (104,144)"

            If gtype.Text <> "" Then sql &= " and checked_by='" & gtype.Text & "'"

            If cmborg.SelectedItem <> "" Then sql &= " and to_organization_id=jan_orgid('" & cmborg.SelectedItem & "' ) "

            sql &= "and receipt_date >=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and receipt_date <=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            sql &= "   group by  checked_by "

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            With dgv1
                .DataSource = ds.Tables("resultab")
                .Columns(0).HeaderText = "Checked By" : .Columns(0).Width = 200
                .Columns(1).HeaderText = "Total Receipt" : .Columns(1).Width = 100 : .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

                .Columns(2).HeaderText = "Qty" : .Columns(2).Width = 50 : .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns(3).HeaderText = "No.Of items" : .Columns(3).Width = 80 : .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End With






            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnprint_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnprint.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Dim qty, itcnt As Double
            s = ""
            s = "<h4 align=center><font face=verdana size=2>Receipt Prepared List <br>"
            s &= "<h4 align=center><font face=verdana size=2>Checked By:" & gtype.SelectedItem & " || Org:" & cmborg.SelectedItem & "<br>"
            s &= " Receipt Date:" & Format(inwdtf.Value, "dd-MMM-yyyy") & " || To :" & Format(inwdtto.Value, "dd-MMM-yyyy") & "<br>"
            s &= " Reportt Date:" & Date.Now & "</font></h4>"
            s &= "<TABLE border=1 cellspacing=0 cellpadding=2 align=center  width=100%><tr>"
            s &= " <td height=50><FONT SIZE=2 font face=verdana>S.No</td>"
            For i = 0 To dgv.Columns.Count - 1
                With dgv.Columns(i)
                    s &= " <td height=50><FONT SIZE=2 font face=verdana>" & .HeaderText.ToUpper & "</td>  "
                End With

            Next

            s &= "</tr>"



            For k = 0 To dgv.Rows.Count - 1
                s &= "<tr>"
                s &= "<td><FONT SIZE=2 font face=verdana>" & k + 1 & "</td>"
                For i = 0 To dgv.Columns.Count - 1


                    With dgv.Rows(k)
                        If i = dgv.Columns.Count - 2 Then
                            qty += .Cells(i).Value
                        ElseIf i = dgv.Columns.Count - 1 Then
                            itcnt += .Cells(i).Value
                        End If

                        s &= " <td><FONT SIZE=2 font face=verdana>" & .Cells(i).Value & "  "
                    End With

                Next

                s &= "</tr>"

            Next

            s &= "<tr><td colspan=" & dgv.Columns.Count - 1 & " >&nbsp;</td><td><FONT SIZE=2 font face=verdana> " & qty & "</td> <td><FONT SIZE=2 font face=verdana> " & itcnt & "</td></tr>"

            s &= "</table><br> "


            s &= "<h4 align=center><font face=verdana size=2> Total Receipt Completed</font></h4> <br>"

            '''''''''''''' for dgv1

            s &= "<TABLE border=1 cellspacing=0 cellpadding=2 align=center  width=100%><tr>"
            s &= " <td height=50><FONT SIZE=2 font face=verdana>S.No</td>"
            For i = 0 To dgv1.Columns.Count - 1
                With dgv1.Columns(i)
                    s &= " <td height=50><FONT SIZE=2 font face=verdana>" & .HeaderText.ToUpper & "</td>  "
                End With

            Next

            s &= "</tr>"



            For k = 0 To dgv1.Rows.Count - 1
                s &= "<tr>"
                s &= "<td><FONT SIZE=2 font face=verdana>" & k + 1 & "</td>"
                For i = 0 To dgv1.Columns.Count - 1


                    With dgv1.Rows(k)
                        

                        s &= " <td><FONT SIZE=2 font face=verdana>" & .Cells(i).Value & "  "
                    End With

                Next

                s &= "</tr>"

            Next



            x1 = "c:\receipt-prepared.HTML "



            fstrm = New FileStream(x1, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            sw.WriteLine(s)
            fstrm.Flush()
            sw.Flush()
            sw.Close()
            fstrm.Close()
            System.Diagnostics.Process.Start(x1)
            Me.Cursor = Cursors.Arrow

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class