<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class minmax
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblord = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.lblmaxcst = New System.Windows.Forms.Label
        Me.lblmin = New System.Windows.Forms.Label
        Me.lblmincst = New System.Windows.Forms.Label
        Me.lbitem = New System.Windows.Forms.Label
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rd3 = New System.Windows.Forms.RadioButton
        Me.rd1 = New System.Windows.Forms.RadioButton
        Me.rd2 = New System.Windows.Forms.RadioButton
        Me.dgmm = New System.Windows.Forms.DataGridView
        Me.btnpri = New System.Windows.Forms.Button
        Me.btngo = New System.Windows.Forms.Button
        Me.txtitem = New System.Windows.Forms.TextBox
        Me.cmbitem = New System.Windows.Forms.ComboBox
        Me.cmbtyp = New System.Windows.Forms.ComboBox
        Me.cmbinv = New System.Windows.Forms.ComboBox
        Me.cmborg = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.lbsale = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.lbmfg = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.lbcur = New System.Windows.Forms.Label
        Me.lbfc = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar
        Me.txtitem1 = New System.Windows.Forms.TextBox
        Me.dfm = New System.Windows.Forms.DateTimePicker
        Me.dto = New System.Windows.Forms.DateTimePicker
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.dgfc = New System.Windows.Forms.DataGridView
        Me.cmbfc = New System.Windows.Forms.ComboBox
        Me.cmborg1 = New System.Windows.Forms.ComboBox
        Me.btnpri1 = New System.Windows.Forms.Button
        Me.btngo1 = New System.Windows.Forms.Button
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgmm, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dgfc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(920, 601)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.ProgressBar1)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.dgmm)
        Me.TabPage1.Controls.Add(Me.btnpri)
        Me.TabPage1.Controls.Add(Me.btngo)
        Me.TabPage1.Controls.Add(Me.txtitem)
        Me.TabPage1.Controls.Add(Me.cmbitem)
        Me.TabPage1.Controls.Add(Me.cmbtyp)
        Me.TabPage1.Controls.Add(Me.cmbinv)
        Me.TabPage1.Controls.Add(Me.cmborg)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(912, 575)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Min-Max"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.lblord)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.lblmaxcst)
        Me.GroupBox2.Controls.Add(Me.lblmin)
        Me.GroupBox2.Controls.Add(Me.lblmincst)
        Me.GroupBox2.Controls.Add(Me.lbitem)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 441)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(460, 100)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label11.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(114, 53)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(62, 13)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "Min Value"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label12.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(267, 16)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(66, 13)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Max Value"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label10.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(110, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(62, 13)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Min Value"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "No of Items"
        '
        'lblord
        '
        Me.lblord.AutoSize = True
        Me.lblord.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblord.ForeColor = System.Drawing.Color.Crimson
        Me.lblord.Location = New System.Drawing.Point(175, 53)
        Me.lblord.Name = "lblord"
        Me.lblord.Size = New System.Drawing.Size(15, 13)
        Me.lblord.TabIndex = 2
        Me.lblord.Text = " :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(6, 53)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Below Min"
        '
        'lblmaxcst
        '
        Me.lblmaxcst.AutoSize = True
        Me.lblmaxcst.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmaxcst.ForeColor = System.Drawing.Color.Crimson
        Me.lblmaxcst.Location = New System.Drawing.Point(332, 16)
        Me.lblmaxcst.Name = "lblmaxcst"
        Me.lblmaxcst.Size = New System.Drawing.Size(15, 13)
        Me.lblmaxcst.TabIndex = 2
        Me.lblmaxcst.Text = " :"
        '
        'lblmin
        '
        Me.lblmin.AutoSize = True
        Me.lblmin.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmin.ForeColor = System.Drawing.Color.Crimson
        Me.lblmin.Location = New System.Drawing.Point(77, 53)
        Me.lblmin.Name = "lblmin"
        Me.lblmin.Size = New System.Drawing.Size(15, 13)
        Me.lblmin.TabIndex = 2
        Me.lblmin.Text = " :"
        '
        'lblmincst
        '
        Me.lblmincst.AutoSize = True
        Me.lblmincst.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmincst.ForeColor = System.Drawing.Color.Crimson
        Me.lblmincst.Location = New System.Drawing.Point(174, 16)
        Me.lblmincst.Name = "lblmincst"
        Me.lblmincst.Size = New System.Drawing.Size(15, 13)
        Me.lblmincst.TabIndex = 2
        Me.lblmincst.Text = " :"
        '
        'lbitem
        '
        Me.lbitem.AutoSize = True
        Me.lbitem.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbitem.ForeColor = System.Drawing.Color.Crimson
        Me.lbitem.Location = New System.Drawing.Point(77, 16)
        Me.lbitem.Name = "lbitem"
        Me.lbitem.Size = New System.Drawing.Size(15, 13)
        Me.lbitem.TabIndex = 2
        Me.lbitem.Text = " :"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(9, 551)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(160, 17)
        Me.ProgressBar1.TabIndex = 7
        Me.ProgressBar1.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rd3)
        Me.GroupBox1.Controls.Add(Me.rd1)
        Me.GroupBox1.Controls.Add(Me.rd2)
        Me.GroupBox1.Location = New System.Drawing.Point(607, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(203, 33)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        '
        'rd3
        '
        Me.rd3.AutoSize = True
        Me.rd3.Location = New System.Drawing.Point(119, 8)
        Me.rd3.Name = "rd3"
        Me.rd3.Size = New System.Drawing.Size(71, 17)
        Me.rd3.TabIndex = 4
        Me.rd3.TabStop = True
        Me.rd3.Text = "To Follow"
        Me.rd3.UseVisualStyleBackColor = True
        '
        'rd1
        '
        Me.rd1.AutoSize = True
        Me.rd1.Checked = True
        Me.rd1.Location = New System.Drawing.Point(6, 8)
        Me.rd1.Name = "rd1"
        Me.rd1.Size = New System.Drawing.Size(36, 17)
        Me.rd1.TabIndex = 3
        Me.rd1.TabStop = True
        Me.rd1.Text = "All"
        Me.rd1.UseVisualStyleBackColor = True
        '
        'rd2
        '
        Me.rd2.AutoSize = True
        Me.rd2.Location = New System.Drawing.Point(42, 8)
        Me.rd2.Name = "rd2"
        Me.rd2.Size = New System.Drawing.Size(74, 17)
        Me.rd2.TabIndex = 3
        Me.rd2.Text = "Below Min"
        Me.rd2.UseVisualStyleBackColor = True
        '
        'dgmm
        '
        Me.dgmm.AllowUserToAddRows = False
        Me.dgmm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgmm.Location = New System.Drawing.Point(6, 39)
        Me.dgmm.Name = "dgmm"
        Me.dgmm.ReadOnly = True
        Me.dgmm.Size = New System.Drawing.Size(898, 396)
        Me.dgmm.TabIndex = 5
        '
        'btnpri
        '
        Me.btnpri.Location = New System.Drawing.Point(850, 10)
        Me.btnpri.Name = "btnpri"
        Me.btnpri.Size = New System.Drawing.Size(50, 23)
        Me.btnpri.TabIndex = 4
        Me.btnpri.Text = "Print"
        Me.btnpri.UseVisualStyleBackColor = True
        '
        'btngo
        '
        Me.btngo.Location = New System.Drawing.Point(813, 9)
        Me.btngo.Name = "btngo"
        Me.btngo.Size = New System.Drawing.Size(35, 23)
        Me.btngo.TabIndex = 4
        Me.btngo.Text = "Go"
        Me.btngo.UseVisualStyleBackColor = True
        '
        'txtitem
        '
        Me.txtitem.Location = New System.Drawing.Point(522, 10)
        Me.txtitem.Name = "txtitem"
        Me.txtitem.Size = New System.Drawing.Size(82, 20)
        Me.txtitem.TabIndex = 2
        '
        'cmbitem
        '
        Me.cmbitem.FormattingEnabled = True
        Me.cmbitem.Location = New System.Drawing.Point(419, 10)
        Me.cmbitem.Name = "cmbitem"
        Me.cmbitem.Size = New System.Drawing.Size(75, 21)
        Me.cmbitem.TabIndex = 1
        '
        'cmbtyp
        '
        Me.cmbtyp.FormattingEnabled = True
        Me.cmbtyp.Location = New System.Drawing.Point(287, 10)
        Me.cmbtyp.Name = "cmbtyp"
        Me.cmbtyp.Size = New System.Drawing.Size(75, 21)
        Me.cmbtyp.TabIndex = 1
        '
        'cmbinv
        '
        Me.cmbinv.FormattingEnabled = True
        Me.cmbinv.Location = New System.Drawing.Point(156, 11)
        Me.cmbinv.Name = "cmbinv"
        Me.cmbinv.Size = New System.Drawing.Size(75, 21)
        Me.cmbinv.TabIndex = 1
        '
        'cmborg
        '
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(31, 11)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(75, 21)
        Me.cmborg.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(495, 14)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(27, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Item"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(363, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Item Type"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(232, 14)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Make/Buy"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(104, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Inventory"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Org"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.ProgressBar2)
        Me.TabPage2.Controls.Add(Me.txtitem1)
        Me.TabPage2.Controls.Add(Me.dfm)
        Me.TabPage2.Controls.Add(Me.dto)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.dgfc)
        Me.TabPage2.Controls.Add(Me.cmbfc)
        Me.TabPage2.Controls.Add(Me.cmborg1)
        Me.TabPage2.Controls.Add(Me.btnpri1)
        Me.TabPage2.Controls.Add(Me.btngo1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(912, 575)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Forecast"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox3.Controls.Add(Me.lbsale)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.lbmfg)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.lbcur)
        Me.GroupBox3.Controls.Add(Me.lbfc)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Location = New System.Drawing.Point(11, 437)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(427, 100)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        '
        'lbsale
        '
        Me.lbsale.AutoSize = True
        Me.lbsale.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbsale.ForeColor = System.Drawing.Color.Crimson
        Me.lbsale.Location = New System.Drawing.Point(260, 54)
        Me.lbsale.Name = "lbsale"
        Me.lbsale.Size = New System.Drawing.Size(11, 13)
        Me.lbsale.TabIndex = 3
        Me.lbsale.Text = ":"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(194, 54)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(68, 13)
        Me.Label20.TabIndex = 3
        Me.Label20.Text = "Sale Value"
        '
        'lbmfg
        '
        Me.lbmfg.AutoSize = True
        Me.lbmfg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbmfg.ForeColor = System.Drawing.Color.Crimson
        Me.lbmfg.Location = New System.Drawing.Point(260, 16)
        Me.lbmfg.Name = "lbmfg"
        Me.lbmfg.Size = New System.Drawing.Size(11, 13)
        Me.lbmfg.TabIndex = 3
        Me.lbmfg.Text = ":"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(194, 16)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(67, 13)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "MFG Value"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(6, 54)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(69, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Curr Value"
        '
        'lbcur
        '
        Me.lbcur.AutoSize = True
        Me.lbcur.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbcur.ForeColor = System.Drawing.Color.Crimson
        Me.lbcur.Location = New System.Drawing.Point(74, 54)
        Me.lbcur.Name = "lbcur"
        Me.lbcur.Size = New System.Drawing.Size(11, 13)
        Me.lbcur.TabIndex = 3
        Me.lbcur.Text = ":"
        '
        'lbfc
        '
        Me.lbfc.AutoSize = True
        Me.lbfc.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbfc.ForeColor = System.Drawing.Color.Crimson
        Me.lbfc.Location = New System.Drawing.Point(76, 16)
        Me.lbfc.Name = "lbfc"
        Me.lbfc.Size = New System.Drawing.Size(11, 13)
        Me.lbfc.TabIndex = 3
        Me.lbfc.Text = ":"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(7, 16)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(58, 13)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "FC Value"
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(3, 543)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(100, 18)
        Me.ProgressBar2.TabIndex = 6
        Me.ProgressBar2.Visible = False
        '
        'txtitem1
        '
        Me.txtitem1.Location = New System.Drawing.Point(295, 3)
        Me.txtitem1.Name = "txtitem1"
        Me.txtitem1.Size = New System.Drawing.Size(100, 20)
        Me.txtitem1.TabIndex = 5
        '
        'dfm
        '
        Me.dfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dfm.Location = New System.Drawing.Point(514, 453)
        Me.dfm.Name = "dfm"
        Me.dfm.Size = New System.Drawing.Size(94, 20)
        Me.dfm.TabIndex = 4
        Me.dfm.Visible = False
        '
        'dto
        '
        Me.dto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dto.Location = New System.Drawing.Point(641, 453)
        Me.dto.Name = "dto"
        Me.dto.Size = New System.Drawing.Size(94, 20)
        Me.dto.TabIndex = 4
        Me.dto.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(467, 457)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(44, 13)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "From Dt"
        Me.Label15.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(606, 457)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(34, 13)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "To Dt"
        Me.Label14.Visible = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(112, 7)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = "FC Code"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(266, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(27, 13)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Item"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(4, 7)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Org"
        '
        'dgfc
        '
        Me.dgfc.AllowUserToAddRows = False
        Me.dgfc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgfc.Location = New System.Drawing.Point(11, 32)
        Me.dgfc.Name = "dgfc"
        Me.dgfc.ReadOnly = True
        Me.dgfc.Size = New System.Drawing.Size(883, 392)
        Me.dgfc.TabIndex = 2
        '
        'cmbfc
        '
        Me.cmbfc.FormattingEnabled = True
        Me.cmbfc.Location = New System.Drawing.Point(160, 3)
        Me.cmbfc.Name = "cmbfc"
        Me.cmbfc.Size = New System.Drawing.Size(105, 21)
        Me.cmbfc.TabIndex = 1
        '
        'cmborg1
        '
        Me.cmborg1.FormattingEnabled = True
        Me.cmborg1.Location = New System.Drawing.Point(34, 3)
        Me.cmborg1.Name = "cmborg1"
        Me.cmborg1.Size = New System.Drawing.Size(78, 21)
        Me.cmborg1.TabIndex = 1
        '
        'btnpri1
        '
        Me.btnpri1.Location = New System.Drawing.Point(447, 3)
        Me.btnpri1.Name = "btnpri1"
        Me.btnpri1.Size = New System.Drawing.Size(40, 23)
        Me.btnpri1.TabIndex = 0
        Me.btnpri1.Text = "Print"
        Me.btnpri1.UseVisualStyleBackColor = True
        '
        'btngo1
        '
        Me.btngo1.Location = New System.Drawing.Point(401, 3)
        Me.btngo1.Name = "btngo1"
        Me.btngo1.Size = New System.Drawing.Size(40, 23)
        Me.btngo1.TabIndex = 0
        Me.btngo1.Text = "Go"
        Me.btngo1.UseVisualStyleBackColor = True
        '
        'minmax
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(939, 625)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "minmax"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Planning"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgmm, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.dgfc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents dgmm As System.Windows.Forms.DataGridView
    Friend WithEvents btngo As System.Windows.Forms.Button
    Friend WithEvents rd1 As System.Windows.Forms.RadioButton
    Friend WithEvents txtitem As System.Windows.Forms.TextBox
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbitem As System.Windows.Forms.ComboBox
    Friend WithEvents cmbtyp As System.Windows.Forms.ComboBox
    Friend WithEvents cmbinv As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents rd2 As System.Windows.Forms.RadioButton
    Friend WithEvents btnpri As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents txtitem1 As System.Windows.Forms.TextBox
    Friend WithEvents dfm As System.Windows.Forms.DateTimePicker
    Friend WithEvents dto As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dgfc As System.Windows.Forms.DataGridView
    Friend WithEvents cmbfc As System.Windows.Forms.ComboBox
    Friend WithEvents cmborg1 As System.Windows.Forms.ComboBox
    Friend WithEvents btngo1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblord As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblmaxcst As System.Windows.Forms.Label
    Friend WithEvents lblmin As System.Windows.Forms.Label
    Friend WithEvents lblmincst As System.Windows.Forms.Label
    Friend WithEvents lbitem As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents btnpri1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lbsale As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents lbmfg As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lbcur As System.Windows.Forms.Label
    Friend WithEvents lbfc As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents rd3 As System.Windows.Forms.RadioButton
End Class
