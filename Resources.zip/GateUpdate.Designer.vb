<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GateUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnupdt = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtgate = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtline = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtqty = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.cmbres = New System.Windows.Forms.ComboBox()
        Me.cmbcat = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtrole = New System.Windows.Forms.TextBox()
        Me.txtpodwt = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtpod = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtwt = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btndel = New System.Windows.Forms.Button()
        Me.cmbcr = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnupdt
        '
        Me.btnupdt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnupdt.Location = New System.Drawing.Point(180, 441)
        Me.btnupdt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnupdt.Name = "btnupdt"
        Me.btnupdt.Size = New System.Drawing.Size(136, 35)
        Me.btnupdt.TabIndex = 4
        Me.btnupdt.Text = "Update Po Qty"
        Me.btnupdt.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(26, 46)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 18)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Gate No"
        '
        'txtgate
        '
        Me.txtgate.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgate.Location = New System.Drawing.Point(156, 42)
        Me.txtgate.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtgate.Name = "txtgate"
        Me.txtgate.Size = New System.Drawing.Size(148, 27)
        Me.txtgate.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(26, 86)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Line No"
        '
        'txtline
        '
        Me.txtline.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtline.Location = New System.Drawing.Point(156, 82)
        Me.txtline.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtline.Name = "txtline"
        Me.txtline.Size = New System.Drawing.Size(148, 27)
        Me.txtline.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(26, 126)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 18)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Qty"
        '
        'txtqty
        '
        Me.txtqty.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtqty.Location = New System.Drawing.Point(156, 122)
        Me.txtqty.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtqty.Name = "txtqty"
        Me.txtqty.Size = New System.Drawing.Size(148, 27)
        Me.txtqty.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.cmbcr)
        Me.GroupBox1.Controls.Add(Me.cmbres)
        Me.GroupBox1.Controls.Add(Me.cmbcat)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.txtrole)
        Me.GroupBox1.Controls.Add(Me.txtpodwt)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtpod)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtwt)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.btndel)
        Me.GroupBox1.Controls.Add(Me.txtgate)
        Me.GroupBox1.Controls.Add(Me.txtqty)
        Me.GroupBox1.Controls.Add(Me.btnupdt)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtline)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(10, 14)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Size = New System.Drawing.Size(629, 487)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Updating Gate Values"
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(27, 360)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(121, 40)
        Me.Label25.TabIndex = 100
        Me.Label25.Text = "Responsible Person"
        '
        'cmbres
        '
        Me.cmbres.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbres.FormattingEnabled = True
        Me.cmbres.Location = New System.Drawing.Point(156, 351)
        Me.cmbres.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbres.Name = "cmbres"
        Me.cmbres.Size = New System.Drawing.Size(337, 26)
        Me.cmbres.TabIndex = 99
        '
        'cmbcat
        '
        Me.cmbcat.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcat.FormattingEnabled = True
        Me.cmbcat.Items.AddRange(New Object() {"BINS", "CASH PURCHASE", "COURIER - POD", "INTER UNIT TRANSFERS", "MAINTENANCE ITEMS", "OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "SALES RETURN", "TESTING", "DELIVERY CHALLAN"})
        Me.cmbcat.Location = New System.Drawing.Point(156, 262)
        Me.cmbcat.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbcat.Name = "cmbcat"
        Me.cmbcat.Size = New System.Drawing.Size(337, 26)
        Me.cmbcat.TabIndex = 59
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(26, 264)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(88, 50)
        Me.Label19.TabIndex = 58
        Me.Label19.Text = "Inward Category"
        '
        'txtrole
        '
        Me.txtrole.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrole.Location = New System.Drawing.Point(320, 18)
        Me.txtrole.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(148, 27)
        Me.txtrole.TabIndex = 7
        Me.txtrole.Visible = False
        '
        'txtpodwt
        '
        Me.txtpodwt.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpodwt.Location = New System.Drawing.Point(415, 312)
        Me.txtpodwt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtpodwt.Name = "txtpodwt"
        Me.txtpodwt.Size = New System.Drawing.Size(148, 27)
        Me.txtpodwt.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(305, 315)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(119, 42)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "POD Weight"
        '
        'txtpod
        '
        Me.txtpod.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpod.Location = New System.Drawing.Point(152, 314)
        Me.txtpod.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtpod.Name = "txtpod"
        Me.txtpod.Size = New System.Drawing.Size(148, 27)
        Me.txtpod.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(22, 315)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(119, 42)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "POD No"
        '
        'txtwt
        '
        Me.txtwt.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtwt.Location = New System.Drawing.Point(156, 212)
        Me.txtwt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtwt.Name = "txtwt"
        Me.txtwt.Size = New System.Drawing.Size(148, 27)
        Me.txtwt.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(26, 213)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(119, 42)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Courier Recd Weight"
        '
        'btndel
        '
        Me.btndel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndel.Location = New System.Drawing.Point(320, 441)
        Me.btndel.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btndel.Name = "btndel"
        Me.btndel.Size = New System.Drawing.Size(112, 35)
        Me.btndel.TabIndex = 5
        Me.btndel.Text = "Delete Gate"
        Me.btndel.UseVisualStyleBackColor = True
        '
        'cmbcr
        '
        Me.cmbcr.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcr.FormattingEnabled = True
        Me.cmbcr.Location = New System.Drawing.Point(156, 159)
        Me.cmbcr.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbcr.Name = "cmbcr"
        Me.cmbcr.Size = New System.Drawing.Size(337, 26)
        Me.cmbcr.TabIndex = 99
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(27, 168)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(121, 40)
        Me.Label7.TabIndex = 100
        Me.Label7.Text = "Courier Name"
        '
        'GateUpdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(650, 510)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "GateUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GateUpdate-Gate Register"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnupdt As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtgate As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtline As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtqty As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btndel As System.Windows.Forms.Button
    Friend WithEvents txtwt As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtrole As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents cmbcat As ComboBox
    Friend WithEvents Label25 As Label
    Friend WithEvents cmbres As ComboBox
    Friend WithEvents txtpodwt As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtpod As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents cmbcr As ComboBox
End Class
