Imports System.Data.OracleClient
Imports System.IO
Public Class gateStatus

    
    Dim ds As New DataSet
    Dim i, j, org_id As Integer
    Dim dv As DataView
    Dim dt As DataTable
    Dim sql, unit As String
    Dim WithEvents DoIt As New DoStuffClass


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click


        Me.Cursor = Cursors.WaitCursor
        ProgressBar1.Visible = True
        DoIt.StartValue = 0
        If CheckBox1.Checked = True Then
            sql = "SELECT distinct  GATE_ID,GDATE,substr(validate_date,1,10)validate_date,to_char(receipt_date,'dd/mm/yyyy')receipt_date,INSP_STATUS,to_char(insp_date,'dd/mm/yyyy')insp_date,DELIVERY_STATUS,to_char(delivered_date,'dd/mm/yyyy') delivered_Date,VOUCHER_NOS,PAY_VOUCHER_NOS,REJECTED_QTY,RETURN_VENDOR,SUPPLIER_NAME,GTYPE,NO_OF_ITEMS,DC_QTY,org,RECEIPT_QTY,RECEIPT_NOS,DELY_QTY,MATCHED_QTY,APPROVED_QTY,unit FROM"
            If rd3.Checked = True Then sql &= " JAN_PROCURE_TO_PAY_PUR A "
            If rd4.Checked = True Then sql &= " JAN_PROCURE_TO_PAY_OSP A"

            sql &= "  where a.gdate>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')  and unit in ('" & unit.Replace(",", "','") & "') "
        Else
            sql = "SELECT distinct  GATE_ID,GDATE,substr(validate_date,1,10)validate_date,to_char(receipt_date,'dd/mm/yyyy')receipt_date,INSP_STATUS,to_char(insp_date,'dd/mm/yyyy')insp_date,DELIVERY_STATUS,to_char(delivered_date,'dd/mm/yyyy') delivered_Date,VOUCHER_NOS,PAY_VOUCHER_NOS,REJECTED_QTY,RETURN_VENDOR,MATCHED_QTY,SUPPLIER_NAME,GTYPE,NO_OF_ITEMS,DC_QTY,org,RECEIPT_QTY,RECEIPT_NOS,DELY_QTY,MATCHED_QTY,APPROVED_QTY,unit FROM   "
            If rd3.Checked = True Then sql &= "  JAN_PROCURE_TO_PAY_PUR A "
            If rd4.Checked = True Then sql &= " JAN_PROCURE_TO_PAY_OSP A"
            sql &= "   WHERE  unit  in ('" & unit.Replace(",", "','") & "')  And a.gdate >= TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"
            If Rd1.Checked = True Then
                sql = sql
            End If
            If Rd2.Checked = True Then
                ' sql &= " and delivered_date is not null and voucher_nos is null and  "
                sql &= " and ((DELY_QTY-REJECTED_QTY)<>matched_qty OR voucher_nos IS NULL ) and delivery_status = 0"
                ' sql &= " and delivery_status = 0 and  receipt_qty=dely_qty "
                '  AND  DELY_QTY>0 "
                'AND pay_voucher_nos IS NULL "
                If rd3.Checked = True Then sql &= " and round((po_rate *RECEIPT_QTY),2)>0 "
                If rd4.Checked = True Then sql &= " and round((osp_rate *RECEIPT_QTY),2)>0 "
            End If
            'If rd3.Checked = True Then
            '    sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='PO'"
            'End If
            'If rd4.Checked = True Then
            '    sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='OSP'"
            'End If


        End If



        If ComboBox1.SelectedItem = "Delivered" Then

            sql &= " and delivery_status = 0 and  receipt_qty=dely_qty "

            '(((approved_qty+rejected_qty)=dely_qty) or 
            '   sql &= " and DECODE(DELIVERY_STATUS,1 ,(APPROVED_QTY-REJECTED_QTY)=DELY_QTY,RECEIPT_QTY=DELY_QTY)"


            ' sql &= " and (CASE WHEN delivery_status =1 THEN ((approved_qty - rejected_qty)) ELSE receipt_qty END)= dely_qty "


            '  sql &= " and (CASE WHEN delivery_status = 0 THEN ((approved_qty - rejected_qty)) ELSE receipt_qty END)= dely_qty"




            ' sql &= " RECEIPT_QTY=DELY_QTY"

            '  sql &= " and (APPROVED_QTY-REJECTED_QTY)=DELY_QTY and   dely_qty=DC_QTY"

            'sql &= " and    dely_qty>0  and (dely_qty <> matched_qty)"

        ElseIf ComboBox1.SelectedItem = "Not Delivered" Then
            sql &= " and insp_date is null"
        End If

        If cmborder.SelectedItem = "Gate No" Then
            sql &= " order by to_number(gate_id)"
        ElseIf cmborder.SelectedItem = "Supplier" Then
            sql &= " order by supplier_name"
        End If

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        Dim dsp As New DataSet
        cl.oradap.Fill(dsp, "resultab")
        DoIt.StartValue = 0
        DoIt.CountLoop()

        Dim objFSO
        objFSO = CreateObject("Scripting.FileSystemObject")

        Dim X As String
        X = "c:\gate\" & Trim(CStr(Rnd() * 255)) & ".HTML"
        Dim fstrm As New FileStream(X, FileMode.Create, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        Dim S, GDATE, VENDOR, GTYPE, NITEM, DCQTY, MRIRNO, MRIRDT, MRIRQTY, IDATE, VDATE, DDATE, VNO, PVNO, REJQTY, RVENDOR, DEL As String
        S = "<html><H3 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY STATUS REPORT"
        S &= " <br>Gate Date:" & Format(inwdtf.Value, "dd-MMM-yyyy") & " || To: " & Format(inwdtto.Value, "dd-MMM-yyyy") & " "
        If CheckBox1.Checked = False Then
            S &= " <br> Filter For:"
            If Rd1.Checked = True Then S &= "" & Rd1.Text & ""
            If Rd2.Checked = True Then S &= "" & Rd2.Text & ""
            S &= "<BR>Gate Type:"
            If rd3.Checked = True Then S &= "" & rd3.Text & ""
            If rd4.Checked = True Then S &= "" & rd4.Text & ""
        End If



        S &= "</FONT></H3>"
        S &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GTYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>NO ITEMS</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC QTY</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA> GATE VALIDATE DT</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>MRIR NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>MRIR DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>MRIR QTY</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>INSP DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DEL QTY</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DEL DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>VOUCHER NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PAYMENT</FONT></TH><TH><FONT SIZE=1 FoNT FACE=VERDANA>REJ QTY</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>RETURN VENDOR</FONT></TH><TH><FONT SIZE=1 FoNT FACE=VERDANA>UNIT</FONT></TH></TR>"

        j = 0
        For i = 0 To dsp.Tables("RESULTAB").Rows.Count - 1
            j = j + 1

            With dsp.Tables("RESULTAB").Rows(i)
                GDATE = .Item("GDATE").ToString
                'If GDATE <> "" Then
                '    GDATE = GDATE.Substring(0, 15)
                'Else
                '    GDATE = "-"
                'End If

                If .Item("SUPPLIER_NAME").ToString <> "" Then
                    VENDOR = .Item("SUPPLIER_NAME").ToString
                Else
                    VENDOR = "-"
                End If

                If .Item("GTYPE").ToString <> "" Then
                    GTYPE = .Item("GTYPE").ToString
                Else
                    GTYPE = "-"
                End If

                If .Item("NO_OF_ITEMS").ToString <> "" Then
                    NITEM = .Item("NO_OF_ITEMS").ToString
                Else
                    NITEM = "-"
                End If

                If .Item("DC_QTY").ToString <> "" Then
                    DCQTY = .Item("DC_QTY").ToString
                Else
                    DCQTY = "-"
                End If

                If .Item("DELY_QTY").ToString <> "" Then
                    DEL = .Item("DELY_QTY").ToString
                Else
                    DEL = "-"
                End If
                If .Item("RECEIPT_NOS").ToString <> "" Then
                    MRIRNO = .Item("RECEIPT_NOS").ToString
                Else
                    MRIRNO = "-"
                End If

                If .Item("RECEIPT_DATE").ToString <> "" Then
                    MRIRDT = .Item("RECEIPT_DATE").ToString
                Else
                    MRIRDT = "-"
                End If

                If .Item("RECEIPT_QTY").ToString <> "" Then
                    MRIRQTY = .Item("RECEIPT_QTY").ToString
                Else
                    MRIRQTY = "-"
                End If

                If .Item("INSP_DATE").ToString <> "" Then
                    IDATE = .Item("INSP_DATE").ToString
                Else
                    IDATE = "-"
                End If

                If .Item("VALIDATE_DATE").ToString <> "" Then
                    VDATE = .Item("VALIDATE_DATE").ToString
                Else
                    VDATE = "-"
                End If

                If .Item("DELIVERED_DATE").ToString <> "" Then
                    DDATE = .Item("DELIVERED_DATE").ToString
                Else
                    DDATE = "-"
                End If

                If .Item("VOUCHER_NOS").ToString <> "" Then
                    VNO = .Item("VOUCHER_NOS").ToString
                Else
                    VNO = "-"
                End If
                If .Item("PAY_VOUCHER_NOS").ToString <> "" Then
                    PVNO = .Item("PAY_VOUCHER_NOS").ToString
                Else
                    PVNO = "-"
                End If

                If .Item("RETURN_VENDOR").ToString <> "" Then
                    RVENDOR = .Item("RETURN_VENDOR").ToString
                Else
                    RVENDOR = "-"
                End If

                If .Item("rejected_qty").ToString = "" Then
                    REJQTY = "-"
                Else
                    REJQTY = .Item("rejected_qty").ToString
                End If

                S &= "<TR><Td><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_ID") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & GDATE & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & VENDOR & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & GTYPE & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & NITEM & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & DCQTY & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & VDATE & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & MRIRNO & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & MRIRDT & " </FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & MRIRQTY & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & IDATE & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & DEL & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & DDATE & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & VNO & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & PVNO & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & REJQTY & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & RVENDOR & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("unit") & "</FONT></Td></TR>"
            End With
        Next
        DoIt.StartValue = 0
        DoIt.CountLoop()
        S &= "</table></html>"
        sw.WriteLine(S)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(X)
        ProgressBar1.Visible = False
        Me.Cursor = Cursors.Arrow
    End Sub
    Private Sub UpdateProgressBar(ByVal MyCountInteger As Integer) Handles DoIt.OnProgress
        ProgressBar1.Value = MyCountInteger
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub gateStatus_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        End
    End Sub

    Private Sub gateStatus_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        unit = "UNIT7" ' Environment.GetCommandLineArgs(3)
        cmborder.SelectedItem = "Gate No"
        'ComboBox1.SelectedItem = "Delivered"
        ' cmborg.Items.Add("All")

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Cursor = Cursors.WaitCursor

        sql = "select * from "

        If rd3.Checked = True Then sql &= " jan_gate_status_po"
        If rd4.Checked = True Then sql &= " jan_gate_status_osp"

        sql &= " a "

        sql &= "  where  a.gdate>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')  AND unit  in ('" & unit.Replace(",", "','") & "') "



        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        If ds.Tables.Contains("cr") = True Then
            ds.Tables("cr").Rows.Clear()
        End If
        cl.oradap.Fill(ds, "cr")


        dv = ds.Tables("cr").DefaultView
        ' dv.RowFilter = "(DELY_QTY-REJECTED_QTY)<>matched_qty  and delivery_status = 0"
        ' dv.RowFilter = "    dELY_QTY= quantity_received and    VOUCHER_NOS is null "
        '  dv.RowFilter = " ((-REJECTED_QTY)<>matched_qty Or voucher_nos Is NULL ) And delivery_status = 0 and quantity_Received >0 "
        'dv.RowFilter = " DELY_QTY  >0  and ((DELY_QTY-REJECTED_QTY) <> matched_qty) and delivery_status = 0 and quantity_Received >0 "
        'dv.RowFilter = " DELY_QTY <> quantity_Received and matched_qty =0 "
        dv.RowFilter = "   DELY_QTY =quantity_Received and ((DELY_QTY-REJECTED_QTY)<>matched_qty OR voucher_nos IS NULL ) and delivery_status = 0 and quantity_Received >0 "

        ds1.Tables.Clear()
        ds1.Tables.Add(dv.ToTable())
        ds1.AcceptChanges()

        Dim l As Integer

        s = ""
        s &= "<html><head><h4 align=center font face=Verdana>Not Matched List  | From Dt:" & inwdtf.Text & "| To Dt:" & inwdtto.Text & "</head>"

        s &= "<TABLE border=1 cellspacing=0 cellpadding=1.5><tr> <td><FONT SIZE=2 font face=verdana>S.No</td> "
        For l = 0 To ds1.Tables("cr").Columns.Count - 1
            With ds1.Tables("cr").Columns(l)
                s &= "<td><FONT SIZE=1.5 font face=verdana>" & .ColumnName & "</td>  "
            End With

        Next

        s &= "</tr>"



        For k = 0 To ds1.Tables("cr").Rows.Count - 1
            s &= "<tr><td><FONT SIZE=1.5 font face=verdana>" & k + 1 & "</td>"
            For l = 0 To ds1.Tables("cr").Columns.Count - 1


                With ds1.Tables("cr").Rows(k)
                    If .Item(l).ToString = "" Then
                        s &= " <td><FONT SIZE=1.5 font face=verdana>&nbsp;"
                    Else
                        s &= " <td><FONT SIZE=1.5 font face=verdana>" & .Item(l) & "  "

                    End If
                End With

            Next

            s &= "</tr>"

        Next

        s &= "</table></html>"

        x = "d:\receipt\match_pend.HTML "


        dv.RowFilter = ""
        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
        Me.Cursor = Cursors.Arrow



    End Sub

    Private Sub rd6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rd6.CheckedChanged

    End Sub
End Class