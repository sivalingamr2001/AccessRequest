﻿
Imports System.Data.OracleClient
Public Class Gate_Status_Login
    Private Sub btnlog_Click(sender As Object, e As EventArgs) Handles btnlog.Click
        sql = "SELECT * FROM jan_receipt_rights WHERE UNAME='" & UCase(txtuname.Text) & "' AND UPWD='" & UCase(txtpwd.Text) & "' AND PORTAL_NAME='Gate Status' "
        cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "RESULTAB")
        If ds.Tables("RESULTAB").Rows.Count > 0 Then
            With ds.Tables("RESULTAB").Rows(0)

            End With
            gateStatus.Show()
            Me.Hide()
        Else
            MessageBox.Show("Invalid Login", "Kardex")
        End If
    End Sub

    Private Sub btncan_Click(sender As Object, e As EventArgs) Handles btncan.Click
        Me.Close()
    End Sub

    Private Sub txtpwd_KeyDown(sender As Object, e As KeyEventArgs) Handles txtpwd.KeyDown
        If e.KeyCode = 13 Then
            btnlog_Click(sender, e)
        End If
    End Sub
End Class