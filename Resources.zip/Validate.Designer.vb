<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Validate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbtnnv = New System.Windows.Forms.RadioButton()
        Me.rbtnv = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtlog = New System.Windows.Forms.TextBox()
        Me.txtpo = New System.Windows.Forms.TextBox()
        Me.txtitem = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtgno = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbtype = New System.Windows.Forms.Label()
        Me.txttypt = New System.Windows.Forms.TextBox()
        Me.TXTLINE = New System.Windows.Forms.TextBox()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.txtrole = New System.Windows.Forms.TextBox()
        Me.txtorg = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnok = New System.Windows.Forms.Button()
        Me.dgval = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbval = New System.Windows.Forms.ComboBox()
        Me.chkeinv = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtgst = New System.Windows.Forms.TextBox()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgval, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.BackgroundColor = System.Drawing.Color.White
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(24, 119)
        Me.dgv.Name = "dgv"
        Me.dgv.Size = New System.Drawing.Size(583, 222)
        Me.dgv.TabIndex = 0
        Me.dgv.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbtnnv)
        Me.GroupBox1.Controls.Add(Me.rbtnv)
        Me.GroupBox1.Location = New System.Drawing.Point(7, -3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(197, 31)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'rbtnnv
        '
        Me.rbtnnv.AutoSize = True
        Me.rbtnnv.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnnv.Location = New System.Drawing.Point(86, 9)
        Me.rbtnnv.Name = "rbtnnv"
        Me.rbtnnv.Size = New System.Drawing.Size(100, 17)
        Me.rbtnnv.TabIndex = 2
        Me.rbtnnv.TabStop = True
        Me.rbtnnv.Text = "Not Validated"
        Me.rbtnnv.UseVisualStyleBackColor = True
        '
        'rbtnv
        '
        Me.rbtnv.AutoSize = True
        Me.rbtnv.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnv.Location = New System.Drawing.Point(4, 9)
        Me.rbtnv.Name = "rbtnv"
        Me.rbtnv.Size = New System.Drawing.Size(77, 17)
        Me.rbtnv.TabIndex = 1
        Me.rbtnv.TabStop = True
        Me.rbtnv.Text = "Validated"
        Me.rbtnv.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtlog)
        Me.GroupBox2.Controls.Add(Me.txtpo)
        Me.GroupBox2.Controls.Add(Me.txtitem)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtgno)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(209, -3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(471, 31)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'txtlog
        '
        Me.txtlog.Location = New System.Drawing.Point(490, 16)
        Me.txtlog.Name = "txtlog"
        Me.txtlog.Size = New System.Drawing.Size(53, 20)
        Me.txtlog.TabIndex = 6
        Me.txtlog.Visible = False
        '
        'txtpo
        '
        Me.txtpo.Location = New System.Drawing.Point(196, 6)
        Me.txtpo.Name = "txtpo"
        Me.txtpo.Size = New System.Drawing.Size(120, 20)
        Me.txtpo.TabIndex = 4
        '
        'txtitem
        '
        Me.txtitem.Location = New System.Drawing.Point(346, 6)
        Me.txtitem.Name = "txtitem"
        Me.txtitem.Size = New System.Drawing.Size(120, 20)
        Me.txtitem.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(157, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "PO No"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(319, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Item"
        '
        'txtgno
        '
        Me.txtgno.Location = New System.Drawing.Point(57, 7)
        Me.txtgno.Name = "txtgno"
        Me.txtgno.Size = New System.Drawing.Size(100, 20)
        Me.txtgno.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Gate No"
        '
        'lbtype
        '
        Me.lbtype.Location = New System.Drawing.Point(688, 30)
        Me.lbtype.Name = "lbtype"
        Me.lbtype.Size = New System.Drawing.Size(94, 23)
        Me.lbtype.TabIndex = 7
        Me.lbtype.Text = "dfsdfds"
        Me.lbtype.Visible = False
        '
        'txttypt
        '
        Me.txttypt.Location = New System.Drawing.Point(707, 539)
        Me.txttypt.Name = "txttypt"
        Me.txttypt.Size = New System.Drawing.Size(18, 20)
        Me.txttypt.TabIndex = 7
        Me.txttypt.Visible = False
        '
        'TXTLINE
        '
        Me.TXTLINE.Location = New System.Drawing.Point(363, 538)
        Me.TXTLINE.Name = "TXTLINE"
        Me.TXTLINE.Size = New System.Drawing.Size(49, 20)
        Me.TXTLINE.TabIndex = 5
        Me.TXTLINE.Visible = False
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.BackgroundColor = System.Drawing.Color.White
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(5, 56)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.Size = New System.Drawing.Size(603, 612)
        Me.dgv1.TabIndex = 6
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(538, 538)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(100, 20)
        Me.txtrole.TabIndex = 8
        Me.txtrole.Visible = False
        '
        'txtorg
        '
        Me.txtorg.Location = New System.Drawing.Point(427, 536)
        Me.txtorg.Name = "txtorg"
        Me.txtorg.Size = New System.Drawing.Size(100, 20)
        Me.txtorg.TabIndex = 9
        Me.txtorg.Visible = False
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Red
        Me.Label4.Location = New System.Drawing.Point(7, 56)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(768, 60)
        Me.Label4.TabIndex = 10
        '
        'btnok
        '
        Me.btnok.BackColor = System.Drawing.Color.Yellow
        Me.btnok.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnok.Location = New System.Drawing.Point(608, 29)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(75, 23)
        Me.btnok.TabIndex = 11
        Me.btnok.Text = "Save"
        Me.btnok.UseVisualStyleBackColor = False
        Me.btnok.Visible = False
        '
        'dgval
        '
        Me.dgval.AllowUserToAddRows = False
        Me.dgval.BackgroundColor = System.Drawing.Color.White
        Me.dgval.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgval.Location = New System.Drawing.Point(611, 55)
        Me.dgval.Name = "dgval"
        Me.dgval.Size = New System.Drawing.Size(573, 347)
        Me.dgval.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(391, 34)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Validated By"
        Me.Label5.Visible = False
        '
        'cmbval
        '
        Me.cmbval.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbval.FormattingEnabled = True
        Me.cmbval.Items.AddRange(New Object() {"--Select--"})
        Me.cmbval.Location = New System.Drawing.Point(459, 30)
        Me.cmbval.Name = "cmbval"
        Me.cmbval.Size = New System.Drawing.Size(141, 21)
        Me.cmbval.TabIndex = 50
        Me.cmbval.Visible = False
        '
        'chkeinv
        '
        Me.chkeinv.AutoSize = True
        Me.chkeinv.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkeinv.Location = New System.Drawing.Point(7, 34)
        Me.chkeinv.Margin = New System.Windows.Forms.Padding(2)
        Me.chkeinv.Name = "chkeinv"
        Me.chkeinv.Size = New System.Drawing.Size(131, 17)
        Me.chkeinv.TabIndex = 51
        Me.chkeinv.Text = "E-Invoice Supplier"
        Me.chkeinv.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(141, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(83, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "E-Way Bill No"
        '
        'txtgst
        '
        Me.txtgst.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgst.Location = New System.Drawing.Point(226, 31)
        Me.txtgst.Name = "txtgst"
        Me.txtgst.Size = New System.Drawing.Size(161, 20)
        Me.txtgst.TabIndex = 3
        '
        'Validate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1190, 675)
        Me.Controls.Add(Me.lbtype)
        Me.Controls.Add(Me.chkeinv)
        Me.Controls.Add(Me.cmbval)
        Me.Controls.Add(Me.dgval)
        Me.Controls.Add(Me.btnok)
        Me.Controls.Add(Me.TXTLINE)
        Me.Controls.Add(Me.txttypt)
        Me.Controls.Add(Me.txtgst)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtorg)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dgv)
        Me.Controls.Add(Me.Label4)
        Me.MinimizeBox = False
        Me.Name = "Validate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gate Register-Validation"
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgval, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbtnnv As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnv As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtpo As System.Windows.Forms.TextBox
    Friend WithEvents txtitem As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtgno As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents TXTLINE As System.Windows.Forms.TextBox
    Friend WithEvents txtlog As System.Windows.Forms.TextBox
    Friend WithEvents txttypt As System.Windows.Forms.TextBox
    Friend WithEvents txtrole As System.Windows.Forms.TextBox
    Friend WithEvents txtorg As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents lbtype As Label
    Friend WithEvents btnok As Button
    Friend WithEvents dgval As DataGridView
    Friend WithEvents Label5 As Label
    Friend WithEvents cmbval As ComboBox
    Friend WithEvents chkeinv As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtgst As TextBox
End Class
