<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Add
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.cmbtype = New System.Windows.Forms.ComboBox()
        Me.btnmod = New System.Windows.Forms.Button()
        Me.btnupdt = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtorg = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.dgv12 = New System.Windows.Forms.DataGridView()
        Me.cmbsup = New System.Windows.Forms.ComboBox()
        Me.txttype = New System.Windows.Forms.TextBox()
        Me.txtgno = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cmbpo = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.cmbitem = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtsite = New System.Windows.Forms.TextBox()
        Me.dtdc = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtgdt = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtdcno = New System.Windows.Forms.TextBox()
        Me.TXTUSER = New System.Windows.Forms.TextBox()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.pono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.podt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.org = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.rev = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.popend = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.uom = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dcqty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poqty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Po = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.osp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.operation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.job = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.type = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poline = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pohead = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.val = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lineloc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.remark = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtrole = New System.Windows.Forms.TextBox()
        Me.txt_adi_no = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.scmcon2 = New System.Data.SqlClient.SqlConnection()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.chk_adi = New System.Windows.Forms.CheckBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtinv = New System.Windows.Forms.TextBox()
        Me.xerox = New System.Windows.Forms.CheckBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtadirea = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.dtadi = New System.Windows.Forms.DateTimePicker()
        Me.chkref = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtnorg = New System.Windows.Forms.TextBox()
        Me.TXTREF = New System.Windows.Forms.ComboBox()
        Me.txtveh = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.chkogt = New System.Windows.Forms.CheckBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.cmbcat = New System.Windows.Forms.ComboBox()
        Me.cmbcr = New System.Windows.Forms.ComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtpod = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtbox = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtrwt = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtpodwt = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtper = New System.Windows.Forms.TextBox()
        Me.cmbres = New System.Windows.Forms.ComboBox()
        Me.ddltranp = New System.Windows.Forms.ComboBox()
        Me.ddldept = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtjper = New System.Windows.Forms.TextBox()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'cmbtype
        '
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Items.AddRange(New Object() {"OSP", "PO"})
        Me.cmbtype.Location = New System.Drawing.Point(41, 4)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(82, 21)
        Me.cmbtype.TabIndex = 0
        '
        'btnmod
        '
        Me.btnmod.Location = New System.Drawing.Point(1001, 486)
        Me.btnmod.Name = "btnmod"
        Me.btnmod.Size = New System.Drawing.Size(42, 23)
        Me.btnmod.TabIndex = 14
        Me.btnmod.Text = "Modify"
        Me.btnmod.UseVisualStyleBackColor = True
        Me.btnmod.Visible = False
        '
        'btnupdt
        '
        Me.btnupdt.Location = New System.Drawing.Point(922, 486)
        Me.btnupdt.Name = "btnupdt"
        Me.btnupdt.Size = New System.Drawing.Size(75, 23)
        Me.btnupdt.TabIndex = 49
        Me.btnupdt.Text = "&Update"
        Me.btnupdt.UseVisualStyleBackColor = True
        Me.btnupdt.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(124, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Supplier"
        '
        'txtorg
        '
        Me.txtorg.Location = New System.Drawing.Point(1117, 469)
        Me.txtorg.Name = "txtorg"
        Me.txtorg.Size = New System.Drawing.Size(29, 20)
        Me.txtorg.TabIndex = 7
        Me.txtorg.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(570, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "PO No"
        '
        'btnsave
        '
        Me.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsave.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(442, 542)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(96, 33)
        Me.btnsave.TabIndex = 13
        Me.btnsave.Text = "&Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'dgv12
        '
        Me.dgv12.BackgroundColor = System.Drawing.Color.White
        Me.dgv12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv12.Location = New System.Drawing.Point(5, 106)
        Me.dgv12.Name = "dgv12"
        Me.dgv12.Size = New System.Drawing.Size(906, 323)
        Me.dgv12.TabIndex = 11
        Me.dgv12.Visible = False
        '
        'cmbsup
        '
        Me.cmbsup.FormattingEnabled = True
        Me.cmbsup.Location = New System.Drawing.Point(168, 4)
        Me.cmbsup.Name = "cmbsup"
        Me.cmbsup.Size = New System.Drawing.Size(399, 21)
        Me.cmbsup.TabIndex = 3
        '
        'txttype
        '
        Me.txttype.Location = New System.Drawing.Point(41, 4)
        Me.txttype.Name = "txttype"
        Me.txttype.Size = New System.Drawing.Size(82, 20)
        Me.txttype.TabIndex = 1
        Me.txttype.Visible = False
        '
        'txtgno
        '
        Me.txtgno.Location = New System.Drawing.Point(897, 32)
        Me.txtgno.Name = "txtgno"
        Me.txtgno.Size = New System.Drawing.Size(99, 20)
        Me.txtgno.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(855, 36)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(35, 13)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Gt No"
        '
        'cmbpo
        '
        Me.cmbpo.FormattingEnabled = True
        Me.cmbpo.Location = New System.Drawing.Point(644, 32)
        Me.cmbpo.Name = "cmbpo"
        Me.cmbpo.Size = New System.Drawing.Size(215, 21)
        Me.cmbpo.TabIndex = 6
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(-2, 8)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "GType"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(124, 36)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(27, 13)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Item"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(168, 11)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(398, 20)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.Visible = False
        '
        'cmbitem
        '
        Me.cmbitem.FormattingEnabled = True
        Me.cmbitem.Location = New System.Drawing.Point(169, 32)
        Me.cmbitem.Name = "cmbitem"
        Me.cmbitem.Size = New System.Drawing.Size(397, 21)
        Me.cmbitem.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(943, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(25, 13)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Site"
        '
        'txtsite
        '
        Me.txtsite.Location = New System.Drawing.Point(967, 7)
        Me.txtsite.Name = "txtsite"
        Me.txtsite.Size = New System.Drawing.Size(100, 20)
        Me.txtsite.TabIndex = 8
        '
        'dtdc
        '
        Me.dtdc.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdc.Location = New System.Drawing.Point(843, 7)
        Me.dtdc.Name = "dtdc"
        Me.dtdc.Size = New System.Drawing.Size(99, 20)
        Me.dtdc.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(-1, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 39
        Me.Label5.Text = "GDate"
        '
        'dtgdt
        '
        Me.dtgdt.Enabled = False
        Me.dtgdt.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtgdt.Location = New System.Drawing.Point(41, 32)
        Me.dtgdt.Name = "dtgdt"
        Me.dtgdt.Size = New System.Drawing.Size(82, 20)
        Me.dtgdt.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(570, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 13)
        Me.Label6.TabIndex = 39
        Me.Label6.Text = "DC/Inv No"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(801, 11)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "DC DT"
        '
        'txtdcno
        '
        Me.txtdcno.Location = New System.Drawing.Point(644, 6)
        Me.txtdcno.Name = "txtdcno"
        Me.txtdcno.Size = New System.Drawing.Size(114, 20)
        Me.txtdcno.TabIndex = 3
        '
        'TXTUSER
        '
        Me.TXTUSER.Location = New System.Drawing.Point(1086, 469)
        Me.TXTUSER.Name = "TXTUSER"
        Me.TXTUSER.Size = New System.Drawing.Size(25, 20)
        Me.TXTUSER.TabIndex = 50
        Me.TXTUSER.Visible = False
        '
        'dgv1
        '
        Me.dgv1.BackgroundColor = System.Drawing.Color.White
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.pono, Me.podt, Me.item, Me.description, Me.org, Me.rev, Me.popend, Me.uom, Me.dcqty, Me.Column1, Me.poqty, Me.Cat, Me.Po, Me.osp, Me.operation, Me.job, Me.type, Me.poline, Me.pohead, Me.val, Me.price, Me.lineloc, Me.remark, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6})
        Me.dgv1.Location = New System.Drawing.Point(5, 106)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowHeadersWidth = 25
        Me.dgv1.Size = New System.Drawing.Size(945, 342)
        Me.dgv1.TabIndex = 51
        '
        'pono
        '
        Me.pono.HeaderText = "Pono"
        Me.pono.Name = "pono"
        Me.pono.ReadOnly = True
        Me.pono.Width = 75
        '
        'podt
        '
        Me.podt.HeaderText = "PoDt"
        Me.podt.Name = "podt"
        Me.podt.ReadOnly = True
        Me.podt.Width = 75
        '
        'item
        '
        Me.item.HeaderText = "Item"
        Me.item.Name = "item"
        Me.item.ReadOnly = True
        Me.item.Width = 95
        '
        'description
        '
        Me.description.HeaderText = "Description"
        Me.description.Name = "description"
        Me.description.ReadOnly = True
        Me.description.Width = 120
        '
        'org
        '
        Me.org.HeaderText = "Org"
        Me.org.Name = "org"
        Me.org.ReadOnly = True
        Me.org.Width = 40
        '
        'rev
        '
        Me.rev.HeaderText = "Rev"
        Me.rev.Name = "rev"
        Me.rev.ReadOnly = True
        Me.rev.Width = 30
        '
        'popend
        '
        Me.popend.HeaderText = "PoPend"
        Me.popend.Name = "popend"
        Me.popend.ReadOnly = True
        Me.popend.Width = 50
        '
        'uom
        '
        Me.uom.HeaderText = "UOM"
        Me.uom.Name = "uom"
        Me.uom.ReadOnly = True
        Me.uom.Width = 55
        '
        'dcqty
        '
        Me.dcqty.HeaderText = "DcQty"
        Me.dcqty.Name = "dcqty"
        Me.dcqty.Width = 45
        '
        'Column1
        '
        Me.Column1.HeaderText = "Remark"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 60
        '
        'poqty
        '
        Me.poqty.HeaderText = "POQty"
        Me.poqty.Name = "poqty"
        Me.poqty.ReadOnly = True
        Me.poqty.Width = 45
        '
        'Cat
        '
        Me.Cat.HeaderText = "Cat"
        Me.Cat.Name = "Cat"
        Me.Cat.Width = 40
        '
        'Po
        '
        Me.Po.HeaderText = "PO"
        Me.Po.Name = "Po"
        Me.Po.Visible = False
        Me.Po.Width = 70
        '
        'osp
        '
        Me.osp.HeaderText = "OSP"
        Me.osp.Name = "osp"
        Me.osp.ReadOnly = True
        Me.osp.Visible = False
        Me.osp.Width = 50
        '
        'operation
        '
        Me.operation.HeaderText = "Operation"
        Me.operation.Name = "operation"
        Me.operation.ReadOnly = True
        Me.operation.Visible = False
        '
        'job
        '
        Me.job.HeaderText = "Job"
        Me.job.Name = "job"
        Me.job.ReadOnly = True
        Me.job.Visible = False
        Me.job.Width = 80
        '
        'type
        '
        Me.type.HeaderText = "Type"
        Me.type.Name = "type"
        Me.type.ReadOnly = True
        Me.type.Visible = False
        '
        'poline
        '
        Me.poline.HeaderText = "PoLine"
        Me.poline.Name = "poline"
        Me.poline.ReadOnly = True
        Me.poline.Visible = False
        '
        'pohead
        '
        Me.pohead.HeaderText = "PoHead"
        Me.pohead.Name = "pohead"
        Me.pohead.ReadOnly = True
        Me.pohead.Visible = False
        '
        'val
        '
        Me.val.HeaderText = "Val"
        Me.val.Name = "val"
        Me.val.ReadOnly = True
        Me.val.Visible = False
        '
        'price
        '
        Me.price.HeaderText = "Price"
        Me.price.Name = "price"
        Me.price.ReadOnly = True
        Me.price.Width = 50
        '
        'lineloc
        '
        Me.lineloc.HeaderText = "LineLocation"
        Me.lineloc.Name = "lineloc"
        Me.lineloc.ReadOnly = True
        Me.lineloc.Visible = False
        '
        'remark
        '
        Me.remark.HeaderText = "Tariff"
        Me.remark.Name = "remark"
        Me.remark.Visible = False
        Me.remark.Width = 70
        '
        'Column2
        '
        Me.Column2.HeaderText = "WIPENTITY"
        Me.Column2.Name = "Column2"
        Me.Column2.Visible = False
        '
        'Column3
        '
        Me.Column3.HeaderText = "OPNSEQ"
        Me.Column3.Name = "Column3"
        Me.Column3.Visible = False
        '
        'Column4
        '
        Me.Column4.HeaderText = "Need.by.Dt"
        Me.Column4.Name = "Column4"
        Me.Column4.Visible = False
        Me.Column4.Width = 80
        '
        'Column5
        '
        Me.Column5.HeaderText = "LAST_UPDT"
        Me.Column5.Name = "Column5"
        Me.Column5.Visible = False
        '
        'Column6
        '
        Me.Column6.HeaderText = "lot_no"
        Me.Column6.Name = "Column6"
        Me.Column6.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(242, 521)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(11, 13)
        Me.Label11.TabIndex = 52
        Me.Label11.Text = " "
        Me.Label11.Visible = False
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(1049, 467)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(30, 20)
        Me.txtrole.TabIndex = 54
        Me.txtrole.Visible = False
        '
        'txt_adi_no
        '
        Me.txt_adi_no.Location = New System.Drawing.Point(908, 553)
        Me.txt_adi_no.Name = "txt_adi_no"
        Me.txt_adi_no.Size = New System.Drawing.Size(99, 20)
        Me.txt_adi_no.TabIndex = 82
        Me.txt_adi_no.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(817, 554)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 13)
        Me.Label12.TabIndex = 37
        Me.Label12.Text = "ADI No"
        Me.Label12.Visible = False
        '
        'scmcon2
        '
        Me.scmcon2.ConnectionString = "Data Source=janatics.net;Initial Catalog=scm;User ID=scm;Password=scm#$sql2007"
        Me.scmcon2.FireInfoMessageEventOnUserErrors = False
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Crimson
        Me.Label15.Location = New System.Drawing.Point(882, 456)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(183, 27)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "ADI VENDOR "
        Me.Label15.Visible = False
        '
        'chk_adi
        '
        Me.chk_adi.AutoSize = True
        Me.chk_adi.Enabled = False
        Me.chk_adi.Location = New System.Drawing.Point(758, 8)
        Me.chk_adi.Name = "chk_adi"
        Me.chk_adi.Size = New System.Drawing.Size(44, 17)
        Me.chk_adi.TabIndex = 83
        Me.chk_adi.Text = "ADI"
        Me.chk_adi.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(914, 519)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(128, 15)
        Me.Label16.TabIndex = 37
        Me.Label16.Text = "Total Invoice Value"
        Me.Label16.Visible = False
        '
        'txtinv
        '
        Me.txtinv.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtinv.Location = New System.Drawing.Point(1043, 515)
        Me.txtinv.Name = "txtinv"
        Me.txtinv.Size = New System.Drawing.Size(109, 21)
        Me.txtinv.TabIndex = 85
        Me.txtinv.Visible = False
        '
        'xerox
        '
        Me.xerox.AutoSize = True
        Me.xerox.Location = New System.Drawing.Point(1049, 413)
        Me.xerox.Name = "xerox"
        Me.xerox.Size = New System.Drawing.Size(53, 17)
        Me.xerox.TabIndex = 83
        Me.xerox.Text = "Xerox"
        Me.xerox.UseVisualStyleBackColor = True
        Me.xerox.Visible = False
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(829, 512)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(98, 34)
        Me.Label17.TabIndex = 37
        Me.Label17.Text = "Reason For Manual Entry"
        Me.Label17.Visible = False
        '
        'txtadirea
        '
        Me.txtadirea.Location = New System.Drawing.Point(908, 504)
        Me.txtadirea.Multiline = True
        Me.txtadirea.Name = "txtadirea"
        Me.txtadirea.Size = New System.Drawing.Size(256, 43)
        Me.txtadirea.TabIndex = 12
        Me.txtadirea.Visible = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(969, 555)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(39, 13)
        Me.Label18.TabIndex = 37
        Me.Label18.Text = "ADI Dt"
        Me.Label18.Visible = False
        '
        'dtadi
        '
        Me.dtadi.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtadi.Location = New System.Drawing.Point(1064, 553)
        Me.dtadi.Name = "dtadi"
        Me.dtadi.Size = New System.Drawing.Size(100, 20)
        Me.dtadi.TabIndex = 86
        Me.dtadi.Visible = False
        '
        'chkref
        '
        Me.chkref.AutoSize = True
        Me.chkref.Location = New System.Drawing.Point(1073, 7)
        Me.chkref.Name = "chkref"
        Me.chkref.Size = New System.Drawing.Size(93, 17)
        Me.chkref.TabIndex = 83
        Me.chkref.Text = "No Reference"
        Me.chkref.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(570, 59)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(77, 35)
        Me.Label10.TabIndex = 37
        Me.Label10.Text = "Remarks For No Reference"
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(1014, 59)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 35)
        Me.Label13.TabIndex = 37
        Me.Label13.Text = "Org For No Reference"
        '
        'txtnorg
        '
        Me.txtnorg.Location = New System.Drawing.Point(1078, 59)
        Me.txtnorg.Multiline = True
        Me.txtnorg.Name = "txtnorg"
        Me.txtnorg.Size = New System.Drawing.Size(75, 22)
        Me.txtnorg.TabIndex = 8
        '
        'TXTREF
        '
        Me.TXTREF.FormattingEnabled = True
        Me.TXTREF.Location = New System.Drawing.Point(644, 62)
        Me.TXTREF.Name = "TXTREF"
        Me.TXTREF.Size = New System.Drawing.Size(352, 21)
        Me.TXTREF.TabIndex = 87
        '
        'txtveh
        '
        Me.txtveh.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtveh.Location = New System.Drawing.Point(96, 463)
        Me.txtveh.Multiline = True
        Me.txtveh.Name = "txtveh"
        Me.txtveh.Size = New System.Drawing.Size(142, 20)
        Me.txtveh.TabIndex = 88
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(9, 464)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 25)
        Me.Label14.TabIndex = 89
        Me.Label14.Text = "Vehicle No"
        '
        'chkogt
        '
        Me.chkogt.AutoSize = True
        Me.chkogt.Location = New System.Drawing.Point(1003, 36)
        Me.chkogt.Name = "chkogt"
        Me.chkogt.Size = New System.Drawing.Size(88, 17)
        Me.chkogt.TabIndex = 83
        Me.chkogt.Text = "Old Gate Ref"
        Me.chkogt.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(-2, 63)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(54, 29)
        Me.Label19.TabIndex = 48
        Me.Label19.Text = "Inward Category"
        '
        'cmbcat
        '
        Me.cmbcat.FormattingEnabled = True
        Me.cmbcat.Items.AddRange(New Object() {"OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "INTER UNIT TRANSFERS ", "MAINTENANCE ITEMS", "CASH PURCHASE", "BINS", "SALES RETURN", "COURIER - POD"})
        Me.cmbcat.Location = New System.Drawing.Point(41, 58)
        Me.cmbcat.Name = "cmbcat"
        Me.cmbcat.Size = New System.Drawing.Size(153, 21)
        Me.cmbcat.TabIndex = 0
        '
        'cmbcr
        '
        Me.cmbcr.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcr.FormattingEnabled = True
        Me.cmbcr.Items.AddRange(New Object() {"OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "INTER UNIT TRANSFERS ", "MAINTENANCE ITEMS", "CASH PURCHASE", "BINS", "SALES RETURN", "COURIER - POD"})
        Me.cmbcr.Location = New System.Drawing.Point(319, 495)
        Me.cmbcr.Name = "cmbcr"
        Me.cmbcr.Size = New System.Drawing.Size(177, 21)
        Me.cmbcr.TabIndex = 90
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(242, 492)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(54, 18)
        Me.Label20.TabIndex = 91
        Me.Label20.Text = "Courier"
        '
        'txtpod
        '
        Me.txtpod.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpod.Location = New System.Drawing.Point(96, 519)
        Me.txtpod.Name = "txtpod"
        Me.txtpod.Size = New System.Drawing.Size(142, 20)
        Me.txtpod.TabIndex = 93
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(9, 522)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(51, 13)
        Me.Label21.TabIndex = 92
        Me.Label21.Text = "POD No"
        '
        'txtbox
        '
        Me.txtbox.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbox.Location = New System.Drawing.Point(594, 519)
        Me.txtbox.Name = "txtbox"
        Me.txtbox.Size = New System.Drawing.Size(153, 20)
        Me.txtbox.TabIndex = 95
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(506, 522)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(63, 13)
        Me.Label22.TabIndex = 94
        Me.Label22.Text = "No of Box"
        '
        'txtrwt
        '
        Me.txtrwt.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrwt.Location = New System.Drawing.Point(319, 519)
        Me.txtrwt.Name = "txtrwt"
        Me.txtrwt.Size = New System.Drawing.Size(177, 20)
        Me.txtrwt.TabIndex = 99
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(242, 522)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(47, 13)
        Me.Label23.TabIndex = 98
        Me.Label23.Text = "Rec Wt"
        '
        'txtpodwt
        '
        Me.txtpodwt.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpodwt.Location = New System.Drawing.Point(594, 489)
        Me.txtpodwt.Name = "txtpodwt"
        Me.txtpodwt.Size = New System.Drawing.Size(153, 20)
        Me.txtpodwt.TabIndex = 97
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(506, 493)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(90, 13)
        Me.Label24.TabIndex = 96
        Me.Label24.Text = "Actual POD Wt"
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(9, 492)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(81, 26)
        Me.Label25.TabIndex = 98
        Me.Label25.Text = "Responsible Person"
        '
        'txtper
        '
        Me.txtper.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtper.Location = New System.Drawing.Point(96, 490)
        Me.txtper.Name = "txtper"
        Me.txtper.Size = New System.Drawing.Size(142, 20)
        Me.txtper.TabIndex = 99
        '
        'cmbres
        '
        Me.cmbres.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbres.FormattingEnabled = True
        Me.cmbres.Location = New System.Drawing.Point(97, 489)
        Me.cmbres.Name = "cmbres"
        Me.cmbres.Size = New System.Drawing.Size(141, 21)
        Me.cmbres.TabIndex = 90
        '
        'ddltranp
        '
        Me.ddltranp.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ddltranp.FormattingEnabled = True
        Me.ddltranp.Location = New System.Drawing.Point(594, 462)
        Me.ddltranp.Name = "ddltranp"
        Me.ddltranp.Size = New System.Drawing.Size(153, 21)
        Me.ddltranp.TabIndex = 103
        '
        'ddldept
        '
        Me.ddldept.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ddldept.FormattingEnabled = True
        Me.ddldept.Location = New System.Drawing.Point(319, 465)
        Me.ddldept.Name = "ddldept"
        Me.ddldept.Size = New System.Drawing.Size(177, 21)
        Me.ddldept.TabIndex = 104
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(506, 465)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(76, 25)
        Me.Label26.TabIndex = 101
        Me.Label26.Text = "Transport Mode"
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(242, 468)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(76, 13)
        Me.Label27.TabIndex = 102
        Me.Label27.Text = "Department"
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(755, 463)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(45, 26)
        Me.Label28.TabIndex = 98
        Me.Label28.Text = "Person Name"
        '
        'txtjper
        '
        Me.txtjper.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtjper.Location = New System.Drawing.Point(799, 463)
        Me.txtjper.Name = "txtjper"
        Me.txtjper.Size = New System.Drawing.Size(142, 20)
        Me.txtjper.TabIndex = 99
        '
        'Add
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1189, 649)
        Me.Controls.Add(Me.ddltranp)
        Me.Controls.Add(Me.ddldept)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.txtjper)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.txtper)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.txtrwt)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtpodwt)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.txtbox)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.txtpod)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.cmbres)
        Me.Controls.Add(Me.cmbcr)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.txtveh)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TXTREF)
        Me.Controls.Add(Me.dtadi)
        Me.Controls.Add(Me.txtinv)
        Me.Controls.Add(Me.chkogt)
        Me.Controls.Add(Me.chkref)
        Me.Controls.Add(Me.xerox)
        Me.Controls.Add(Me.chk_adi)
        Me.Controls.Add(Me.txt_adi_no)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.TXTUSER)
        Me.Controls.Add(Me.btnupdt)
        Me.Controls.Add(Me.txtorg)
        Me.Controls.Add(Me.btnmod)
        Me.Controls.Add(Me.txtadirea)
        Me.Controls.Add(Me.txtgno)
        Me.Controls.Add(Me.cmbcat)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.cmbtype)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.dgv12)
        Me.Controls.Add(Me.dtdc)
        Me.Controls.Add(Me.dtgdt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtdcno)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txttype)
        Me.Controls.Add(Me.txtnorg)
        Me.Controls.Add(Me.txtsite)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cmbitem)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmbpo)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbsup)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnsave)
        Me.Name = "Add"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gate Register- Add"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents cmbitem As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbpo As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbsup As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtsite As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtdcno As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dtgdt As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtdc As System.Windows.Forms.DateTimePicker
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents dgv12 As System.Windows.Forms.DataGridView
    Friend WithEvents cmbtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txttype As System.Windows.Forms.TextBox
    Friend WithEvents txtgno As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents btnmod As System.Windows.Forms.Button
    Friend WithEvents txtorg As System.Windows.Forms.TextBox
    Friend WithEvents btnupdt As System.Windows.Forms.Button
    Friend WithEvents TXTUSER As System.Windows.Forms.TextBox
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtrole As System.Windows.Forms.TextBox
    Friend WithEvents txt_adi_no As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents scmcon2 As System.Data.SqlClient.SqlConnection
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents chk_adi As System.Windows.Forms.CheckBox
    Friend WithEvents txtinv As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents xerox As System.Windows.Forms.CheckBox
    Friend WithEvents txtadirea As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents dtadi As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents chkref As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtnorg As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TXTREF As System.Windows.Forms.ComboBox
    Friend WithEvents txtveh As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents chkogt As System.Windows.Forms.CheckBox
    Friend WithEvents cmbcat As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtrwt As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents txtpodwt As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents txtbox As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents txtpod As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents cmbcr As ComboBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtper As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents cmbres As ComboBox
    Friend WithEvents pono As DataGridViewTextBoxColumn
    Friend WithEvents podt As DataGridViewTextBoxColumn
    Friend WithEvents item As DataGridViewTextBoxColumn
    Friend WithEvents description As DataGridViewTextBoxColumn
    Friend WithEvents org As DataGridViewTextBoxColumn
    Friend WithEvents rev As DataGridViewTextBoxColumn
    Friend WithEvents popend As DataGridViewTextBoxColumn
    Friend WithEvents uom As DataGridViewTextBoxColumn
    Friend WithEvents dcqty As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents poqty As DataGridViewTextBoxColumn
    Friend WithEvents Cat As DataGridViewTextBoxColumn
    Friend WithEvents Po As DataGridViewTextBoxColumn
    Friend WithEvents osp As DataGridViewTextBoxColumn
    Friend WithEvents operation As DataGridViewTextBoxColumn
    Friend WithEvents job As DataGridViewTextBoxColumn
    Friend WithEvents type As DataGridViewTextBoxColumn
    Friend WithEvents poline As DataGridViewTextBoxColumn
    Friend WithEvents pohead As DataGridViewTextBoxColumn
    Friend WithEvents val As DataGridViewTextBoxColumn
    Friend WithEvents price As DataGridViewTextBoxColumn
    Friend WithEvents lineloc As DataGridViewTextBoxColumn
    Friend WithEvents remark As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents ddltranp As ComboBox
    Friend WithEvents ddldept As ComboBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents txtjper As TextBox
    Friend WithEvents Label28 As Label
End Class
