Imports System.Data.OracleClient

Public Class fifo_login

     
    Private Sub bnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnlogin.Click
        sql = "select * from jan_receipt_rights where UNAME='" & UCase(txtuname.Text) & "' AND UPWD='" & UCase(txtpwd.Text) & "' AND portal_name ='Fifo' "
        cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "RESULTAB")
        If ds.Tables("RESULTAB").Rows.Count > 0 Then
            With ds.Tables("RESULTAB").Rows(0)
                category = .Item("cat").ToString()
                orgid = .Item("org_ID").ToString()
            End With
            fifo_sticker.Show()
            Me.Hide()
        Else
            MessageBox.Show("Invalid Login", "FIFO Sticker Print")
        End If

    End Sub

    Private Sub txtpwd_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtpwd.KeyDown
        If e.KeyCode = 13 Then
            bnlogin_Click(sender, e)
        End If
    End Sub

    Private Sub fifo_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class