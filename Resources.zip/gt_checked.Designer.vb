﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class gt_checked
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.cmborg = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtqty = New System.Windows.Forms.TextBox()
        Me.btngo = New System.Windows.Forms.Button()
        Me.txtgate = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_oth = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtshtr = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbitem = New System.Windows.Forms.ComboBox()
        Me.cmbchk1 = New System.Windows.Forms.TextBox()
        Me.txtchk = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbpack = New System.Windows.Forms.ComboBox()
        Me.txtpqty = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtstby = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cmbpitem = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dgvpack = New System.Windows.Forms.DataGridView()
        Me.Item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmbpk = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnpack = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dgvpack, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmborg
        '
        Me.cmborg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(466, 36)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(159, 21)
        Me.cmborg.TabIndex = 74
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(6, 71)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(136, 13)
        Me.Label26.TabIndex = 72
        Me.Label26.Text = "Item Check Closed By"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(322, 41)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(28, 13)
        Me.Label25.TabIndex = 73
        Me.Label25.Text = "Org"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(322, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 72
        Me.Label1.Text = "Location"
        '
        'txtqty
        '
        Me.txtqty.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtqty.Location = New System.Drawing.Point(467, 67)
        Me.txtqty.Name = "txtqty"
        Me.txtqty.Size = New System.Drawing.Size(158, 21)
        Me.txtqty.TabIndex = 76
        '
        'btngo
        '
        Me.btngo.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btngo.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngo.Location = New System.Drawing.Point(277, 183)
        Me.btngo.Name = "btngo"
        Me.btngo.Size = New System.Drawing.Size(99, 33)
        Me.btngo.TabIndex = 77
        Me.btngo.Text = "&Save"
        Me.btngo.UseVisualStyleBackColor = True
        '
        'txtgate
        '
        Me.txtgate.Location = New System.Drawing.Point(140, 6)
        Me.txtgate.Name = "txtgate"
        Me.txtgate.Size = New System.Drawing.Size(159, 20)
        Me.txtgate.TabIndex = 78
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 73
        Me.Label2.Text = "Gate No"
        '
        'txt_oth
        '
        Me.txt_oth.Location = New System.Drawing.Point(385, 30)
        Me.txt_oth.Name = "txt_oth"
        Me.txt_oth.Size = New System.Drawing.Size(43, 20)
        Me.txt_oth.TabIndex = 78
        Me.txt_oth.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(5, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 13)
        Me.Label3.TabIndex = 72
        Me.Label3.Text = "Shortage Qty"
        '
        'txtshtr
        '
        Me.txtshtr.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtshtr.Location = New System.Drawing.Point(143, 50)
        Me.txtshtr.Name = "txtshtr"
        Me.txtshtr.Size = New System.Drawing.Size(158, 21)
        Me.txtshtr.TabIndex = 76
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(5, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 13)
        Me.Label4.TabIndex = 72
        Me.Label4.Text = "Shortage Item"
        '
        'cmbitem
        '
        Me.cmbitem.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbitem.FormattingEnabled = True
        Me.cmbitem.Location = New System.Drawing.Point(143, 24)
        Me.cmbitem.Name = "cmbitem"
        Me.cmbitem.Size = New System.Drawing.Size(159, 21)
        Me.cmbitem.TabIndex = 75
        '
        'cmbchk1
        '
        Me.cmbchk1.Location = New System.Drawing.Point(385, 6)
        Me.cmbchk1.Name = "cmbchk1"
        Me.cmbchk1.ReadOnly = True
        Me.cmbchk1.Size = New System.Drawing.Size(43, 20)
        Me.cmbchk1.TabIndex = 78
        Me.cmbchk1.Visible = False
        '
        'txtchk
        '
        Me.txtchk.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtchk.Location = New System.Drawing.Point(141, 67)
        Me.txtchk.Name = "txtchk"
        Me.txtchk.Size = New System.Drawing.Size(158, 21)
        Me.txtchk.TabIndex = 76
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(7, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 13)
        Me.Label5.TabIndex = 72
        Me.Label5.Text = "Packing Method"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(7, 56)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(75, 13)
        Me.Label6.TabIndex = 72
        Me.Label6.Text = "Packing Qty"
        '
        'cmbpack
        '
        Me.cmbpack.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbpack.FormattingEnabled = True
        Me.cmbpack.Location = New System.Drawing.Point(132, 18)
        Me.cmbpack.Name = "cmbpack"
        Me.cmbpack.Size = New System.Drawing.Size(159, 21)
        Me.cmbpack.TabIndex = 75
        '
        'txtpqty
        '
        Me.txtpqty.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpqty.Location = New System.Drawing.Point(131, 53)
        Me.txtpqty.Name = "txtpqty"
        Me.txtpqty.Size = New System.Drawing.Size(158, 21)
        Me.txtpqty.TabIndex = 76
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmbpack)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtpqty)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(325, 93)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(307, 85)
        Me.GroupBox1.TabIndex = 79
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Packing"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cmbitem)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txtshtr)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 93)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(313, 85)
        Me.GroupBox2.TabIndex = 80
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Shortage"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(5, 41)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(125, 13)
        Me.Label7.TabIndex = 72
        Me.Label7.Text = "Item Check Start By"
        '
        'txtstby
        '
        Me.txtstby.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstby.Location = New System.Drawing.Point(140, 37)
        Me.txtstby.Name = "txtstby"
        Me.txtstby.Size = New System.Drawing.Size(158, 21)
        Me.txtstby.TabIndex = 76
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnpack)
        Me.GroupBox3.Controls.Add(Me.cmbpitem)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.dgvpack)
        Me.GroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(8, 224)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(685, 419)
        Me.GroupBox3.TabIndex = 79
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Packing"
        Me.GroupBox3.Visible = False
        '
        'cmbpitem
        '
        Me.cmbpitem.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbpitem.FormattingEnabled = True
        Me.cmbpitem.Location = New System.Drawing.Point(63, 19)
        Me.cmbpitem.Name = "cmbpitem"
        Me.cmbpitem.Size = New System.Drawing.Size(239, 21)
        Me.cmbpitem.TabIndex = 75
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(4, 22)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 72
        Me.Label8.Text = "Item No"
        '
        'dgvpack
        '
        Me.dgvpack.BackgroundColor = System.Drawing.Color.White
        Me.dgvpack.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvpack.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Item, Me.Column1, Me.cmbpk, Me.Column3, Me.Column2, Me.Column4, Me.Column5})
        Me.dgvpack.Location = New System.Drawing.Point(5, 64)
        Me.dgvpack.Name = "dgvpack"
        Me.dgvpack.RowHeadersVisible = False
        Me.dgvpack.Size = New System.Drawing.Size(674, 310)
        Me.dgvpack.TabIndex = 0
        '
        'Item
        '
        Me.Item.HeaderText = "Item No"
        Me.Item.Name = "Item"
        Me.Item.Width = 150
        '
        'Column1
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.Column1.DefaultCellStyle = DataGridViewCellStyle9
        Me.Column1.HeaderText = "Gate Qty"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 60
        '
        'cmbpk
        '
        Me.cmbpk.HeaderText = "Pack Method"
        Me.cmbpk.Name = "cmbpk"
        Me.cmbpk.Width = 200
        '
        'Column3
        '
        Me.Column3.HeaderText = "No Of Pack Method"
        Me.Column3.Name = "Column3"
        '
        'Column2
        '
        Me.Column2.HeaderText = "Pack Qty"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 80
        '
        'Column4
        '
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Column4.DefaultCellStyle = DataGridViewCellStyle10
        Me.Column4.HeaderText = "Total Qty"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 80
        '
        'Column5
        '
        Me.Column5.HeaderText = "status"
        Me.Column5.Name = "Column5"
        Me.Column5.Visible = False
        '
        'btnpack
        '
        Me.btnpack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpack.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpack.Location = New System.Drawing.Point(269, 380)
        Me.btnpack.Name = "btnpack"
        Me.btnpack.Size = New System.Drawing.Size(130, 33)
        Me.btnpack.TabIndex = 78
        Me.btnpack.Text = "&Save Pack Details"
        Me.btnpack.UseVisualStyleBackColor = True
        '
        'gt_checked
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(744, 647)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txt_oth)
        Me.Controls.Add(Me.cmbchk1)
        Me.Controls.Add(Me.txtgate)
        Me.Controls.Add(Me.btngo)
        Me.Controls.Add(Me.txtstby)
        Me.Controls.Add(Me.txtchk)
        Me.Controls.Add(Me.txtqty)
        Me.Controls.Add(Me.cmborg)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label25)
        Me.Name = "gt_checked"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gate Checked"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.dgvpack, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmborg As ComboBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtqty As TextBox
    Friend WithEvents btngo As Button
    Friend WithEvents txtgate As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_oth As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtshtr As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cmbitem As ComboBox
    Friend WithEvents cmbchk1 As TextBox
    Friend WithEvents txtchk As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents cmbpack As ComboBox
    Friend WithEvents txtpqty As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtstby As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents dgvpack As DataGridView
    Friend WithEvents cmbpitem As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Item As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents cmbpk As DataGridViewComboBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents btnpack As Button
End Class
