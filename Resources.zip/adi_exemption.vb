Imports System.Data.OracleClient
Imports oracleclass
Public Class adi_exemption
    Dim cl As New oracleclass.Class1

    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click

        sql = "SELECT * FROM jan_gate_adi_exempt WHERE VENDOR_ID=" & cmbsup.SelectedValue & ""
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")

        If ds.Tables("RESULTAB").Rows.Count = 0 Then

            sql = "insert into jan_gate_adi_exempt VALUES ('" & cmbsup.Text.Replace("'", "''") & "',TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS')," & cmbsup.SelectedValue & ")"

        Else
            sql = " Update jan_gate_adi_exempt SET exemption_validity_till=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') WHERE VENDOR_ID=" & cmbsup.SelectedValue & ""

        End If

        If CON.State = ConnectionState.Closed Then CON.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        CON.Close()
        MessageBox.Show("Exemption for ADI Saved")

    End Sub

    Private Sub adi_exemption_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "select VENDOR_NAME,vendor_id from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' order by vendor_name asc"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds1 = New DataSet
        adap.Fill(ds1, "resultab")
        cmbsup.DisplayMember = "vendor_name"
        cmbsup.ValueMember = "vendor_id"
        cmbsup.DataSource = ds1.Tables("resultab")

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        sql = "select supplier,exemption_validity_till from jan_gate_adi_exempt order by supplier"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds1 = New DataSet
        adap.Fill(ds1, "resultab")
        dgv.DataSource = ds1.Tables("resultab")
        dgv.Columns(0).HeaderText = "Suppplier" : dgv.Columns(0).Width = 350
        dgv.Columns(1).HeaderText = "Exemption Till" : dgv.Columns(1).Width = 250

    End Sub
End Class