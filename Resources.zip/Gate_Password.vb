Imports System.Data.OracleClient
Imports oracleclass
Public Class Gate_Password
    Dim cl As New oracleclass.Class1
    Private Sub updt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles updt.Click
        Try
            sql = "Update jan_gate_login set upwd='" & UCase(txtcpwd.Text) & "',person_name='" & txtper.Text & "' where uname='" & UCase(txtuname.Text) & "' and upwd='" & UCase(txtpwd.Text) & "' and role='" & txtrole.Text & "'"
            If CON.State = ConnectionState.Closed Then CON.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            MessageBox.Show("Password Changed", "Gate Register")
            txtcpwd.Text = ""
            txtuname.Text = ""
            txtpwd.Text = ""
            txtrole.Text = ""
            load()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub txtpwd_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtpwd.Leave
        sql = "select role from jan_gate_login where uname='" & UCase(txtuname.Text) & "' and upwd='" & UCase(txtpwd.Text) & "'"
        ds = New DataSet
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        adap.Fill(ds, "resultab")
        txtrole.Text = ds.Tables("resultab").Rows(0).Item("role")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Gate_Password_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load()

    End Sub

    Private Sub DGV1_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV1.CellClick
        txtuname.Text = DGV1.CurrentRow.Cells(0).Value
        txtpwd.Text = DGV1.CurrentRow.Cells(1).Value
        txtper.Text = DGV1.CurrentRow.Cells(2).Value
    End Sub
    Sub load()
        sql = " SELECT uname,upwd,PERSON_NAME FROM jan_gatE_login where role not IN ('UNIT4','UNIT2')"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "RESULTAB")
        DGV1.DataSource = ds.Tables("RESULTAB")
        DGV1.Columns(0).HeaderText = "UserName" : DGV1.Columns(0).Width = 100
        DGV1.Columns(1).HeaderText = "Password" : DGV1.Columns(1).Width = 100
        DGV1.Columns(2).HeaderText = "Person" : DGV1.Columns(2).Width = 100
    End Sub
End Class