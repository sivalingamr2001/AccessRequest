﻿Imports Microsoft.Office.Interop.Excel
Imports Microsoft.Office.Interop.Access
Imports System.IO
Imports System.Drawing


Public Class eod
    Dim xlapp As Microsoft.Office.Interop.Excel.Application
    Dim xlWorkBook As Microsoft.Office.Interop.Excel.Workbook
    Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
    Dim misValue As Object = System.Reflection.Missing.Value
    Dim res, tmsres, mdsres As String
    Dim oadp As New Odbc.OdbcDataAdapter
    Dim Con As New Odbc.OdbcConnection("Driver={MySQL ODBC 8.0 ANSI Driver};Server=192.168.0.66;Database=jan_etms;uid=jan_etms;pwd=jan_etms@786")
    Private Sub eod_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' res = Environment.GetCommandLineArgs(3).Replace("_", " ")
        'tmsres = Environment.GetCommandLineArgs(4).Replace("_", " ")
        'mdsres = Environment.GetCommandLineArgs(5).Replace("_", " ")
        Label3.Text = Environment.UserName
        ' res = "Pandian"
        res = Environment.GetCommandLineArgs(3).Replace("_", " ")
        ORG_ID = Environment.GetCommandLineArgs(4)

        res = res.Replace("_", " ")
        tmsres = "All"


        If res.Contains(",") = True Then
            Dim arrayList = res.Split(",")
            For Each value As String In arrayList
                txtres.Items.Add(value.ToString.Replace("_", " "))
            Next
        Else
            res = res.Replace("_", " ")
        End If

        ' If ORG_ID.Contains(",") = True Then
        sql = "Select  name,organization_id from hr_operating_units WHERE ORGANIZATION_ID In (" & ORG_ID & ")"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "res")
        cmbou.DisplayMember = "name"
        cmbou.ValueMember = "organization_id"
        cmbou.DataSource = ds.Tables("res")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'sql = "Select * from jan_eod_process_master where working_Set=1"
        Me.Cursor = Cursors.WaitCursor
        If cmbprc.SelectedIndex = 1 Then
            '            sql = "Select C.*,Case When PENDING_DAYS> 0 Then'OVER DUE' ELSE'DUE' END STATUS,(SELECT DECODE(PLANNING_MAKE_BUY_CODE,1,'Make',2,'Buy') from mtl_system_items where organization_id=JAN_ORGID(C.org) and inventory_item_id=JAN_ITEMNO(C.Item_NO))make_buy FROM( "

            '            sql &= " Select B.PROCESS_name, JAN_ORGCODE(a.ORGANIZATION_ID)ORG,case when process_id=1053 then item_no else JAN_ITEMNAME(A.INVENTORY_ITEM_ID) end ITEM_NO,case when process_id=1053 then item_Desc else  jan_itemdesc(JAN_ITEMNAME(A.INVENTORY_ITEM_ID))   end item_desc,(SELECT VENDOR_NAME FROM PO_VENDORS WHERE VENDOR_ID=A.VENDOR_ID)VENDOR_NAME,REF_ID,REf_DT,a.quantity,A.TARGET_DATE,case when process_id=1015 and mast_id=41 then (SELECT ATTRIBUTE10 FROM WIP_DISCRETE_JOBS WHERE WIP_eNTITY_ID=A.SHIPMENT_LINE_ID)  when process_id=1052 then responsible_person else b.prime_responsibility end prime_responsibility,ROUND(SYSDATE-TARGET_DATE)PENDING_DAYS,Case WHEN  ROUND(SYSDATE-TARGET_DATE) <=0 THEN 'NA'WHEN ROUND(SYSDATE-TARGET_DATE) >0 And ROUND(SYSDATE-TARGET_DATE)<=3 THEN 'SEVERITY-4' WHEN ROUND(SYSDATE-TARGET_DATE) >3 And ROUND(SYSDATE-TARGET_DATE) <=7 THEN 'SEVERITY-3'WHEN  ROUND(SYSDATE-TARGET_DATE) >7 And  ROUND(SYSDATE-TARGET_DATE) <=15 THEN 'SEVERITY-2'WHEN  ROUND(SYSDATE-TARGET_DATE) >15 THEN 'SEVERITY-1' END PENDING_SEVERITY, "

            '            sql &= "(select COMMODITY from jan_item_master_tab where organization_id=A.organization_id And inventory_item_id=A.inventory_item_id)COMMODITy,Case when b.item_responsibility='Buyers' then (select buyer_name from jan_item_master_tab where organization_id=A.organization_id and inventory_item_id=A.inventory_item_id)
            'Else b.prime_responsibility End responsible_person,target_category insp_target_category,case when process_id=1048 then (select jan_orgcode(organization_id) from mtl_material_transactions where transaction_id=a.shipment_line_id)  when process_id=1025 then (select jan_orgcode(destination_organization_id) from JAN_DIRECT_ORG_TRANSFER_T where sor_no=a.shipment_line_id) else '' end des_org ,
            '(SELECT AP_FOR FROM JAN_ASSEMBLY_PRIORITY WHERE AP_ID=(SELECT ATTRIBUTE12 FROM WIP_DISCRETE_JOBS WHERE WIP_ENTITY_ID=A.shipment_line_ID))fg_delivery,case when process_id in (1036,1026) then (select (select user_name from fnd_user where user_id=x.created_by) from mtl_material_transactions x where transaction_id=a.shipment_line_id) else to_char(null) end user_name   From jan_eod_transactions a, JAN_EOD_PROCESS_MASTER b Where a.comp_flag = 0 And b.live_flag = 1 And a.process_id=b.idno And a.mast_id=b.row_id   "

            sql = " select *  from jan_eod_excel_list a where 1=1 and operating_unit=" & cmbou.SelectedValue & " "

            If res = "All" Then

                If cmbp.Text <> "" Then
                    sql &= "  and a.process_id =" & cmbp.SelectedValue & " AND prime_responsibility = '" & txtres.Text & "' "
                Else
                    sql &= " And (a.process_id,mast_id) in (select idno,row_id from JAN_EOD_PROCESS_MASTER where live_Flag=1)  "
                End If

            Else

                If cmbp.Text <> "" Then
                    sql &= " and  a.process_id =" & cmbp.SelectedValue & "  AND prime_responsibility = '" & txtres.Text & "' "
                Else
                    sql &= " And (a.process_id,a.mast_id) in (select idno,row_id from JAN_EOD_PROCESS_MASTER where prime_responsibility = '" & txtres.Text & "')  "
                End If
            End If


        End If

        If cmbprc.SelectedIndex = 1 Then
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "val")

            dgv1.DataSource = ds.Tables("val")

            Dim i, l As Integer
            Dim j As Integer
            Dim pathExcel, fname As String

            Try


                Dim path As String = "d:\excel\" & Label3.Text & ""
                If Not Directory.Exists(path) Then
                    Directory.CreateDirectory(path)
                End If

                If cmbprc.SelectedIndex = 1 Then
                    fname = "eod.xls"
                ElseIf cmbprc.SelectedIndex = 2 Then
                    fname = "tms.xls"
                End If

                Dim objfso
                objfso = CreateObject("Scripting.FileSystemObject")
                pathExcel = "d:\excel\" & Label3.Text & "\" & fname & ""
                If objfso.FileExists(pathExcel) Then
                    objfso.DeleteFile(pathExcel)
                End If

                xlapp = New Microsoft.Office.Interop.Excel.Application
                xlWorkBook = xlapp.Workbooks.Add(misValue)
                xlWorkSheet = CType(xlWorkBook.Sheets("Sheet1"), Microsoft.Office.Interop.Excel.Worksheet)

                For k = 0 To dgv1.ColumnCount - 1
                    xlWorkSheet.Cells(1, k + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft
                    xlWorkSheet.Cells(1, k + 1) = dgv1.Columns(k).Name
                Next
                For i = 0 To dgv1.Rows.Count - 1
                    For j = 0 To dgv1.ColumnCount - 1
                        xlWorkSheet.Cells(i + 2, j + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft
                        xlWorkSheet.Cells(i + 2, j + 1) =
                             dgv1(j, i).Value.ToString()
                    Next
                Next
                ' Workbook.SaveAs("c:\output.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                '  Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing)
                xlWorkBook.SaveAs(pathExcel)
                xlWorkBook.Close()
                xlapp.Quit()
                System.Diagnostics.Process.Start(pathExcel)
            Catch ex As Exception
                s = ""


                s &= "<TABLE border=1 cellspacing=0 cellpadding=2><tr> <td><FONT SIZE=2 font face=verdana>S.No</td> "
                For l = 0 To ds.Tables("val").Columns.Count - 1
                    With ds.Tables("val").Columns(l)
                        s &= "<td><FONT SIZE=2 font face=verdana>" & .ColumnName & "</td>  "
                    End With

                Next

                s &= "</tr>"



                For k = 0 To ds.Tables("val").Rows.Count - 1
                    s &= "<tr><td><FONT SIZE=2 font face=verdana>" & k + 1 & "</td>"
                    For l = 0 To ds.Tables("val").Columns.Count - 1


                        With ds.Tables("val").Rows(k)
                            If .Item(l).ToString = "" Then
                                s &= " <td><FONT SIZE=2 font face=verdana>&nbsp;"
                            Else
                                s &= " <td><FONT SIZE=2 font face=verdana>" & .Item(l) & "  "

                            End If
                        End With

                    Next

                    s &= "</tr>"

                Next

                s &= "</table></html>"

                x = "d:\receipt\list.HTML "



                fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
                sw = New StreamWriter(fstrm)
                sw.WriteLine(s)
                fstrm.Flush()
                sw.Flush()
                sw.Close()
                fstrm.Close()
                System.Diagnostics.Process.Start(x)
                Me.Cursor = Cursors.Arrow



            End Try
        End If

        If cmbprc.SelectedIndex = 2 Then Process.Start("http://web2.janaticsindia.com/erfa/eod/main/index.php")

        If cmbprc.SelectedIndex = 3 Then Process.Start("http://web2.janaticsindia.com/erfa/eod/main/index-2.php")

        If cmbprc.SelectedIndex = 4 Then Process.Start("http://web2.janaticsindia.com/erfa/eod/main/index-3.php")

        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub cmbprc_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbprc.SelectedIndexChanged, cmbou.SelectedIndexChanged
        If cmbprc.SelectedIndex = 1 Then
            If res = "All" Then
                sql = "Select distinct prime_responsibility from jan_eod_process_master where live_flag=1 and org_id=" & cmbou.SelectedValue & " "
                cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "res")
                For i = 0 To ds.Tables("res").Rows.Count - 1
                    txtres.Items.Add(ds.Tables("res").Rows(i).Item("prime_responsibility"))
                Next
            Else
                txtres.Text = res
            End If
            sql = "Select distinct process_name,idno from jan_eod_process_master where live_flag=1 and org_id=" & cmbou.SelectedValue & "  And prime_responsibility ="

            If res = "All" Then
                sql &= " '" & txtres.Text & "' "

            Else
                sql &= " '" & res & "' "
            End If

            sql &= " And live_flag=1 "
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "val")
            cmbp.ValueMember = "idno"
            cmbp.DisplayMember = "process_name"
            cmbp.DataSource = ds.Tables("val")



        End If
    End Sub

    Private Sub txtres_SelectedIndexChanged(sender As Object, e As EventArgs) Handles txtres.SelectedIndexChanged
        sql = "Select distinct process_name,idno from jan_eod_process_master where live_flag=1 and org_id=" & cmbou.SelectedValue & "  And prime_responsibility ="

        'If res = "All" Then

        'Else
        '    sql &= " '" & res & "' "
        'End If

        sql &= " '" & txtres.Text & "' "

        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "val")
        cmbp.ValueMember = "idno"
        cmbp.DisplayMember = "process_name"
        cmbp.DataSource = ds.Tables("val")

    End Sub



    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
            MessageBox.Show("Exception Occured while releasing object " + ex.ToString())
        Finally
            GC.Collect()
        End Try
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        sql = "Select C.*,Case When PENDING_DAYS> 0 Then'OVER DUE' ELSE'DUE' END STATUS,(SELECT DECODE(PLANNING_MAKE_BUY_CODE,1,'Make',2,'Buy') from mtl_system_items where organization_id=JAN_ORGID(C.org) and inventory_item_id=JAN_ITEMNO(C.Item_NO))make_buy FROM( "

        sql &= " Select B.PROCESS_name, JAN_ORGCODE(a.ORGANIZATION_ID)ORG,JAN_ITEMNAME(a.INVENTORY_ITEM_ID)ITEM_NO, jan_itemdesc(JAN_ITEMNAME(a.INVENTORY_ITEM_ID))item_desc ,(SELECT VENDOR_NAME FROM PO_VENDORS WHERE VENDOR_ID=A.VENDOR_ID)VENDOR_NAME,REF_ID,REf_DT,a.quantity,A.TARGET_DATE,b.prime_responsibility,ROUND(SYSDATE-TARGET_DATE)PENDING_DAYS,Case WHEN  ROUND(SYSDATE-TARGET_DATE) <=0 THEN 'NA'WHEN ROUND(SYSDATE-TARGET_DATE) >0 And ROUND(SYSDATE-TARGET_DATE)<=3 THEN 'SEVERITY-4' WHEN ROUND(SYSDATE-TARGET_DATE) >3 And ROUND(SYSDATE-TARGET_DATE) <=7 THEN 'SEVERITY-3'
WHEN  ROUND(SYSDATE-TARGET_DATE) >7 And  ROUND(SYSDATE-TARGET_DATE) <=15 THEN 'SEVERITY-2'WHEN  ROUND(SYSDATE-TARGET_DATE) >15 THEN 'SEVERITY-1' END PENDING_SEVERITY, "

        sql &= "(select COMMODITY from jan_item_master_tab where organization_id=A.organization_id And inventory_item_id=A.inventory_item_id)COMMODITy,Case when b.item_responsibility='Buyers' then (select buyer_name from jan_item_master_tab where organization_id=A.organization_id and inventory_item_id=A.inventory_item_id)
Else b.prime_responsibility End responsible_person,target_category insp_target_category  From jan_eod_transactions a, JAN_EOD_PROCESS_MASTER b Where a.comp_flag = 0 And b.live_flag = 1 And a.process_id=b.idno And a.mast_id=b.row_id   "

        If res <> "All" Then
            sql &= " And (a.process_id,mast_id) in (select idno,row_id from JAN_EOD_PROCESS_MASTER where prime_responsibility = '" & txtres.Text & "')  "
        Else

            If cmbp.Text <> "" Then
                sql &= " and (a.process_id,mast_id) in (select idno,row_id from JAN_EOD_PROCESS_MASTER where prime_responsibility = '" & txtres.Text & "' and b.process_name='" & cmbp.Text & "') "
            Else
                sql &= " And (a.process_id,mast_id) in (select idno,row_id from JAN_EOD_PROCESS_MASTER where prime_responsibility = '" & txtres.Text & "')  "
                sql &= " And (a.process_id,mast_id) in (select idno,row_id from JAN_EOD_PROCESS_MASTER where prime_responsibility = '" & txtres.Text & "')  "
            End If
        End If

        sql &= " ) c"



        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "val")
        dgv1.DataSource = ds.Tables("val")
        Dim pathExcel As String = "C:\Users\4153\Desktop\eod\mds.xlsx"
        xlapp = New Microsoft.Office.Interop.Excel.Application
        xlWorkBook = xlapp.Workbooks.Add(misValue)
        xlWorkSheet = CType(xlWorkBook.Sheets("Sheet1"), Microsoft.Office.Interop.Excel.Worksheet)

        For k = 0 To dgv1.ColumnCount - 1
            xlWorkSheet.Cells(1, k + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft
            xlWorkSheet.Cells(1, k + 1) = dgv1.Columns(k).Name
        Next
        For i = 0 To dgv1.Rows.Count - 1
            For j = 0 To dgv1.ColumnCount - 1
                xlWorkSheet.Cells(i + 2, j + 1).HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft
                xlWorkSheet.Cells(i + 2, j + 1) =
                     dgv1(j, i).Value.ToString()
            Next
        Next

        xlWorkBook.SaveAs(pathExcel)
        xlWorkBook.Close()
        xlapp.Quit()

        releaseObject(xlWorkSheet)
        releaseObject(xlWorkBook)
        releaseObject(xlapp)

        MessageBox.Show("Over")
    End Sub
End Class