Imports System.Data.OracleClient
Imports oracleclass
Public Class Login
    Dim sql, a, b, c As String

    Dim ds As New DataSet
    Dim i As Integer
    Dim ip As String
    Dim cl As New oracleclass.Class1
    Dim host As System.Net.IPHostEntry = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName)
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'If a <> "" And b <> "" Then
        '    txtuser.Text = a
        '    txtpwd.Text = b
        'End If
        cl.sql = "select * from jan_gate_login where "

        cl.sql &= " role ='" & userid & "'"

        ' cl.sql &= " uname='" & UCase(txtuser.Text) & "' and upwd='" & UCase(txtpwd.Text) & "'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        cl.ds = New DataSet
        cl.oradap.Fill(cl.ds, "resultab")
        If cl.ds.Tables("resultab").Rows.Count > 0 Then
            With cl.ds.Tables("resultab").Rows(0)
                a = .Item("uname")
                txtuser.Text = a
                unit = .Item("unit_name").ToString()
                b = .Item("upwd")
                txtpwd.Text = b
                c = .Item("role")
                 orgid = .Item("org_id").ToString()
                per = .Item("PERSON_NAME").ToString
                OP_ID = .Item("OPID")
                VALBY = .Item("validated_by").ToString()
                gtpur = .Item("gate_purpose")
                unames = .Item("unit_to_view").ToString
                If Not IsDBNull(.Item("seq_no")) Then SEQNO = .Item("seq_no")
                If Not IsDBNull(.Item("adi_allow")) Then adi_allow = .Item("adi_allow")
                tr_mode = .Item("transport_mode").ToString()
                pack_met = .Item("pack_method").ToString()
                If Not IsDBNull(.Item("modify_Flag")) Then modify_Flag = .Item("modify_Flag")
            End With
        Else
            MessageBox.Show("Login Mismatch !!!", "Gate Register")
        End If

        If txtuser.Text <> txtuser.Text.ToUpper Then txtuser.Text = UCase(txtuser.Text)
        If txtpwd.Text <> txtpwd.Text.ToUpper Then txtpwd.Text = UCase(txtpwd.Text)
        mmcard.txtrole.Text = c
        Add.txtrole.Text = c

        If a = txtuser.Text And b = txtpwd.Text And (c = "SKYFAST") Then
            Gate.btnval.Text = "Validate"
            ' Gate.mmcards.Visible = True
            Gate.txtlog.Text = txtuser.Text : Gate.txtrole.Text = c : Gate.lbupdt.Visible = True
            'Gate.btnrtv.Visible = True
            '  Gate.btnreport.Visible = True
            Gate.ADIbt.Visible = True : Gate.UNBLOCK.Visible = True : Gate.dgvcr.Visible = False
            Gate.btntag.Visible = False
            Gate.btnnonpo.Visible = True
            '   Gate.btnxs.Visible = True
            Me.Hide()
            Gate.ShowDialog()
        ElseIf a = txtuser.Text And b = txtpwd.Text And (c = "UNIT1" Or c = "UNIT2") Then
            Gate.btnval.Text = "Validate"
            Gate.txtlog.Text = txtuser.Text : Gate.txtrole.Text = c
            '  Gate.mmcards.Visible = True
            Gate.btnreport.Visible = False : Gate.btntag.Visible = False
            Gate.lbupdt.Visible = True
            'Gate.LinkLabel1.Visible = True:Gate.btnrtv.Visible = True
            Gate.ADIbt.Visible = True : Gate.UNBLOCK.Visible = True
            Me.Hide()

            Gate.ShowDialog()
        ElseIf a = txtuser.Text And b = txtpwd.Text And c = "UNIT4" Then

            Gate.btnval.Text = "Validate"
            Gate.txtlog.Text = txtuser.Text : Gate.txtrole.Text = c
            '  Gate.mmcards.Visible = True
            ' Gate.btnreport.Visible = True
            Gate.lbupdt.Visible = True
            'Gate.LinkLabel1.Visible = True:Gate.btnrtv.Visible = True
            Gate.ADIbt.Visible = True : Gate.UNBLOCK.Visible = True
            Me.Hide()
            Gate.ShowDialog()
        ElseIf a = txtuser.Text And b = txtpwd.Text And gtpur = "View" Then
            Gate.btnadd.Enabled = False ' Gate.btnvou.Enabled = False
            'Gate.btnreport.Visible = True
            Gate.txtlog.Text = txtuser.Text
            Gate.txtrole.Text = c
            Gate.mmcard.Visible = True
            Gate.btncan.Enabled = False
            Gate.btntag.Visible = False
            Gate.btnwop.Enabled = False
            Gate.btnitem.Enabled = False


            If c = "U7" Or c = "U7VIEW" Then Gate.btnmod.Enabled = True Else Gate.btnmod.Enabled = False

            If c = "U7_VIEW" Then Gate.btnitem.Enabled = True : Gate.lbupdt.Visible = True

            Gate.linkpwd.Visible = False : Gate.btndel.Enabled = False

            suplist.rdadi.Enabled = False : suplist.sealed.Enabled = False : suplist.btncan.Enabled = False

            ip = host.AddressList.GetValue(0).ToString
            '  If c = "USER" Or c = "USER1" And (ip = "192.168.12.157" Or ip = "192.168.0.178" Or ip = "192.168.12.11") Then Gate.btnxs.Visible = True

            Me.Hide()


            ' Gate.btnval.Enabled = FalseOr ip = "192.168.12.11"Or ip = "192.168.13.11"
            Gate.ShowDialog()
        ElseIf a = txtuser.Text And b = txtpwd.Text And c = "GATE" Or c = "POVIEW" Or c = "APPL" Then
            Gate.btnadd.Enabled = False ' Gate.btnvou.Enabled = False 
            Gate.btncan.Enabled = False
            ' Gate.btnval.Enabled = False
            Gate.mmcard.Visible = False : Gate.btnwop.Visible = False : Gate.btnitem.Enabled = False : Gate.btngacc.Visible = False
            Gate.btnmod.Enabled = False : Gate.txtlog.Text = txtuser.Text : Gate.btnmod.Enabled = False
            Gate.btndel.Enabled = False : Gate.linkpwd.Visible = False : Gate.txtrole.Text = c : Gate.btntag.Visible = False
            Me.Hide()
            Gate.ShowDialog()
        ElseIf a = txtuser.Text And b = txtpwd.Text And c = "VALID" Then
            Gate.btnadd.Enabled = False ' Gate.btnvou.Enabled = False
            Gate.txtlog.Text = txtuser.Text
            Gate.txtrole.Text = c : Gate.btndel.Enabled = False : Gate.btnmod.Enabled = False : Gate.btntag.Visible = False
            Gate.linkpwd.Visible = False : Gate.btnval.Text = "Enter Action" : Gate.btncan.Enabled = False
            Me.Hide()
            Gate.ShowDialog()
        ElseIf a = txtuser.Text And b = txtpwd.Text And c = "VIEW" Then
            Gate.btnadd.Enabled = False ' Gate.btnvou.Enabled = False
            Gate.btndel.Enabled = False
            Gate.btnmod.Enabled = False : Gate.bprint.Enabled = False : Gate.btnview.Enabled = False
            Gate.glist.Enabled = False : Gate.btnmod.Enabled = False : Gate.txtlog.Text = txtuser.Text
            Gate.txtrole.Text = c : Gate.linkpwd.Visible = False : Gate.btncan.Enabled = False : Gate.btntag.Visible = False
            Me.Hide()
            Gate.ShowDialog()

        ElseIf a = txtuser.Text And b = txtpwd.Text And c = "INWARD" Then
            Gate.btnval.Text = "Validate"
            Gate.txtlog.Text = txtuser.Text ' Gate.mmcards.Visible = True
            Gate.txtrole.Text = c
            Gate.btnrecpt.Visible = False
            Gate.btnitem.Enabled = True
            'Gate.btnrtv.Visible = True.
            ' Gate.linkpwd.Visible = True
            ' Gate.btnxs.Visible = True
            'Gate.btnreport.Visible = True
            Gate.ADIbt.Visible = True : Gate.UNBLOCK.Visible = True
            Gate.lbupdt.Visible = True
            Me.Hide()
            Gate.ShowDialog()

        ElseIf a = txtuser.Text And b = txtpwd.Text And c = "U7_ADD" Or C = "SKY_ADD" Or c = "U1_ADD" Or c = "POLYADD" Then
            Gate.txtlog.Text = txtuser.Text : Gate.mmcard.Visible = True
            Gate.txtrole.Text = c
            Gate.ADIbt.Visible = True : Gate.btntag.Enabled = False
            Gate.btnadd.Visible = True
            Gate.UNBLOCK.Visible = True : Gate.btnnonpo.Visible = True
            Gate.btnval.Enabled = False : Gate.btnmod.Enabled = False : Gate.btncan.Enabled = False : Gate.btndel.Enabled = False : Gate.btnsta.Enabled = False : Gate.glist.Enabled = False : Gate.btnrecpt.Enabled = False : Gate.btnview.Enabled = False : Gate.bprint.Enabled = False  'Gate.btnreport.Visible = False
            Gate.Button1.Enabled = False : Gate.btnxs.Enabled = False : Gate.btnwop.Enabled = False : Gate.btnitem.Enabled = False
            If c = "U7_ADD" Then Gate.btnsta.Enabled = True
            Me.Hide()
            Gate.ShowDialog()

        ElseIf a = txtuser.Text And b = txtpwd.Text And gtpur = "Entry" Then
            'Gate.btnvou.Enabled = False : Gate.btngtlot.Visible = True
            Gate.mmcard.Visible = True
            Gate.btnitem.Enabled = True
            Gate.txtlog.Text = txtuser.Text : Gate.txtrole.Text = c : Gate.btnmod.Enabled = True
            'Gate.btnrtv.Location = New System.Drawing.Point(554, 196) : Gate.btnrtv.Visible = True
            ' Gate.btnxs.Visible = True
            Gate.btncan.Enabled = True
            Gate.btnnonpo.Visible = True
            Gate.ADIbt.Visible = True : Gate.UNBLOCK.Visible = True : Gate.lbupdt.Visible = True
            '  Gate.btn_auto_receipt.Visible = True
            Me.Hide()

            ' Gate.linkpwd.Visible = True
            Gate.ShowDialog()
        ElseIf c = "JAPL" Then
                Gate.txtlog.Text = txtuser.Text
            Gate.txtrole.Text = c
            Gate.ADIbt.Visible = True
            Gate.btnadd.Visible = True : Gate.btntag.Visible = False
            Gate.btnnonpo.Visible = True
            Gate.lbupdt.Visible = False : Gate.btnval.Visible = True : Gate.btnmod.Visible = True : Gate.btncan.Visible = True : Gate.btndel.Visible = True : Gate.UNBLOCK.Visible = False : Gate.btnview.Visible = True  'Gate.bprint.Visible = True 
            'Gate.btnreport.Visible = True
            Gate.Button1.Visible = False : Gate.btnxs.Visible = False : Gate.lbupdt.Visible = True : Gate.dgvcr.Visible = False : Gate.btnitem.Enabled = True
            Me.Hide()
            Gate.ShowDialog()


            'ElseIf a <> txtuser.Text Then
            '    ErrorProvider1.SetError(txtuser, "Invalid Username")
            'ElseIf b <> txtpwd.Text Then
            '    ErrorProvider1.SetError(txtpwd, "Invalid Pwd")
        End If
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub txtpwd_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtpwd.KeyDown
        If e.KeyCode = 13 Then
            Button1_Click(sender, e)
        End If
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles Me.Load
        userid = "UNIT7"
        orgid = "444"

        'userid = Environment.GetCommandLineArgs(3)
        'orgid = Environment.GetCommandLineArgs(4)

        Button1_Click(sender, e)

        Me.Hide()


    End Sub
End Class