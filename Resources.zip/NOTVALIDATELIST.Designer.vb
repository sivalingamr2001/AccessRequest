<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NOTVALIDATELIST
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.btnshow = New System.Windows.Forms.Button
        Me.dgvdetails = New System.Windows.Forms.DataGridView
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbsup = New System.Windows.Forms.ComboBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.tocal = New System.Windows.Forms.MonthCalendar
        Me.txtqpto = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.fmcal = New System.Windows.Forms.MonthCalendar
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtqpfm = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.btnfm = New System.Windows.Forms.Button
        Me.btnto = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmborg = New System.Windows.Forms.ComboBox
        Me.dgvlines = New System.Windows.Forms.DataGridView
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.btnprint = New System.Windows.Forms.Button
        CType(Me.dgvdetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgvlines, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnshow
        '
        Me.btnshow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnshow.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshow.Location = New System.Drawing.Point(707, 11)
        Me.btnshow.Name = "btnshow"
        Me.btnshow.Size = New System.Drawing.Size(56, 23)
        Me.btnshow.TabIndex = 0
        Me.btnshow.Text = "Show"
        Me.btnshow.UseVisualStyleBackColor = True
        '
        'dgvdetails
        '
        Me.dgvdetails.AllowUserToAddRows = False
        Me.dgvdetails.BackgroundColor = System.Drawing.Color.White
        Me.dgvdetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvdetails.EnableHeadersVisualStyles = False
        Me.dgvdetails.Location = New System.Drawing.Point(12, 40)
        Me.dgvdetails.Name = "dgvdetails"
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvdetails.RowHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvdetails.RowHeadersWidth = 25
        Me.dgvdetails.RowTemplate.Height = 30
        Me.dgvdetails.Size = New System.Drawing.Size(844, 408)
        Me.dgvdetails.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(0, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "Supplier"
        '
        'cmbsup
        '
        Me.cmbsup.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsup.FormattingEnabled = True
        Me.cmbsup.Location = New System.Drawing.Point(56, 12)
        Me.cmbsup.Name = "cmbsup"
        Me.cmbsup.Size = New System.Drawing.Size(220, 21)
        Me.cmbsup.TabIndex = 38
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Black
        Me.GroupBox3.Controls.Add(Me.tocal)
        Me.GroupBox3.Location = New System.Drawing.Point(557, 35)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(198, 162)
        Me.GroupBox3.TabIndex = 86
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Visible = False
        '
        'tocal
        '
        Me.tocal.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tocal.Location = New System.Drawing.Point(3, 3)
        Me.tocal.Name = "tocal"
        Me.tocal.TabIndex = 2
        '
        'txtqpto
        '
        Me.txtqpto.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtqpto.Location = New System.Drawing.Point(572, 12)
        Me.txtqpto.Name = "txtqpto"
        Me.txtqpto.Size = New System.Drawing.Size(100, 21)
        Me.txtqpto.TabIndex = 83
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Black
        Me.GroupBox2.Controls.Add(Me.fmcal)
        Me.GroupBox2.Location = New System.Drawing.Point(354, 37)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(198, 162)
        Me.GroupBox2.TabIndex = 85
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Visible = False
        '
        'fmcal
        '
        Me.fmcal.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fmcal.Location = New System.Drawing.Point(3, 3)
        Me.fmcal.Name = "fmcal"
        Me.fmcal.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(381, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 13)
        Me.Label2.TabIndex = 80
        Me.Label2.Text = "From"
        '
        'txtqpfm
        '
        Me.txtqpfm.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtqpfm.Location = New System.Drawing.Point(419, 12)
        Me.txtqpfm.Name = "txtqpfm"
        Me.txtqpfm.Size = New System.Drawing.Size(100, 21)
        Me.txtqpfm.TabIndex = 84
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(550, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(21, 13)
        Me.Label3.TabIndex = 79
        Me.Label3.Text = "To"
        '
        'btnfm
        '
        Me.btnfm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnfm.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfm.Location = New System.Drawing.Point(519, 12)
        Me.btnfm.Name = "btnfm"
        Me.btnfm.Size = New System.Drawing.Size(29, 21)
        Me.btnfm.TabIndex = 82
        Me.btnfm.Text = "..."
        Me.btnfm.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnfm.UseVisualStyleBackColor = True
        '
        'btnto
        '
        Me.btnto.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnto.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnto.Location = New System.Drawing.Point(672, 11)
        Me.btnto.Name = "btnto"
        Me.btnto.Size = New System.Drawing.Size(29, 22)
        Me.btnto.TabIndex = 81
        Me.btnto.Text = "..."
        Me.btnto.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnto.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(278, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Org"
        '
        'cmborg
        '
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(312, 12)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(66, 21)
        Me.cmborg.TabIndex = 87
        '
        'dgvlines
        '
        Me.dgvlines.AllowUserToAddRows = False
        Me.dgvlines.BackgroundColor = System.Drawing.Color.White
        Me.dgvlines.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvlines.EnableHeadersVisualStyles = False
        Me.dgvlines.Location = New System.Drawing.Point(12, 476)
        Me.dgvlines.Name = "dgvlines"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvlines.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvlines.RowHeadersWidth = 25
        Me.dgvlines.RowTemplate.Height = 30
        Me.dgvlines.Size = New System.Drawing.Size(844, 174)
        Me.dgvlines.TabIndex = 88
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Peru
        Me.Label15.ForeColor = System.Drawing.Color.Peru
        Me.Label15.Location = New System.Drawing.Point(687, 452)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(39, 18)
        Me.Label15.TabIndex = 90
        Me.Label15.Text = "Ro"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(728, 454)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(126, 14)
        Me.Label10.TabIndex = 89
        Me.Label10.Text = "Not-Validated Item"
        '
        'btnprint
        '
        Me.btnprint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnprint.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprint.Location = New System.Drawing.Point(770, 11)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(49, 23)
        Me.btnprint.TabIndex = 91
        Me.btnprint.Text = "Print"
        Me.btnprint.UseVisualStyleBackColor = True
        '
        'NOTVALIDATELIST
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(868, 658)
        Me.Controls.Add(Me.btnprint)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.dgvlines)
        Me.Controls.Add(Me.cmborg)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.txtqpto)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtqpfm)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnfm)
        Me.Controls.Add(Me.btnto)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbsup)
        Me.Controls.Add(Me.dgvdetails)
        Me.Controls.Add(Me.btnshow)
        Me.Name = "NOTVALIDATELIST"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Not-Validated  List"
        CType(Me.dgvdetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.dgvlines, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnshow As System.Windows.Forms.Button
    Friend WithEvents dgvdetails As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbsup As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents tocal As System.Windows.Forms.MonthCalendar
    Friend WithEvents txtqpto As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents fmcal As System.Windows.Forms.MonthCalendar
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtqpfm As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnfm As System.Windows.Forms.Button
    Friend WithEvents btnto As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents dgvlines As System.Windows.Forms.DataGridView
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents btnprint As System.Windows.Forms.Button
End Class
