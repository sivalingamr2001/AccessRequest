Imports System.Data.OracleClient
Imports System.IO
Imports oracleclass
Public Class CycleCount
    Dim sql, s As String
    Dim cl As New oracleclass.Class1
    Dim adap As New OracleDataAdapter
    Dim i, j As Integer
    Dim cc, c0, c2 As New DataGridViewTextBoxColumn
    Dim ds As New DataSet
    Dim a, b, a1, b1, c, d, ee, f, g, h, c1, d1, e1, f1, g1, h1 As Double
    Dim WithEvents DoIt As New DoStuffClass
    Private Sub CycleCount_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "select secondary_inventory_name from jan_subinventories "
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbinv.Items.Add(ds.Tables("resultab").Rows(i).Item("secondary_inventory_name"))
        Next
        sql = "select organization_code  from apps.org_organization_definitions where organization_code  not in('I08','I09')order by organization_code"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub
    Private Sub UpdateProgressBar(ByVal MyCountInteger As Integer) Handles DoIt.OnProgress
        ProgressBar1.Value = MyCountInteger
    End Sub
    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Try
            DoIt.StartValue = 0
            ds.Clear()
            ds.Dispose()
            dgcycle.Columns.Clear()
            ProgressBar1.Visible = True
            sql = "select (select organization_code from org_organization_definitions where organization_id=a.organization_id)org,item_no,item_description,adj_date,appd_date,revision,round(system_quantity,2)system_quantity,round(final_quantity,2)final_quantity,round(short_quantity,2)short_quantity,round(short_value,2)short_value,round(excess_quantity,2)excess_quantity,round(excess_value,2)excess_value,item_type,make_buy,subinventory from jan_cycle_count a where 1=1"

            If cmborg.SelectedItem <> "" Then
                sql &= " and  organization_id=(select organization_id from org_organization_definitions a  where a.organization_code='" & cmborg.SelectedItem & "')"
            End If
            If cmbitem.SelectedItem <> "" Then
                sql &= " and item_type='" & cmbitem.SelectedItem & "'"
            End If
            If cmbmb.SelectedItem <> "" Then
                sql &= " and make_buy='" & cmbmb.SelectedItem & "'"
            End If
            If cmbinv.SelectedItem <> "" Then
                sql &= " and subinventory='" & cmbinv.SelectedItem & "'"
            End If
            If txtitem.Text <> "" Then
                sql &= " and item_no ='" & txtitem.Text & "'"
            End If
            sql &= " and adj_date>='" & Format(adjfm.Value, "dd-MMM-yyyy") & "' and adj_date<='" & Format(adjto.Value, "dd-MMM-yyyy") & "'"
            sql &= " and appd_date >='" & Format(appfm.Value, "dd-MMM-yyyy") & "' and appd_date<='" & Format(appto.Value, "dd-MMM-yyyy") & "'"
            sql &= "order by item_no"

            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.oradap = New OracleDataAdapter(cl.orcmd)
            ds = New DataSet
            DoIt.StartValue = 0
            DoIt.CountLoop()
            adap.Fill(ds, "resultab")
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Org"
            cc.DataPropertyName = "org"
            cc.Width = 30
            Me.dgcycle.Columns.Add(cc)
            c0 = New DataGridViewTextBoxColumn()
            c0.HeaderText = "Item"
            c0.DataPropertyName = "item_no"
            c0.Width = 70
            Me.dgcycle.Columns.Add(c0)
            c2 = New DataGridViewTextBoxColumn()
            c2.HeaderText = "Description"
            c2.DataPropertyName = "item_description"
            c2.Width = 90
            Me.dgcycle.Columns.Add(c2)
            c2 = New DataGridViewTextBoxColumn()
            c2.HeaderText = "Adj.Dt"
            c2.DataPropertyName = "adj_date"
            c2.Width = 75
            Me.dgcycle.Columns.Add(c2)
            c2 = New DataGridViewTextBoxColumn()
            c2.HeaderText = "App.Dt"
            c2.DataPropertyName = "appd_date"
            c2.Width = 75
            Me.dgcycle.Columns.Add(c2)
            c2 = New DataGridViewTextBoxColumn()
            c2.HeaderText = "Rev"
            c2.DataPropertyName = "revision"
            c2.Width = 30
            Me.dgcycle.Columns.Add(c2)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "SysQty"
            cc.DataPropertyName = "system_quantity"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "FinalQty"
            cc.DataPropertyName = "final_quantity"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "ShortQty"
            cc.DataPropertyName = "short_quantity"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "ShortVal"
            cc.DataPropertyName = "short_value"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "ExcessQty"
            cc.DataPropertyName = "excess_quantity"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "ExcessVal"
            cc.DataPropertyName = "Excess_value"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "IType"
            cc.DataPropertyName = "item_type"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "MB"
            cc.DataPropertyName = "make_buy"
            cc.Width = 45
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Inv"
            cc.DataPropertyName = "subinventory"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgcycle.Columns.Add(cc)
            a1 = 0
            b1 = 0
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                a = 0
                b = 0
                With ds.Tables("resultab").Rows(i)
                    a = .Item("short_value")
                    a1 = a + a1
                    b = .Item("excess_value")
                    b1 = b + b1
                End With
            Next
            lbst.Text = a1
            lbex.Text = b1
            dgcycle.DataSource = ds.Tables("resultab")
            ProgressBar1.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.StackTrace)
        End Try
    End Sub

    Private Sub btnpri_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpri.Click
        Dim objFSO
        objFSO = CreateObject("Scripting.FileSystemObject")
        Dim FullPath
        FullPath = "D:\\cyclecount"
        If Not objFSO.FolderExists(FullPath) Then
            objFSO.CreateFolder(FullPath)
        ElseIf objFSO.FolderExists(FullPath) Then
            objFSO.DeleteFolder(FullPath)
            objFSO.CreateFolder(FullPath)
        End If
        Dim X As String
        X = "D:\cyclecount\" & Trim(CStr(Rnd() * 255)) & ".HTML"
        Dim fstrm As New FileStream(X, FileMode.OpenOrCreate, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        j = 0
        s = "<html><H4 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>CycleCount-MIS Report</FONT></H4>"
        s &= "<table cellSpacing=0 cellPadding=0 BORDER=1 align=center position=top><TH><B><FONT SIZE=2 font face=Arial narrow>S.No</font></TH><TH><B><FONT SIZE=2 font face=Arial narrow>Org</font></TH><TH BORDER=0><B><FONT SIZE=2 font face=Arial narrow>Item No/Desc</font></TH><TH BORDER=0><B><FONT SIZE=2 font face=Arial narrow>Adj.Dt</font></TH><TH BORDER=0><B><FONT SIZE=2 font face=Arial narrow>Appd.Dt</font></TH><th><B><FONT SIZE=2 font face=Arial narrow>Rev</font></TH><TH BORDER=0><B><FONT SIZE=2 font face=Arial narrow>SysQty</font></TH><TH><B><FONT SIZE=2 font face=Arial narrow>FinalQty</font></TH><TH><B><FONT SIZE=2 font face=Arial narrow>ShortQty</font></TH><TH><B><FONT SIZE=2 font face=Arial narrow>ShortVal</font></TH><TH><B><FONT SIZE= 2 font face=Arial narrow>ExcessQty</font></TH><TH><B><FONT SIZE=2 font face=Arial narrow>ExcessVal</font></TH><TH><B><FONT SIZE=2 font face=Arial narrow>ItemType</font><TH><B><FONT SIZE=2 font face=Arial narrow>Make/Buy</font></TH><TH><B><FONT SIZE=2 font face=Arial narrow>Inventory</font></TH></TR>"
        c1 = 0
        d1 = 0
        e1 = 0
        f1 = 0
        g1 = 0
        h1 = 0

        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            j += 1
            With ds.Tables("resultab").Rows(i)
                c = 0
                d = 0
                ee = 0
                f = 0
                g = 0
                h = 0
                c = .Item("system_quantity")
                c1 = c + c1
                d = .Item("final_quantity")
                d1 = +d + d1
                ee = .Item("short_quantity")
                e1 = ee + e1
                g = .Item("short_value")
                g1 = g + g1
                f = .Item("excess_quantity")
                f1 = f + f1
                h = .Item("excess_value")
                h1 = h + h1
                s &= "<TR><Td><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("Org") & "</FONT></TH><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("item_no") & " ||" & .Item("item_description") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("adj_date") & "</FONT></Td><Td ><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("appd_date") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("revision") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("system_quantity") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("final_quantity") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("short_quantity") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("short_value") & " </FONT></Td><Td align=right ><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("excess_quantity") & " </FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("excess_value") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("item_type") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("make_buy") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("subinventory") & "</FONT></Td></TR>"
            End With
        Next
        s &= "<TR><td align=right>-</td><td align=right>-</td><td align=right>-</td><td align=right>-</td><td align=right>-</td><td align=right>-</td><Td ><FONT SIZE=1 FONT FACE=VERDANA >" & c1 & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA >" & d1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & e1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & g1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & f1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & h1 & " </FONT></Td><td align=right>-</td><td align=right>-</td><td align=right>-</td></TR>"

        DoIt.StartValue = 0
        DoIt.CountLoop()
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(X)
    End Sub
End Class