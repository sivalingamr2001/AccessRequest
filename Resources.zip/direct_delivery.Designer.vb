<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class direct_delivery
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.cmborg = New System.Windows.Forms.ComboBox
        Me.cmbven = New System.Windows.Forms.ComboBox
        Me.btnshow = New System.Windows.Forms.Button
        Me.dtto = New System.Windows.Forms.DateTimePicker
        Me.dtfrm = New System.Windows.Forms.DateTimePicker
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.dgv1 = New System.Windows.Forms.DataGridView
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtitem = New System.Windows.Forms.TextBox
        Me.RDAPP = New System.Windows.Forms.RadioButton
        Me.rdrej = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmbcri = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmborg
        '
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(357, 12)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(60, 21)
        Me.cmborg.TabIndex = 18
        '
        'cmbven
        '
        Me.cmbven.FormattingEnabled = True
        Me.cmbven.Location = New System.Drawing.Point(55, 13)
        Me.cmbven.Name = "cmbven"
        Me.cmbven.Size = New System.Drawing.Size(268, 21)
        Me.cmbven.TabIndex = 19
        '
        'btnshow
        '
        Me.btnshow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnshow.Location = New System.Drawing.Point(275, 41)
        Me.btnshow.Name = "btnshow"
        Me.btnshow.Size = New System.Drawing.Size(48, 23)
        Me.btnshow.TabIndex = 17
        Me.btnshow.Text = "Show"
        Me.btnshow.UseVisualStyleBackColor = True
        '
        'dtto
        '
        Me.dtto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtto.Location = New System.Drawing.Point(168, 42)
        Me.dtto.Name = "dtto"
        Me.dtto.Size = New System.Drawing.Size(96, 20)
        Me.dtto.TabIndex = 16
        '
        'dtfrm
        '
        Me.dtfrm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtfrm.Location = New System.Drawing.Point(55, 42)
        Me.dtfrm.Name = "dtfrm"
        Me.dtfrm.Size = New System.Drawing.Size(96, 20)
        Me.dtfrm.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 18)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Vendor"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(327, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Org"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 46)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Gate Dt"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(150, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(20, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "To"
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(1, 68)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowHeadersVisible = False
        Me.dgv1.RowHeadersWidth = 20
        Me.dgv1.RowTemplate.Height = 30
        Me.dgv1.Size = New System.Drawing.Size(1018, 621)
        Me.dgv1.TabIndex = 20
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Location = New System.Drawing.Point(329, 42)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(48, 23)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Print"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(423, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Item No"
        '
        'txtitem
        '
        Me.txtitem.Location = New System.Drawing.Point(474, 12)
        Me.txtitem.Name = "txtitem"
        Me.txtitem.Size = New System.Drawing.Size(100, 20)
        Me.txtitem.TabIndex = 21
        '
        'RDAPP
        '
        Me.RDAPP.AutoSize = True
        Me.RDAPP.Checked = True
        Me.RDAPP.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RDAPP.Location = New System.Drawing.Point(6, 9)
        Me.RDAPP.Name = "RDAPP"
        Me.RDAPP.Size = New System.Drawing.Size(80, 17)
        Me.RDAPP.TabIndex = 0
        Me.RDAPP.TabStop = True
        Me.RDAPP.Text = "Approved"
        Me.RDAPP.UseVisualStyleBackColor = True
        '
        'rdrej
        '
        Me.rdrej.AutoSize = True
        Me.rdrej.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdrej.Location = New System.Drawing.Point(92, 9)
        Me.rdrej.Name = "rdrej"
        Me.rdrej.Size = New System.Drawing.Size(75, 17)
        Me.rdrej.TabIndex = 1
        Me.rdrej.Text = "Rejected"
        Me.rdrej.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RDAPP)
        Me.GroupBox1.Controls.Add(Me.rdrej)
        Me.GroupBox1.Location = New System.Drawing.Point(581, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(170, 29)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        '
        'cmbcri
        '
        Me.cmbcri.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcri.FormattingEnabled = True
        Me.cmbcri.Items.AddRange(New Object() {"ADI Prepared-Gate Pending", "Po Preparation Pending ", "Challan Preparation Pending"})
        Me.cmbcri.Location = New System.Drawing.Point(805, 11)
        Me.cmbcri.Name = "cmbcri"
        Me.cmbcri.Size = New System.Drawing.Size(208, 21)
        Me.cmbcri.TabIndex = 23
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(754, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Criteria"
        '
        'direct_delivery
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1021, 695)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbcri)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtitem)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.cmborg)
        Me.Controls.Add(Me.cmbven)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnshow)
        Me.Controls.Add(Me.dtto)
        Me.Controls.Add(Me.dtfrm)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Name = "direct_delivery"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Direct Delivery Report"
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents cmbven As System.Windows.Forms.ComboBox
    Friend WithEvents btnshow As System.Windows.Forms.Button
    Friend WithEvents dtto As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtfrm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtitem As System.Windows.Forms.TextBox
    Friend WithEvents rdrej As System.Windows.Forms.RadioButton
    Friend WithEvents RDAPP As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbcri As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
