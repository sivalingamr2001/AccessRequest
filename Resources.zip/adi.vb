﻿Public Class adi


    Dim sql, a, s, de, c, asndt, SID, SNAME, ASNTYPE As String
    Dim ds, dsad, ds1, MDS As New DataSet
    Dim i, j, line, LLID As Integer

    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Try
            Dim A, B As Boolean
            Dim dsID As New DataSet
            A = False
            B = False
            line = 0
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            If txtrole.Text = "UNIT2" Then
                sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='UNIT2'"
                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)

                cl.oradap.Fill(dsID, "resultab")

                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    txtgno.Text = 700100001
                End If
            End If



            If txtrole.Text = "U7_ADD" Or txtrole.Text = "UNIT7" Or txtrole.Text = "U7" Then
                If chkoadi.Checked = False Then
                    sql = "select jan_GATE_NO_SEQ.NEXTVAL FROM DUAL"
                    cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                    cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)

                    cl.oradap.Fill(dsID, "resultab")



                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item(0)
                Else
                    '    txtgno.Text = txtgno.Text = 700100001
                End If
            End If

            If txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Then
                sql = "SELECT TO_CHAR(JAN_FYR_DATE,'yyyy') FROM DUAL"
                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)
                ds = New DataSet
                cl.oradap.Fill(ds, "ID")
                Dim IDS As String = ds.Tables("ID").Rows(0).Item(0)
                'Dim GT As Integer

                sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='" & txtrole.Text & "'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    If txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Then ID = String.Concat(IDS, "9000", 1) Else ID = String.Concat(IDS, "000", 1)
                    txtgno.Text = ID
                End If
            End If

            If txtrole.Text = "JAPL" Then
                sql = "SELECT TO_CHAR(JAN_FYR_DATE,'yyyy') FROM DUAL"
                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)
                ds = New DataSet
                cl.oradap.Fill(ds, "ID")
                Dim IDS As String = ds.Tables("ID").Rows(0).Item(0)
                'Dim GT As Integer

                sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='JAPL'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    If txtrole.Text = "JAPL" Then ID = String.Concat(IDS, "80000", 1) Else ID = String.Concat(IDS, "000", 1)
                    txtgno.Text = ID
                End If
            End If


            head = txtgno.Text

            ''''unit7

            'sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='UNIT7' "
            'cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
            'cl.oradap= New OracleClient.OracleDataAdapter(cl.orcmd)
            'Dim dsID1 As New DataSet
            'cl.oradap.Fill(dsID1, "resultab")
            'If txtrole.Text = "UNIT7" Then
            '    If dsID1.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
            '        txtgno.Text = dsID1.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
            '    Else
            '        txtgno.Text = 2015170000
            '    End If
            'End If




            'head = txtgno.Text


            ''''checking gate existence
            sql = "select gate_no from jan_gate_header where gate_no='" & txtgno.Text & "'and extract (month from gdate)=" & Date.Now.Month & " and extract (year from gdate)=" & Date.Now.Year & " and unit='" & txtrole.Text & "'"
            cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
            cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "resultab")

            If ds1.Tables("resultab").Rows.Count <> 0 Then
                For i = 0 To ds1.Tables("resultab").Rows.Count - 1
                    If IsNumeric(txtgno.Text) Then
                        If ds1.Tables("resultab").Rows(i).Item("gate_no") = txtgno.Text Then
                            MessageBox.Show("Gate Number Already Exists!", "Gate Entry")
                            Exit Sub
                        End If
                    End If
                Next
            End If
            ''''checking dcno
            sql = "select GATE_ID,UNIT,GTYPE,DC_DATE,dc_no ,supplier_name from jan_gate_header where validated<>6 and supplier_name='" & cmbsup.Text & "' and extract (month from gdate)=" & Date.Now.Month & " and unit='" & txtrole.Text & "' and extract (year from gdate)=" & Date.Now.Year & ""
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            If ds.Tables("resultab").Rows.Count <> 0 Then
                For i = 0 To ds.Tables("resultab").Rows.Count - 1
                    If ds.Tables("resultab").Rows(i).Item("dc_no").ToString = txtdcno.Text Then
                        With ds.Tables("resultab").Rows(i)
                            sql = "DCNo already available for the supplier" & vbNewLine & vbNewLine & "Gate No : " & .Item("gATE_ID") & vbNewLine & "Unit : " & .Item("Unit") & vbNewLine & "Gate Type : " & .Item("gtype") & vbNewLine & "DC No : " & .Item("dc_no") & vbNewLine & "DC Date : " & Format(.Item("dc_date"), "dd-MMM-yyyy")
                        End With

                        MessageBox.Show(sql, "Gate Entry")
                        Exit Sub
                    End If
                Next
            End If

            For i = 0 To dgv1.RowCount - 1
                If CType(dgv1.Rows(i).Cells(0).Value, String) <> "" And CType(dgv1.Rows(i).Cells(8).Value, String) = "" Then
                    B = True
                    Exit Sub
                End If
            Next

            'If cmbtype.Text <> "OSP" Then
            '    For i = 0 To dgv1.RowCount - 1
            '        If dgv1.Rows(i).Cells(8).Value <> "" Then
            '            If CType(dgv1.Rows(i).Cells(24).Value, String) = "" Then
            '                MsgBox("Tariff No Not Empty !..")
            '                Exit Sub
            '            End If
            '        End If
            '    Next
            'End If


            For i = 0 To dgv1.RowCount - 1
                If dgv1.Rows(i).Cells(8).Value = "" Then Exit For
                If dgv1.Rows(i).Cells(0).Value <> "" And txtdcno.Text <> "" And dgv1.Rows(i).Cells(8).Value <> "" And Convert.ToDecimal(dgv1.Rows(i).Cells(8).Value) > Convert.ToDecimal(dgv1.Rows(i).Cells(6).Value) Then
                    MessageBox.Show("DcQty Greater Then Po Pend", "Gate Entry")
                    Exit Sub
                End If
            Next

            If txtdcno.Text <> "" Then
                Dim d As Date
                d = Date.Today
                sql = "insert into jan_gate_header(gate_no,gate_id,supplier_name,supplier_site,dc_no,dc_date,validated,gtype,gdate,vehicle_det,courier_name,pod_no ,no_of_box ,po_wt ,rec_Wt,unit,flag,adi_no,adi_date,INVOICE_VAL,xerox,VENDOR_ID,adi_via,ADI_TYPE,direct_dlyd_flag) 
                values(" & txtgno.Text & ",'" & txtgno.Text & "','" & cmbsup.Text & "','" & txtsite.Text & "','" & txtdcno.Text & "','" & Format(dtdc.Value, "dd-MMM-yyyy") & "',"

                ' If nval_cb.Checked = True Then
                'sql &= "'" & 0 & "',"
                'Else
                sql &= "'" & 1 & "',"
                ' End If

                sql &= "'" & cmbtype.Text & "'"

                If chkoadi.Checked = True Then
                    sql &= ",nvl((select gate_Dt from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1),sysdate),nvl((select vehicle_Det from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1),'') ,(select courier_name from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1),(select pod_no from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1),(select no_of_box from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1),(select pod_wt from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1),(select rec_wt from jan_gate_del where gate_no=" & txtgno.Text & " and rownum=1)"
                Else
                    sql &= ",sysdate,'" & txtveh.Text & "','" & cmbcr.Text & "','" & txtpod.Text & "','" & txtbox.Text & "','" & txtpodwt.Text & "','" & txtrwt.Text & "'"
                End If


                If txtrole.Text = "UNIT1" Or txtrole.Text = "ADD" Then
                    sql &= " ,'UNIT1'"
                ElseIf txtrole.Text = "U7_ADD" Or txtrole.Text = "UNIT7" Or txtrole.Text = "U7" Then
                    sql &= " ,'UNIT7'"
                ElseIf txtrole.Text = "UNIT2" Then
                    sql &= " ,'UNIT2'"
                ElseIf txtrole.Text = "UNIT4" Then
                    sql &= " ,'UNIT4'"
                ElseIf txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Then
                    sql &= " ,'SKYFAST'"
                ElseIf txtrole.Text = "JAPL" Then
                    sql &= " ,'JAPL'"

                End If

                sql &= ",'" & 1 & "','" & TXT_ASN_NO.Text & "','" & Format(CDate(asndt), "dd-MMM-yyyy") & "','" & Txt_inv_val.Text & "','No'," & SID & ",'ADI','" & ASNTYPE & "','Y')"

                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
            Else
                B = True
            End If

            For i = 0 To dgv1.RowCount - 1
                If B = False Then
                    If dgv1.Rows(i).Cells(8).Value = "" Then Exit For
                    dt2 = dgv1.Item(1, i).Value
                    line = line + 1
                    de = dgv1.Item(3, i).Value.ToString.Replace("""", """")
                    de = de.Replace("'", "''")
                    sql = "insert into jan_gate_lines (line_no,gate_no,gate_id,pono,podt,item,description,rev,popend,supdcqty,uom,job,oper,osp,type,remark,status,validated,org,flag,poline,pohead,location_id,poqty,actval,ratecat,potype,tariff"

                    If cmbtype.Text = "OSP" Then
                        sql &= " ,wip_entity_id,opn_seq "
                    End If


                    sql &= ",spot_inspection,self_certify"

                    If cmbtype.Text = "PO" Then
                        If txtrole.Text = "U7_ADD" Or txtrole.Text = "UNIT7" Or txtrole.Text = "U7" Then sql &= ",lot_no "
                    End If



                    sql &= " )values(" & line & "," & txtgno.Text & ",'" & txtgno.Text & "','" & dgv1.Item(0, i).Value & "','" & Format(dt2, "dd-MMM-yyyy") & "','" & dgv1.Item(2, i).Value & "','" & de & "','" & dgv1.Item(5, i).Value & "'," & dgv1.Item(6, i).Value & ", '" & dgv1.Item(8, i).Value.ToString & "','" & dgv1.Item(7, i).Value & "','" & dgv1.Item(13, i).Value & "','" & dgv1.Item(12, i).Value & "','" & dgv1.Item(11, i).Value & "','" & dgv1.Item(14, i).Value & "','" & dgv1.Item(9, i).Value & "','" & 1 & "',"

                    '" & dgv1.Item(17, i).Value & "',


                    'If nval_cb.Checked = True Then
                    sql &= "'" & 1 & "',"
                    'Else
                    'sql &= "'" & 1 & "',"
                    'End If

                    sql &= "'" & dgv1.Item(4, i).Value & "','" & 1 & "','" & dgv1.Item(15, i).Value & "','" & dgv1.Item(16, i).Value & "','" & dgv1.Item(19, i).Value & "' ,'" & dgv1.Item(10, i).Value & "','" & dgv1.Item(8, i).Value & "','" & dgv1.Item(22, i).Value & "','" & dgv1.Item(23, i).Value & "','" & dgv1.Item(24, i).Value & "'"

                    If cmbtype.Text = "OSP" Then
                        sql &= " ,'" & dgv1.Item(25, i).Value & "','" & dgv1.Item(26, i).Value & "'"
                    End If

                    sql &= " ,'" & dgv1.Item(27, i).Value & "','" & dgv1.Item(28, i).Value & "'"
                    If cmbtype.Text = "PO" Then
                        If txtrole.Text = "U7_ADD" Or txtrole.Text = "UNIT7" Or txtrole.Text = "U7" Then

                            If dgv1.Item(31, i).Value <> "" Then sql &= ",'" & dgv1.Item(31, i).Value & "'" Else sql &= ", '' "

                        End If
                    End If




                    sql &= " )"


                    ' sql = "insert into jan_gate_lines (line_no,gate_no,gate_id,pono,podt,item,description,rev,popend,supdcqty,uom,job,oper,osp,type,remark,status,validated,org,flag,poline,pohead,location_id,poqty,actval,ratecat)values(" & line & "," & head & ",'" & head & "','" & dgv1.Item(0, i).Value & "','" & Format(dt2, "dd-MMM-yyyy") & "','" & dgv1.Item(2, i).Value & "','" & de & "','" & dgv1.Item(5, i).Value & "'," & dgv1.Item(6, i).Value & ", '" & dgv1.Item(8, i).Value.ToString & "','" & dgv1.Item(7, i).Value & "','" & dgv1.Item(14, i).Value & "','" & dgv1.Item(13, i).Value & "','" & dgv1.Item(12, i).Value & "','" & dgv1.Item(15, i).Value & "','" & dgv1.Item(9, i).Value & "','" & 1 & "','" & dgv1.Item(18, i).Value & "','" & dgv1.Item(4, i).Value & "','" & 1 & "','" & dgv1.Item(16, i).Value & "','" & dgv1.Item(17, i).Value & "','" & dgv1.Item(20, i).Value & "' ,'" & dgv1.Item(10, i).Value & "','" & dgv1.Item(8, i).Value & "','" & dgv1.Item(22, i).Value & "')"
                    cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                    cl.orcmd.ExecuteNonQuery()

                    ''''''' INSERTING LOTNO IN FIFO TABLE

                    'If cmbtype.Text = "PO" Then

                    '    If txtrole.Text = "U7_ADD" Or txtrole.Text = "UNIT7" Or txtrole.Text = "U7" Then

                    '        sql = "select count(*) from JAN_FIFO_LOTNO_dETAILS where ref_id=" & txtgno.Text & " and item_no='" & dgv1.Item(2, i).Value & "'"
                    '        cl.oradap= New OracleClient.OracleDataAdapter(sql,cl.oracon)
                    '        ds = New DataSet
                    '        cl.oradap.Fill(ds, "resultab")

                    '        If ds.Tables("resultab").Rows(0).Item(0) = 0 Then
                    '            sql = "INSERT INTO JAN_FIFO_LOTNO_dETAILS (ORGANIZATION_ID,INVENTORY_ITEM_ID,ITEM_NO,REF_ID,REF_SOURCE,LOT_NO,CREATION_DATE) VALUES (JAN_ORGID('" & dgv1.Item(4, i).Value & "') , JAN_ITEMNO('" & dgv1.Item(2, i).Value & "'),'" & dgv1.Item(2, i).Value & "', " & txtgno.Text & ", 'Po','" & dgv1.Item(31, i).Value & "',sysdate)"

                    '        End If
                    '    End If
                    'End If

                End If
                A = True
            Next
            If A = True Then
                If cmbtype.Text = "PO" Then

                    If txtrole.Text = "U7_ADD" Or txtrole.Text = "UNIT7" Or txtrole.Text = "U7" Then
                        '  head = 2019753509
                        sql = "select count(*) from jan_gate_del where gatE_no=" & head & ""
                        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
                        ds = New DataSet()
                        cl.oradap.Fill(ds, "cnt")
                        If ds.Tables("cnt").Rows(0).Item(0) > 0 Then

                            sql = "delete from  jan_fifo_lotno_details where ref_id=" & head & ""
                            cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                            cl.orcmd.ExecuteNonQuery()

                            sql = "select count(*) from jan_fifo_lotno_details where ref_id=" & head & ""
                            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
                            ds = New DataSet()
                            cl.oradap.Fill(ds, "fcnt")
                            If ds.Tables("fcnt").Rows(0).Item(0) = 0 Then
                                sql = "insert into jan_fifo_lotno_details select org_id,item_id,item,gh.gate_no,'Po',nvl(LOT_NO,gl.item||'_'||to_char(gh.gdate,'iyyyiwdhhmi')),sum(supdcqty),'',sysdate, '' from jan_gate_lines gl,jan_gate_header gh where gl.gate_no=gh.gate_no and gh.gate_no=" & head & "group by org_id,item_id,item,gh.gate_no, nvl(LOT_NO,gl.item||'_'||to_char(gh.gdate,'iyyyiwdhhmi')) "

                                '''''sql = "update jan_fifo_lotno_Details a set lot_Qty=(select sum(supdcqty) from jan_gatE_lines where gate_no=" & head & " and item =a.item_no) where ref_id=" & head & " "

                                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                                cl.orcmd.ExecuteNonQuery()
                            End If

                        Else
                            sql = "select count(*) from jan_fifo_lotno_details where ref_id=" & head & ""
                            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
                            ds = New DataSet()
                            cl.oradap.Fill(ds, "fcnt")
                            If ds.Tables("fcnt").Rows(0).Item(0) = 0 Then
                                sql = "insert into jan_fifo_lotno_details select org_id,item_id,item,gh.gate_no,'Po',nvl(LOT_NO,gl.item||'_'||to_char(gh.gdate,'iyyyiwdhhmi')),sum(supdcqty),'',sysdate, '' from jan_gate_lines gl,jan_gate_header gh where gl.gate_no=gh.gate_no and gh.gate_no=" & head & "group by org_id,item_id,item,gh.gate_no, nvl(LOT_NO,gl.item||'_'||to_char(gh.gdate,'iyyyiwdhhmi')) "

                                '''''sql = "update jan_fifo_lotno_Details a set lot_Qty=(select sum(supdcqty) from jan_gatE_lines where gate_no=" & head & " and item =a.item_no) where ref_id=" & head & " "

                                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                                cl.orcmd.ExecuteNonQuery()
                            End If
                        End If
                    End If
                End If

                MessageBox.Show("Saved Successfully !!-Gate Number is: " & head & "", "Gate Entry")

                'sql = "update JAN_GATE_HEADER set unit='UNIT7' WHERE GATE_NO LIKE '201517%'"
                'cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
                'cl.orcmd.ExecuteNonQuery()

                'sql = "update JAN_GATE_NVAL_REASON set unit='UNIT7' WHERE GATE_NO LIKE '201517%'"
                'cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
                'cl.orcmd.ExecuteNonQuery()


                sql = "UPDATE JAN_GATE_HEADER SET ORG='" & dgv1.Item(4, 0).Value & "' WHERE GATE_NO=" & head & ""
                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                clear()

                Try
EXEC_SCM:
                    sql = "update jan_gate_header set gate_no='" & head & "' where asn_no='" & TXT_ASN_NO.Text & "'"
                    If scmcon2.State = ConnectionState.Closed Then scmcon2.Open()
                    Dim cmdsql As New SqlClient.SqlCommand(sql, scmcon2) '
                    cmdsql.ExecuteNonQuery()
                    sql = "update jan_gate_lines set gate_no='" & head & "' where asn_no='" & TXT_ASN_NO.Text & "'"
                    cmdsql.ExecuteNonQuery()
                    If scmcon2.State = ConnectionState.Open Then scmcon2.Close()
                Catch ex As Exception
                    GoTo EXEC_SCM
                End Try



            End If
            If B = True Then
                MessageBox.Show("Enter Dcno,DCqty,Remark To Save Gate Values", "Gate Entry")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            cl.oracon.Close()
        End Try
        'Dim add_frm As New adi
        'add_frm.Show()
        Me.Close()
        'End
    End Sub

    Private Sub cmbtype_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbtype.SelectedIndexChanged
        txttype.Text = cmbtype.SelectedItem
        txttype.Visible = True
        cmbtype.Visible = False
    End Sub
    Public Sub clear()
        cmbsup.SelectedIndex = -1
        cmbpo.SelectedIndex = -1
        cmbitem.SelectedIndex = -1
        cmbtype.SelectedIndex = -1
        txtsite.Text = ""
        txtdcno.Text = ""
        TextBox1.Text = ""
        TextBox1.Visible = False
        cmbsup.Visible = True
        txttype.Text = ""
        txttype.Visible = False
        cmbtype.Visible = True
        Label11.Text = ""
        txtgno.Text = ""
        bind()
    End Sub

    Public Sub bind()
        dt = New DataTable("gate")
        Dim pon As DataColumn = New DataColumn("PoNo")
        dt.Columns.Add("PoNo")
        For i = 0 To 200
            dr = dt.NewRow
            dr.Item("PoNo") = ""
            dt.Rows.Add(dr)
        Next
        dsad.Tables.Clear()
        dsad.Tables.Add(dt)
        dgv1.DataSource = dsad.Tables("gate")
    End Sub

    Private Sub BUT_DWNLD_ASN_Click(sender As Object, e As EventArgs) Handles BUT_DWNLD_ASN.Click
        LLID = 0
        For i = 0 To dgv1.RowCount - 1
            If dgv1.Rows(i).Cells(20).Value = TXT_ASN_NO.Text Then
                MsgBox("This A D I No Already Exists !..,")
                Exit Sub
            End If
        Next

        sql = "select JH.*,JL.*,JH.DEL_ASN DELASN from jan_gate_header jh,jan_gate_lines jl where jh.ASN_NO=JL.ASN_NO  AND JH.ASN_NO=" & TXT_ASN_NO.Text
        'Dim cl.orcmds As New OleDb.OleDbCommand(sql, SCMCON)
        ' Dim ADAPs As New OleDb.OleDbDataAdapter(cl.orcmds)
        Dim cmdsql As New SqlClient.SqlCommand(sql, scmcon2)
        Dim adapsql As New SqlClient.SqlDataAdapter(cmdsql)
        If MDS.Tables.Contains("asn_det") = True Then
            MDS.Tables.Remove("asn_det")
        End If
        'ADAPs.Fill(ds, "asn_det")
        adapsql.Fill(MDS, "asn_det")
        asn_grid.DataSource = MDS.Tables("asn_det").DefaultView
        If MDS.Tables("ASN_dET").Rows.Count = 0 Then
            MsgBox("ADI Not Available!..,")
            Exit Sub
        End If

        If MDS.Tables("asn_det").Rows(0).Item("DELASN") = 1 Then
            MsgBox("ADI Entry Deleted by Supplier/Vendor !..,")
            Exit Sub
        End If

        'If IsDBNull(MDS.Tables("asn_det").Rows(0).Item("wop_flag")) Then
        '    MDS.Tables("asn_det").Rows(0).Item("wop_flag") = "N"
        'End If
        'If (MDS.Tables("asn_det").Rows(0).Item("wop_flag").ToString) = "Y" Then
        '    For ASNCNT = 0 To MDS.Tables("asn_det").Rows.Count - 1
        '        With MDS.Tables("asn_det").Rows(ASNCNT)
        '            sql = "select price from jan_po_pending_OSP where vendor_id = " & .Item("SUPPLIER_ID") & " and pono='" & .Item("PONO").ToString & "' and price=0"

        '            ' and po_line_id=" & .Item("POLINE").ToString & " and line_location_id=" & .Item("LOCATION_ID")
        '            If ret_val(sql) <> "0" Then
        '                MsgBox("Without Process ADI !.." & vbNewLine & vbNewLine & vbNewLine & "PO : [ " & .Item("PONO").ToString & " ] Price Must be Zero !.." & vbNewLine & vbNewLine)
        '                btnsave.Visible = False
        '                Exit Sub
        '            End If
        '        End With
        '    Next
        'End If
        Dim dsID1 As New DataSet
        Dim DCNT As Integer = 0
        Dim VID As Integer
        Dim NBDCNT As Integer = 0
        Dim NBDTOT As Integer = 0

        'For ASNCNT = 0 To MDS.Tables("asn_det").Rows.Count - 1

        '    With MDS.Tables("asn_det").Rows(ASNCNT)
        '        VID = .Item("SUPPLIER_ID")

        '        ' sql = " SELECT COUNT(*) CNT  FROM PO_LINE_LOCATIONS_ALL WHERE PO_LINE_ID=" & .Item("POLINE") & "  AND LINE_LOCATION_ID=" & .Item("LOCATION_ID") & " AND INSPECTION_REQUIRED_FLAG='N'"

        '        '  sql = "SELECT  COUNT(*)CNT FROM JAN_SOURCING_RULE_BACKUP WHERE SOURCING_PERCENT>0 AND PROCESS_TYPE='PO' AND ITEM_NO='" & .Item("ITEM") & "' AND VENDOR_ID=" & VID & " AND ORG_ID=" & .Item("ORG") & " AND SPOT_INSPECTION=1"

        '        sql = " select COUNT(*) CNT  from PO_LINE_LOCATIONS_ALL a ,PO_LINES_ALL B,JAN_SOURCING_RULE_BACKUP C  where a.PO_LINE_ID=" & .Item("POLINE") & "  and a.LINE_LOCATION_ID=" & .Item("LOCATION_ID") & " and a.INSPECTION_REQUIRED_FLAG='N' and PROCESS_TYPE='PO' and SOURCING_PERCENT>0 and NVL(SPOT_INSPECTION,0)=1 AND C.VENDOR_ID=" & VID & "  AND B.ITEM_ID=C.INVENTORY_ITEM_ID AND A.SHIP_TO_ORGANIZATION_ID=C.ORG_ID AND A.PO_LINE_ID=B.PO_LINE_ID"
        '        dsID1 = New DataSet
        '        cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
        '        cl.oradap= New OracleClient.OracleDataAdapter(cl.orcmd)
        '        cl.oradap.Fill(dsID1, "insp")
        '        If dsID1.Tables("INSP").Rows(0).Item(0) = 1 Then DCNT = DCNT + 1

        '    End With

        'Next
        DCNT = 0

        'For ASNCNT = 0 To MDS.Tables("asn_det").Rows.Count - 1

        '    With MDS.Tables("asn_det").Rows(ASNCNT)
        '        If .Item("GTYPE") = "PO" Then
        '            sql = "SELECT COUNT(*) FROM jan_po_pending A WHERE   a.PO_LINE_ID=" & .Item("POLINE") & "  and a.LINE_LOCATION_ID=" & .Item("LOCATION_ID") & ""
        '        Else
        '            sql = "SELECT COUNT(*) FROM jan_osp_pending_backup A WHERE    a.PO_LINE_ID=" & .Item("POLINE") & "   "
        '        End If

        '        Dim dsNBD1 As New DataSet
        '        cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
        '        cl.oradap= New OracleClient.OracleDataAdapter(cl.orcmd)
        '        cl.oradap.Fill(dsNBD1, "VCNT1")

        '        If dsNBD1.Tables("VCNT1").Rows(0).Item(0) = 0 Then
        '            MessageBox.Show("po pending not avail")

        '            Exit Sub
        '        End If
        '    End With
        'Next

        Dim ip As String


        sql = "select sys_context ('USERENV', 'IP_ADDRESS')ip ,(SELECT COUNT(*) FROM PO_VENDORS WHERE VENDOR_ID=" & MDS.Tables("asn_det").Rows(0).Item("supplier_id") & " AND INVOICE_CURRENCY_CODE<>'INR') from dual"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        Dim ds2 As New DataSet
        cl.oradap.Fill(ds2, "resultab")

        ip = ds2.Tables("RESULTAB").Rows(0).Item(0)

        'If ip = "192.168.71.42" Or ip = "192.168.71.38" And ds2.Tables("resultab").Rows(0).Item(1) > 0 Or MDS.Tables("asn_det").Rows(0).Item("supplier_id") = 825328 Then

        '    GoTo FDATA

        'Else

        '    For ASNCNT = 0 To MDS.Tables("asn_det").Rows.Count - 1

        '        With MDS.Tables("asn_det").Rows(ASNCNT)

        '            If .Item("ORG") = 444 Or .Item("ORG") = 464 Or .Item("ORG") = 484 Or .Item("ORG") = 504 Or .Item("ORG") = 524 Then


        '                If .Item("GTYPE") = "PO" And ds2.Tables("resultab").Rows(0).Item(1) > 0 Then
        '                    sql = " SELECT  COUNT(*),(SELECT COUNt(*) FROM jan_blanket_po_inward WHERE LINE_LOCATION_ID=" & .Item("LOCATION_ID") & " AND  PO_LINE_ID=" & .Item("POLINE") & " )APP_VAL  FROM jan_po_pending A WHERE    a.PO_LINE_ID=" & .Item("POLINE") & "  and a.LINE_LOCATION_ID=" & .Item("LOCATION_ID") & " AND TRUNC(NEED_BY_DATE) > TRUNC(SYSDATE+30) GROUP BY LINE_LOCATION_ID,PO_LINE_ID"

        '                Else
        '                    sql = " SELECT  COUNT(*)CNT ,(SELECT COUNt(*) FROM jan_blanket_po_inward WHERE   LINE_LOCATION_ID=" & .Item("LOCATION_ID") & " ) CNT1 FROM jan_po_pending A WHERE  cfd_open is null and   a.PO_LINE_ID=" & .Item("POLINE") & "  and a.LINE_LOCATION_ID=" & .Item("LOCATION_ID") & " AND TRUNC(NEED_BY_DATE) > TRUNC(SYSDATE+7) and BLANKET_RELEASE_NUM IS NOT NULL GROUP BY LINE_LOCATION_ID,PO_LINE_ID"
        '                End If

        '                Dim dsNBD As New DataSet
        '                cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
        '                cl.oradap= New OracleClient.OracleDataAdapter(cl.orcmd)
        '                cl.oradap.Fill(dsNBD, "VCNT")

        '                If dsNBD.Tables("vcnt").Rows.Count > 0 Then

        '                    If dsNBD.Tables("VCNT").Rows(0).Item(0) > 0 And dsNBD.Tables("VCNT").Rows(0).Item(1) = 0 Then
        '                        NBDCNT = NBDCNT + 1

        '                    ElseIf dsNBD.Tables("VCNT").Rows(0).Item(0) > 0 And dsNBD.Tables("VCNT").Rows(0).Item(1) > 0 Then
        '                        DCNT = DCNT + 1

        '                    End If

        '                End If

        '            End If

        '        End With
        '    Next

        '    'If DCNT > 0 And NBDCNT = 0 Then
        '    '    MessageBox.Show("ADI has direct delivery items ,Amend the po and proceed")
        '    '    Exit Sub
        '    If NBDCNT > 0 And ds2.Tables("resultab").Rows(0).Item(1) > 0 Then
        '        MessageBox.Show("ADI has items with need by date more than 1 month, Gate entry Can't be made get approval for inwarding the items")
        '        Exit Sub

        '    ElseIf DCNT = 0 And NBDCNT > 0 And ds2.Tables("resultab").Rows(0).Item(1) = 0 Then

        '        MessageBox.Show("Blanket schedule is more than 7 days, Gate entry Can't be made get approval for inwarding the items")
        '        Exit Sub

        '    ElseIf DCNT > 0 Then
        '        GoTo FDATA
        '    Else
        '        GoTo FDATA
        '    End If

        'End If



        '''' BLANKET PO MORE THAN 7 DAYS
        'NBDCNT = 0

        'If ip = "192.168.71.42" Or ip = "192.168.71.39" Or ip = "192.168.71.38" Then
        '    GoTo FDATA
        'Else

        '    For ASNCNT = 0 To MDS.Tables("asn_det").Rows.Count - 1

        '        With MDS.Tables("asn_det").Rows(ASNCNT)
        '            VID = .Item("SUPPLIER_ID")

        '            If .Item("ORG") = 444 Or .Item("ORG") = 464 Or .Item("ORG") = 484 Or .Item("ORG") = 504 Or .Item("ORG") = 524 Then


        '                If .Item("GTYPE") = "PO" Then

        '                    sql = " SELECT  COUNT(*)CNT ,(SELECT COUNt(*) FROM jan_blanket_po_inward WHERE   POLINE=" & .Item("POLINE") & " ) CNT1 FROM jan_po_pending A WHERE    a.PO_LINE_ID=" & .Item("POLINE") & "  and a.LINE_LOCATION_ID=" & .Item("LOCATION_ID") & " AND TRUNC(NEED_BY_DATE) > TRUNC(SYSDATE+7) and BLANKET_RELEASE_NUM IS NOT NULL GROUP BY LINE_LOCATION_ID,PO_LINE_ID"

        '                    'Else
        '                    '    '  sql = " SELECT  COUNT(*),(SELECT COUNt(*) FROM JAN_RM_IMP_RECEIPT_APPROVAL WHERE   PO_LINE_ID=" & .Item("POLINE") & " )APP_VAL  FROM JAN_OSP_PENDING_BACKUP A WHERE  ship_to_organization_id in (104,106,107,108,109,444,484,504,464) and  a.PO_LINE_ID=" & .Item("POLINE") & "  AND TRUNC(NEED_BY_DATE) < TRUNC(SYSDATE+30) GROUP BY PO_LINE_ID"



        '                    Dim dsNBD As New DataSet
        '                    cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
        '                    cl.oradap= New OracleClient.OracleDataAdapter(cl.orcmd)
        '                    cl.oradap.Fill(dsNBD, "VCNT")

        '                    If dsNBD.Tables("vcnt").Rows.Count > 0 Then



        '                        If dsNBD.Tables("VCNT").Rows(0).Item(0) > 0 And dsNBD.Tables("VCNT").Rows(0).Item(1) = 0 Then
        '                            NBDCNT = NBDCNT + 1

        '                        ElseIf dsNBD.Tables("VCNT").Rows("ASNCNT").Item(0) > 0 And dsNBD.Tables("VCNT").Rows("ASNCNT").Item(1) > 0 Then
        '                            DCNT = DCNT + 1

        '                        End If
        '                    End If
        '                End If

        '            End If

        '        End With
        '    Next

        '    'If DCNT > 0 And NBDCNT = 0 Then
        '    '    MessageBox.Show("ADI has direct delivery items ,Amend the po and proceed")
        '    '    Exit Sub
        '    If DCNT = 0 And NBDCNT > 0 Then
        '        MessageBox.Show("Blanket schedule is more than 7 days, Gate entry Can't be made get approval for inwarding the items")
        '        Exit Sub
        '    ElseIf DCNT > 0 Then
        '        GoTo FDATA
        '    Else
        '        GoTo FDATA
        '    End If

        'End If






FDATA:
        For ASNCNT = 0 To MDS.Tables("asn_det").Rows.Count - 1

            With MDS.Tables("asn_det").Rows(ASNCNT)
                'f = 12
                SID = .Item("SUPPLIER_ID")
                f = .Item("PONO").ToString
                r = .Item("POLINE").ToString

                Dim ORG As Integer

                ORG = .Item("ORG").ToString

                LLID = .Item("LOCATION_ID")
                cmbpo.Text = f & "|----|" & r
                cmbitem.Text = .Item("item") & "|----|" & .Item("description")
                cmbitem.Select()
                txttype.Text = .Item("GTYPE")
                cmbtype.Text = .Item("GTYPE")
                If IsDBNull(.Item("spot_inspection")) Then
                    .Item("spot_inspection") = 0
                End If
                If IsDBNull(.Item("self_certified")) Then
                    .Item("self_certified") = 0
                End If
                spot_inspection_s = .Item("spot_inspection")
                self_certified_s = .Item("self_certified")
                lotno = .Item("lot_number").ToString

                'Txt_inv_val.Text = MDS.Tables("asn_det").Compute("sum(total_amt)", "total_amt is not null")
                Txt_inv_val.Text = 0
                For i = 0 To MDS.Tables("asn_det").Rows.Count - 1
                    If Not IsDBNull(MDS.Tables("asn_det").Rows(i).Item("total_amt")) Then
                        Txt_inv_val.Text = Format(CDbl(Txt_inv_val.Text) + CDbl(MDS.Tables("asn_det").Rows(i).Item("total_amt")), "0.00")
                    End If
                Next

                If txtdcno.Text = "" Then
                    txtdcno.Text = .Item("DC_NO").ToString
                Else
                    If txtdcno.Text <> .Item("DC_NO") Then
                        MsgBox("Different Supplier DC Nos Occured !..," & vbNewLine & vbNewLine & "Rule : One Supplier DC No = One ASN No")
                        Exit Sub
                    End If
                End If
                cmbsup.Text = .Item("supplier_name").ToString
                dtdc.Text = .Item("DC_DATE").ToString
                cmbitem.Items.Clear()





                If ORG = 444 Or ORG = 464 Or ORG = 484 Or ORG = 504 Or ORG = 505 Or ORG = 384 Or ORG = 524 Or ORG = 664 Then
                    txtrole.Text = "UNIT7"
                End If
                If ORG = 144 Then txtrole.Text = "UNIT4"

                If ORG = 224 Or ORG = 225 Then txtrole.Text = "SKYFAST"

                If ORG = 604 Or ORG = 624 Then txtrole.Text = "JAPL"


                If txtrole.Text = "UNIT2" Then
                    txtgno.ReadOnly = True
                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                    sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='UNIT2'"
                    cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)
                    cl.oradap = New OracleClient.OracleDataAdapter(cl.orcmd)
                    Dim dsID As New DataSet
                    cl.oradap.Fill(dsID, "GATE_NO")
                    If txtrole.Text = "UNIT2" Then
                        If dsID.Tables("GATE_NO").Rows(0).Item("GATE_NO") <> 0 Then
                            txtgno.Text = dsID.Tables("GATE_NO").Rows(0).Item("GATE_NO") + 1
                        Else
                            txtgno.Text = 700100001
                        End If
                    End If
                Else
                    txtgno.Visible = True
                    Label9.Visible = True
                End If



                'If txtrole.Text = "UNIT7" Then

                '    txtgno.ReadOnly = True
                '    If con1.State = ConnectionState.Closed Then con1.Open()
                '    sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='UNIT7'"
                '    cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
                '    cl.oradap= New OracleClient.OracleDataAdapter(cl.orcmd)
                '    Dim dsID As New DataSet
                '    cl.oradap.Fill(dsID, "GATE_NO")
                '    If txtrole.Text = "UNIT7" Then
                '        If dsID.Tables("GATE_NO").Rows(0).Item("GATE_NO") <> 0 Then
                '            txtgno.Text = dsID.Tables("GATE_NO").Rows(0).Item("GATE_NO") + 1
                '        Else
                '            txtgno.Text = 2015170000
                '        End If
                '    End If
                'Else
                '    txtgno.Visible = True
                '    Label9.Visible = True
                'End If



                cmbitem.Items.Add(.Item("item") & "|----|" & .Item("description"))
                SUPDCQTY = .Item("SUPDCQTY").ToString
                asndt = .Item("asn_date").ToString
                ASNTYPE = .Item("ADI_TYPE").ToString
                cmbitem.Select(0, 1)
                '.Item("item") & "|----|" & .Item("description")).
                sql = "SELECT pov.*, (SELECT VENDOR_SITE_CODE FROM PO_VENDOR_SITES_ALL WHERE VENDOR_ID=POv.VENDOR_ID and rownum=1) site FROM PO_VENDORS pov WHERE pov.VENDOR_ID=" & SID
                cl.orcmd = New OracleClient.OracleCommand(sql, cl.oracon)

                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                drr = cl.orcmd.ExecuteReader
                If drr.HasRows = True Then
                    drr.Read()
                    SNAME = drr("VENDOR_NAME")
                    If IsDBNull(drr("site")) Then
                        txtsite.Text = "COIMBATORE"
                    Else
                        txtsite.Text = drr("site")
                    End If

                End If
                drr.Close()
                If cl.oracon.State = ConnectionState.Open Then cl.oracon.Close()
                cmbsup.Text = SNAME
                TextBox1.Text = SNAME


                Call DWNLD_ASN()



            End With

        Next

    End Sub

    Dim head As Double
    Dim dt2, dt1 As Date
    Dim dt As New DataTable
    Dim dr As DataRow

    Dim ASNCNT As Int32
    Dim SUPDCQTY As Double
    Dim e1 As String
    Dim f As String
    Dim r As String
    Dim spot_inspection_s, self_certified_s, lotno As String
    Private Sub DWNLD_ASN()

        'Dim e1 As String = cmbpo.SelectedItem
        'Dim f As String = e1.Substring(0, e1.IndexOf("|"))
        'Dim r As String = e1.Substring(15)
        Dim a1, b1, c1, d1 As Double

        ' F - PO_NO
        ' R - PO_LINE_ID
        ' cmbitem.SelectedItem - item_no || '|----|' || description
        ' txttype.Text = PO or OSP
        ' dgv1.Rows(i).Cells(8).Value = DC_QTY



        If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
            sql = "select nvl(sum(po_qty-recd),0) po from jan_po_pending_bought_outs where pono='" & f & "' and po_line_id='" & r & "' AND LINE_LOCATION_ID=" & LLID
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            a1 = ds.Tables("resultab").Rows(0).Item("po")

            sql = "select nvl(sum(supdcqty),0) po from jan_gate_lines  where pono='" & f & "'  and validated<>'4'  and flag<>0 and poline='" & r & "' AND LOCATION_ID=" & LLID
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            b1 = ds.Tables("resultab").Rows(0).Item("po")

            sql = "select nvl(sum(b.quantity_received),0) po from jan_gate_lines a,jan_pur_listing b where  a.item=b.item_no and a.gate_id=b.gate_no and b.pono ='" & f & "' and a.flag<>0 and a.poline=" & r & " AND LOCATION_ID=" & LLID
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            c1 = ds.Tables("resultab").Rows(0).Item("po")

        ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then

            sql = "select nvl(sum(po_qty-recd),0) po from jan_po_pending_osp where pono='" & f & "'   and po_line_id='" & r & "'"
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            a1 = ds.Tables("resultab").Rows(0).Item("po")

            sql = "select nvl(sum(supdcqty),0) po from jan_gate_lines  where pono='" & f & "'   and validated<>'4'  and flag<>0 and poline='" & r & "'"
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            b1 = ds.Tables("resultab").Rows(0).Item("po")

            sql = "select nvl(sum(b.quantity_received),0) po from jan_gate_lines a,jan_osp_listing b where  a.item=b.partno and a.gate_id=b.gate_no  and b.pono='" & f & "'  and a.flag<>0 and a.poline='" & r & "'"
            cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            c1 = ds.Tables("resultab").Rows(0).Item("po")
        End If

        'If a1 = (b1 - c1) Then
        '    d1 = a1
        '    sql = "update jan_gate_lines set supdcqty='" & c1 & "',actval='" & c1 & "' where pono='" & f & "' and (item || '|----|' || description)='" & cmbitem.SelectedItem & "' and flag<>0 and poline='" & r & "' "
        '    cl.orcmd = New OracleClient.OracleCommand(sql,cl.oracon)
        '    cl.orcmd.ExecuteNonQuery()
        'Else
        d1 = (a1) ' - (b1 - c1)) 3280
        ' End If

        ''''''''''''' for PO
        If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
            'sql = "select  a.po_line_id,a.po_header_id,a.line_location_id,a.po_qty,nvl(a.rev,'') rev, a.uom uom,'' osp_no,'' operations,'' job_no,(select organization_code from org_organization_definitions  where organization_id=a.ship_to_organization_id)org,a.price,A.DESCRIPTION,a.podt podt from jan_po_pending_bought_outs a where A.SUPPLIER='" & Trim(cmbsup.Text.Replace("(Purchase)", "")) & "' and (a.item_no || '|----|' || a.description)='" & cmbitem.Text.ToString.Replace("'", "''") & "' and a.pono='" & f & "' and a.po_line_id='" & r & "' "
            sql = "select  a.po_line_id,a.po_header_id,a.line_location_id,a.po_qty,nvl(a.rev,'') rev, a.uom uom,'' osp_no,'' operations,'' job_no,(select organization_code from org_organization_definitions  where organization_id=a.ship_to_organization_id)org,a.price,A.DESCRIPTION,a.podt podt,(SELECT CATEGORY FROM JAN_COUNTING_CATEGORY WHERE A.PRICE BETWEEN FROM_VALUE AND TO_VALUE AND ORGANIZATION_ID=A.SHIP_TO_ORGANIZATION_ID) CAT,DECODE(a.LINE_TYPE_ID,1021,'Services',a.LINE_TYPE)LINE_TYPE,0 wip_entity_id,0 opn_seq   from jan_po_pending_bought_outs a where  a.pono='" & f & "' and a.po_line_id='" & r & "' and LINE_LOCATION_ID=" & LLID
        End If

        '''''''''''' For OSP
        If cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
            sql = "select  b.po_line_id,b.po_header_id,b.line_location_id,b.po_qty,b.bom_revision, b.po_uom, b.osp_no,(select organization_code from org_organization_definitions  where organization_id=b.ship_to_organization_id)org ,b.price,B.PARTNAME,b.podt,b.operations, b.job_no,(SELECT CATEGORY  FROM(JAN_COUNTING_CATEGORY)  WHERE(organization_id = b.ship_to_organization_id) AND DECODE((SELECT ITEM_COST  FROM JAN_ITEMCOST B   WHERE(ITEM_NO = b.PARTNO) AND org_id = b.ship_to_organization_id  AND PO_LINE_ID=B.PO_LINE_ID),0,"
            sql &= "  (SELECT STAGE_COST FROM JAN_PO_PENDING_OSP C WHERE(PARTNO = b.PARTNO)AND ship_to_organization_id = b.ship_to_organization_id AND PO_LINE_ID=B.PO_LINE_ID), (SELECT ITEM_COST  FROM JAN_ITEMCOST B WHERE(ITEM_NO = b.PARTNO) AND org_id = b.ship_to_organization_id AND PO_LINE_ID=B.PO_LINE_ID)) BETWEEN from_value and to_value) CAT,DECODE(B.LINE_TYPE_ID,1021,'Services',B.LINE_TYPE)LINE_TYPE,wip_entity_id,opn_seq   from jan_po_pending_osp b  where b.VENDOR_ID=" & SID & " and B.pono='" & f & "'  and b.po_line_id='" & r & "'"
        End If



        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        If dsad.Tables().Contains("resultab") Then
            dsad.Tables("resultab").Rows.Clear()
        End If
        cl.oradap.Fill(dsad, "resultab")
        Dim lcnt, adcnt As Integer

        If dsad.Tables("resultab").Rows.Count > 0 Then
            Dim a, b, d As String
            a = cmbitem.Text
            b = a.Substring(0, a.IndexOf("|"))
            'c = cmbpo.SelectedItem
            'd = c.Substring(0, c.IndexOf("|"))
            d = f
            'i = dgv1.CurrentRow.Index
            i = ASNCNT

            adcnt = ASNCNT + 1

            If i = 0 Then
                If dgv1.Rows(i).Cells(0).Value = "" Or dgv1.Rows(i).Cells(1).Value = "" Or dgv1.Rows(i).Cells(2).Value = "" Then

                    dgv1.Rows(i).Cells(0).Value = d.ToString
                    dgv1.Rows(i).Cells(1).Value = Format(dsad.Tables("resultab").Rows(0).Item("podt"), "dd-MMM-yyyy")
                    dgv1.Rows(i).Cells(2).Value = b.ToString
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(3).Value = dsad.Tables("resultab").Rows(0).Item("description")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(3).Value = dsad.Tables("resultab").Rows(0).Item("partname")
                    End If
                    dgv1.Rows(i).Cells(4).Value = dsad.Tables("resultab").Rows(0).Item("org")
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(5).Value = dsad.Tables("resultab").Rows(0).Item("rev")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(5).Value = dsad.Tables("resultab").Rows(0).Item("bom_revision")
                    End If
                    If txttype.Text = "PO" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(6).Value = d1
                    End If
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(7).Value = dsad.Tables("resultab").Rows(0).Item("uom")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(7).Value = dsad.Tables("resultab").Rows(0).Item("po_uom")
                    End If
                    dgv1.Rows(i).Cells(10).Value = dsad.Tables("resultab").Rows(0).Item("po_qty")
                    dgv1.Rows(i).Cells(22).Value = dsad.Tables("resultab").Rows(0).Item("cat")
                    If txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(11).Value = dsad.Tables("resultab").Rows(0).Item("osp_no")
                    ElseIf txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(11).Value = dsad.Tables("resultab").Rows(0).Item("osp_no")
                        dgv1.Rows(i).Cells(12).Value = dsad.Tables("resultab").Rows(0).Item("operations")
                        dgv1.Rows(i).Cells(13).Value = dsad.Tables("resultab").Rows(0).Item("job_no")
                    End If
                    If cmbtype.SelectedItem = "PO" Or cmbtype.SelectedItem = "OSP" Then
                        dgv1.Rows(i).Cells(14).Value = cmbtype.SelectedItem
                    ElseIf txttype.Text = "PO" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(14).Value = txttype.Text
                    End If
                    dgv1.Rows(i).Cells(15).Value = dsad.Tables("resultab").Rows(0).Item("po_line_id")
                    dgv1.Rows(i).Cells(16).Value = dsad.Tables("resultab").Rows(0).Item("po_header_id")
                    dgv1.Rows(i).Cells(17).Value = "1"
                    dgv1.Rows(i).Cells(18).Value = dsad.Tables("resultab").Rows(0).Item("price")
                    dgv1.Rows(i).Cells(19).Value = dsad.Tables("resultab").Rows(0).Item("line_location_id")
                    dgv1.Rows(i).Cells(8).Value = SUPDCQTY.ToString
                    dgv1.Rows(i).Cells(20).Value = TXT_ASN_NO.Text
                    dgv1.Rows(i).Cells(21).Value = asndt
                    dgv1.Rows(i).Cells(23).Value = dsad.Tables("resultab").Rows(0).Item("line_type")

                    dgv1.Rows(i).Cells(25).Value = dsad.Tables("resultab").Rows(0).Item("wip_entity_id")
                    dgv1.Rows(i).Cells(26).Value = dsad.Tables("resultab").Rows(0).Item("opn_seq")
                    dgv1.Rows(i).Cells(27).Value = spot_inspection_s
                    dgv1.Rows(i).Cells(28).Value = self_certified_s
                    dgv1.Rows(i).Cells(29).Value = ASNTYPE

                    ''''' dgv1.Rows(i).Cells(30).Value = dsad.Tables("resultab").Rows(0).Item("weight_in_kg").ToString
                    dgv1.Rows(i).Cells(31).Value = lotno




                Else
                    MessageBox.Show("Select Next Row", "Gate Entry")
                End If
            Else

                If dgv1.Rows(i).Cells(0).Value = "" Then
                    dgv1.Rows(i).Cells(0).Value = d.ToString
                    dgv1.Rows(i).Cells(1).Value = Format(dsad.Tables("resultab").Rows(0).Item("podt"), "dd-MMM-yyyy")
                    dgv1.Rows(i).Cells(2).Value = b.ToString
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(3).Value = dsad.Tables("resultab").Rows(0).Item("description")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(3).Value = dsad.Tables("resultab").Rows(0).Item("partname")
                    End If
                    dgv1.Rows(i).Cells(4).Value = dsad.Tables("resultab").Rows(0).Item("org")
                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(5).Value = dsad.Tables("resultab").Rows(0).Item("rev")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(5).Value = dsad.Tables("resultab").Rows(0).Item("bom_revision")
                    End If
                    If txttype.Text = "PO" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(6).Value = d1.ToString
                    End If

                    If cmbtype.SelectedItem = "PO" Or txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(7).Value = dsad.Tables("resultab").Rows(0).Item("uom")
                    ElseIf cmbtype.SelectedItem = "OSP" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(7).Value = dsad.Tables("resultab").Rows(0).Item("po_uom")
                    End If
                    dgv1.Rows(i).Cells(10).Value = dsad.Tables("resultab").Rows(0).Item("po_qty")
                    dgv1.Rows(i).Cells(22).Value = dsad.Tables("resultab").Rows(0).Item("cat")
                    If txttype.Text = "PO" Then
                        dgv1.Rows(i).Cells(11).Value = dsad.Tables("resultab").Rows(0).Item("osp_no")
                    ElseIf txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(11).Value = dsad.Tables("resultab").Rows(0).Item("osp_no")
                        dgv1.Rows(i).Cells(12).Value = dsad.Tables("resultab").Rows(0).Item("operations")
                        dgv1.Rows(i).Cells(13).Value = dsad.Tables("resultab").Rows(0).Item("job_no")
                    End If
                    If cmbtype.SelectedItem = "PO" Or cmbtype.SelectedItem = "OSP" Then
                        dgv1.Rows(i).Cells(14).Value = cmbtype.SelectedItem
                    ElseIf txttype.Text = "PO" Or txttype.Text = "OSP" Then
                        dgv1.Rows(i).Cells(14).Value = txttype.Text
                    End If
                    dgv1.Rows(i).Cells(15).Value = dsad.Tables("resultab").Rows(0).Item("po_line_id")
                    dgv1.Rows(i).Cells(16).Value = dsad.Tables("resultab").Rows(0).Item("po_header_id")
                    dgv1.Rows(i).Cells(17).Value = "1"
                    dgv1.Rows(i).Cells(18).Value = dsad.Tables("resultab").Rows(0).Item("price")
                    dgv1.Rows(i).Cells(19).Value = dsad.Tables("resultab").Rows(0).Item("line_location_id").ToString
                    dgv1.Rows(i).Cells(8).Value = SUPDCQTY.ToString
                    dgv1.Rows(i).Cells(20).Value = TXT_ASN_NO.Text
                    dgv1.Rows(i).Cells(21).Value = asndt
                    dgv1.Rows(i).Cells(23).Value = dsad.Tables("resultab").Rows(0).Item("line_type")
                    dgv1.Rows(i).Cells(25).Value = dsad.Tables("resultab").Rows(0).Item("wip_entity_id")
                    dgv1.Rows(i).Cells(26).Value = dsad.Tables("resultab").Rows(0).Item("opn_seq")
                    dgv1.Rows(i).Cells(27).Value = spot_inspection_s
                    dgv1.Rows(i).Cells(28).Value = self_certified_s
                    dgv1.Rows(i).Cells(31).Value = lotno
                Else
                    MessageBox.Show("Select Next Row", "Gate Entry")
                End If
            End If
        Else
            If ASNCNT = 0 Then adcnt = 1

            MessageBox.Show("Line no : " & adcnt & " in ADI is not in Pending purchase order")
            Exit Sub
        End If
    End Sub

    Private Sub adi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sql = "SELECT COUNT(*)CNT,TO_CHAR(JAN_FYR_DATE,'yyyy')"

        If Command.ToString = "1" Then sql &= " ||1 "

        If Command.ToString = "7" Then sql &= " ||7 "

        If Command.ToString = "4" Then sql &= " ||4 "

        If Command.ToString = "5" Then sql &= " ||8 "

        If Command.ToString = "6" Then sql &= "|| 1"



        sql &= " YR FROM DUAL WHERE SYSDATE  BETWEEN JAN_FYR_DATE AND JAN_FYR_END_DATE"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "DT")

        If ds1.Tables("DT").Rows(0).Item(0) = 1 Then
            txtgno.Text = ds1.Tables("DT").Rows(0).Item(1)
        End If
        ' End If

        Try
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        sql = "select * from jan_gate_courier"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "cr")
        For i = 0 To ds.Tables("cr").Rows.Count - 1
            cmbcr.Items.Add(ds.Tables("cr").Rows(i).Item("courier_name"))
        Next
        sql = "select vendor_name from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' order by vendor_name asc"
        cl.oradap = New OracleClient.OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbsup.Items.Add(ds.Tables("resultab").Rows(i).Item("vendor_name").ToString.Replace("'", "''"))
        Next
        Me.StartPosition = FormStartPosition.CenterParent
        Me.BringToFront()
        bind()
        'dgv1.Columns(24).Visible = True
        If txtgno.Text <> "" Then
            '   btnmod_Click(sender, e)
        End If
        Try
            ' TXT_ASN_NO.Text = Command.ToString
            If TXT_ASN_NO.Text <> "" Then
                Call BUT_DWNLD_ASN_Click(sender, e)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        If txtrole.Text = "UNIT7" Or txtrole.Text = "U7_ADD" Then
            chkoadi.Visible = True
            Label20.Visible = True : Label21.Visible = True : Label22.Visible = True : Label23.Visible = True : Label24.Visible = True : cmbcr.Visible = True : txtpod.Visible = True : txtpodwt.Visible = True : txtbox.Visible = True : txtrwt.Visible = True

        Else
            chkoadi.Visible = True : Label20.Visible = False : Label21.Visible = False
            Label22.Visible = False : Label23.Visible = False : Label24.Visible = False : cmbcr.Visible = False : txtpod.Visible = False : txtpodwt.Visible = False : txtbox.Visible = False : txtrwt.Visible = False

        End If

    End Sub
End Class