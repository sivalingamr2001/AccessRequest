<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class suplist
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnsave = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtitem = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.cmbsup = New System.Windows.Forms.ComboBox
        Me.btncan = New System.Windows.Forms.Button
        Me.dt = New System.Windows.Forms.DateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.dt1 = New System.Windows.Forms.DateTimePicker
        Me.sealed = New System.Windows.Forms.CheckBox
        Me.rdurg = New System.Windows.Forms.RadioButton
        Me.rdadi = New System.Windows.Forms.RadioButton
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtname = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'btnsave
        '
        Me.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsave.Location = New System.Drawing.Point(117, 148)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(57, 23)
        Me.btnsave.TabIndex = 4
        Me.btnsave.Text = "Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Supplier Name"
        '
        'txtitem
        '
        Me.txtitem.Location = New System.Drawing.Point(91, 71)
        Me.txtitem.Name = "txtitem"
        Me.txtitem.Size = New System.Drawing.Size(129, 20)
        Me.txtitem.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(15, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Part No"
        '
        'cmbsup
        '
        Me.cmbsup.FormattingEnabled = True
        Me.cmbsup.Location = New System.Drawing.Point(91, 42)
        Me.cmbsup.Name = "cmbsup"
        Me.cmbsup.Size = New System.Drawing.Size(265, 21)
        Me.cmbsup.TabIndex = 1
        '
        'btncan
        '
        Me.btncan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncan.Location = New System.Drawing.Point(180, 148)
        Me.btncan.Name = "btncan"
        Me.btncan.Size = New System.Drawing.Size(57, 23)
        Me.btncan.TabIndex = 0
        Me.btncan.Text = "Delete"
        Me.btncan.UseVisualStyleBackColor = True
        '
        'dt
        '
        Me.dt.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dt.Location = New System.Drawing.Point(91, 122)
        Me.dt.Name = "dt"
        Me.dt.Size = New System.Drawing.Size(94, 20)
        Me.dt.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Date"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(191, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Date"
        '
        'dt1
        '
        Me.dt1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dt1.Location = New System.Drawing.Point(227, 122)
        Me.dt1.Name = "dt1"
        Me.dt1.Size = New System.Drawing.Size(94, 20)
        Me.dt1.TabIndex = 3
        '
        'sealed
        '
        Me.sealed.AutoSize = True
        Me.sealed.Location = New System.Drawing.Point(227, 73)
        Me.sealed.Name = "sealed"
        Me.sealed.Size = New System.Drawing.Size(100, 17)
        Me.sealed.TabIndex = 5
        Me.sealed.Text = "Sealed Supplier"
        Me.sealed.UseVisualStyleBackColor = True
        '
        'rdurg
        '
        Me.rdurg.AutoSize = True
        Me.rdurg.Checked = True
        Me.rdurg.Location = New System.Drawing.Point(12, 12)
        Me.rdurg.Name = "rdurg"
        Me.rdurg.Size = New System.Drawing.Size(79, 17)
        Me.rdurg.TabIndex = 6
        Me.rdurg.TabStop = True
        Me.rdurg.Text = "Urgent  List"
        Me.rdurg.UseVisualStyleBackColor = True
        '
        'rdadi
        '
        Me.rdadi.AutoSize = True
        Me.rdadi.Location = New System.Drawing.Point(95, 12)
        Me.rdadi.Name = "rdadi"
        Me.rdadi.Size = New System.Drawing.Size(43, 17)
        Me.rdadi.TabIndex = 6
        Me.rdadi.Text = "ADI"
        Me.rdadi.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(15, 101)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Follower Name"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(91, 97)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(130, 20)
        Me.txtname.TabIndex = 2
        '
        'suplist
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(364, 186)
        Me.Controls.Add(Me.rdadi)
        Me.Controls.Add(Me.rdurg)
        Me.Controls.Add(Me.sealed)
        Me.Controls.Add(Me.dt1)
        Me.Controls.Add(Me.dt)
        Me.Controls.Add(Me.cmbsup)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.txtitem)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btncan)
        Me.Controls.Add(Me.btnsave)
        Me.Name = "suplist"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gate Register-Supplier List"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtitem As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbsup As System.Windows.Forms.ComboBox
    Friend WithEvents btncan As System.Windows.Forms.Button
    Friend WithEvents dt As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dt1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents sealed As System.Windows.Forms.CheckBox
    Friend WithEvents rdurg As System.Windows.Forms.RadioButton
    Friend WithEvents rdadi As System.Windows.Forms.RadioButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtname As System.Windows.Forms.TextBox
End Class
