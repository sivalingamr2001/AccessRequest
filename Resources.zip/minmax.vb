Imports System.Data.OracleClient
Imports System.IO
Imports oracleclass
Public Class minmax

    Dim cl As New oracleclass.Class1
    Dim adap, ada1 As OracleDataAdapter
    Dim ds, ds1, ds2 As New DataSet
    Dim i, j As Integer
    Dim sql, s As String
    Dim WithEvents DoIt As New DoStuffClass
    Dim cc As New DataGridViewTextBoxColumn
    Dim a, a1, b, c, d, b1, cs, d1, f1, f, ee, e1, g, g1, h, h1 As Double

    Private Sub minmax_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If cl.oracon.State = ConnectionState.Closed Then
            cl.oracon.Open()
        End If
        sql = "select secondary_inventory_name from jan_subinventories "
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbinv.Items.Add(ds.Tables("resultab").Rows(i).Item("secondary_inventory_name"))
        Next
        sql = "select organization_code  from org_organization_definitions where organization_code  not in('I08','I09')order by organization_code"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
            cmborg1.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
        sql = "select distinct item_type from jan_minmax_planning"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbitem.Items.Add(ds.Tables("resultab").Rows(i).Item("item_type"))
        Next
        sql = "select distinct make_buy from jan_minmax_planning"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbtyp.Items.Add(ds.Tables("resultab").Rows(i).Item("make_buy"))
        Next
        sql = "select distinct fc_code from jan_monthly_forecast"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbfc.Items.Add(ds.Tables("resultab").Rows(i).Item("fc_code"))
        Next
    End Sub

    Private Sub UpdateProgressBar(ByVal MyCountInteger As Integer) Handles DoIt.OnProgress
        ProgressBar1.Value = MyCountInteger
    End Sub

    Private Sub UpdateProgressBar1(ByVal MyCountInteger As Integer) Handles DoIt.OnProgress
        ProgressBar2.Value = MyCountInteger
    End Sub

    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Try
            dgmm.Columns.Clear()
            ProgressBar1.Visible = True
            DoIt.StartValue = 0
            Me.Cursor = Cursors.WaitCursor
            ds.Clear()
            ds.Dispose()
            ds1.Clear()
            ds1.Dispose()
            lblmincst.Text = ""
            lblmaxcst.Text = ""
            lblord.Text = ""
            lblmin.Text = ""


            sql = "select inventory, (select organization_code  from org_organization_definitions where organization_id=a.organization_id)org ,item_no,description,min_minmax_quantity minqty,nvl((min_minmax_quantity*item_cost),0) mincost,max_minmax_quantity maxqty,nvl((max_minmax_quantity*item_cost),0)maxcost,minimum_order_quantity minordqty,maximum_order_quantity maxordqty,round(nvl(on_hand,0),2)on_hand,"

            sql &= "round(nvl(decode(conversion_Rate,null,(1*po_pend),(po_pend* conversion_rate)),0)+nvl(wip_qty,0)+nvl(decode(conversion_Rate,null,(1*qty_inspn),(qty_inspn* conversion_rate)),0)+nvl(decode(conversion_Rate,null,(1*store_pend),(store_pend* conversion_rate)),0),2)InspPend,"

            sql &= "round(min_minmax_quantity -(nvl(on_hand,0)+nvl(decode(conversion_Rate,null,(1*po_pend),(po_pend* conversion_rate)),0)+nvl(wip_qty,0)+nvl(decode(conversion_Rate,null,(1*qty_inspn),(qty_inspn* conversion_rate)),0)+nvl(decode(conversion_Rate,null,(1*store_pend),(store_pend* conversion_rate)),0)),2)shortage,"

            sql &= "nvl(decode(sign(min_minmax_quantity -(nvl(on_hand,0)+nvl(decode(conversion_Rate,null,(1*po_pend),(po_pend* conversion_rate)),0)+nvl(wip_qty,0)+nvl(decode(conversion_Rate,null,(1*qty_inspn),(qty_inspn* conversion_rate)),0)+nvl(decode(conversion_Rate,null,(1*store_pend),(store_pend* conversion_rate)),0))),-1,0,1,min_minmax_quantity),0) ordqty,"

            sql &= "primary_uom_code uom, item_type, make_buy, nvl(item_cost,0)item_cost,"

            sql &= " (nvl(on_hand,0)+nvl(decode(conversion_Rate,null,(1*po_pend),(po_pend* conversion_rate)),0)+nvl(wip_qty,0)+nvl(decode(conversion_Rate,null,(1*qty_inspn),(qty_inspn* conversion_rate)),0)+nvl(decode(conversion_Rate,null,(1*store_pend),(store_pend* conversion_rate)),0)) value from jan_minmax_planning a where rownum>0"

            If rd1.Checked = True Then
                sql = sql
            End If

            If rd2.Checked = True Then
                sql &= " and  min_minmax_quantity >  (nvl(on_hand,0)+nvl(decode(conversion_Rate,null,(1*po_pend),(po_pend* conversion_rate)),0)+nvl(wip_qty,0)+nvl(decode(conversion_Rate,null,(1*qty_inspn),(qty_inspn* conversion_rate)),0)+nvl(decode(conversion_Rate,null,(1*store_pend),(store_pend* conversion_rate)),0))"
            End If

            If rd3.Checked = True Then
                sql &= " and nvl(on_hand,0) < min_minmax_quantity"
            End If

            If cmborg.SelectedItem <> "" Then
                sql &= " and  organization_id=(select organization_id from org_organization_definitions a  where a.organization_code='" & cmborg.SelectedItem & "')"
            End If

            If cmbinv.SelectedItem <> "" Then
                sql &= " and inventory='" & cmbinv.SelectedItem & "'"
            End If
            If cmbitem.SelectedItem <> "" Then
                sql &= "  and item_type='" & cmbitem.SelectedItem & "'"
            End If
            If txtitem.Text <> "" Then
                sql &= " and item_no ='" & txtitem.Text & "'"
            End If
            If cmbtyp.SelectedItem <> "" Then
                sql &= " and make_buy='" & cmbtyp.SelectedItem & "'"
            End If
            sql &= " order by item_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            DoIt.StartValue = 0
            DoIt.CountLoop()

            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Inv"
            cc.DataPropertyName = "inventory"
            cc.Width = 50
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Org"
            cc.DataPropertyName = "org"
            cc.Width = 30
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Item"
            cc.DataPropertyName = "item_no"
            cc.Width = 60
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Description"
            cc.DataPropertyName = "description"
            cc.Width = 70
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Minqty"
            cc.DataPropertyName = "minqty"
            cc.Width = 45
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Mincost"
            cc.DataPropertyName = "mincost"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Maxqty"
            cc.DataPropertyName = "maxqty"
            cc.Width = 45
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Maxcost"
            cc.DataPropertyName = "maxcost"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Minord"
            cc.DataPropertyName = "minordqty"
            cc.Width = 45
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Maxord"
            cc.DataPropertyName = "maxordqty"
            cc.Width = 45
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "OnHand"
            cc.DataPropertyName = "on_hand"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "InProc"
            cc.DataPropertyName = "Insppend"
            cc.Width = 40
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Short"
            cc.DataPropertyName = "shortage"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "OrdQty"
            cc.DataPropertyName = "ordqty"
            cc.Width = 40
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Uom"
            cc.DataPropertyName = "uom"
            cc.Width = 30
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Type"
            cc.DataPropertyName = "item_type"
            cc.Width = 40
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "MB"
            cc.DataPropertyName = "make_buy"
            cc.Width = 40
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Cost"
            cc.DataPropertyName = "item_cost"
            cc.Width = 40
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgmm.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Value"
            cc.DataPropertyName = "Value"
            cc.Width = 70
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            cc.Visible = False
            Me.dgmm.Columns.Add(cc)

            b1 = 0
            cs = 0
            d1 = 0
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                b = 0 And c = 0 And d = 0
                With ds.Tables("resultab").Rows(i)
                    b = .Item("minqty") * .Item("item_cost")
                    b1 = b + b1
                    c = .Item("maxqty") * .Item("item_cost")
                    cs = c + cs
                    d = .Item("ordqty") * .Item("item_cost")
                    d1 = d + d1
                End With
            Next
            lbitem.Text = ds.Tables("resultab").Rows.Count

            s = "select count(*) from jan_minmax_planning where min_minmax_quantity >  (nvl(on_hand,0)+nvl(decode(conversion_Rate,null,(1*po_pend),(po_pend* conversion_rate)),0)+nvl(wip_qty,0)+nvl(decode(conversion_Rate,null,(1*qty_inspn),(qty_inspn* conversion_rate)),0)+nvl(decode(conversion_Rate,null,(1*store_pend),(store_pend* conversion_rate)),0)) "
            If rd1.Checked = True Then
                s = s
            End If

            If rd2.Checked = True Then
                s &= " and  min_minmax_quantity >  (nvl(on_hand,0)+nvl(decode(conversion_Rate,null,(1*po_pend),(po_pend* conversion_rate)),0)+nvl(wip_qty,0)+nvl(decode(conversion_Rate,null,(1*qty_inspn),(qty_inspn* conversion_rate)),0)+nvl(decode(conversion_Rate,null,(1*store_pend),(store_pend* conversion_rate)),0))"
            End If

            If rd3.Checked = True Then
                s &= " and nvl(on_hand,0) < min_minmax_quantity"
            End If

            If cmborg.SelectedItem <> "" Then
                s &= " and  organization_id=(select organization_id from org_organization_definitions a  where a.organization_code='" & cmborg.SelectedItem & "')"
            End If

            If cmbinv.SelectedItem <> "" Then
                s &= " and inventory='" & cmbinv.SelectedItem & "'"
            End If
            If cmbitem.SelectedItem <> "" Then
                s &= "  and item_type='" & cmbitem.SelectedItem & "'"
            End If
            If txtitem.Text <> "" Then
                s &= " and item_no ='" & txtitem.Text & "'"
            End If
            If cmbtyp.SelectedItem <> "" Then
                s &= " and make_buy='" & cmbtyp.SelectedItem & "'"
            End If

            s &= " order by item_no"
            cl.oradap = New OracleDataAdapter(s, CON)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "result")
            DoIt.StartValue = 0
            DoIt.CountLoop()

            lblmin.Text = ds1.Tables("result").Rows(0)(0)
            lblmincst.Text = b1
            lblmaxcst.Text = cs
            lblord.Text = d1
            dgmm.DataSource = ds.Tables("resultab")
            Me.Cursor = Cursors.Arrow
            ProgressBar1.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnpri_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpri.Click
        Dim objFSO
        objFSO = CreateObject("Scripting.FileSystemObject")
        Dim FullPath
        FullPath = "c:\gate\\minmax"
        If Not objFSO.FolderExists(FullPath) Then
            objFSO.CreateFolder(FullPath)
        ElseIf objFSO.FolderExists(FullPath) Then
            objFSO.DeleteFolder(FullPath)
            objFSO.CreateFolder(FullPath)
        End If
        Dim X As String
        Dim a, a1 As Double
        X = "c:\gate\minmax\" & Trim(CStr(Rnd() * 255)) & ".HTML"
        Dim fstrm As New FileStream(X, FileMode.OpenOrCreate, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        j = 0
        s = "<html><H3 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Planning-MinMax Report</FONT></H3>"
        s &= "<table cellSpacing=0 cellPadding=0 BORDER=1 align=center position=top><TH><B><FONT SIZE=1 font face=Arial narrow>S.No</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>Org</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>Inv/Date</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>Item No/Desc</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>Minqty</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>MinCost</font></TH><th><B><FONT SIZE=1 font face=Arial narrow>MaxQty</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>MaxCost</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>MinOrdQty</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>MaxOrdQty</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>Onhand</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>InProcess</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>Shortage</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>OrdQty</font><TH><B><FONT SIZE=1 font face=Arial narrow>UOM</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>Cost</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>Value</font></TH></TR>"

        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            j += 1
            With ds.Tables("resultab").Rows(i)
                a = 0
                a = .Item("ordqty") * .Item("item_cost")
                a1 = a + a1

                s &= "<TR><Td><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("Org") & "</FONT></TH><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("inventory") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("item_no") & " ||" & .Item("description") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("minqty") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("mincost") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA align=right>" & .Item("maxqty") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("maxcost") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("minordqty") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("maxordqty") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("on_hand") & " </FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("insppend") & "</FONT></Td><Td align=right ><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("shortage") & " </FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("ordqty") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("uom") & "</FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("item_cost") & "</FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("item_cost") * .Item("ordqty") & "</FONT></Td></TR>"
            End With
        Next
        s &= "<TR><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td></Td><Td align=right><b><FONT SIZE=1  FONT FACE=VERDANA>" & a1 & "</FONT></b></Td></TR>"
        DoIt.StartValue = 0
        DoIt.CountLoop()
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(X)
        ProgressBar1.Visible = False
    End Sub

    Private Sub dgmm_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgmm.CellFormatting
        Try
            If e.RowIndex >= 0 Then
                If e.RowIndex <= dgmm.Rows.Count - 1 Then
                    If dgmm.Rows(e.RowIndex).Cells(4).Value > dgmm.Rows(e.RowIndex).Cells(18).Value Then
                        e.CellStyle.ForeColor = Color.Red
                    ElseIf dgmm.Rows(e.RowIndex).Cells(10).Value < dgmm.Rows(e.RowIndex).Cells(4).Value Then
                        e.CellStyle.ForeColor = Color.Green
                    Else
                        e.CellStyle.ForeColor = Color.Black
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.StackTrace)
        End Try
    End Sub

    Private Sub btngo1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo1.Click
        Try
            dgfc.Columns.Clear()
            ds2.Clear()
            ds2.Dispose()
            ProgressBar2.Visible = True
            DoIt.StartValue = 0
            lbfc.Text = ""
            lbmfg.Text = ""
            lbcur.Text = ""
            lbsale.Text = ""
            sql = "select(select organization_code  from org_organization_definitions where organization_id=a.organization_id)org,fc_code,item_no,item_desc,fc_qty,nvl((fc_Qty *sale_price),0)fcprice,curr_fc_qty,nvl((curr_fc_Qty*sale_price),0)currprice,nvl(mfg_Qty,0)mfg_qty,nvl((mfg_qty * sale_price),0) mfgprice,nvl(sale_qty,0)sale_qty,nvl((sale_qty * sale_price),0)saleprice from jan_monthly_forecast a where rownum>0"
            If cmborg1.SelectedItem <> "" Then
                sql &= "  and  organization_id=(select organization_id from org_organization_definitions a  where a.organization_code='" & cmborg1.SelectedItem & "')"
            End If
            If cmbfc.SelectedItem <> "" Then
                sql &= " and fc_code='" & cmbfc.SelectedItem & "'"
            End If
            If txtitem1.Text <> "" Then
                sql &= " and item_no='" & txtitem1.Text & "'"
            End If
            sql &= "order by item_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds2 = New DataSet
            DoIt.StartValue = 0
            DoIt.CountLoop()
            adap.Fill(ds2, "resultab")
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Org"
            cc.DataPropertyName = "org"
            cc.Width = 40
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "FCCode"
            cc.DataPropertyName = "Fc_code"
            cc.Width = 80
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Item"
            cc.DataPropertyName = "item_no"
            cc.Width = 80
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Description"
            cc.DataPropertyName = "item_desc"
            cc.Width = 170
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "FCQty"
            cc.DataPropertyName = "fc_qty"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "FCprice"
            cc.DataPropertyName = "fcprice"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "CurFcQty"
            cc.DataPropertyName = "curr_fc_qty"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Curprice"
            cc.DataPropertyName = "currprice"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "MFGQty"
            cc.DataPropertyName = "mfg_qty"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "MFGprice"
            cc.DataPropertyName = "mfgprice"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "SaleQty"
            cc.DataPropertyName = "sale_qty"
            cc.Width = 50
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            cc = New DataGridViewTextBoxColumn()
            cc.HeaderText = "Saleprice"
            cc.DataPropertyName = "saleprice"
            cc.Width = 60
            cc.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            Me.dgfc.Columns.Add(cc)
            b1 = 0
            cs = 0
            d1 = 0
            f1 = 0
            For i = 0 To ds2.Tables("resultab").Rows.Count - 1
                b = 0
                c = 0
                d = 0
                f = 0
                With ds2.Tables("resultab").Rows(i)
                    b = .Item("fcprice")
                    b1 = b + b1
                    c = .Item("currprice")
                    cs = c + cs
                    d = .Item("mfgprice")
                    d1 = d + d1
                    f = .Item("saleprice")
                    f1 = f + f1
                End With
            Next
            lbfc.Text = Math.Round(b1, 2)
            lbmfg.Text = Math.Round(d1, 2)
            lbcur.Text = Math.Round(cs, 2)
            lbsale.Text = Math.Round(f1, 2)
            dgfc.DataSource = ds2.Tables("resultab")
            ProgressBar2.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnpri1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpri1.Click
        Dim objFSO
        objFSO = CreateObject("Scripting.FileSystemObject")
        Dim FullPath
        FullPath = "D:\\forecast"
        If Not objFSO.FolderExists(FullPath) Then
            objFSO.CreateFolder(FullPath)
        ElseIf objFSO.FolderExists(FullPath) Then
            objFSO.DeleteFolder(FullPath)
            objFSO.CreateFolder(FullPath)
        End If
        Dim X As String
        X = "D:\forecast\" & Trim(CStr(Rnd() * 255)) & ".HTML"
        Dim fstrm As New FileStream(X, FileMode.OpenOrCreate, FileAccess.Write)
        Dim sw As New StreamWriter(fstrm)
        j = 0
        s = "<html><H3 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Planning-Forecast Report</FONT></H3><h4 align=center> Item No:<font size=2 font face=verdana>" & txtitem1.Text & "Organization:<font size=2 font face=verdana>" & cmborg1.SelectedItem & "|FC Code:<font size=2 font face=verdana>" & cmbfc.SelectedItem & "</h4></head>"
        s &= "<table cellSpacing=0 cellPadding=0 BORDER=1 align=center position=top><TH><B><FONT SIZE=1 font face=Arial narrow>S.No</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>Org</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>FC Code/Date</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>Item No/Desc</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>FCQty</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>FCPrice</font></TH><th><B><FONT SIZE=1 font face=Arial narrow>Curr-FCQty</font></TH><TH BORDER=0><B><FONT SIZE=1 font face=Arial narrow>CurPrice</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>MFGQty<font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>MFGprice</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>SaleQty</font></TH><TH><B><FONT SIZE=1 font face=Arial narrow>SalePrice</font></TH></TR>"
        a1 = 0
        b1 = 0
        cs = 0
        d1 = 0
        e1 = 0
        f1 = 0
        g1 = 0
        h1 = 0
        For i = 0 To ds2.Tables("resultab").Rows.Count - 1
            j += 1
            With ds2.Tables("resultab").Rows(i)
                a = 0
                b = 0
                c = 0
                d = 0
                ee = 0
                f = 0
                g = 0
                h = 0
                a = .Item("fc_qty")
                a1 = a + a1
                b = .Item("fcprice")
                b1 = b + b1
                c = .Item("curr_fc_qty")
                cs = c + cs
                d = .Item("currprice")
                d1 = d + d1
                ee = .Item("mfg_qty")
                e1 = ee + e1
                f = .Item("mfgprice")
                f1 = f + f1
                g = .Item("sale_qty")
                g1 = g + g1
                h = .Item("saleprice")
                h1 = h + h1
                s &= "<TR><Td><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("Org") & "</FONT></TH><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("fc_code") & "</FONT></Td><Td><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("item_no") & " ||" & .Item("item_desc") & "</FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("fc_qty") & "</FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("fcprice") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & .Item("curr_fc_qty") & "</FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("currprice") & "</FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("mfg_qty") & "</FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("mfgprice") & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("sale_qty") & " </FONT></Td><Td align=right><FONT SIZE=1  FONT FACE=VERDANA>" & .Item("saleprice") & "</FONT></TR>"
            End With
        Next
        s &= "<TR><td align=right>-</td><td align=right>-</td><td align=right>-</td><td align=right>-</td><Td align=right ><FONT SIZE=1 FONT FACE=VERDANA >" & a1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & b1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & cs & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & d1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & e1 & "</FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & f1 & " </FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & g1 & " </FONT></Td><Td align=right><FONT SIZE=1 FONT FACE=VERDANA >" & h1 & " </FONT></Td></TR>"

        DoIt.StartValue = 0
        DoIt.CountLoop()
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(X)
        ProgressBar2.Visible = False
    End Sub

End Class