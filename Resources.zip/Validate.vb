Imports System.Data.OracleClient
Imports oracleclass
Imports System.Configuration
Public Class Validate
    Dim ds, ds1, dsval As New DataSet
    Dim sql, sql1 As String
    Dim i, j As Integer
    Private WithEvents CHK As DataGridViewCheckBoxColumn
    Private WithEvents REASON, REMARK, DT, CODE, ACT, ACTDT, ACTR, reasel, app As DataGridViewTextBoxColumn
    Dim cl As New oracleclass.Class1
    Dim a, b, AC, c As Boolean
    Dim val, val1, val2 As Integer
    Private Sub VALIDATE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If userid = "UNIT7" Then
            If valby.Contains(",") = True Then
                Dim arrayList = VALBY.Split(",")
                For Each value As String In arrayList
                    cmbval.Items.Add(value)
                Next
            End If
            Label5.Visible = True
            cmbval.Visible = True
        End If


        If cl.oracon.State = ConnectionState.Closed Then
            cl.oracon.Open()
        End If

        cl.sql = "SELECT pono,ITEM , STATUS  FROM  (SELECT  pono,LOCATION_ID,ITEM ,(select case when (quantity-(quantity_received+quantity_cancelled)) =0 THEN 'No pending Qty' when QUANTITY_CANCELLED>0 then 'PO cancelled' when nvl(closed_code,'OPEN')<>'OPEN' then 'Line closed' when APPROVED_FLAG   <>'Y' then 'Approval Pend'  when  (quantity-(quantity_received+quantity_cancelled))<a.supdcqty then 'Po Qty less than inward Qty' when(select  count(*) from po_headers_all where authorization_status <>'APPROVED' and po_header_id=a.pohead)>0 then 'PO Not Approved' when (select count(*) from po_lines_all where po_line_id=a.poline and item_revision is null)>0  then  'No Revision for item in PO' else 'NP' end from PO_LINE_LOCATIONS_ALL  where LINE_LOCATION_ID=a.LOCATION_ID  ) STATUS from JAN_GATE_LINES a where GATE_NO=" & txtgno.Text & " and location_id in ( select location_id  from jan_receipt_pending where gate_no=a.gate_no and shipment_line_id is null) )  where STATUS<>'NP'"


        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        dsval = New DataSet
        cl.oradap.Fill(dsval, "val")
        dgval.DataSource = dsval.Tables("val")
        dgval.Columns(0).HeaderText = "PoNo" : dgval.Columns(0).Width = 80
        dgval.Columns(1).HeaderText = "Item No" : dgval.Columns(1).Width = 80
        dgval.Columns(2).HeaderText = "Status" : dgval.Columns(2).Width = 150
        'sql = "select JAN_gate_po_status(" & txtgno.Text & ",0"

        ''If lbtype.Text = "PO" Then sql &= "0"

        ''If lbtype.Text = "OSP" Then sql &= "1"

        'sql &= ")"

        'sql &= ", (select count(*) from JAN_GATE_LINES where GATE_NO=" & txtgno.Text & ")gcnt From dual "
        'cl.oradap = New OracleDataAdapter(cl.sql,cl.oracon)
        'ds = New DataSet()
        'cl.oradap.Fill(ds, "val")


        'If ds.Tables("val").Rows(0).Item(0).ToString <> "" Then

        '    If lbtype.Text = "PO" Then Label4.Text = "PO status  " + ds.Tables("val").Rows(0).Item(0).ToString()

        '    'If lbtype.Text = "OSP" Then

        '    '    If ds.Tables("val").Rows(0).Item(0) = ds.Tables("val").Rows(0).Item(1) Then

        '    '        Label4.Text = " Challan closed lines " + ds.Tables("val").Rows(0).Item(0).ToString()
        '    '    Else
        '    '        Label4.Text = "  Challan Not closed"
        '    '    End If

        '    'End If
        'End If


        RBTNNV_CheckedChanged(sender, e)
        rbtnnv.Checked = True

        Dim f As New Login
        If gtpur = "Entry" Or txtrole.Text = "U7_VIEW" Then btnok.Visible = True Else btnok.Visible = False

        '  If control = "VIEW" Then btnok.Visible = False Else btnok.Visible = True

        'If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Then
        '    rbtnv.Enabled = False
        '    dgv.Visible = False
        '    rbtnnv.Enabled = True
        '    dgv1.Visible = True
        'ElseIf txtlog.Text = "VALID" Then
        '    GroupBox1.Enabled = False
        '    rbtnnv.Enabled = False
        '    rbtnv.Checked = True
        '    dgv.Visible = True
        '    rbtnv.Enabled = False
        '    dgv1.Visible = False
        '    RBTNV_CheckedChanged(sender, e)
        'End If
        'Me.StartPosition = FormStartPosition.CenterScreen

        'If txtrole.Text = "ADD4" Then
        '    If txtgno.Text.Contains("72014") = True Then
        '        btnok.Visible = True
        '    Else
        '        btnok.Visible = False
        '    End If
        'End If

    End Sub

    Private Sub RBTNV_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtnv.CheckedChanged
        Dim DSN As New DataSet
        DSN.Clear()
        DSN.Dispose()
        dgv.Columns.Clear()
        dgv1.Visible = False
        dgv.Visible = True
        cl.sql = "SELECT REA_CODE,REA_NAME,REA_REMARK,ACTION,ACTION_REMARK,TO_CHAR(ACTION_DT)ACTION_DT,REA_SEL FROM JAN_GATE_NVAL_REASON WHERE GATE_NO='" & txtgno.Text & "' and line_no='" & TXTLINE.Text & "'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        cl.oradap.Fill(DSN, "JAN_GATE_NVAL_REASON")

        Dim sel, CD, REA, RR, ACT, ACTR, ACTD As DataGridViewTextBoxColumn
        CHK = New DataGridViewCheckBoxColumn
        CHK.HeaderText = "SELECT"
        CHK.Width = 53
        Me.dgv.Columns.Add(CHK)

        CD = New DataGridViewTextBoxColumn
        CD.HeaderText = "CODE"
        CD.DataPropertyName = "REA_CODE"
        CD.Width = 50
        Me.dgv.Columns.Add(CD)

        REA = New DataGridViewTextBoxColumn
        REA.HeaderText = "REASON"
        REA.DataPropertyName = "REA_NAME"
        REA.Width = 120
        REA.ReadOnly = True
        Me.dgv.Columns.Add(REA)

        RR = New DataGridViewTextBoxColumn
        RR.HeaderText = "REASON REMARK"
        RR.DataPropertyName = "REA_REMARK"
        RR.Width = 130
        RR.ReadOnly = True
        Me.dgv.Columns.Add(RR)

        ACT = New DataGridViewTextBoxColumn
        ACT.HeaderText = "ACTION TAKEN"
        ACT.DataPropertyName = "ACTION"
        ACT.Width = 0
        ACT.Visible = False
        Me.dgv.Columns.Add(ACT)

        ACTR = New DataGridViewTextBoxColumn
        ACTR.HeaderText = "REMARK"
        ACTR.DataPropertyName = "ACTION_REMARK"
        ACTR.Width = 0
        ACTR.Visible = False
        Me.dgv.Columns.Add(ACTR)

        ACTD = New DataGridViewTextBoxColumn
        ACTD.HeaderText = "DATE"
        ACTD.DataPropertyName = "ACTION_DT"
        ACTD.Width = 0
        ACTD.Visible = False

        Me.dgv.Columns.Add(ACTD)

        'If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Then
        '    ACT.ReadOnly = True
        '    ACTR.ReadOnly = True
        '    ACTD.ReadOnly = True
        'ElseIf txtrole.Text = "VALID" Then
        '    ACT.ReadOnly = False
        '    ACTR.ReadOnly = False
        '    ACTD.ReadOnly = False
        'End If

        'sel = New DataGridViewTextBoxColumn
        sel.HeaderText = "SEL"
        sel.DataPropertyName = "REA_SEL"
        sel.Width = 110
        sel.Visible = False
        Me.dgv.Columns.Add(sel)
        dgv.DataSource = DSN.Tables("JAN_GATE_NVAL_REASON")
    End Sub

    Private Sub RBTNNV_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtnnv.CheckedChanged

        Try
            ds.Clear()
            ds.Dispose()
            dgv1.Columns.Clear()
            dgv.Visible = False
            dgv1.Visible = True

            cl.sql = "select nvl(eway_no,(select eway_bill from jan_gate_del where gate_no=" & txtgno.Text & " and  DEL_FOR='Header' and eway_bill is not null and rownum=1)) from jan_gate_header where gate_no=" & txtgno.Text & ""
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            cl.oradap.Fill(ds, "eway")
            txtgst.Text = ds.Tables("eway").Rows(0).Item(0).ToString

            cl.sql = "SELECT REA_CODE,REA_NAME FROM JAN_GATE_REASON  WHERE LIVE_FLAG='Y' "

            If txtrole.Text = "U7_VIEW" Then cl.sql &= " and counting_area_flag =1"

            cl.sql &= " ORDER BY REA_CODE"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            cl.oradap.Fill(ds, "JAN_GATE_REASON")

            CHK = New DataGridViewCheckBoxColumn
            CHK.Width = 30
            Me.dgv1.Columns.Add(CHK)

            CODE = New DataGridViewTextBoxColumn
            CODE.DataPropertyName = "REA_CODE"
            CODE.HeaderText = "CODE"
            CODE.Width = 45
            CODE.ReadOnly = True
            Me.dgv1.Columns.Add(CODE)

            REASON = New DataGridViewTextBoxColumn
            REASON.DataPropertyName = "REA_NAME"
            REASON.HeaderText = "REASON"
            REASON.Width = 220
            REASON.ReadOnly = True
            Me.dgv1.Columns.Add(REASON)

            REMARK = New DataGridViewTextBoxColumn
            REMARK.HeaderText = "REMARK"
            REMARK.Width = 100
            Me.dgv1.Columns.Add(REMARK)

            DT = New DataGridViewTextBoxColumn
            DT.HeaderText = "DATE/TIME"
            DT.Width = 165
            DT.ReadOnly = True
            Me.dgv1.Columns.Add(DT)

            ACT = New DataGridViewTextBoxColumn
            ACT.HeaderText = "ACTION TAKEN"
            ACT.Width = 100
            ACT.Visible = False
            Me.dgv1.Columns.Add(ACT)

            ACTR = New DataGridViewTextBoxColumn
            ACTR.HeaderText = "ACTION REMARK"
            ACTR.Width = 100
            ACTR.ReadOnly = True
            ACTR.Visible = False
            Me.dgv1.Columns.Add(ACTR)

            reasel = New DataGridViewTextBoxColumn
            reasel.HeaderText = "res sel"
            reasel.Width = 100
            reasel.ReadOnly = False
            reasel.Visible = False
            Me.dgv1.Columns.Add(reasel)

            ACTDT = New DataGridViewTextBoxColumn
            ACTDT.HeaderText = "ACTION DATE"
            ACTDT.Width = 100
            ACTDT.Visible = False
            Me.dgv1.Columns.Add(ACTDT)

            dgv1.DataSource = ds.Tables("JAN_GATE_REASON")

            Dim J As Integer
            For J = 0 To ds.Tables("JAN_GATE_REASON").Rows.Count - 1
                Dim DSACT As New DataSet
                DSACT = New DataSet
                cl.sql = "SELECT REA_REMARK,REAson_Date,TO_CHAR(ACTION)ACTION,TO_CHAR(ACTION_REMARK)ACTION_REMARK,ACTION_DT,rea_sel FROM JAN_GATE_NVAL_REASON WHERE GATE_NO='" & txtgno.Text & "' AND LINE_NO IN (" & TXTLINE.Text & ") AND DECODE(REA_CODE,8,28,REA_CODE)='" & ds.Tables("JAN_GATE_REASON").Rows(J).Item("REA_CODE") & "'"
                cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
                cl.oradap.Fill(DSACT, "RESULTAB")
                If DSACT.Tables("RESULTAB").Rows.Count <> 0 Then
                    With DSACT.Tables("resultab").Rows(0)
                        dgv1.Rows(J).Cells(3).Value = .Item("REA_REMARK")
                        dgv1.Rows(J).Cells(4).Value = .Item("REAson_Date")
                        dgv1.Rows(J).Cells(5).Value = .Item("ACTION")
                        dgv1.Rows(J).Cells(8).Value = .Item("ACTION_DT")
                        dgv1.Rows(J).Cells(7).Value = .Item("rea_sel")
                    End With
                    If dgv1.Rows(J).Cells(7).Value = "1" Or dgv1.Rows(J).Cells(7).Value = "0" Then
                        dgv1.Rows(J).Cells(0).Value = True
                    End If
                End If


            Next

            'For J = 0 To dgv1.Rows.Count - 1

            '    If txtrole.Text = "U7_VIEW" And dgv1.Rows(J).Cells(1).Value = 33 Or dgv1.Rows(J).Cells(1).Value = 34 Or dgv1.Rows(J).Cells(1).Value = 37 Then
            '        dgv1.Rows(J).Cells(0).ReadOnly = False
            '    Else
            '        dgv1.Rows(J).Cells(0).ReadOnly = True
            '        ' dgv1.Rows(J).Cells(0).Value = False
            '        dgv1.Rows(J).Cells(0).Style.BackColor = System.Drawing.Color.Gray
            '    End If

            'Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Gate Entry")
        End Try
    End Sub
    Private Sub BTNOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Try

            sql = "select JAN_iNWARD_QTY_VALIDATE (" & txtgno.Text & ",1) gate_Val from dual  "
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            Dim dsqty As New DataSet
            cl.oradap.Fill(dsqty, "gval")


            If Not IsDBNull(dsqty.Tables("gval").Rows(0).Item(0)) Then
                With dsqty.Tables("gval").Rows(0)


                    sql = "Update  JAN_GATE_HEADER Set VALIDATED=2 WHERE GATE_NO=" & txtgno.Text & ""
                    cl.orcmd = New OracleCommand(sql, cl.oracon)
                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                    cl.orcmd.ExecuteNonQuery()
                    cl.oracon.Close()

                    sql = "Update JAN_GATE_LINES SET VALIDATED=2 WHERE GATE_NO=" & txtgno.Text & ""
                    cl.orcmd = New OracleCommand(sql, cl.oracon)
                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                    cl.orcmd.ExecuteNonQuery()
                    cl.oracon.Close()

                    sql = " INSERT INTO JAN_GATE_NVAL_REASON(GATE_NO, LINE_NO, REA_CODE, REA_NAME, REA_DT, REA_SEL, REASON_DATE, unit) values(" & txtgno.Text & ", 1, 31, (select rea_name from jan_gate_reason where rea_code=31),sysdate,1,sysdate,(Select unit from jan_gate_header where gate_No= " & txtgno.Text & "))"

                    cl.orcmd = New OracleCommand(sql, cl.oracon)
                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                    cl.orcmd.ExecuteNonQuery()
                    cl.oracon.Close()

                    MessageBox.Show(.Item(0))

                    Exit Sub
                End With
            End If


            If userid = "UNIT7" Then
                sql = "select count(*) from jan_gate_header where gate_no=" & txtgno.Text & " and po_Wt is not null and rec_wt is null"
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                Dim dswt As New DataSet
                cl.oradap.Fill(dswt, "cnt")

                If dswt.Tables("cnt").Rows(0).Item(0) > 0 Then
                    MessageBox.Show("Received Weight not entered for POD", "Gate Entry")
                    Exit Sub
                End If
            End If


            sql = "select *"

            sql = "select count(*) from po_vendors where invoice_currency_code='INR' and vendor_id in (select vendor_id from jan_gate_header where gate_no=" & txtgno.Text & ")"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            Dim dsven As New DataSet
            cl.oradap.Fill(dsven, "cur_Cnt")

            If dsven.Tables("cur_cnt").Rows.Count > 0 Then

                sql = "select count(distinct pohead) from jan_gate_lines where gate_no=" & txtgno.Text & ""
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                Dim dsgt As New DataSet
                cl.oradap.Fill(dsgt, "gate_Cnt")

                sql = "select count(distinct trx_id) from jai_tax_lines where trx_id in (select pohead from jan_gate_lines where gate_no=" & txtgno.Text & ")"
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                Dim dscnt As New DataSet
                cl.oradap.Fill(dscnt, "tax_cnt")

                If dsgt.Tables("gate_Cnt").Rows.Count <> dscnt.Tables("tax_cnt").Rows.Count Then
                    MessageBox.Show("Tax not available for all lines as in gate entry", "Gate Register")
                    Exit Sub
                Else
                    GoTo Validate
                End If
            End If
            ''''''' checking for validated by person name 
Validate:
            sql = "select count(*) from jan_gate_einvoice_Vendor where vendor_id=(select vendor_id from jan_gate_header where gate_no=" & txtgno.Text & " )"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "einv")

            '''' check for einv eligible vendor tick 

            If ds1.Tables("einv").Rows(0).Item(0) > 0 And chkeinv.Checked = False Then val = 1 Else val = 0

            sql = "select nvl(state_code,substr(REGISTRATION_NUMBER, 0,2)),(select dcval from jan_gate_header where gate_no=" & txtgno.Text & ")inv_amt,nvl((select eway_bill from jan_gate_del where gate_no=" & txtgno.Text & " and del_for='Header' and rownum=1),'" & txtgst.Text & "')eway from  JAN_GST_REG_DETAILS_VIEW where PARTY_CLASS_NAME='Supplier' AND REGISTRATION_TYPE_CODE='GSTIN' and party_id=(select vendor_id from jan_gate_header where gate_no=" & txtgno.Text & " ) and org_id=" & OP_ID & " and party_id in (select vendor_id from po_Vendors where invoice_Currency_code='INR') "

            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds2 = New DataSet
            cl.oradap.Fill(ds2, "gst")

            '''' eway no for amount 
            If ds2.Tables("gst").Rows.Count > 0 Then
                If lbtype.Text <> "Services" And ds2.Tables("gst").Rows(0).Item(0).ToString.Contains("NA") = True Then

                    If ds2.Tables("gst").Rows(0).Item(2).ToString <> "" Then txtgst.Text = ds2.Tables("gst").Rows(0).Item(2)

                    If ds2.Tables("gst").Rows(0).Item(0).ToString = "33" Then
                        If ds2.Tables("gst").Rows(0).Item(1).ToString > 100000 And txtgst.Text = "" Then val1 = 1 Else val1 = 0
                    Else
                        If ds2.Tables("gst").Rows(0).Item(1).ToString > 50000 And txtgst.Text = "" Then val1 = 1 Else val1 = 0
                        If ds2.Tables("gst").Rows(0).Item(1).ToString.Contains("NA") = True Then val1 = 1 Else val1 = 0
                    End If

                ElseIf lbtype.Text = "Services" Then
                    val1 = 0
                ElseIf ds2.Tables("gst").Rows(0).Item(0) = "NA" Or ds2.Tables("gst").Rows(0).Item(0) = "#N/A" Then
                    val1 = 0
                End If
            Else
                val1 = 0
            End If



            If userid <> "UNIT7" Then
                If val = 0 And val1 = 0 Then
                    valfun()
                ElseIf val = 1 Then
                    MessageBox.Show("Tick E-invoice Supplier and proceed", "Gate Register")
                    Exit Sub
                ElseIf val1 = 1 Then
                    MessageBox.Show("Enter Supplier E-way bill No and proceed", "Gate Register")
                    Exit Sub
                End If

            ElseIf userid = "UNIT7" Then

                sql = "select count(*) from jan_gate_lines where gate_no=" & txtgno.Text & " and checked_by is not null"
                cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                ds = New DataSet
                cl.oradap.Fill(ds, "cnt")

                If ds.Tables("cnt").Rows(0).Item(0) > 0 Then val2 = 1

                If val = 0 And val2 = 1 And val1 = 0 And cmbval.SelectedIndex > 0 Then
                    valfun()

                ElseIf val = 0 And val2 = 0 And val1 = 0 And cmbval.SelectedIndex = 0 Then
                    MessageBox.Show("Select validated By and proceed validation", "Gate Register")
                    Exit Sub

                ElseIf val2 = 1 Then
                    MessageBox.Show("Enter Item checked by details To proceed validation", "Gate Register")
                    Exit Sub

                ElseIf val = 1 Then
                    MessageBox.Show("Tick E-invoice Supplier and proceed", "Gate Register")
                    Exit Sub

                ElseIf val1 = 1 Then
                    MessageBox.Show("Enter E-way Bill No and proceed", "Gate Register")
                    Exit Sub
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Gate Entry")
        End Try
    End Sub

    Sub valfun()

        If val1 = 1 Then
            If txtgst.Text.ToString.Length = 12 And txtgst.Text <> "" Then
                MessageBox.Show("Enter valid Eway bill no and proceed", "Gate Register")
                Exit Sub
            End If
        End If

        cl.sql = "Select receipt_num from rcv_shipment_headers where packing_slip='" & txtgno.Text & "'"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        Dim dar As OracleDataReader
        dar = cl.orcmd.ExecuteReader
        'If txtrole.Text <> "UNIT7" And txtrole.Text <> "UNIT2" And txtrole.Text <> "UNIT4" And txtrole.Text <> "SKYFAST" And txtrole.Text <> "ADD" And txtrole.Text <> "JAPL" Then
        '    If (dar.HasRows = True) Then
        '        MessageBox.Show("Receipt Made,Validation Not allowed", "Gate Register")
        '        Exit Sub
        '    Else
        '        GoTo a
        '    End If
        'Else
a:
        a = False And b = False And c = False And AC = False
        If rbtnnv.Checked = True Then
            For i = 0 To dgv1.Rows.Count - 1
                If dgv1.Rows(i).Cells(0).Value = True Then
                    ADD_REASON()
                    If dgv1.Rows(i).Cells(1).Value = 28 Or dgv1.Rows(i).Cells(1).Value = 9 Then

                        'sql = "SELECT JAN_INSP_decision_proc(" & txtgno.Text & ") FROM DUAL"
                        'adap = New OracleDataAdapter(sql, cl.oracon)
                        'ds = New DataSet()
                        'adap.Fill(ds, "cnt")

                        '    sql1 = "update jan_gate_LINES set validated='0',hold_for_qc=" & ds.Tables("cnt").Rows(0).Item(0) & "  where gate_no='" & txtgno.Text & "' and line_no IN (" & TXTLINE.Text & ")"
                        sql1 = "update jan_gate_LINES set validated='0'  where gate_no='" & txtgno.Text & "' and line_no IN (" & TXTLINE.Text & ")"

                    ElseIf dgv1.Rows(i).Cells(1).Value = 7 Then
                        sql1 = "update jan_gate_LINES set validated='4' , supdcqty='0' where gate_no='" & txtgno.Text & "' and line_no (" & TXTLINE.Text & ")"
                    ElseIf dgv1.Rows(i).Cells(1).Value = 21 Then
                        sql1 = "update jan_gate_LINES set validated='5', supdcqty='0' where gate_no='" & txtgno.Text & "' and line_no IN (" & TXTLINE.Text & ")"
                    Else
                        sql1 = "update jan_gate_LINES set validated='2' where gate_no='" & txtgno.Text & "' and line_no IN (" & TXTLINE.Text & ")"
                    End If
                    cl.orcmd = New OracleCommand(sql1, cl.oracon)
                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                    cl.orcmd.ExecuteNonQuery()
                    cl.oracon.Close()
                    VALID()
                    If dgv1.Rows(i).Cells(1).Value = 8 Then a = True
                    If dgv1.Rows(i).Cells(1).Value = 7 Then b = True
                    If dgv1.Rows(i).Cells(1).Value <> 8 And dgv1.Rows(i).Cells(1).Value <> 7 Then c = True
                End If
            Next
        ElseIf rbtnv.Checked = True Then
            For i = 0 To dgv.Rows.Count - 1
                If dgv.Rows(i).Cells(0).Value = True Then
                    cl.sql = "update jan_gate_nval_reason set action='" & dgv.Rows(i).Cells(4).Value & " ' , action_remark='" & dgv.Rows(i).Cells(5).Value & "' , action_dt='" & dgv.Rows(i).Cells(6).Value & "', rea_sel='0' where gate_no='" & txtgno.Text & "' and rea_code='" & dgv.Rows(i).Cells(1).Value & "' AND LINE_NO IN (" & TXTLINE.Text & ")"
                    cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                    cl.orcmd.ExecuteNonQuery()
                    VALID()
                    AC = True
                End If
            Next
        End If
        cl.sql = "update jan_gate_nval_Reason set gdate=(select gdate from jan_gate_header where gate_no='" & txtgno.Text & "'),ORG=(SELECT ORG FROM JAN_GATE_HEADER WHERE GATE_NO='" & txtgno.Text & "') WHERE GATE_NO='" & txtgno.Text & "'"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        cl.oracon.Close()

        If chkeinv.Checked = True Then
            cl.sql = "update jan_gate_header set einv_flag=1 WHERE GATE_NO='" & txtgno.Text & "'"
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
        End If


        cl.sql = "update jan_gate_header set eway_no='" & txtgst.Text & "' WHERE GATE_NO='" & txtgno.Text & "'"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        cl.oracon.Close()
        If a = True Then
            MessageBox.Show("VALIDATED", "Gate Entry")
            Me.Close()
        ElseIf b = True Then
            MessageBox.Show("REASON SAVED", "Gate Entry")
            Me.Close()
        ElseIf c = True Then
            MessageBox.Show("REASON SAVED", "Gate Entry")
            Me.Close()
        ElseIf AC = True Then
            MessageBox.Show("ACTION ENTERED", "Gate Entry")
            Me.Close()
        End If

        '        End If
    End Sub


    Private Sub dgv1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv1.CellClick

        'If dgv1.CurrentCell.ColumnIndex = 0 Then

        '   cl.sql= "select RECEIPT_QTY,REQUIRED_QTY2,ALLOW_QTY,"

        '    sql &= " (select count(rel_remark) from jan_gate_excess_qty where item_no='" & txtitem.Text & "' and organization_id=" & txtorg.Text & " AND GATE_NO=" & txtgno.Text & " AND LINE_NO=" & TXTLINE.Text & "  )rel_remark "

        '    sql &= "  from  jan_gate_poqty_check where item_no='" & txtitem.Text & "' and organization_id=" & txtorg.Text & " "

        '   cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        '    ds = New DataSet
        '    cl.oradap.Fill(ds, "resultab")

        '    If ds.Tables("resultab").Rows.Count > 0 Then

        '        If ds.Tables("resultab").Rows(0).Item("rel_remark") > 0 Then

        '            sql1 = "update jan_gate_LINES set validated=1 where gate_no='" & txtgno.Text & "' and line_no='" & TXTLINE.Text & "'"

        '            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        '            cl.orcl.or(cl.orcmd) = New oracleCommand(sql1, CON)
        '            (cl.orcmd).ExecuteNonQuery()
        '            cl.oracon.Close()
        '            dgv1.Rows(dgv1.CurrentRow.Index).Cells(4).Value = Now.Date + Now.TimeOfDay

        '        Else


        '            If ds.Tables("resultab").Rows(0).Item("receipt_qty") > ds.Tables("resultab").Rows(0).Item("REQUIRED_QTY2") Then

        '               cl.sql= "select count(*)cnt from jan_gate_excess_qty  where gatE_no=" & txtgno.Text & " and line_no=" & TXTLINE.Text & ""

        '               cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        '                ds1 = New DataSet
        '                cl.oradap.Fill(ds1, "resultab")

        '                If ds1.Tables("resultab").Rows(0).Item("cnt") = 0 Then

        '                   cl.sql= "insert into jan_gate_excess_qty (gate_no,gdate,line_no,item_no,org_id ,nval_dt,  last_updt,req_qty,recpt_qty,VENDOR_ID,POLINE,LINE_LOCATION_ID,ALLOW_QTY)"

        '                    sql &= " values(" & txtgno.Text & ",(select gdate from jan_gatE_header where gate_no=" & txtgno.Text & ")," & TXTLINE.Text & ",'" & txtitem.Text & "'," & txtorg.Text & " ,sysdate,sysdate," & ds.Tables("resultab").Rows(0).Item("required_qty2") & "," & ds.Tables("resultab").Rows(0).Item("receipt_qty") & ",(SELECT VENDOR_ID FROM JAN_GATE_HEADER WHERE GATE_NO=" & txtgno.Text & "),(SELECT POLINE FROM JAN_GATe_LINES WHERE GATE_NO=" & txtgno.Text & " AND LINE_NO=" & TXTLINE.Text & "),(SELECT   LOCATION_ID FROM JAN_GATe_LINES WHERE GATE_NO=" & txtgno.Text & " AND LINE_NO=" & TXTLINE.Text & ")," & ds.Tables("resultab").Rows(0).Item("ALLOW_qty") & "  )"

        '                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        '                    cl.orcl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
        '                    (cl.orcmd).ExecuteNonQuery()
        '                    cl.oracon.Close()

        '                    sql1 = "update jan_gate_LINES set validated='2' where gate_no=" & txtgno.Text & " and line_no='" & TXTLINE.Text & "'"

        '                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        '                    cl.orcl.or(cl.orcmd) = New oracleCommand(sql1, CON)
        '                    (cl.orcmd).ExecuteNonQuery()
        '                    cl.oracon.Close()

        '                    sql1 = "update jan_gate_header set validated='2' where gate_no=" & txtgno.Text & " "

        '                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()

        '                    cl.orcl.or(cl.orcmd) = New oracleCommand(sql1, CON)

        '                    (cl.orcmd).ExecuteNonQuery()
        '                    cl.oracon.Close()

        '                End If

        '                MessageBox.Show("Excess Qty Inwarded Than Required Qty!!! Line Can't Be Validated", "Gate Register")
        '                btnok.Enabled = False


        '            End If


        '        End If

        '    Else
        '        dgv1.Rows(dgv1.CurrentRow.Index).Cells(4).Value = Now.Date + Now.TimeOfDay
        '    End If

        '  End If

        dgv1.Rows(dgv1.CurrentRow.Index).Cells(4).Value = Now.Date + Now.TimeOfDay


    End Sub

    Private Sub dgv_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv.CellClick
        dgv.Rows(dgv.CurrentRow.Index).Cells(6).Value = Now.Date + Now.TimeOfDay
    End Sub
    Public Sub ADD_REASON()
        Dim ST, ST1, ST2 As Integer
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        If rbtnv.Checked = True Then
            cl.sql = "update jan_gate_nval_reason set action='" & dgv.Rows(i).Cells(4).Value & " ' , action_remark='" & dgv.Rows(i).Cells(5).Value & "' , action_dt='" & dgv.Rows(i).Cells(6).Value & "', rea_sel='0' where gate_no='" & txtgno.Text & "' and rea_code='" & dgv.Rows(i).Cells(1).Value & "' AND LINE_NO IN (" & TXTLINE.Text & ")"
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
        ElseIf rbtnnv.Checked = True Then
            ''''''''''''' CHECK FOR ALREADY ENTERED REASON 
            cl.sql = "select gate_no,rea_code from jan_gate_nval_reason where gate_no='" & txtgno.Text & "' and rea_code='" & dgv1.Rows(i).Cells(1).Value & "' AND LINE_NO IN (" & TXTLINE.Text & ")"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            Dim dss As New DataSet
            cl.oradap.Fill(dss, "resultab")
            If dss.Tables("resultab").Rows.Count = 0 Then

                If TXTLINE.Text.Length > 1 Then
                    '  e1.Substring(0, e1.IndexOf("|"))

                    ' ST = TXTLINE.Text.Substring(0, TXTLINE.Text.IndexOf(","))

                    ST1 = TXTLINE.Text.Replace(",", "").Length

                    GoTo MULINS
                Else
                    sql = "INSERT INTO JAN_GATE_NVAL_REASON(GATE_NO,LINE_NO,REA_CODE,REA_NAME,REA_REMARK,REA_DT,REA_SEL,rea_dt1,REASON_DATE,unit,UNAME"

                    sql &= " ) VALUES('" & txtgno.Text & "'," & TXTLINE.Text & ", '" & dgv1.Rows(i).Cells(1).Value & "','" & dgv1.Rows(i).Cells(2).Value & "','" & dgv1.Rows(i).Cells(3).Value & "','" & dgv1.Rows(i).Cells(4).Value & "','1',sysdate,SYSDATE,'" & unit & "' "


                    If per <> "" Then
                        sql &= ",'" & per & "'"
                    Else
                        sql &= " ,''"
                    End If


                    sql &= ")"

                End If
MULINS:
                For ST2 = 0 To ST1 - 1

                    ST = TXTLINE.Text.Replace(",", "").Substring(ST2, 1)

                    sql = "INSERT INTO JAN_GATE_NVAL_REASON(GATE_NO,LINE_NO,REA_CODE,REA_NAME,REA_REMARK,REA_DT,REA_SEL,rea_dt1,REASON_DATE,unit ,UNAME"

                    sql &= " ) VALUES('" & txtgno.Text & "'," & ST & ", '" & dgv1.Rows(i).Cells(1).Value & "','" & dgv1.Rows(i).Cells(2).Value & "','" & dgv1.Rows(i).Cells(3).Value & "','" & dgv1.Rows(i).Cells(4).Value & "','1',sysdate,SYSDATE,'" & unit & "' "



                    If per <> "" Then
                        sql &= ",'" & per & "'"
                    Else
                        sql &= " ,''"
                    End If

                    sql &= ")"
                    If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()

                    cl.orcmd = New OracleCommand(sql, cl.oracon)
                    cl.orcmd.ExecuteNonQuery()
                    cl.oracon.Close()
                Next

            Else
                sql = "update JAN_GATE_NVAL_REASON set  REA_DT= SYSDATE ,reason_date=sysdate where gate_no='" & txtgno.Text & "' and  line_no IN (" & TXTLINE.Text & ")  and rea_code='" & dgv1.Rows(i).Cells(1).Value & "' "
            End If
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()

            cl.orcmd = New OracleCommand(sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()

        End If
    End Sub
    Public Sub VALID()
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        If rbtnv.Checked = True Then
            cl.sql = "SELECT * FROM JAN_GATE_LINES WHERE VALIDATED IN ('0','4') AND GATE_NO='" & txtgno.Text & "' AND LINE_NO='" & TXTLINE.Text & "'"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "RESULTAB")
            If ds.Tables("RESULTAB").Rows.Count = 0 Then
                sql1 = "update jan_gate_LINES set validated='3' where gate_no='" & txtgno.Text & "' AND LINE_NO='" & TXTLINE.Text & "'"
                If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
                cl.orcmd = New OracleCommand(sql1, cl.oracon)
                cl.orcmd.ExecuteNonQuery()
                cl.oracon.Close()
            End If
        End If
        cl.sql = "SELECT * FROM JAN_GATE_LINES WHERE GATE_NO='" & txtgno.Text & "' AND VALIDATED NOT IN('0','4') and flag<>'0'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "RESULTAB")
        If ds.Tables("RESULTAB").Rows.Count = 0 Then

            ' ,hold_for_qc=case when (select count(*) from jan_gate_lines where hold_for_qc=1 and gate_no=" & txtgno.Text & ") >0 then 1 else 0 end 

            sql1 = "update jan_gate_HEADER set validated='0',VALIDATED_BY='" & cmbval.SelectedItem & "' where gate_no='" & txtgno.Text & "'"
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(sql1, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
        Else
            sql1 = "update jan_gate_HEADER set validated='2',VALIDATED_BY='" & cmbval.SelectedItem & "' where gate_no='" & txtgno.Text & "'"
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(sql1, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()

        End If

        cl.sql = "SELECT * FROM JAN_GATE_LINES WHERE GATE_NO='" & txtgno.Text & "' AND VALIDATED IN('4') "
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "RESULTAB")
        If ds.Tables("RESULTAB").Rows.Count <> 0 Then
            sql1 = "update jan_gate_HEADER set validated='4',VALIDATED_BY='" & cmbval.SelectedItem & "' where gate_no='" & txtgno.Text & "'"
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(sql1, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
        End If
        ''''''''''''''ON 11TH DEC
        cl.sql = "SELECT * FROM JAN_GATE_LINES WHERE GATE_NO='" & txtgno.Text & "' AND VALIDATED IN('5') "
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "RESULTAB")
        If ds.Tables("RESULTAB").Rows.Count <> 0 Then
            cl.sql = "update jan_gate_HEADER set validated='5',VALIDATED_BY='" & cmbval.SelectedItem & "' where gate_no='" & txtgno.Text & "'"
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
        End If
    End Sub
End Class