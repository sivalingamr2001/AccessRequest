Imports System.Data.OracleClient
Imports oracleclass
Public Class cancelentry
    Dim cl As New oracleclass.Class1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            sql = "update  jan_gate_header set reason='" & cmbrea.SelectedItem & "',rearef='" & txtref.Text & "' ,org='" & cmborg.SelectedItem & "' where gate_no=" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(1).Value & ""
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
            sql = "insert into jan_gatE_nval_reason (gate_no,rea_remark,rea_dt,flag,gdate,UNAME,rea_code,reason_date) values (" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(1).Value & ",'" & cmbrea.SelectedItem & "',sysdate,'1',sysdate"
            ' If txtrole.Text <> "UNIT2" Then

            sql &= ", '" & userid & "'"

            'Else
            '    sql &= ",'UNIT2'"
            'End If

            If cmbrea.SelectedItem = "Die DC" Or cmbrea.SelectedItem = "PO Open Challan" Or cmbrea.SelectedItem = "Unit II Bill" Or cmbrea.SelectedItem = "Double Entry" Or cmbrea.SelectedItem = "Rework Challan" Or cmbrea.SelectedItem = "Sample Materials" Or cmbrea.SelectedItem = "Unit IV Bill" Or cmbrea.SelectedItem = "Item Not Received" Then
                sql &= ",'21',sysdate)"
            ElseIf cmbrea.SelectedItem = "RTV" Then
                sql &= ",'4',sysdate)"
            Else
                sql &= ",'1',sysdate)"
            End If

            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
            sql = "select reason from jan_gatE_header where gatE_no=" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(1).Value & ""
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            Dim rea As String
                rea = ds.Tables("resultab").Rows(0).Item("reason").ToString
                If rea = "Die DC" Or rea = "PO Open Challan" Or rea = "Unit II Bill" Or rea = "Double Entry" Or rea = "Rework Challan" Or rea = "Sample Materials" Or rea = "Unit I Bill" Or rea = "Unit IV Bill" Or rea = "Item Not Received" Then
                sql = "update jan_gate_header set validated='5' where gate_no= " & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(1).Value & ""
            ElseIf rea = "RTV" Then
                sql = "update jan_gate_header set validated='4' where gate_no= " & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(1).Value & ""
            End If
            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
            cl.orcmd = New OracleCommand(sql, cl.oracon)
            cl.orcmd.ExecuteNonQuery()
            cl.oracon.Close()
            MessageBox.Show("Gate No Cancelled", "Gate Register")
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Private Sub cancelentry_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtrole.Text = Gate.txtrole.Text
        sql = "select organization_code  from org_organization_definitions where organization_id     in(" & orgid & " )order by organization_code"
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next

        sql = "SELECT REASON,REAREF,ORG FROM JAN_GAte_HEADER WHERE GATe_NO=" & Gate.dgv.Rows(Gate.dgv.CurrentRow.Index).Cells(1).Value & ""
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "RESULTAB")
        If ds1.Tables("RESULTAB").Rows.Count > 0 Then
            With ds1.Tables("RESULTAB").Rows(0)
                cmbrea.SelectedText = .Item("REASON").ToString
                txtref.Text = .Item("REAREF").ToString
                cmborg.SelectedText = .Item("ORG").ToString
            End With
        End If
    End Sub
End Class