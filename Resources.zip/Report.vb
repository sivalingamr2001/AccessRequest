Imports System.Data.OracleClient
Imports system.io
Public Class Report
    Dim sql, s, a, b, c, gdt, x, d As String
    Dim ds As New DataSet
    Dim adap As New oracleDataAdapter
    Dim i, j As Integer
    Dim fstrm As FileStream
    Dim sw As StreamWriter
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If RadioButton1.Checked = True Then
            sql = "select a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,a.gtype,A.ORG,b.rea_name,b.rea_remark  from jan_gate_header a,jan_gate_nval_reason b where a.gatE_no=b.gate_no and b.rea_code <>8 AND A.GDATE>='" & Format(dtfm.Value, "dd-MMM-yyyy") & "' AND A.GDATE<='" & Format(dtto.Value, "dd-MMM-yyyy") & "'"

            If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND A.UNIT='UNIT1'"
            If txtrole.Text = "UNIT2" Then sql &= " AND A.UNIT='UNIT2'"

            If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            If ds.Tables("resultab").Rows.Count <> 0 Then
                j = 0
                x = "c:\gate\GATE.HTML"
                fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
                sw = New StreamWriter(fstrm)

                s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & dtfm.Value & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Value & " || Org:" & cmborg.SelectedItem & "<br> Criteria :" & cmbval.SelectedItem & " </FONT></H2>"

                s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA CODE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA REMARK</FONT></TH></TR>"

                For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                    With ds.Tables("RESULTAB").Rows(i)
                        If ds.Tables("resultab").Rows(i).Item("rea_remark").ToString = "" Then a = "-"
                        If ds.Tables("resultab").Rows(i).Item("rea_remark").ToString <> "" Then a = ds.Tables("resultab").Rows(i).Item("rea_remark")
                        j = j + 1
                        s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & a & "</FONT></TD></TR>"
                    End With
                Next
                tail()
            End If
        ElseIf RadioButton2.Checked = True Then
            sql = "select a.gate_no,a.supplier_name,a.supplier_site,to_char(a.gdate)gdate,a.dc_no,a.dc_Date,A.VALIDATED,gtype, DECODE(A.VALIDATED,'0','VALIDATED','1','GATE','2','NOT VALIDATED','3','ACTION TAKEN','4','RTV')STATUS,a.org  from jan_gate_header a where a.gdate>='" & Format(dtfm.Value, "dd-MMM-yyyy") & "' and  a.gdate<='" & Format(dtto.Value, "dd-MMM-yyyy") & "' "

            If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND A.UNIT='UNIT1'"
            If txtrole.Text = "UNIT2" Then sql &= " AND A.UNIT='UNIT2'"
            If cmbval.SelectedItem = "Validated" Then sql &= " and validated='0'"
            If cmbval.SelectedItem = "Gate" Then sql &= " and validated='1'"
            If cmbval.SelectedItem = "Not Validated" Then sql &= " and validated='2'"
            If cmbval.SelectedItem = "Action Taken" Then sql &= " and validated='3'"
            If cmbval.SelectedItem = "RTV" Then sql &= " and validated='4'"

            If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            If ds.Tables("RESULTAB").Rows.Count <> 0 Then
                j = 0
                x = "c:\gate\GATE.HTML"
                fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
                sw = New StreamWriter(fstrm)

                s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & dtfm.Value & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Value & " || Org:" & cmborg.SelectedItem & "<br> Criteria :" & cmbval.SelectedItem & " </FONT></H2>"

                s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SITE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>STATUS</FONT></TH></TR>"

                For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                    With ds.Tables("RESULTAB").Rows(i)
                        j = j + 1
                        s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_SITE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("STATUS") & "</FONT></TD></TR>"
                    End With
                Next
                tail()
            End If
        End If
    End Sub

    Private Sub Report_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Gate.txtlog.Text = txtrole.Text
        sql = "select organization_code  from org_organization_definitions where organization_code  not in('I08','I09')order by organization_code"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub

    Private Sub po_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles po.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select a.gate_no,a.dc_no,a.dc_date,b.pono,b.podt,b.item,b.description,b.supdcqty,a.supplier_name,a.gdate,a.org,b.ratecat  from jan_gate_header a,jan_gatE_lines b where a.gate_no=b.gate_no and  a.gdate>=TO_DATE('" & Format(dtfm.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(dtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"
            'If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "USER" Then sql &= " AND A.UNIT='UNIT1'"
            If txtrole.Text = "UNIT2" Then sql &= " AND A.UNIT='UNIT2'" Else sql &= " AND A.UNIT='UNIT1'"
            If cmborg.SelectedItem <> "" Then sql &= " and b.org='" & cmborg.SelectedItem & "'"
            If rdpo.Checked = True Then sql &= " and a.gtype='PO'"
            If rdosp.Checked = True Then sql &= " and a.gtype='OSP'"

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")

            j = 0
            x = "c:\gate\GatePO.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & Format(dtfm.Value, "dd-MMM-yyyy") & " &nbsp;&nbsp;&nbsp;TO : " & Format(dtto.Value, "dd-MMM-yyyy") & " || Org:" & cmborg.SelectedItem & "<br> Gate Type :"
            If rdpo.Checked = True Then s &= "" & rdpo.Text & ""
            If rdosp.Checked = True Then s &= "" & rdosp.Text & ""

            s &= "</FONT></H2>"
            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>S.No</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Gate.No</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Gate.Date</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Org</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC.No</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC.Date</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PO.No</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>PO.Date</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Supplier</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Item</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Description</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC.Qty</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Rate Category</FONT></TH></TR>"
            Dim GATE, ID As String
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                With ds.Tables("resultab").Rows(i)
                    d = .Item("gate_no")
                    GATE = "&nbsp;"
                    ID = "&nbsp;"
                    s &= "<TR>"
                    If i - 1 <= ds.Tables("resultab").Rows.Count Then
                        If i <> 0 Then
                            Do Until d = ds.Tables("resultab").Rows(i - 1).Item("gate_no")
                                j = j + 1
                                ID = j
                                GATE = .Item("gate_no")
                                Exit Do
                            Loop
                        Else
                            j = j + 1
                            ID = j
                            GATE = .Item("gate_no")
                        End If
                    Else
                        j = j + 1
                        ID = j
                        GATE = .Item("gate_no")
                    End If
                    s &= "<td align=right><font face=verdana size=1>" & ID & "</td><td align=left><font face=verdana size=1>" & GATE & "</font></td>"
                    s &= "<td align=right><font face=verdana size=1>" & .Item("gdate") & "</font></td></td><Td align=right><font face=verdana size=1>" & .Item("org") & "</font></td><Td align=left><font face=verdana size=1>" & .Item("dc_no") & "</font></td><Td align=right><font face=verdana size=1>" & .Item("dc_date") & "</font></td><Td align=right><font face=verdana size=1>" & .Item("pono") & "</font></td><Td align=right><font face=verdana size=1>" & .Item("podt") & "</font></td><Td align=left><font face=verdana size=1>" & .Item("supplier_name") & "</font></td><Td align=item><font face=verdana size=1>" & .Item("item") & "</font></td><Td align=left><font face=verdana size=1>" & .Item("description") & "</td><Td align=right><font face=verdana size=1>" & .Item("supdcqty") & "</font></td><Td align=right><font face=verdana size=1>" & .Item("ratecat") & "</font></td></tr>"

                    If i + 1 <= ds.Tables("resultab").Rows.Count - 1 Then
                        If i = 0 Then
                            Do Until d = ds.Tables("resultab").Rows(i + 1).Item("gate_no")
                                s &= "<tr><td align=right>&nbsp;</td><td align=left>&nbsp;</td><td align=right>&nbsp;</td><td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td></tr>"
                                Exit Do
                            Loop
                        Else
                            Do Until d = ds.Tables("resultab").Rows(i + 1).Item("gate_no")
                                s &= "<tr><td align=right>&nbsp;</td><td align=left>&nbsp;</td><td align=right>&nbsp;</td><td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td></tr>"
                                Exit Do
                            Loop
                        End If
                    Else
                        s &= "<tr><td align=right>&nbsp;</td><td align=left>&nbsp;</td><td align=right>&nbsp;</td><td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td><Td align=right>&nbsp;</td></tr>"
                    End If
                End With
            Next
            tail()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        sql = "select gate_no,gdate,supplier_name,dc_no,dc_date,gtype,org from jan_Gate_header where validated='2' and  gdate>='" & Format(dtfm.Value, "dd-MMM-yyyy") & "'and gdate<='" & Format(dtto.Value, "dd-MMM-yyyy") & "'"
        If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND UNIT='UNIT1'"
        If txtrole.Text = "UNIT2" Then sql &= " AND UNIT='UNIT2'"
        If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"
        sql &= "order by gate_no"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        j = 0
        x = "c:\gate\GATE.HTML"
        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)

        s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & dtfm.Value & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Value & " || Org:" & cmborg.SelectedItem & "<br> Criteria :" & cmbval.SelectedItem & " </FONT></H2>"

        s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><tr><th><font face=verdana size=2>S.No</font></th><th><font face=verdana size=2>Gate.No</font></th><th><font face=verdana size=2>Gate.Dt</font></th><th><font face=verdana size=2>Supplier</font></th><th><font face=verdana size=2>Dc.No</font></th><th><font face=verdana size=2>DC.Dt</font></th><th><font face=verdana size=2>Gate.Type</font></th><th><font face=verdana size=2>Org</font></th></tr>"
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            j += 1
            With ds.Tables("resultab").Rows(i)
                s &= "<tr><td align=right><font face=verdana size=1>" & j & "</font></td> <td align=left><font face=verdana size=1>" & .Item("gate_no") & "</font></td><td align=left><font face=verdana size=1>" & .Item("gdate") & "</font></td><td align=leftt><font face=verdana size=1>" & .Item("supplier_name") & "</font></td><td align=left><font face=verdana size=1>" & .Item("dc_no") & "</font></td><td align=left><font face=verdana size=1>" & .Item("dc_date") & "</font></td><td align=left><font face=verdana size=1>" & .Item("gtype") & "</font></td><td align=left><font face=verdana size=1>" & .Item("org") & "</font></td></tr>"
            End With
        Next
        tail()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        sql = "select distinct a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,a.gtype,nvl(A.ORG,'-')org,nvl(b.rea_name,'-')rea_name,nvl(b.rea_remark,'-')rea_remark  from jan_gate_header a,jan_gate_nval_reason b where a.gatE_no=b.gate_no and a.validated='0' AND A.GDATE>='" & Format(dtfm.Value, "dd-MMM-yyyy") & "' AND A.GDATE<='" & Format(dtto.Value, "dd-MMM-yyyy") & "'"
        If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND A.UNIT='UNIT1'"
        If txtrole.Text = "UNIT2" Then sql &= " AND A.UNIT='UNIT2'"
        If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"

        sql &= " order by a.gate_no"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        If ds.Tables("resultab").Rows.Count <> 0 Then
            j = 0
            x = "c:\gate\GATE.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & dtfm.Value & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Value & " || Org:" & cmborg.SelectedItem & "<br> Criteria :" & cmbval.SelectedItem & " </FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA CODE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA REMARK</FONT></TH></TR>"

            For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                With ds.Tables("RESULTAB").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("rea_remark") & "</FONT></TD></TR>"
                End With
            Next
            tail()
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        sql = "select distinct a.gate_no,a.supplier_name,to_char(a.gdate)gdate,a.dc_no,a.dc_Date,gtype,DECODE(A.VALIDATED,'0','VALIDATED','1','GATE','2','NOT VALIDATED','3','ACTION TAKEN','4','RTV','5','Cancel Entry')STATUS,a.org, (Select substr(rea_dt,0,10) rea_dt from jan_gatE_nval_reason where gate_no=a.gate_no and rea_name in ('NO PROBLEM') and rownum=1) rea_dt"

        sql &= " from jan_gate_header a where a.gdate>='" & Format(dtfm.Value, "dd-MMM-yyyy") & "' and  a.gdate<='" & Format(dtto.Value, "dd-MMM-yyyy") & "' "

        If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND A.UNIT='UNIT1'"
        If txtrole.Text = "UNIT2" Then sql &= " AND A.UNIT='UNIT2'"
        If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        If ds.Tables("resultab").Rows.Count <> 0 Then
            j = 0
            x = "c:\gate\GATE.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & dtfm.Value & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Value & " || Org:" & cmborg.SelectedItem & "<br> Criteria :" & cmbval.SelectedItem & " </FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC.NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>STATUS</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>VALIDATED.DATE</FONT></TH></TR>"

            For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                With ds.Tables("RESULTAB").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("status") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("rea_dt") & "</FONT></TD></TR>"
                End With
            Next
            tail()
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprintnew.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select DISTINCT  a.gate_no,a.supplier_name,nvl(a.supplier_site,'-')supplier_site,to_char(a.gdate)gdate,a.dc_no,a.dc_Date,a.dcval,A.VALIDATED,nvl((case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) ,'PO') gtype, DECODE(A.VALIDATED,'0','VALIDATED','1','GATE','2','NOT VALIDATED','3','ACTION TAKEN','4','RTV','5','Cancel Entry','6','No Reference')STATUS,nvl(a.org,'-')org,NVL(DECODE(B.REA_CODE ,'8','NO PROBLEM',B.REA_NAME),'-') REA_NAME,NVL(b.rea_reMArk ,'-')REA_REMARK"

            If cmborg.SelectedItem = "I07" Then
                If rdpo.Checked = True Then
                    sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='PO' AND ROWNUM=1))),'-')DIV"
                ElseIf rdosp.Checked = True Then
                    sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='OSP' AND ROWNUM=1))),'-')DIV"
                ElseIf rdser.Checked = True Then
                    sql &= ",NVL((SELECT DESCRIPTION FROM JAN_PUR_cAT WHERE CAT_NO=(SELECT ATTRIBUTE1 FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=(SELECT POHEAD FROM JAN_GATe_LINES WHERE GATE_nO=A.GATE_NO AND TYPE='Services' AND ROWNUM=1))),'-')DIV"
                End If
            End If

            sql &= "  from jan_gate_header a,JAN_GATE_NVAL_REASON B  where A.GATE_NO=B.GATE_NO(+) AND  a.gdate>=TO_DATE('" & Format(dtfm.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(dtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and b.rea_name(+)<>'NO PROBLEM'"

            '  If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "USER" Then sql &= " AND A.UNIT='UNIT1'"
            If txtrole.Text = "UNIT2" Then sql &= " AND A.UNIT='UNIT2'" Else sql &= " AND A.UNIT='UNIT7'"
            If cmbval.SelectedItem = "Validated" Then sql &= " and validated='0'"
            If cmbval.SelectedItem = "Gate" Then sql &= " and validated='1' "
            If cmbval.SelectedItem = "Not Validated" Then sql &= " and validated='2'"
            If cmbval.SelectedItem = "Action Taken" Then sql &= " and validated='3'"
            If cmbval.SelectedItem = "RTV" Then sql &= " and validated='4'"
            If cmbval.SelectedItem = "Cancel Entry" Then sql &= " and validated='5'"
            If cmbval.SelectedItem = "No Reference" Then sql &= " and validated='6'"

            If cmbcat.SelectedItem <> "" Then sql &= " and inv_category='" & cmbcat.SelectedItem & "' "

            If cmbval.SelectedItem = "All" Then sql = sql

            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"

            If rdpo.Checked = True Then sql &= " and nvl((case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) ,'PO')='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='Services'"

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            j = 0
            x = "c:\gate\Gate.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & Format(dtfm.Value, "dd-MMM-yyyy") & " &nbsp;&nbsp;&nbsp;TO : " & Format(dtto.Value, "dd-MMM-yyyy") & " || Org:" & cmborg.SelectedItem & "<br> Criteria :" & cmbval.SelectedItem & " ||Gate Type: "

            If rdpo.Checked = True Then s &= "" & rdpo.Text & ""
            If rdosp.Checked = True Then s &= "" & rdosp.Text & ""
            If rdser.Checked = True Then s &= " " & rdser.Text & ""
            s &= "</FONT></H2>"
            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SITE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH>"
            If cmbval.SelectedItem = "Validated" Then s &= "<TH><FONT SIZE=1 FONT FACE=VERDANA>DC VAL</FONT></TH>"

            s &= "<TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH>"

            If cmborg.SelectedItem = "I07" Then s &= " <TH><FONT SIZE=1 FONT FACE=VERDANA>DIV</FONT></TH>"

            s &= "<TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>STATUS</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REASON</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REMARK</FONT></TH></TR>"

            For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                With ds.Tables("RESULTAB").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_SITE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD>"
                    If cmbval.SelectedItem = "Validated" Then s &= "<TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DCval") & "</FONT></TD>"

                    s &= "<TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD>"

                    If cmborg.SelectedItem = "I07" Then s &= "<TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("div") & "</FONT></TD>"

                    s &= " <TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("STATUS") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_REMARK") & "</FONT></TD></TR>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btngt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngt.Click

        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select * from (select  a.pono,b.pono rpono,a.gate_id ,(select organization_code from org_organization_definitions where organization_id=b.to_organization_id)org, (select gdate from jan_Gate_header where gatE_no=a.gatE_no)gdate,b.receipt_num  from jan_gate_lines a,"

            If rdpo.Checked = True Then sql &= "jan_pur_listing  b "
            If rdosp.Checked = True Then sql &= "jan_osp_listing  b "
            sql &= "where a.gate_id=b.gate_no and a.poline=b.po_line_id and b.quantity_received>0 "
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='OSP'"
            If cmborg.SelectedItem <> "" Then sql &= " and org='" & cmborg.SelectedItem & "'"
            ' If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " and org not like 'I01'"
            If txtrole.Text = "UNIT2" Then sql &= " and org  like 'I01'" Else sql &= " and org not like 'I01'"
            sql &= " order by a.gate_id) "
            sql &= " where gdate>=TO_DATE('" & Format(dtfm.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  gdate<=TO_DATE('" & Format(dtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            j = 0
            x = "c:\gate\Gate.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE + RECEIPT REPORT<BR>GATE DATE FROM :" & Format(dtfm.Value, "dd-MMM-yyyy") & " &nbsp;&nbsp;&nbsp;TO : " & Format(dtto.Value, "dd-MMM-yyyy") & " || Org:" & cmborg.SelectedItem & "<br> Gate Type: "
            If rdpo.Checked = True Then s &= "" & rdpo.Text & ""
            If rdosp.Checked = True Then s &= "" & rdosp.Text & ""
            s &= "</FONT></H2>"
            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DT</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.PO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>RECEIPT.PO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>RECEIPT .NO</FONT></TH></tr>"
            j = 0
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                j += 1
                With ds.Tables("resultab").Rows(i)
                    s &= "<tr> <td><FONT SIZE=1 FONT FACE=VERDANA> " & j & "</FONT></td><td><FONT SIZE=1 FONT FACE=VERDANA> " & .Item("org") & "</FONT></td><td><FONT SIZE=1 FONT FACE=VERDANA> " & .Item("gate_id") & "</FONT></td><td><FONT SIZE=1 FONT FACE=VERDANA> " & .Item("gdate") & "</FONT></td><td><FONT SIZE=1 FONT FACE=VERDANA> " & .Item("pono") & "</FONT></td><td><FONT SIZE=1 FONT FACE=VERDANA> " & .Item("rpono") & "</FONT></td><td><FONT SIZE=1 FONT FACE=VERDANA> " & .Item("receipt_num") & "</FONT></td> </tr>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub btnnval_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnval.Click

        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select DISTINCT a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-') org,nvl(b.rea_name,'-')rea_name,nvl(b.rea_remark,'-')rea_remark  "
            sql &= " from jan_gate_header a,jan_gate_nval_reason b where a.gatE_no=b.gate_no and a.validated in('2')and b.rea_code <>28 AND  a.gdate>=TO_DATE('" & Format(dtfm.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(dtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"
            ' If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND A.UNIT='UNIT1'"
            If txtrole.Text = "UNIT7" Then sql &= " AND A.UNIT='UNIT7'" Else sql &= " AND A.UNIT='UNIT1'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"
            'If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='PO'"
            'If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='OSP'"
            'If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='Services'"

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            j = 0
            x = "c:\gate\gate.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & dtfm.Value & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Value & " || Org:" & cmborg.SelectedItem & " <br> Gate Type: "
            If rdpo.Checked = True Then s &= "" & rdpo.Text & ""
            If rdosp.Checked = True Then s &= "" & rdosp.Text & ""
            If rdser.Checked = True Then s &= "" & rdser.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA CODE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA REMARK</FONT></TH></TR>"

            For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                With ds.Tables("RESULTAB").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("rea_remark") & "</FONT></TD></TR>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Public Sub tail()
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
    End Sub



    Private Sub btnnoref_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-') org,nvl(b.rea_name,'-')rea_name,nvl(b.rea_remark,'-')rea_remark  "
            sql &= " from jan_gate_header a,jan_gate_nval_reason b where a.gatE_no=b.gate_no and a.validated in('6')and b.rea_code <>8 AND  a.gdate>=TO_DATE('" & Format(dtfm.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(dtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"
            ' If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND A.UNIT='UNIT1'"
            If txtrole.Text = "UNIT2" Then sql &= " AND A.UNIT='UNIT2'" Else sql &= " AND A.UNIT='UNIT1'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"
            If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='PO'"
            If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='OSP'"
            If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='Services'"

            sql &= " order by a.gate_no"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            j = 0
            x = "c:\gate\gate.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>GATE ENTRY REPORT<BR>GATE DATE FROM :" & dtfm.Value & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Value & " || Org:" & cmborg.SelectedItem & " <br> Gate Type: "
            If rdpo.Checked = True Then s &= "" & rdpo.Text & ""
            If rdosp.Checked = True Then s &= "" & rdosp.Text & ""
            If rdser.Checked = True Then s &= "" & rdser.Text & ""
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA CODE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA REMARK</FONT></TH></TR>"

            For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                With ds.Tables("RESULTAB").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("rea_remark") & "</FONT></TD></TR>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub dtto_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtto.ValueChanged

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub dtfm_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtfm.ValueChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class