Imports System.Data.OracleClient
Imports System.IO
Public Class Status
    Dim r As String
    Dim WithEvents DoIt As New DoStuffClass

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Status_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If cl.oracon.State = ConnectionState.Closed Then
            cl.oracon.Open()
        End If
        sql = "select REPLACE(vendor_name,'''','''''')supplier,vendor_id from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' AND END_DATE_ACTIVE IS NULL "


        sql &= " AND VENDOR_ID IN (SELECT VENDOR_ID FROM PO_vENDOR_SITES_ALL WHERE ORG_ID=" & OP_ID & " AND INACTIVE_DATE IS NULL ) ORDER BY VENDOR_NAME "

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        cl.ds = New DataSet
        cl.oradap.Fill(cl.ds, "resultab")
        For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
            cmbsup.Items.Add(cl.ds.Tables("resultab").Rows(i).Item("supplier"))
        Next
        sql = "select organization_code  from org_organization_definitions where organization_id   in(" & orgid & " )order by organization_code"
        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
        sql = "select * from jan_gate_courier"
        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        adap.Fill(ds, "cr")
        For i = 0 To ds.Tables("cr").Rows.Count - 1
            cmbcr.Items.Add(ds.Tables("cr").Rows(i).Item("courier_name"))
        Next
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click


        sql = "select gate_no,gdate,dc_no,dc_Date,supplier_name,courier_name,pod_no,po_wt,no_of_box,rec_Wt,rec_wt_dt from jan_gatE_header where unit= '" & unit & "' and inv_category is null and gtype='PO'  and courier_name is not null and "

        sql &= " to_date(gdate)>='" & Format(inwdtf.Value, "dd-MMM-yyyy") & "' and to_date(gdate)<='" & Format(inwdtto.Value, "dd-MMM-yyyy") & "' "


        If cmbcr.SelectedItem <> "" Then sql &= " and courier_name ='" & cmbcr.Text & "' "

        sql &= " order by gate_no,supplier_name "

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "cr")

        Dim l As Integer

        s = ""
        s &= "<html><head><h4 align=center font face=Verdana>Receipt Report</h4><h4 align=center> DC Received Via Courier | From Dt:" & inwdtf.Text & "| To Dt:" & inwdtto.Text & "</head>"

        s &= "<TABLE border=1 cellspacing=0 cellpadding=2><tr> <td><FONT SIZE=2 font face=verdana>S.No</td> "
        For l = 0 To ds.Tables("cr").Columns.Count - 1
            With ds.Tables("cr").Columns(l)
                s &= "<td><FONT SIZE=2 font face=verdana>" & .ColumnName & "</td>  "
            End With

        Next

        s &= "</tr>"



        For k = 0 To ds.Tables("cr").Rows.Count - 1
            s &= "<tr><td><FONT SIZE=2 font face=verdana>" & k + 1 & "</td>"
            For l = 0 To ds.Tables("cr").Columns.Count - 1


                With ds.Tables("cr").Rows(k)
                    If .Item(l).ToString = "" Then
                        s &= " <td><FONT SIZE=2 font face=verdana>&nbsp;"
                    Else
                        s &= " <td><FONT SIZE=2 font face=verdana>" & .Item(l) & "  "

                    End If
                End With

            Next

            s &= "</tr>"

        Next

        s &= "</table></html>"

        x = "d:\receipt\rec_pend.HTML "



        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        sql = "select  Gate_no , GDate, (SELECT LISTAGG   ( distinct org, ', ' ) WITHIN GROUP (ORDER BY line_no) from jan_gate_lines where gate_no=a.gate_no )org, supplier_name, supplier_site, (select registration_number from  JAN_GST_REG_DETAILS_VIEW where PARTY_CLASS_NAME='Supplier' AND REGISTRATION_TYPE_CODE='GSTIN' and rownum=1   "

        'ADDED on 28-nov-2020

        sql &= " And org_id = " & OP_ID & " "


        sql &= " And party_id=a.vendor_id  And PARTY_SITE_ID=(Select VENDOR_SITE_ID FROM PO_VENDOR_SITES_ALL WHERE VENDOR_SITE_CODE=A.SUPPLIER_SITE And inactive_Date Is null "

        'ADDED on 28-nov-2020

        sql &= " And org_id=" & OP_ID & " "


        sql &= " And vendor_id=a.vendor_id))gst,dc_no,dc_date , gType ,(Select count(*) from jan_gate_lines where gate_no=a.gate_no) no_of_lines, case when (SELECT  COUNT(*)  FROM jan_vendor_item_master_Temp1 xx,jan_gate_lines bb   WHERE sourcing_percent >0 and xx.self_Certified=1   AND  gcs_from_Date is not null and vendor_id=a.vendor_id and xx.org_id=bb.org_id and inventory_item_id=JAN_ITEMNO(BB.ITEM) and gate_no=a.gate_no) >0 then 'GCS DC' else ''end gcs, responsible_person,( select listagg(distinct  rea_name, ', ' )WITHIN GROUP (ORDER BY line_no)  from jan_gate_nval_reason where gate_no= a.gate_no  and rea_code<>28  )reason_for_notvalidate,( select min(reason_Date) from jan_gate_nval_reason where gate_no= a.gate_no  and rea_code<>28  ) notvalidate_Date , case when validated=0 then 'Validated' when validated=2 then 'Not Validated' when validated=1 then 'Gate' when validated=4 then 'RTV' when validated=6 then 'No Reference' end    Status ,''Remark,(select max(reason_Date) from jan_gate_nval_reason where gate_no=a.gate_no and rea_code=28) validated_on,validated_by,eway_no,(select checked_by from jan_gate_lines where gate_no=a.gate_no and rownum=1 and checked_by is not null)checked_by,dcval , ( select LISTAGG   ( receipt_num, ', ' ) WITHIN GROUP (ORDER BY packing_slip) from rcv_shipment_headers where packing_slip=  a.gate_id   )receipt_no   from jan_gate_header a where unit='" & unit & "' and  gDATE>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and gDATE<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and inv_Category is null"



        If txtrole.Text = "POVIEW" Then sql &= " and gate_no in (select gate_no from jan_gate_lines xx where upper((SELECT DESCRIPTION FROM JAN_PUR_CAT WHERE rownum=1 and  CAT_NO=   nvl( nvl( (SELECT ATTRIBUTE1  FROM PO_HEADERS_ALL WHERE PO_HEADER_ID=xx.POHEAD), (SELECT ATTRIBUTE8  FROM PO_lines_ALL WHERE PO_line_ID=xx.POline)) , (SELECT ATTRIBUTE15  FROM PO_line_locationS_ALL WHERE line_location_ID=xx.location_id))))  like 'EDP%') "


        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "cr")

        Dim l As Integer

        s = ""
        s &= "<html><head> <h4 align=center> Gate Report | From Dt:" & inwdtf.Text & "| To Dt:" & inwdtto.Text & "</head>"

        s &= "<TABLE border=1 cellspacing=0 cellpadding=2><tr> <td><FONT SIZE=2 font face=verdana>S.No</td> "
        For l = 0 To ds.Tables("cr").Columns.Count - 1
            With ds.Tables("cr").Columns(l)
                s &= "<td><FONT SIZE=2 font face=verdana>" & .ColumnName & "</td>  "
            End With

        Next

        s &= "</tr>"



        For k = 0 To ds.Tables("cr").Rows.Count - 1
            s &= "<tr><td><FONT SIZE=2 font face=verdana>" & k + 1 & "</td>"
            For l = 0 To ds.Tables("cr").Columns.Count - 1


                With ds.Tables("cr").Rows(k)
                    If .Item(l).ToString = "" Then
                        s &= " <td><FONT SIZE=2 font face=verdana>&nbsp;"
                    Else
                        s &= " <td><FONT SIZE=2 font face=verdana>" & .Item(l) & "  "

                    End If
                End With

            Next

            s &= "</tr>"

        Next

        s &= "</table></html>"

        x = "d:\receipt\rec_pend.HTML "



        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
        Me.Cursor = Cursors.Arrow





    End Sub

    Private Sub inwdtf_ValueChanged(sender As Object, e As EventArgs) Handles inwdtf.ValueChanged

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub inwdtto_ValueChanged(sender As Object, e As EventArgs) Handles inwdtto.ValueChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            sql = "select DISTINCT a.gate_no,a.gdate,a.supplier_name,a.dc_no,a.dc_date,(case when (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0) is not  null then (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_NO=A.GATE_NO and rownum=1 and flag<>0)  else a. gtype end ) gtype,nvl(A.ORG,'-') org,nvl(b.rea_name,'-')rea_name,nvl(b.rea_remark,'-')rea_remark ,A.validated_by ,B.reason_Date ,(select checked_by from jan_gate_lines where gate_no=a.gate_no AND ROWNUM=1)checked_by  "
            sql &= " from jan_gate_header a,jan_gate_nval_reason b where a.gatE_no=b.gate_no and a.validated in(2) and b.rea_code <>28 AND  a.gdate>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

            sql &= " and A.unit='" & unit & "'"


            ' If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Then sql &= " AND A.UNIT='UNIT1'"
            ' If txtrole.Text = "UNIT7" Then sql &= " AND A.UNIT='UNIT7'" Else sql &= " AND A.UNIT='UNIT1'"
            If cmborg.SelectedItem <> "" Then sql &= " and a.org='" & cmborg.SelectedItem & "'"
            'If rdpo.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='PO'"
            'If rdosp.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='OSP'"
            'If rdser.Checked = True Then sql &= " and (SELECT DECODE(POTYPE,'Services',potype,type) from jan_gate_lines  WHERE GATe_id=A.GATE_id and rownum=1)='Services'"

            sql &= " order by a.gate_no"
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")
            j = 0
            x = "c:\gate\not validate.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)

            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Not Validate Report<BR>GATE DATE FROM :" & inwdtf.Value & " &nbsp;&nbsp;&nbsp;TO : " & inwdtto.Value & " || Org:" & cmborg.SelectedItem & " <br> Gate Type: "

            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC DATE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>GATE TYPE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA CODE</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>REA REMARK</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Checked By</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Validated By</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Validate Dt</FONT></TH></TR>"

            For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
                With ds.Tables("RESULTAB").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("org") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GTYPE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("REA_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("rea_remark") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("checked_by") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("validated_by") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("reason_Date") & "</FONT></TD></TR>"
                End With
            Next
            tail()
            Me.Cursor = Cursors.Arrow
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Public Sub tail()
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        sql = "select  a.Gate_no , a.GDate,  supplier_name, supplier_site, dc_no,dc_date , A.gType , case when A.validated=0 then 'Validated' when A.validated=2 then 'Not Validated' when A.validated=1 then 'Gate' when A.validated=4 then 'RTV' when A.validated=6 then 'No Reference' end    Status ,''Remark,(select max(reason_Date) from jan_gate_nval_reason where gate_no=a.gate_no and rea_code=28) validated_on,validated_by,(select checked_by from jan_gate_lines where gate_no=a.gate_no and rownum=1 and checked_by is not null)checked_by,rowtocol('select receipt_num from rcv_shipment_headers where packing_slip='''||a.gate_id||'''' )receipt_no,b.item,b.supdcqty qty ,jan_orgcode(org_id)org,substr(rowtocol('select location from jan_item_vs_locator where inventory_item_id =jan_itemno('''|| b.item|| ''' ) and organization_id= '||b.org_id|| '' ),0,35) location from jan_gate_header a ,jan_gate_lines b  where a.gate_no=b.gate_no and a.unit='" & unit & "' and  a.gDATE>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and a.gDATE<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and inv_Category is null"

        If cmbsup.SelectedItem <> "" Then sql &= " and  a.VENDOR_ID=JAN_VENDORNO('" & cmbsup.SelectedItem.ToString.Replace("'", "''") & "') "





        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "cr")

        Dim l As Integer

        s = ""
        s &= "<html><head> <h4 align=center> Gate Report | From Dt:" & inwdtf.Text & "| To Dt:" & inwdtto.Text & "</head>"

        s &= "<TABLE border=1 cellspacing=0 cellpadding=2><tr> <td><FONT SIZE=2 font face=verdana>S.No</td> "
        For l = 0 To ds.Tables("cr").Columns.Count - 1
            With ds.Tables("cr").Columns(l)
                s &= "<td><FONT SIZE=2 font face=verdana>" & .ColumnName & "</td>  "
            End With

        Next

        s &= "</tr>"



        For k = 0 To ds.Tables("cr").Rows.Count - 1
            s &= "<tr><td><FONT SIZE=2 font face=verdana>" & k + 1 & "</td>"
            For l = 0 To ds.Tables("cr").Columns.Count - 1


                With ds.Tables("cr").Rows(k)
                    If .Item(l).ToString = "" Then
                        s &= " <td><FONT SIZE=2 font face=verdana>&nbsp;"
                    Else
                        s &= " <td><FONT SIZE=2 font face=verdana>" & .Item(l) & "  "

                    End If
                End With

            Next

            s &= "</tr>"

        Next

        s &= "</table></html>"

        x = "d:\receipt\rec_pend.HTML "



        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
        Me.Cursor = Cursors.Arrow

    End Sub

    Private Sub btn_short_Click(sender As Object, e As EventArgs) Handles btn_short.Click
        sql = "select  a.Gate_no , a.GDate, a.shortage_form_no, supplier_name, supplier_site, dc_no,dc_date , A.gType , case when A.validated=0 then 'Validated' when A.validated=2 then 'Not Validated' when A.validated=1 then 'Gate' when A.validated=4 then 'RTV' when A.validated=6 then 'No Reference' end    Status ,''Remark,(select max(reason_Date) from jan_gate_nval_reason where gate_no=a.gate_no and rea_code=28) validated_on,validated_by,(select checked_by from jan_gate_lines where gate_no=a.gate_no and rownum=1 and checked_by is not null)checked_by,rowtocol('select receipt_num from rcv_shipment_headers where packing_slip='''||a.gate_id||'''' )receipt_no,b.item,b.supdcqty qty ,jan_orgcode(org_id)org,b.shortage_Qty,  round(b.shortage_Qty* case when a.gtype='OSP' then nvl((select sum(stg_mtl_cost) from jan_wip_materials where entity_id=b.wip_entity_id) ,0)
+ nvl((select  stage_cost from jan_osp_Rate_all_view x where vendor_id=a.vendor_id and part_no=b.item
and  (osp_no,bom_revision) in (select jan_itemname(item_id),(select bom_revision from wip_discrete_jobs where wip_entity_id= b.wip_entity_id )
from po_lines_all y where po_line_id=b.poline) and  (TRUNC(SYSDATE)<=TRUNC(TO_dATE(x.end_date_ACTIVE,'YYYY/MM/DD HH24:MI:SS '))
OR x.end_date_ACTIVE  IS NULL and  TRUNC(sysdate) >= TRUNC(TO_DATE(x.start_date_ACTIVE, 'YYYY/MM/DD HH24:MI:SS ')))    ),0) when a.gtype='PO' then 
(select unit_price from po_lines_all where po_line_id=b.poline and rownum=1)  end ,0)    to_bedebit_value   from jan_gate_header a ,jan_gate_lines b  where a.gate_no=b.gate_no and a.unit='" & unit & "' and  a.gDATE>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and a.gDATE<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and inv_Category is null and shortage_Qty > 0 "

        If cmbsup.SelectedItem <> "" Then sql &= " and  a.VENDOR_ID=JAN_VENDORNO('" & cmbsup.SelectedItem.ToString.Replace("'", "''") & "') "

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "cr")

        Dim l As Integer

        s = ""
        s &= "<html><head> <h4 align=center> Gate Report | From Dt:" & inwdtf.Text & "| To Dt:" & inwdtto.Text & "</head>"

        s &= "<TABLE border=1 cellspacing=0 cellpadding=2><tr> <td><FONT SIZE=2 font face=verdana>S.No</td> "
        For l = 0 To ds.Tables("cr").Columns.Count - 1
            With ds.Tables("cr").Columns(l)
                s &= "<td><FONT SIZE=2 font face=verdana>" & .ColumnName & "</td>  "
            End With

        Next

        s &= "</tr>"



        For k = 0 To ds.Tables("cr").Rows.Count - 1
            s &= "<tr><td><FONT SIZE=2 font face=verdana>" & k + 1 & "</td>"
            For l = 0 To ds.Tables("cr").Columns.Count - 1


                With ds.Tables("cr").Rows(k)
                    If .Item(l).ToString = "" Then
                        s &= " <td><FONT SIZE=2 font face=verdana>&nbsp;"
                    Else
                        s &= " <td><FONT SIZE=2 font face=verdana>" & .Item(l) & "  "

                    End If
                End With

            Next

            s &= "</tr>"

        Next

        s &= "</table></html>"

        x = "d:\receipt\gate_shortage.HTML "



        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
End Class