Imports System.Data.OracleClient
Public Class gatelist

    Dim sql As String
    Dim ds As New DataSet
    Dim adap As New oracleDataAdapter
    Dim cc As New DataGridViewTextBoxColumn

    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Try
            If txtpo.Text <> "" And txtitem.Text <> "" Then
                dgv1.Columns.Clear()
                dgv2.Columns.Clear()
                dgv3.Columns.Clear()

                If rd1.Checked = True Then
                    sql = "select  gate_no,receipt_num,receipt_date,pono,podt,item_description,quantity_received,qty_appd,inv_no from jan_pur_listing where pono='" & txtpo.Text & "' and item_no='" & txtitem.Text & "' order by gate_no"
                    cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                    ds = New DataSet
                    cl.oradap.Fill(ds, "resultab")
                    bind()
                    dgv1.DataSource = ds.Tables("resultab")
                    sql = "select description,pono,podt,po_qty,recd,po_pend,gate_receipt from jan_po_pending_bought_outs where pono='" & txtpo.Text & "' and item_no='" & txtitem.Text & "'"
                    cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                    ds = New DataSet
                    cl.oradap.Fill(ds, "resultab")
                    bind1()
                    dgv2.DataSource = ds.Tables("resultab")
                    sql = "select gatE_no,pono,podt,description,popend,supdcqty from jan_gatE_lines where type='PO' and   pono='" & txtpo.Text & "' and item='" & txtitem.Text & "' and flag='1' order by gate_no"
                    cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                    ds = New DataSet
                    cl.oradap.Fill(ds, "resultab")
                    bind2()
                    dgv3.DataSource = ds.Tables("resultab")
                ElseIf rd2.Checked = True Then
                    sql = "select gate_no,receipt_num,receipt_date,pono,podt,partname as item_description,quantity_received,qty_appd,inv_no from jan_osp_listing where pono='" & txtpo.Text & "' and partno='" & txtitem.Text & "' order by gate_no"
                    cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                    ds = New DataSet
                    cl.oradap.Fill(ds, "resultab")
                    bind()
                    dgv1.DataSource = ds.Tables("resultab")
                    sql = "select partname as description,pono,podt,po_qty,recd,po_pend,gate_receipt from jan_po_pending_osp where partno='" & txtitem.Text & " ' and pono='" & txtpo.Text & "' "
                    cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                    ds = New DataSet
                    cl.oradap.Fill(ds, "resultab")
                    bind1()
                    dgv2.DataSource = ds.Tables("resultab")
                    sql = "select gate_no,pono,podt,description,popend,supdcqty from jan_gatE_lines where type='OSP' and  pono='" & txtpo.Text & "' and item='" & txtitem.Text & "' and flag='1' order by gate_no"
                    cl.oradap = New OracleDataAdapter(sql, cl.oracon)
                    ds = New DataSet
                    cl.oradap.Fill(ds, "resultab")
                    bind2()
                    dgv3.DataSource = ds.Tables("resultab")
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            CON.Close()
        End Try
    End Sub
    Public Sub bind()
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Gate.No"
        cc.DataPropertyName = "gate_no"
        cc.Width = 60
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Receipt.No"
        cc.DataPropertyName = "receipt_num"
        cc.Width = 80
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Receipt.Dt"
        cc.DataPropertyName = "receipt_date"
        cc.Width = 70
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Po.No"
        cc.DataPropertyName = "pono"
        cc.Width = 80
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Po.Dt"
        cc.DataPropertyName = "podt"
        cc.Width = 70
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Description"
        cc.DataPropertyName = "item_description"
        cc.Width = 160
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Recd"
        cc.DataPropertyName = "quantity_received"
        cc.Width = 40
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Appd"
        cc.DataPropertyName = "qty_appd"
        cc.Width = 40
        Me.dgv1.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Inv.No"
        cc.DataPropertyName = "inv_no"
        cc.Width = 50
        Me.dgv1.Columns.Add(cc)
    End Sub
    Public Sub bind1()
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Description"
        cc.DataPropertyName = "description"
        cc.Width = 160
        Me.dgv2.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Po.No"
        cc.DataPropertyName = "pono"
        cc.Width = 80
        Me.dgv2.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Po.Dt"
        cc.DataPropertyName = "podt"
        cc.Width = 70
        Me.dgv2.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Po.Qty"
        cc.DataPropertyName = "po_qty"
        cc.Width = 50
        Me.dgv2.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Recd"
        cc.DataPropertyName = "recd"
        cc.Width = 50
        Me.dgv2.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "PoPend"
        cc.DataPropertyName = "po_pend"
        cc.Width = 50
        Me.dgv2.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Gate.Recpt"
        cc.DataPropertyName = "gate_receipt"
        cc.Width = 70
        Me.dgv2.Columns.Add(cc)
    End Sub
    Public Sub bind2()
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Gate.No"
        cc.DataPropertyName = "gate_no"
        cc.Width = 70
        Me.dgv3.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Description"
        cc.DataPropertyName = "description"
        cc.Width = 160
        Me.dgv3.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Po.No"
        cc.DataPropertyName = "pono"
        cc.Width = 80
        Me.dgv3.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "Po.Dt"
        cc.DataPropertyName = "podt"
        cc.Width = 80
        Me.dgv3.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "PoPend"
        cc.DataPropertyName = "popend"
        cc.Width = 50
        Me.dgv3.Columns.Add(cc)
        cc = New DataGridViewTextBoxColumn
        cc.HeaderText = "DcQty"
        cc.DataPropertyName = "supdcqty"
        cc.Width = 50
        Me.dgv3.Columns.Add(cc)
    End Sub
End Class