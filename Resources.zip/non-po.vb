Imports System.Data.OracleClient
Imports System.IO
Imports oracleclass

Public Class non_po

    Dim gid As Int64
    Dim cl As New oracleclass.Class1
    Dim IDS As String

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click


        cl.sql = "SELECT TO_CHAR(JAN_FYR_DATE,'yyyy') FROM DUAL"
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.oradap = New OracleDataAdapter((cl.orcmd))
        ds = New DataSet
        cl.oradap.Fill(ds, "ID")
        IDS = ds.Tables("ID").Rows(0).Item(0)

        If unit = "UNIT7" And gtpur = "Entry" Then
            Dim dsID As New DataSet

            If chkogt.Checked = False Then
                cl.sql = "select jan_GATE_NO_SEQ.NEXTVAL FROM DUAL"
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter(cl.orcmd)
                cl.oradap.Fill(dsID, "resultab")

                txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item(0)
            Else
                txtgno.Text = txtogno.Text
            End If

        ElseIf unit = "POLYMER" And gtpur = "Entry" Then
            If chkogt.Checked = False Then

                'Dim GT As Integer

                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='POLYMER'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    Dim ID As String
                    ID = String.Concat(IDS, "13000", 1)
                    txtgno.Text = ID
                End If
            Else
                txtgno.Text = txtogno.Text
            End If



        ElseIf unit = "SKYFAST" And gtpur = "Entry" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='SKYFAST'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    If txtrole.Text = "SKYFAST" Or txtrole.Text = "SKY_ADD" Then ID = String.Concat(IDS, "9000", 1) Else ID = String.Concat(IDS, "000", 1)
                    txtgno.Text = ID
                End If
            Else
                txtgno.Text = txtogno.Text
            End If

        ElseIf unit = "UNIT1" And gtpur = "Entry" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='UNIT1'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    'If txtrole.Text = "SKYFAST" Then IDS = String.Concat(IDS, 5)
                    'If txtrole.Text = "UNIT4" Then IDS = String.Concat(IDS, 4)
                    Dim ID As String
                    ID = String.Concat(IDS, "10000", 1)
                    txtgno.Text = ID
                End If

            Else
                txtgno.Text = txtogno.Text
            End If


        ElseIf unit = "SPM" And gtpur = "Entry" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='SPM'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter(cl.orcmd)
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    Dim ID As String
                    ID = String.Concat(IDS, "17000", 1)
                    txtgno.Text = ID
                End If
            Else
                txtgno.Text = txtogno.Text
            End If


        ElseIf unit = "COIL" And gtpur = "Entry" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='COIL'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    Dim ID As String
                    ID = String.Concat(IDS, "80000", 1)
                    txtgno.Text = ID
                End If
            Else
                txtgno.Text = txtogno.Text
            End If

        ElseIf unit = "GLOBAL" Then
            If chkogt.Checked = False Then
                cl.sql = "select NVL(MAX(gate_no),0)GATE_NO from jan_gate_header WHERE UNIT='GLOBAL'  AND GDATE>JAN_FYR_DATE "
                cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
                cl.oradap = New OracleDataAdapter((cl.orcmd))
                Dim dsID As New DataSet
                cl.oradap.Fill(dsID, "resultab")
                If dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") <> 0 Then
                    txtgno.Text = dsID.Tables("RESULTAB").Rows(0).Item("GATE_NO") + 1
                Else
                    Dim ID As String
                    ID = String.Concat(IDS, "15000", 1)
                    txtgno.Text = ID
                End If
            Else
                txtgno.Text = txtogno.Text
            End If
        End If

        ''''checking dcno

        cl.sql = "select COUNT(*) CNT from jan_gate_header where supplier_name='" & cmbsup.Text.ToString.Replace("'", "''") & "'   and  gdate BETWEEN JAN_FYR_DATE AND JAN_FYR_END_DATE  AND DC_NO='" & txtdcno.Text & "'  "

        cl.sql &= " And UNIT= '" & unit & "'"


        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")
        If ds.Tables("resultab").Rows.Count <> 0 Then
            ' For i = 0 To ds.Tables("resultab").Rows.Count - 1
            If ds.Tables("resultab").Rows(0).Item(0) > 0 Then
                MessageBox.Show("DCNo already available for the supplier", "Gate Entry")
                Exit Sub
            End If
            '  Next
        End If

        If cmbcat.SelectedIndex = 0 And txtbin.Text = "" Then
            MessageBox.Show("Enter Bin Qty and Proceed", "Gate Entry")
            Exit Sub
        End If

        Dim d As Date
        d = Date.Today
        sql = "insert into jan_gate_header(gate_no,gate_id,supplier_name,vendor_id, dc_no,dc_date,validated, gdate,vehicle_det"

        sql &= " ,unit,flag ,inv_category,responsible_person"


        sql &= " ,responsible_dept ,transport_mode,person_name "

        If cmbcat.SelectedIndex = 0 And txtbin.Text <> "" Then

            sql &= " ,bin_qty "
        End If


        sql &= " ) values(" & txtgno.Text & ",'" & txtgno.Text & "',"

        If chknon.Checked = False Then sql &= "  '" & cmbsup.Text & "', " & cmbsup.SelectedValue & "  ," Else sql &= "  '" & txtsup.Text & "', '' ,"

        sql &= " '" & txtdcno.Text & "','" & Format(dtdc.Value, "dd-MMM-yyyy") & "',1"

        If chkogt.Checked = True Then sql &= ",(select gate_Dt from jan_gate_del where gate_no=" & txtogno.Text & " and rownum=1)" Else sql &= ",sysdate"

        sql &= ",'" & txtveh.Text & "'"

        sql &= " , '" & unit & "'"

        sql &= ",1,'" & cmbcat.Text & "'  "

        If txtper.Visible = True Then
            sql &= " ,'" & txtper.Text & "'  "
        Else
            sql &= " ,'" & cmbres.Text & "'  "
        End If

        sql &= ",'" & ddldept.Text & "','" & ddltranp.Text & "','" & txtjper.Text & "' "

        If cmbcat.SelectedIndex = 0 And txtbin.Text <> "" Then

            sql &= " ," & txtbin.Text & ""

        End If

        sql &= " )"

        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        MessageBox.Show("Saved Successfully !!-Gate Number is: " & txtgno.Text & "", "Gate Entry")
        clear()


    End Sub

    Private Sub clear()
        txtdcno.Text = ""
        txtveh.Text = ""
        txtsup.Text = ""
        cmbcat.SelectedIndex = -1
        cmbsup.SelectedIndex = -1
    End Sub
    Private Sub non_po_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        sql = "select REPLACE(vendor_name,'''','''''')VENDOR_NAME,vendor_id from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' AND END_DATE_ACTIVE IS NULL "


        sql &= " AND VENDOR_ID IN (SELECT VENDOR_ID FROM PO_vENDOR_SITES_ALL WHERE ORG_ID=" & OP_ID & " AND INACTIVE_DATE IS NULL )"

        sql &= " union "

        sql &= " select REPLACE(customer_name,'''','''''')VENDOR_NAME,customer_id from ra_customers"

        sql &= " order by vendor_name asc"

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "resultab")
        cmbsup.DisplayMember = "vendor_name"
        cmbsup.ValueMember = "vendor_id"
        cmbsup.DataSource = ds1.Tables("resultab")

        If unit.Contains("SPM") = True Then
            cmbres.Visible = True
            txtper.Visible = False
            cl.sql = "select description from jan_open_challan_Category where cat_for_gate=1 and live_Flag=1"

            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "resultab")
            cmbres.DisplayMember = "description"
            cmbres.ValueMember = "description"
            cmbres.DataSource = ds1.Tables("resultab")
        Else
            cmbres.Visible = False
            txtper.Visible = True
        End If

        sql = "select description from jan_open_challan_Category where org_id=" & OP_ID & " and live_Flag=1 "

        If unit = "UNIT7" Then sql &= " UNION ALL select  distinct  company_name  from jan_gate_login where unit_name not like '%UNIT7%' AND company_name  is not null "

        If OP_ID = 584 Then
            sql &= " and CAT_FOR_GATE=1 and unit_name='" & unit & "'"
        End If


        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        adap.Fill(ds, "resultab")
        Dim dv As New DataView
        dv = ds.Tables(0).DefaultView
        dv.Sort = "description asc"

        Dim dt As New DataTable
        dt = dv.ToTable
        ds.Tables.Clear()
        ds.Tables.Add(dt)
        ds.AcceptChanges()
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            ddldept.Items.Add(ds.Tables("resultab").Rows(i).Item("description").ToString.Replace("'", "''"))
        Next
        Dim arrayList = tr_mode.Split(",")
        For Each value As String In arrayList
            ddltranp.Items.Add(value)
        Next

        ' If txtrole.Text = "UNIT7" Or txtrole.Text = "U7_ADD" Then
        chkogt.Visible = True
            txtogno.Visible = True
            Label5.Visible = True

        ' End If
    End Sub

    Private Sub chknon_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chknon.CheckedChanged
        If chknon.Checked = True Then
            txtsup.Visible = True
            cmbsup.Visible = False
        Else
            txtsup.Visible = False
            cmbsup.Visible = True

        End If
    End Sub

    Private Sub btnrep_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnrep.Click
        Panel1.Visible = True

    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        sql = " select gate_no,gdate,supplier_name,dc_no,dc_date,vehicle_det,inv_category ,responsible_dept ,transport_mode from jan_gate_header a where inv_category is not null and a.gdate>=TO_DATE('" & Format(dtfm.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(dtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS')"

        If txtgno.Text <> "" Then
            sql &= " and gate_no=" & txtgno.Text & ""
        End If
        sql &= " AND UNIT='" & unit & "'"

        cl.oradap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "res")


        x = "c:\gate\Non Po Inward.HTML"
        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)


        If txtgno.Text <> "" Then

            s = "<html>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800 height=50%><TR><Td colspan=2 align=center><FONT SIZE=6 FONT FACE=VERDANA>Non Po Inward List</FONT></Td><Td colspan=2 align=right><FONT SIZE=2 FONT FACE=VERDANA><img src='f:/oa/logo2.jpg'/></FONT></Td>  </TR>"

            s &= " <TR><Td><FONT SIZE=3 FONT FACE=VERDANA>Gate No</FONT></Td> <td><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("gatE_no") & " </td> <Td ><FONT SIZE=3 FONT FACE=VERDANA>Gate DT</FONT></Td> <td><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("gdate") & " </td> </TR>"

            s &= " <TR><Td><FONT SIZE=3 FONT FACE=VERDANA>Inward Category</FONT></Td> <td colspan=3><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("inv_category") & " </td>   </TR>"

            s &= " <TR><Td><FONT SIZE=3 FONT FACE=VERDANA>DC NO</FONT></Td> <td><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("dc_no") & " </td>    <Td ><FONT SIZE=3 FONT FACE=VERDANA>DC DT</FONT></Td> <td><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("dc_Date") & " </td></TR>"

            s &= " <TR><Td><FONT SIZE=3 FONT FACE=VERDANA>Supplier Name </FONT></Td> <td colspan=3><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("supplier_name").ToString() & " </td>   </TR>"

            s &= " <TR><Td><FONT SIZE=3 FONT FACE=VERDANA>Vehicle Responsible Person Details </FONT></Td> <td colspan=3><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("vehicle_Det") & " </td>   </TR>"

            s &= " <TR><Td><FONT SIZE=3 FONT FACE=VERDANA>Vehicle Responsible Dept</FONT></Td> <td colspan=3><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("responsible_Dept") & " </td>   </TR>"

            s &= " <TR><Td><FONT SIZE=3 FONT FACE=VERDANA>Transport Details </FONT></Td> <td colspan=3><FONT SIZE=3 FONT FACE=VERDANA> " & ds.Tables("res").Rows(0).Item("transport_mode") & " </td>   </TR>"
        Else
            s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Non Po Inward List<BR>GATE DATE FROM :" & Format(dtfm.Value, "dd-MMM-yyyy") & " &nbsp;&nbsp;&nbsp;TO : " & Format(dtto.Value, "dd-MMM-yyyy") & "  "

            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=1 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Gate NO</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Gate.Date</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Supplier</FONT></TH> </TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC No</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>DC Date</FONT></TH>"

            s &= "<TH><FONT SIZE=1 FONT FACE=VERDANA>Vehicle Details</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>Category</FONT></TH> <TH><FONT SIZE=1 FONT FACE=VERDANA>RESPONSIBLE DEPT</FONT></TH><TH><FONT SIZE=1 FONT FACE=VERDANA>TRANSPORT DETAILS</FONT></TH></TR>"

            For i = 0 To ds.Tables("res").Rows.Count - 1
                With ds.Tables("res").Rows(i)
                    j = j + 1
                    s &= "<TR><TD><FONT SIZE=1 FONT FACE=VERDANA>" & j & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GATE_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("GDATE") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("SUPPLIER_NAME") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_NO") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("DC_DATE") & "</FONT></TD> <TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("vehicle_Det") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("inv_category") & "</FONT></TD><TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("RESPONSIBLE_DEPT") & "</FONT></TD> <TD><FONT SIZE=1 FONT FACE=VERDANA>" & .Item("TRANSPORT_MODE") & "</FONT></TD></TR>"
                End With
            Next
        End If
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
        Panel1.Visible = False


    End Sub

    Private Sub txtogno_Leave(sender As Object, e As EventArgs) Handles txtogno.Leave

        cl.sql = "select vehicle_Det from jan_gate_del where gate_no=" & txtogno.Text & " and rownum=1"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "vno")

        If ds.Tables("vno").Rows.Count > 0 Then
            txtveh.Text = ds.Tables("vno").Rows(0).Item(0)
        End If

    End Sub
End Class