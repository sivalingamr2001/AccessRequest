Imports System.Data.OracleClient
Imports System.IO

Public Class direct_delivery

    Dim dr As DataView
    Dim r As String

    Dim conn As New OleDb.OleDbConnection("provider=sqloledb;workstation id=59.160.116.114;packet size=4096;user id=scm;password=scm#$sql2007;data source=59.160.116.114;persist security info=False;initial catalog=SCM")
    Private Sub direct_delivery_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "select vendor_name from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' order by vendor_name asc"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet()
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbven.Items.Add(ds.Tables("resultab").Rows(i).Item("vendor_name").ToString.Replace("'", "''"))
        Next
        sql = "select organization_code  from org_organization_definitions where organization_id not in(105,112 )order by organization_code"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
        Next
    End Sub

    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click

        'sql = "select "
        ' sql = "select jan_orgcodE(organization_id)org,item_no,item_description,jobno,(select creation_date from wip_entities where wip_entity_id=a.wip_entity_id)job_Dt,released_qty,cur_opn,(select segment1 from po_headers_all where po_header_id=a.po_header_id)pono,(select creation_date from po_headers_all where po_header_id=a.po_header_id)podt,(select jan_challan_no from jan_osp_regular_challan_mast where wip_entity_id=a.wip_entity_id and jan_operation_sequence=a.cur_opn)challan_no, (select creation_date from jan_osp_regular_challan_mast where wip_entity_id=a.wip_entity_id and jan_operation_sequence=a.cur_opn)challan_dt,(select gate_no from jan_gate_lines where wip_entity_id=a.wip_entity_id and opn_seq=a.cur_opn)gate_no,(select gdate  from jan_gate_lines where wip_entity_id=a.wip_entity_id and opn_seq=a.cur_opn)gate_dt, (select receipt_num from rcv_shipment_headers where packing_slip=(select gate_id from jan_gate_lines where wip_entity_id=a.wip_entity_id and opn_seq=a.cur_opn))receipt_num, (select creation_date from rcv_shipment_headers where packing_slip=(select gate_id from jan_gate_lines where wip_entity_id=a.wip_entity_id and opn_seq=a.cur_opn))receipt_dt,(select sum(qty_appd) from jan_osp_listing_test where wip_entity_id=a.wip_entity_id and wip_operation_Seq_num=a.cur_opn)insp_qty,(select insp_dt from jan_osp_listing_test where wip_entity_id=a.wip_entity_id and wip_operation_Seq_num=a.cur_opn) insp_dt ,ROWTOCOL('select dept_id from (select operation_seq_num,lead(department_id) over (order by operation_seq_num)dept_id from wip_operations where wip_entity_id=' || A.WIP_ENTITY_ID || ') xx  where operation_seq_num= ' || a.cur_opn) next_opn  from jan_outward_req_mis a where ITEM_NO in  ('610016','434001','414223','314051')AND status_type=3 "ROWTOCOL('select dept_id from (select operation_seq_num,lead(department_id) over (order by operation_seq_num)dept_id from wip_operations where wip_entity_id=' || A.WIP_ENTITY_ID || ') xx  where operation_seq_num= ' || a.cur_opn) next_opn,ROWTOCOL('select dept_id from (select operation_seq_num,lag(department_id) over (order by operation_seq_num)dept_id from wip_operations where wip_entity_id=' || A.WIP_ENTITY_ID || ') xx  where operation_seq_num= ' || a.cur_opn) prev_opn,
        '"

        '   sql &="and stage_date >=TO_DATE('" & Format(dtfrm.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and stage_date <=TO_DATE('" & Format(dtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and status_type=3 "

        sql = "select jan_orgcodE(a.organization_id)org,item_no,item_description, (select wip_entity_name from wip_entities where wip_entity_id=b.wip_entity_id)jobno,(select creation_date from wip_entities where wip_entity_id=b.wip_entity_id)job_Dt, (select start_quantity from wip_discrete_jobs where wip_entity_id=b.wip_entity_id)released_qty,b.opn_Seq,(select DISTINCT segment1 from po_headers_all xx,po_distributions_all yy,PO_LINE_LOCATIONS_ALL ZZ where  wip_entity_id=b.wip_entity_id and wip_operation_seq_num=b.opn_seq and xx.po_header_id=yy.po_header_id AND ZZ.CANCEL_FLAG IS NULL AND ZZ.PO_HEADER_ID=YY.PO_HEADER_ID AND XX.PO_HEADER_ID=YY.PO_HEADER_ID AND ROWNUM=1)pono,(select jan_challan_no from jan_osp_regular_challan_mast where wip_entity_id=b.wip_entity_id and jan_operation_sequence=b.opn_Seq)challan_no,0 adi_no,"

        sql &= "  (select gh.gate_no from jan_gate_lines gl,jan_gate_header gh where wip_entity_id=b.wip_entity_id and opn_seq=b.opn_Seq AND ROWNUM=1 and gl.gate_no=gh.gate_no and adi_type="

        If RDAPP.Checked = True Then sql &= " 'Approved'" Else sql &= "'Rejected'"

        sql &= " )gate_no,"

        sql &= " (select receipt_num from rcv_shipment_headers where ROWNUM=1 AND packing_slip=(select gl.gate_id from jan_gate_lines gl,jan_gate_header gh where wip_entity_id=b.wip_entity_id and opn_seq=b.opn_Seq AND ROWNUM=1 AND gl.gate_no=gh.gate_no and  adi_type="

        If RDAPP.Checked = True Then sql &= " 'Approved'" Else sql &= "'Rejected'"


        sql &= " ))receipt_num, "

        '   sql &= " case when nvl((select sum(qty_appd) from jan_osp_listing_test where wip_entity_id=b.wip_entity_id and wip_operation_Seq_num=b.opn_seq),0)=0 then nvl((select sum(qty_appd) from jan_osp_listing where wip_entity_id=b.wip_entity_id and po_header_id=(select DISTINCT xx.po_header_id from po_headers_all xx,po_distributions_all yy ,PO_LINE_LOCATIONS_ALL ZZ where  wip_entity_id=b.wip_entity_id and ROWNUM=1 AND  wip_operation_seq_num=b.opn_seq and xx.po_header_id=yy.po_header_id AND ZZ.CANCEL_FLAG IS NULL AND ZZ.PO_HEADER_ID=YY.PO_HEADER_ID AND XX.PO_HEADER_ID=YY.PO_HEADER_ID )),0) else nvl((select sum(qty_appd) from jan_osp_listing_test where wip_entity_id=b.wip_entity_id and wip_operation_Seq_num=b.opn_seq),0) end insp_qty"
        'sql &= "NVL((select sum(qty_appd) from jan_osp_listing WHERE RECEIPT_NUM=(select receipt_num from rcv_shipment_headers where packing_slip=(select gl.gate_id from jan_gate_lines gl,jan_gate_header gh where wip_entity_id=b.wip_entity_id and opn_seq=b.opn_Seq AND ROWNUM=1 AND gl.gate_no=gh.gate_no and  adi_type="

        'If RDAPP.Checked = True Then sql &= " 'Approved'" Else sql &= "'Rejected'"


        'sql &= " AND WIP_ENTITY_ID=b.WIP_ENTITY_ID AND PO_HEADER_ID=(select DISTINCT XX.PO_HEADER_ID from po_headers_all xx,po_distributions_all yy,PO_LINE_LOCATIONS_ALL ZZ where  wip_entity_id=b.wip_entity_id and wip_operation_seq_num=b.opn_seq and xx.po_header_id=yy.po_header_id AND ZZ.CANCEL_FLAG IS NULL AND ZZ.PO_HEADER_ID=YY.PO_HEADER_ID AND XX.PO_HEADER_ID=YY.PO_HEADER_ID AND ROWNUM=1)))),0) QTY_APPD"

        sql &= "NVL((SELECT SUM(QTY_APPD) FROM jan_osp_listing WHERE RECEIPT_NUM=(SELECT receipt_num  FROM rcv_shipment_headers  WHERE ROWNUM=1 AND packing_slip=(SELECT gl.gate_id FROM jan_gate_lines gl, jan_gate_header gh  WHERE wip_entity_id = b.WIP_ENTITY_ID  AND opn_seq =B.OPN_sEQ AND ROWNUM =1 AND gl.gate_no     =gh.gate_no AND adi_type       = "
        If RDAPP.Checked = True Then sql &= " 'Approved'" Else sql &= "'Rejected' "

        sql &= " ) )AND wip_entity_id=B.WIP_ENTITY_ID AND PO_HEADER_ID= (SELECT   XX.PO_HEADER_ID   FROM po_headers_all xx,po_distributions_all yy,  PO_LINE_LOCATIONS_ALL ZZ  WHERE wip_entity_id = b.WIP_ENTITY_ID  AND wip_operation_seq_num=B.OPN_sEQ AND xx.po_header_id=yy.po_header_id AND ZZ.CANCEL_FLAG IS NULL AND ZZ.PO_HEADER_ID =YY.PO_HEADER_ID AND XX.PO_HEADER_ID =YY.PO_HEADER_ID AND ROWNUM =1  )),0) QTY_APPD"


        sql &= " ,(select  vendor_name from po_vendors where vendor_id=b.vendor_id)ven, (SELECT DEPARTMENT_ID FROM WIP_OPERATIONS WHERE WIP_ENTITY_ID=b.WIP_ENTITY_ID AND NEXT_OPERATION_SEQ_NUM=b.opn_Seq)pre,(SELECT DEPARTMENT_ID FROM WIP_OPERATIONS WHERE WIP_ENTITY_ID=b.WIP_ENTITY_ID AND PREVIOUS_OPERATION_SEQ_NUM=b.opn_Seq)next_opn ,b.wip_entity_id,b.vendor_id,"

        sql &= "(SELECT VALIDATED FROM JAN_GATE_HEADER WHERE adi_type="

        If RDAPP.Checked = True Then sql &= "'Approved'" Else sql &= "'Rejected'"


        sql &= " and GATE_NO=(select gate_no from jan_gate_lines where wip_entity_id=b.wip_entity_id and opn_seq=b.opn_Seq  AND SPOT_INSPECTION IS NOT NULL AND ROWNUM=1 ))VAL  "


        sql &= " from jan_outward_priority a,jan_outward_vendor_entry b  where a.osp_id=b.osp_id AND A.live_flag=1  AND DIRECT_DLYD_FLG='Y'  "

        If cmborg.Text <> "" Then sql &= " and a.organization_id=jan_orgid('" & cmborg.Text & "')"

        If txtitem.Text <> "" Then sql &= " and a.item_no='" & txtitem.Text & "'"

        If cmbven.Text <> "" Then sql &= " and b.vendor_id=jan_vendorno('" & cmbven.Text & "')"

        If cmbcri.SelectedIndex = 1 Then sql &= " and stage=8 "

        If cmbcri.SelectedIndex = 2 Then sql &= " and stage=10  "



        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "resultab")
        DV = ds.Tables("resultab").DefaultView

        'DV.RowFilter = " next_opn in (519,520,521,522,523)"
        DV.Sort = " item_no,wip_entity_id,opn_seq asc"



        For i = 0 To DV.Count - 1

            If RDAPP.Checked = True Then
                DV(i)("adi_no") = SCMRETVAL("select asn_no from jan_gate_lines_v where job='" & DV(i)("jobno") & "' and oper='" & DV(i)("opn_Seq") & "' and adi_type IN ('All','Approved')")
            Else
                DV(i)("adi_no") = SCMRETVAL("select asn_no from jan_gate_lines_v where job='" & DV(i)("jobno") & "' and oper='" & DV(i)("opn_Seq") & "' and adi_type IN ('Rejected')")
            End If

            If DV(i)("adi_no") = "0" Then
                DV(i)("adi_no") = DBNull.Value
            End If
        Next

        If cmbcri.SelectedIndex = 0 Then
            DV.RowFilter = "ADI_NO IS NOT NULL AND GATE_NO IS NULL"
        End If


        With dgv1
            .DataSource = DV
            .Columns(0).HeaderText = "Org" : .Columns(0).Width = 30
            '.Columns(1).HeaderText = "Item No" : .Columns(1).Width = 80
            '.Columns(2).HeaderText = "Description" : .Columns(2).Width = 100
            '.Columns(3).HeaderText = "Job No" : .Columns(3).Width = 80
            '.Columns(4).HeaderText = "Job Dt" : .Columns(4).Width = 80
            '.Columns(5).HeaderText = "Qty" : .Columns(5).Width = 30 : .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            '.Columns(6).HeaderText = "Opn" : .Columns(6).Width = 30
            '.Columns(7).HeaderText = "Po No" : .Columns(7).Width = 80
            '.Columns(8).HeaderText = "Po Dt" : .Columns(8).Width = 80
            '.Columns(9).HeaderText = "Challan No" : .Columns(9).Width = 80
            '.Columns(10).HeaderText = "Challan Dt" : .Columns(10).Width = 80
            '.Columns(11).HeaderText = "Gate No" : .Columns(11).Width = 80
            '.Columns(12).HeaderText = "Gate Dt" : .Columns(12).Width = 80
            '.Columns(13).HeaderText = "Receipt No" : .Columns(13).Width = 80
            '.Columns(14).HeaderText = "Receipt Dt" : .Columns(14).Width = 80
            '.Columns(15).HeaderText = "Insp Qty" : .Columns(15).Width = 30 : .Columns(15).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            '.Columns(16).HeaderText = "Insp Dt" : .Columns(16).Width = 80
            '.Columns(17).Visible = False


            .Columns(1).HeaderText = "Item No" : .Columns(1).Width = 80
            .Columns(2).HeaderText = "Description" : .Columns(2).Width = 100
            .Columns(3).HeaderText = "Job No" : .Columns(3).Width = 85
            .Columns(4).HeaderText = "Job Dt" : .Columns(4).Width = 80
            .Columns(5).HeaderText = "Qty" : .Columns(5).Width = 40 : .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight : .Columns(5).Frozen = True
            .Columns(6).HeaderText = "Opn" : .Columns(6).Width = 40
            .Columns(7).HeaderText = "Po No" : .Columns(7).Width = 75

            .Columns(8).HeaderText = "Challan No" : .Columns(8).Width = 75

            .Columns(9).HeaderText = "ADI No" : .Columns(9).Width = 60
            .Columns(10).HeaderText = "Gate No" : .Columns(10).Width = 60

            .Columns(11).HeaderText = "Receipt No" : .Columns(11).Width = 75

            .Columns(12).HeaderText = "Insp Qty" : .Columns(12).Width = 40 : .Columns(12).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            .Columns(13).HeaderText = "Vendor" : .Columns(13).Width = 170
            .Columns(14).Visible = False : .Columns(17).Visible = False : .Columns(15).Visible = False : .Columns(16).Visible = False : .Columns(18).Visible = False

        End With




    End Sub
    Public Sub tail()
        s = s & "</table></html>"
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

      

        s = "<html><H2 ALIGN=CENTER><FONT SIZE=2 FONT FACE=VERDANA>Direct Delivery In-Progress List<BR>GATE DATE FROM :" & dtfrm.Text & " &nbsp;&nbsp;&nbsp;TO : " & dtto.Text & " "

        s &= "</FONT></H2>"

        s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=600><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>S.No</FONT></TH><TH ><FONT SIZE=2 FONT FACE=VERDANA>Org</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Item No/ Desc</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Job.No/Job.Dt</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Qty</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Opn Seq</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Po.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Challan.no</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>ADI No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Gate.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Receipt.No</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>Insp.Qty</FONT></TH><TH ><FONT SIZE=2 FONT FACE=VERDANA>Vendor</FONT></TH></TR>"


        j = 0

        'Dim DV As DataView
        'DV = ds.Tables("resultab").DefaultView
        'DV.RowFilter = "receipt_num is null"

        'ds.Tables("resultab").AcceptChanges()


        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            With ds.Tables("resultab").Rows(i)
                j += 1
                ' s &= " <TR><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & j & "</FONT></Td><Td ><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("Org") & "</FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>'" & .Item("Item_No") & " <br> " & .Item("item_description") & "</FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("JobNo") & " <br> " & .Item("job_dt") & "</FONT></Td><Td align=right><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("released_Qty") & " </FONT></Td><Td align=right><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("cur_opn") & " </FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("pono") & "<br>" & .Item("podt") & " </FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("Challan_no") & "<br> " & .Item("challan_dt") & "</FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("Gate_No") & " <br>" & .Item("gate_dt") & " </FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("receipt_num") & " <br>" & .Item("receipt_dt") & " </FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("insp_qty") & "<br>Dt</FONT></Td></TR>"

                s &= " <TR><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & j & "</FONT></Td><Td ><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("Org") & "</FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>'" & .Item("Item_No") & " <br> " & .Item("item_description") & "</FONT></Td><Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("JobNo") & " <br> " & .Item("job_dt") & "</FONT></Td><Td align=right><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("released_Qty") & " </FONT></Td><Td align=right><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("opn_seq") & " </FONT></Td>"

                If IsDBNull(.Item("pono")) Then s &= " <Td><FONT SIZE=1.5 FONT FACE=VERDANA>&nbsp;</FONT></Td>" Else s &= " <Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("pono") & "</FONT></Td>"

                If IsDBNull(.Item("Challan_no")) Then s &= " <Td><FONT SIZE=1.5 FONT FACE=VERDANA>&nbsp;</FONT></Td>" Else s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("Challan_no") & "</FONT></Td>"

                If IsDBNull(.Item("adi_no")) Then s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>&nbsp;</FONT></Td>" Else s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("adi_no") & "  </FONT></Td>"

                If IsDBNull(.Item("Gate_No")) Then s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>&nbsp;</FONT></Td>" Else s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("Gate_No") & "  </FONT></Td>"


                If IsDBNull(.Item("receipt_num")) Then s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>&nbsp;</FONT></Td>" Else s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("receipt_num") & " </FONT></Td>"

                If IsDBNull(.Item("insp_qty")) Then s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>&nbsp;</FONT></Td>" Else s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("insp_qty") & "</FONT></Td>"

                s &= "<Td><FONT SIZE=1.5 FONT FACE=VERDANA>" & .Item("ven") & " </FONT></Td>"

                s &= "</TR>"


            End With
        Next
        x = "c:\gate\direct delivery Report.HTML"
        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        tail()

    End Sub

    Private Sub dgv1_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgv1.CellFormatting

        If dgv1.Rows.Count >= 1 Then

            With dgv1.Rows(e.RowIndex)

                If Not IsDBNull(.Cells(7).Value) Then
                    .Cells(7).Style.BackColor = Color.ForestGreen
                    .Cells(7).Style.SelectionBackColor = Color.ForestGreen
                    .Cells(7).Style.ForeColor = Color.White
                Else
                    .Cells(7).Style.BackColor = Color.DarkRed
                    .Cells(7).Style.SelectionBackColor = Color.DarkRed
                    .Cells(7).Style.ForeColor = Color.White
                End If

                If Not IsDBNull(.Cells(8).Value) Then
                    .Cells(8).Style.BackColor = Color.ForestGreen
                    .Cells(8).Style.SelectionBackColor = Color.ForestGreen
                    .Cells(8).Style.ForeColor = Color.White
                Else
                    .Cells(8).Style.BackColor = Color.DarkRed
                    .Cells(8).Style.SelectionBackColor = Color.DarkRed
                    .Cells(8).Style.ForeColor = Color.White
                End If


                If Not IsDBNull(.Cells(9).Value) Then
                    .Cells(9).Style.BackColor = Color.ForestGreen
                    .Cells(9).Style.SelectionBackColor = Color.ForestGreen
                    .Cells(9).Style.ForeColor = Color.White
                 
                Else
                    .Cells(9).Style.BackColor = Color.DarkRed
                    .Cells(9).Style.SelectionBackColor = Color.DarkRed
                    .Cells(9).Style.ForeColor = Color.White
                End If

                If Not IsDBNull(.Cells(10).Value) Then
                    .Cells(10).Style.BackColor = Color.ForestGreen
                    .Cells(10).Style.SelectionBackColor = Color.ForestGreen
                    .Cells(10).Style.ForeColor = Color.White

                Else
                    .Cells(10).Style.BackColor = Color.DarkRed
                    .Cells(10).Style.SelectionBackColor = Color.DarkRed
                    .Cells(10).Style.ForeColor = Color.White
                End If

                If Not IsDBNull(.Cells(11).Value) Then
                    .Cells(11).Style.BackColor = Color.ForestGreen
                    .Cells(11).Style.SelectionBackColor = Color.ForestGreen
                    .Cells(11).Style.ForeColor = Color.White

                Else
                    .Cells(11).Style.BackColor = Color.DarkRed
                    .Cells(11).Style.SelectionBackColor = Color.DarkRed
                    .Cells(11).Style.ForeColor = Color.White
                End If

                If .Cells(12).Value > 0 Then
                    .Cells(12).Style.BackColor = Color.ForestGreen
                    .Cells(12).Style.SelectionBackColor = Color.ForestGreen
                    .Cells(12).Style.ForeColor = Color.White

                Else
                    .Cells(12).Style.BackColor = Color.DarkRed
                    .Cells(12).Style.SelectionBackColor = Color.DarkRed
                    .Cells(12).Style.ForeColor = Color.White

                End If

                If Not IsDBNull(.Cells(17).Value) Then
                    If .Cells(17).Value = 2 Then
                        .Cells(10).Style.BackColor = Color.Yellow
                        .Cells(10).Style.SelectionBackColor = Color.Yellow
                        .Cells(10).Style.ForeColor = Color.Black
                    ElseIf .Cells(17).Value = 0 Then
                        .Cells(10).Style.BackColor = Color.ForestGreen
                        .Cells(10).Style.SelectionBackColor = Color.ForestGreen
                        .Cells(10).Style.ForeColor = Color.White
                    End If
                Else
                    .Cells(10).Style.BackColor = Color.DarkRed
                    .Cells(10).Style.SelectionBackColor = Color.DarkRed
                    .Cells(10).Style.ForeColor = Color.White
                End If
            End With
        End If
    End Sub
End Class