Imports System.Data.OracleClient
Imports oracleclass
Public Class GateUpdate

    Dim cl As New oracleclass.Class1
    Private Sub btnupdt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdt.Click
        Me.Cursor = Cursors.WaitCursor

        If cmbcat.SelectedItem <> "" Then

            cl.sql = "update jan_gate_header set inv_Category='" & cmbcat.Text & "' where gate_no=" & txtgate.Text & " "
            func()
        End If

        If txtqty.Text <> "" Then

            cl.sql = "update jan_gate_lines set "

            If txtrole.Text = "U7_VIEW" Then
                cl.sql &= "shortage_qty ='" & txtqty.Text & "' "
            Else
                cl.sql &= " supdcqty ='" & txtqty.Text & "' ,popend='" & txtqty.Text & "' ,actval='" & txtqty.Text & "'"
            End If

            cl.sql &= " where gate_no=" & txtgate.Text & " and line_no='" & txtline.Text & "'"

            func()
        End If

        If txtwt.Text <> "" Then
            cl.sql = " update jan_gate_header set rec_Wt =" & txtwt.Text & ",rec_wt_Dt =sysdate  where gate_no=" & txtgate.Text & ""
            func()

        End If

        If cmbcr.SelectedItem <> "" Then
            cl.sql = " update jan_gate_header set courier_name ='" & cmbcr.Text & "'  where gate_no=" & txtgate.Text & ""
            func()
        End If

        If txtpod.Text <> "" Then
            cl.sql = " update jan_gate_header set pod_no =" & txtpod.Text & ",po_wt =" & txtpodwt.Text & "  where gate_no=" & txtgate.Text & ""
            func()

        End If

        If unit.Contains("SPM") = True And cmbres.Text <> "" Then
            cl.sql = "update jan_gate_header set responsible_person ='" & cmbres.Text & "' where gate_no='" & txtgate.Text & "'"
            func()
        End If
        MessageBox.Show("Gate Value Updated", " Gate Register")
        clear()
        Me.Cursor = Cursors.Arrow
    End Sub
    Public Sub func()
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
    End Sub
    Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click

        Me.Cursor = Cursors.WaitCursor

        cl.sql = "select receipt_num from rcv_shipment_headers where packing_slip='" & txtgate.Text & "'"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        Dim dar As OracleDataReader
        dar = (cl.orcmd).ExecuteReader

        If (dar.HasRows = True) Then
            MessageBox.Show("Receipt Made,Gate Can't be updated", "Gate Register")
            Exit Sub
        Else

            cl.sql = "SELECT * FROM JAN_GATe_LINES WHERE GATE_NO=" & txtgate.Text & ""
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "RESULTAB")
            'For i = 0 To ds.Tables("RESULTAB").Rows.Count - 1
            '    sql = "SELECT  *  FROM JAN_INWARD_STATUS WHERE  GATE_NO=" & txtgate.Text & " AND ITEM_NO='" & ds.Tables("RESULTAB").Rows(i).Item("ITEM") & "' AND PO_LINE='" & ds.Tables("RESULTAB").Rows(i).Item("POLINE") & "'"
            '    cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            '    Dim DSITEM As New DataSet
            '    cl.oradap.Fill(DSITEM, "RESULTAB")
            '    If DSITEM.Tables("RESULTAB").Rows.Count > 0 Then
            '        sql = "DELETE FROM JAN_INWARD_STATUS WHERE GATE_NO=" & txtgate.Text & " AND ITEM_NO='" & DSITEM.Tables("RESULTAB").Rows(0).Item("ITEM_no") & "' AND PO_LINE='" & DSITEM.Tables("RESULTAB").Rows(0).Item("PO_LINE") & "'"
            '        func()
            '    End If
            'Next

            '''' query for penalty checking

            'sql = "select * from jan_gatE_header where gate_no=" & txtgate.Text & " and validated=6"
            'ds = New DataSet
            'cl.oradap.Fill(ds, "RESULTAB")
            'If ds.Tables("RESULTAB").Rows.Count > 0 Then

            cl.sql = "INSERT INTO jan_gate_del  (GATE_NO,LINE_NO,REASON,DELDATE,GATE_DT,VEHICLE_DET,courier_name ,pod_no,pod_wt ,no_of_box ,rec_wt,eway_bill   ,del_For,no_ref_flag) VALUES(" & txtgate.Text & ",'','No reference-for penalty',sysdate,(select gdate from jan_gate_header where gate_no=" & txtgate.Text & "),(select vehicle_Det from jan_gate_header where gate_no=" & txtgate.Text & "),(select courier_name from jan_gate_header where gate_no=" & txtgate.Text & "),(select pod_no from jan_gate_header where gate_no=" & txtgate.Text & "),(select po_wt from jan_gate_header where gate_no=" & txtgate.Text & "),(select no_of_box from jan_gate_header where gate_no=" & txtgate.Text & "),(select rec_wt from jan_gate_header where gate_no=" & txtgate.Text & "),(select eway_no from jan_gate_header where gate_no=" & txtgate.Text & "),  'Header',case when (select count(*) from jan_gate_header where gate_no=" & txtgate.Text & " and validated=6)>0 then 1 else 0 end   )"
            func()

            sql = "select count(*) from jan_gate_lines where checked_by is not null  and gate_no=" & txtgate.Text & ""
            cl.oradap = New OracleDataAdapter(sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "cnt")

            If ds1.Tables("cnt").Rows(0).Item(0) > 0 Then
                cl.sql = "INSERT INTO jan_gate_del  (GATE_NO ,org_id,item_location,del_For,item_checked_Dt,item_check_start,checked_by )  select distinct " & txtgate.Text & ",org_id,item_location,'Lines',item_checked_Dt,item_check_start,checked_by   from jan_gate_lines where gate_no= " & txtgate.Text & " and rownum=1 and checked_by is not null "
                func()

            End If

            '  End If

            '''' end of query for penalty checking

            cl.sql = "delete from jan_gate_lines where gate_no='" & txtgate.Text & "'"
            func()
            cl.sql = "delete from jan_gate_nval_reason where gate_no= '" & txtgate.Text & "'"
            func()
            cl.sql = "delete from jan_gate_header where gate_no= '" & txtgate.Text & "'"
            func()
            MessageBox.Show("Gate No:  " & txtgate.Text & "deleted", "Gate Register")
            txtgate.Text = ""
            Me.Cursor = Cursors.Arrow

        End If

    End Sub
    Public Sub clear()
        txtgate.Text = ""
        txtline.Text = ""
        txtqty.Text = ""
    End Sub

    Private Sub GateUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If txtrole.Text = "U7_ADD" Then
            txtqty.ReadOnly = True
            txtline.ReadOnly = True
            btndel.Visible = False
        End If

        If txtrole.Text = "U7_VIEW" Then
            btndel.Visible = False
            Label3.Text = "Shortage Qty"
            Label4.Visible = False
            txtwt.Visible = False
        End If

        If unit.Contains("SPM") = True Then
            cmbres.Visible = True
            Label25.Visible = True
            cl.sql = "select description from jan_open_challan_Category where CAT_FOR_GATE=1 and live_Flag=1"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            cl.ds = New DataSet
            cl.oradap.Fill(cl.ds, "resultab")
            For i = 0 To cl.ds.Tables("resultab").Rows.Count - 1
                cmbres.Items.Add(cl.ds.Tables("resultab").Rows(i).Item("description"))
            Next
        Else
            cmbres.Visible = False
            Label25.Visible = False
        End If

        sql = "select * from jan_gate_courier"
        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet()
        adap.Fill(ds, "cr")
        For i = 0 To ds.Tables("cr").Rows.Count - 1
            cmbcr.Items.Add(ds.Tables("cr").Rows(i).Item("courier_name"))
        Next
    End Sub

End Class