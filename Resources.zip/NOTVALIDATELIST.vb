Imports System.Data.OracleClient
Imports System.IO
Public Class NOTVALIDATELIST

    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        Try
            Dim s As String
            dgvdetails.Columns.Clear()
            Me.Cursor = Cursors.WaitCursor
            sql = "  SELECT A.GATE_NO,A.GDATE,A.SUPPLIER_NAME,B.REA_NAME,(SELECT rowtocol('SELECT DISTINCT org from JAN_gate_lines WHERE gate_NO = '''|| A.gate_NO||'''') from dual)org, "

            sql &= "(SELECT COUNT(ITEM) FROM JAN_GATe_LINES WHERE GATE_NO=A.GATE_NO ) ITEM,round((sysdate-a.gdate),0)   FROM JAN_GATe_HEADER A ,JAN_GATe_NVAL_REASON B  "

            sql &= " WHERE a.GATe_NO = b.GATe_NO And a.VALIDATED = 2  AND B.REA_NAME <>'NO PROBLEM' "

            If cmbsup.SelectedItem <> "" Then sql &= " and supplier_name='" & cmbsup.SelectedItem.ToString.Replace("',", "") & "'"

            If txtqpfm.Text <> "" And txtqpto.Text <> "" Then sql &= "  and a.gdate>='" & txtqpfm.Text & "' and a.gdate<='" & txtqpto.Text & "'"

            sql &= "order by a.gate_no "

            If cmborg.SelectedItem <> "" Then s = sql : sql = " select * from( " & s & " )  where  org='" & cmborg.SelectedItem & "'"


            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            With dgvdetails
                .DataSource = ds.Tables("resultab")
                .Columns(0).HeaderText = "Gate.No" : .Columns(0).Width = 70
                .Columns(1).HeaderText = "Gate.Dt" : .Columns(1).Width = 120
                .Columns(2).HeaderText = "Supplier.Name" : .Columns(2).Width = 220
                .Columns(3).HeaderText = "Reason" : .Columns(3).Width = 200
                .Columns(4).HeaderText = "Org" : .Columns(4).Width = 35
                .Columns(5).HeaderText = "Pending Item" : .Columns(5).Width = 70 : .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns(6).HeaderText = "No.Off Days" : .Columns(6).Width = 70 : .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End With
            Me.Cursor = Cursors.Arrow



        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub

    Private Sub btnfm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfm.Click
        GroupBox2.Visible = True
    End Sub

    Private Sub btnto_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnto.Click
        GroupBox3.Visible = True
    End Sub

    Private Sub fmcal_DateSelected(ByVal sender As Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles fmcal.DateSelected
        Dim dt As Date = e.Start.ToShortDateString
        txtqpfm.Text = Format(dt, "dd-MMM-yyyy")
        GroupBox2.Visible = False
    End Sub

    Private Sub tocal_DateSelected(ByVal sender As Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles tocal.DateSelected
        Dim dt As Date = e.Start.ToShortDateString
        txtqpto.Text = Format(dt, "dd-MMM-yyyy")
        GroupBox3.Visible = False
    End Sub

    Private Sub NOTVALIDATELIST_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            sql = "SELECT distinct supplier_name  supplier From jan_gate_header"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "RESULTAB")
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                cmbsup.Items.Add(ds.Tables("resultab").Rows(i).Item("supplier").ToString.Replace("'", "''"))
            Next
            sql = "select organization_code  from org_organization_definitions where organization_code  not in('I08','I09')order by organization_code"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                cmborg.Items.Add(ds.Tables("resultab").Rows(i).Item("organization_code"))
            Next
            btnshow_Click(sender, e)
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Private Sub dgvdetails_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles dgvdetails.CellPainting
        Dim StringFormat As New StringFormat
        StringFormat.Alignment = StringAlignment.Near
        If e.ColumnIndex = -1 AndAlso e.RowIndex >= 0 AndAlso e.RowIndex < dgvdetails.Rows.Count Then
            e.PaintBackground(e.ClipBounds, True)
            e.Graphics.DrawString((e.RowIndex + 1).ToString, Me.Font, Brushes.Black, e.CellBounds, StringFormat)
            e.Handled = True
        End If
    End Sub

    Private Sub dgvdetails_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvdetails.CellClick
        Try
            dgvlines.Columns.Clear()
            sql = "select pono,podt,item,description,supdcqty,validated from jan_gatE_lines where gate_no=" & dgvdetails.Rows(dgvdetails.CurrentRow.Index).Cells(0).Value & ""
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "resultab")
            With dgvlines
                .DataSource = ds.Tables("resultab")
                .Columns(0).HeaderText = "PO.No" : .Columns(0).Width = 90
                .Columns(1).HeaderText = "Po.Dt" : .Columns(1).Width = 100
                .Columns(2).HeaderText = "Item" : .Columns(2).Width = 100
                .Columns(3).HeaderText = "Description" : .Columns(3).Width = 250
                .Columns(4).HeaderText = "Qty" : .Columns(4).Width = 40 : .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns(5).Visible = False
            End With
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub

    Private Sub dgvlines_CellFormatting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellFormattingEventArgs) Handles dgvlines.CellFormatting
        With dgvlines.Rows(e.RowIndex)
            If .Cells(5).Value = 2 Then
                e.CellStyle.BackColor = Color.Peru
            Else
                e.CellStyle.ForeColor = Color.Black
            End If
        End With

    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        Try
            s = "<html><H3 ALIGN=CENTER><FONT SIZE=3 FONT FACE=VERDANA>Gate Entry Not Validate List</FONT><BR> <FONT SIZE=2 FONT FACE=VERDANA>FROM :" & txtqpfm.Text & " &nbsp;&nbsp;&nbsp;TO : " & txtqpto.Text & " <br> Supplier: " & cmbsup.SelectedItem & " | Org: " & cmborg.SelectedItem & " "
            s &= "</FONT></H2>"

            s &= "<table border=1 cellspacing=0 cellpading=0 align=CENTER width=800><TR><TH><FONT SIZE=2 FONT FACE=VERDANA>SNO</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>GATE NO</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>GATE.DATE</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>ORG</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>SUPPLIER</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>REASON</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>NO.OF ITEMS</FONT></TH><TH><FONT SIZE=2 FONT FACE=VERDANA>NO.OF DAYS</FONT></TH></TR>"
            j = 0
            For i = 0 To dgvdetails.Rows.Count - 1
                j = j + 1
                With dgvdetails.Rows(i)
                    s &= " <TR><TD><FONT SIZE=2 FONT FACE=VERDANA>" & j & " </FONT></TD><TD><FONT SIZE=2 FONT FACE=VERDANA>" & .Cells(0).Value & " </FONT></TD><TD><FONT SIZE=2 FONT FACE=VERDANA>" & .Cells(1).Value & " </FONT></TD><TD><FONT SIZE=2 FONT FACE=VERDANA>" & .Cells(4).Value & " </FONT></TD><TD><FONT SIZE=2 FONT FACE=VERDANA>" & .Cells(2).Value & " </FONT></TD><TD><FONT SIZE=2 FONT FACE=VERDANA>" & .Cells(3).Value & " </FONT></TD><TD ALIGN=RIGHT><FONT SIZE=2 FONT FACE=VERDANA>" & .Cells(5).Value & " </FONT></TD><TD ALIGN=RIGHT><FONT SIZE=2 FONT FACE=VERDANA>" & .Cells(6).Value & " </FONT></TD></TR>"
                End With
            Next
            x = "c:\gate\gate not validate list.HTML"
            fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
            sw = New StreamWriter(fstrm)
            s = s & "</table></html>"
            sw.WriteLine(s)
            fstrm.Flush()
            sw.Flush()
            sw.Close()
            fstrm.Close()
            System.Diagnostics.Process.Start(x)

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub
End Class