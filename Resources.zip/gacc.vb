﻿Imports System.Data.OracleClient
Imports System.IO

Public Class gacc
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        cl.sql = "select gate_no,gdate,supplier_name,dc_no,dc_date,gtype,vehicle_det ,inv_category,case when validated=1 then 'Gate' when validated=0 then 'Validated' when validated=2 then 'Not Validate' when validated=6 then 'No Reference' end status from jan_gatE_header a where a.gdate>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='" & unit & "'"

        cl.sql &= " order by A.gate_no"
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.oradap = New OracleDataAdapter(cl.orcmd)
        DSGATE = New DataSet
        cl.oradap.Fill(DSGATE, "gt")
        dgv.DataSource = DSGATE.Tables("gt")

        dgv.Columns(0).HeaderText = "Gate No" : dgv.Columns(0).Width = 80
        dgv.Columns(1).HeaderText = "Gate Dt" : dgv.Columns(1).Width = 80
        dgv.Columns(2).HeaderText = "Supplier" : dgv.Columns(2).Width = 150
        dgv.Columns(3).HeaderText = "DC No" : dgv.Columns(3).Width = 100
        dgv.Columns(4).HeaderText = "DC Dt" : dgv.Columns(4).Width = 100
        dgv.Columns(5).HeaderText = "Type" : dgv.Columns(5).Width = 30
        dgv.Columns(6).HeaderText = "Vehicle Details" : dgv.Columns(6).Width = 200
        dgv.Columns(7).HeaderText = "Inv Category" : dgv.Columns(7).Width = 150
        dgv.Columns(8).HeaderText = "Status" : dgv.Columns(8).Width = 50

        Dim cc As New DataGridViewCheckBoxColumn
        cc.Width = 30
        Me.dgv.Columns.Add(cc)
        cc.DisplayIndex = 0
    End Sub

    Private Sub gacc_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        sql = "select MIN(GATE_NO),MAX(GATE_NO),count(*)cnt,SUM(CASE WHEN GTYPE='PO' THEN 1 ELSE 0 END) PO_CNT,SUM(cASE WHEN GTYPE='OSP' THEN 1 ELSE 0 END)OSP_CNT,SUM (CASE WHEN  GTYPE IS NULL THEN 1 ELSE 0 END)NON_PO,SUM(CASE WHEN POD_NO IS NOT NULL THEN 1 ELSE 0 END)POD   from jan_gatE_header a where a.gdate>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='" & unit & "'"
        cl.orcmd = New OracleCommand(sql, cl.oracon)
        cl.oradap = New OracleDataAdapter(cl.orcmd)
        ds = New DataSet
        cl.oradap.Fill(ds, "cnt")


        sql = "select gate_no from jan_gatE_header where gate_no between " & ds.Tables("cnt").Rows(0).Item(0) & " and " & ds.Tables("cnt").Rows(0).Item(1) & "and unit='" & unit & "'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        dsrep = New DataSet
        cl.oradap.Fill(dsrep, "resultab")
        DV = dsrep.Tables("resultab").DefaultView
        Dim ICNT, mgt As Int64
        For ICNT = a To b
            DV.RowFilter = "gate_no=" & ICNT
            If DV.Count = 0 Then
                mgt = mgt + 1
            End If
        Next

        If mgt = 1 Then mgt = 0 Else mgt = mgt

        DV.RowFilter = ""
        dsrep.Tables("resultab").RejectChanges()

        s = ""
        s &= "<html><head> <h4 align=center> <FONT SIZE=4 font face=verdana>Gate Entry Bill Inward-Accounts status | From Dt:" & inwdtf.Text & "| To Dt:" & inwdtto.Text & "</font></head>"

        s &= "<TABLE border=1 cellspacing=0 cellpadding=5 width=100%><tr> <td colspan=3><FONT SIZE=2 font face=verdana>Total Gate Entry</font></td> <td colspan=31 align=center><FONT SIZE=2 font face=verdana>Accounts Received Bills</font></td></tr>"

        s &= "<tr><td><FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item(0) & " </td> <td><FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item(1) & " </td> <td><FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item(2) & " </td>  "

        For i = 0 To 10

            s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> " & i + 1 & "</td>"

        Next

        '''''''''''''' for po 
        i = 0
        s &= "</tr>"
        s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana>PO</td> <td> <FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item("po_cnt") & " </td> "

        For i = 0 To 10

            s &= "<td WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

        Next
        s &= "</tr>"
        ''''''''''''' for osp
        i = 0
        s &= "</tr>"
        s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana>OSP</td> <td> <FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item("osp_cnt") & " </td> "

        For i = 0 To 10

            s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

        Next
        s &= "</tr>"
        '''''''''''' for non po
        i = 0
        s &= "</tr>"
        s &= "<tr><td colspan=34><FONT SIZE=2 font face=verdana><B>Non Po Inward</B></td>   "


        s &= "</tr>"


        sql = "select count(*),inv_category from jan_Gate_header a where  a.gdate>=TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.gdate<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') and unit='" & unit & "' AND inv_category IS NOT NULL group by inv_category"
        cl.orcmd = New OracleCommand(sql, cl.oracon)
        cl.oradap = New OracleDataAdapter(cl.orcmd)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "non")

        Dim z As Integer


        If ds1.Tables("non").Rows.Count > 0 Then
            i = 0
            '  s &= "</tr>"
            For z = 0 To ds1.Tables("non").Rows.Count - 1

                s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana>" & ds1.Tables("non").Rows(z).Item(1) & "  </td> <td> <FONT SIZE=2 font face=verdana> " & ds1.Tables("non").Rows(z).Item(0) & " </td> "

                For i = 0 To 10

                    s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

                Next
                s &= "</tr>"
            Next



        End If

        i = 0
        s &= "</tr>"
        s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana><B>Total</B></td> <td> <FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item("non_po") & " </td> "

        For i = 0 To 10

            s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

        Next
        s &= "</tr>"



        ''''''''''''' for jumping
        i = 0
        s &= "</tr>"
        s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana>Jumping</td> <td> <FONT SIZE=2 font face=verdana> " & mgt & " </td> "

        For i = 0 To 10

            s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

        Next
        s &= "</tr>"
        i = 0
        ''''''''''''''for total

        s &= "</tr>"
        i = 0
        ''''''''''''''for pod
        s &= "</tr>"
        s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana>POD</td> <td> <FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item("POD") & "</td> "

        For i = 0 To 10

            s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

        Next
        s &= "</tr>"
        i = 0 : j = 0
        For i = 0 To dgv.Rows.Count - 1
            If dgv.Rows(i).Cells(9).Value = True Then
                With dgv.Rows(i)
                    j += 1
                End With
            End If
        Next

        '''''''''''for missing
        s &= "</tr>"
        s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana>Missing</td> <td> <FONT SIZE=2 font face=verdana> " & j & " </td> "

        For i = 0 To 10

            s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

        Next
        s &= "</tr>"
        i = 0


        '''''''''''' for total

        s &= "<tr><td colspan=2><FONT SIZE=2 font face=verdana backcolor=Tomato><B>Total</B></td> <td> <FONT SIZE=2 font face=verdana> " & ds.Tables("cnt").Rows(0).Item("po_cnt") + ds.Tables("cnt").Rows(0).Item("osp_cnt") + ds.Tables("cnt").Rows(0).Item("non_po") + mgt & " </td> "

        For i = 0 To 10

            s &= "<td  WIDTH=5%><FONT SIZE=2 font face=verdana> &nbsp;</td>"

        Next
        s &= "</tr>"
        s &= "</table><br><table align=left border=1 cellspacing=0 cellpadding=6 width=100%>"
        i = 0
        s &= "<tr><td colspan=9 align=center><FONT SIZE=2 font face=verdana>Missing</td></tr>"
        s &= "<tr><td><FONT SIZE=2 font face=verdana>S.No</td> <td> <FONT SIZE=2 font face=verdana>Gate No</font></td> <td><FONT SIZE=2 font face=verdana>Vendor Name</td> <td> <FONT SIZE=2 font face=verdana>Type</font></td> <td><FONT SIZE=2 font face=verdana>Department</td> <td> <FONT SIZE=2 font face=verdana>Name</font></td><td> <FONT SIZE=2 font face=verdana>Vehicle Details</font></td><td> <FONT SIZE=2 font face=verdana>Inv Category</font></td><td> <FONT SIZE=2 font face=verdana>Status</font></td> </tr>"
        j = 0
        For i = 0 To dgv.Rows.Count - 1
            If dgv.Rows(i).Cells(9).Value = True Then
                With dgv.Rows(i)
                    j += 1
                    s &= "<tr><td><FONT SIZE=2 font face=verdana>" & j & " </td> <td> <FONT SIZE=2 font face=verdana>" & .Cells(0).Value & " </font></td> <td><FONT SIZE=2 font face=verdana>" & .Cells(2).Value & "</td> <td> <FONT SIZE=2 font face=verdana>" & .Cells(5).Value & "</font></td> <td><FONT SIZE=2 font face=verdana>&nbsp;</td> <td> <FONT SIZE=2 font face=verdana>&nbsp;</font></td> <td> <FONT SIZE=2 font face=verdana>" & .Cells(6).Value & "</font></td><td> <FONT SIZE=2 font face=verdana>" & .Cells(7).Value & "</font></td><td> <FONT SIZE=2 font face=verdana>" & .Cells(8).Value & "</font></td></tr>"
                End With
            End If
        Next
        s &= "</table></html>"
        x = "d:\receipt\rec_pend.HTML "



        fstrm = New FileStream(x, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fstrm)
        sw.WriteLine(s)
        fstrm.Flush()
        sw.Flush()
        sw.Close()
        fstrm.Close()
        System.Diagnostics.Process.Start(x)
        Me.Cursor = Cursors.Arrow

    End Sub
End Class