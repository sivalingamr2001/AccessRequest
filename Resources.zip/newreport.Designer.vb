<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class newreport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnconsolidate = New System.Windows.Forms.Button
        Me.txtfm = New System.Windows.Forms.TextBox
        Me.calto = New System.Windows.Forms.MonthCalendar
        Me.calfm = New System.Windows.Forms.MonthCalendar
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtto = New System.Windows.Forms.TextBox
        Me.btnfm = New System.Windows.Forms.Button
        Me.btnto = New System.Windows.Forms.Button
        Me.btndaily = New System.Windows.Forms.Button
        Me.btncancel = New System.Windows.Forms.Button
        Me.btnrtv = New System.Windows.Forms.Button
        Me.btnpoamend = New System.Windows.Forms.Button
        Me.btninward = New System.Windows.Forms.Button
        Me.btntime = New System.Windows.Forms.Button
        Me.txtrole = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbsup = New System.Windows.Forms.ComboBox
        Me.btnadi = New System.Windows.Forms.Button
        Me.btnurg = New System.Windows.Forms.Button
        Me.btnskip = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.txt_miss = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtgfm = New System.Windows.Forms.TextBox
        Me.txtgto = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmborg = New System.Windows.Forms.ComboBox
        Me.btngt = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnm2o = New System.Windows.Forms.Button
        Me.btnprep = New System.Windows.Forms.Button
        Me.adimanual = New System.Windows.Forms.Button
        Me.btnvallist = New System.Windows.Forms.Button
        Me.xerox = New System.Windows.Forms.Button
        Me.btnlong = New System.Windows.Forms.Button
        Me.delayaccount = New System.Windows.Forms.Button
        Me.btninv = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.rdpo = New System.Windows.Forms.RadioButton
        Me.rdosp = New System.Windows.Forms.RadioButton
        Me.rdser = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.RDALL = New System.Windows.Forms.RadioButton
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.btnper = New System.Windows.Forms.Button
        Me.UNIT7 = New System.Windows.Forms.RadioButton
        Me.UNIT2 = New System.Windows.Forms.RadioButton
        Me.Label6 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.RDSKY = New System.Windows.Forms.RadioButton
        Me.RD3 = New System.Windows.Forms.RadioButton
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.rdu1 = New System.Windows.Forms.RadioButton
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(7, 126)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Gate Dt"
        '
        'btnconsolidate
        '
        Me.btnconsolidate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnconsolidate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnconsolidate.Location = New System.Drawing.Point(7, 22)
        Me.btnconsolidate.Name = "btnconsolidate"
        Me.btnconsolidate.Size = New System.Drawing.Size(163, 26)
        Me.btnconsolidate.TabIndex = 1
        Me.btnconsolidate.Text = "Consolidation Pending "
        Me.btnconsolidate.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnconsolidate.UseVisualStyleBackColor = True
        '
        'txtfm
        '
        Me.txtfm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfm.Location = New System.Drawing.Point(64, 121)
        Me.txtfm.Name = "txtfm"
        Me.txtfm.Size = New System.Drawing.Size(116, 21)
        Me.txtfm.TabIndex = 2
        '
        'calto
        '
        Me.calto.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calto.Location = New System.Drawing.Point(4, 2)
        Me.calto.Margin = New System.Windows.Forms.Padding(10)
        Me.calto.Name = "calto"
        Me.calto.TabIndex = 3
        '
        'calfm
        '
        Me.calfm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calfm.Location = New System.Drawing.Point(3, 3)
        Me.calfm.Margin = New System.Windows.Forms.Padding(10)
        Me.calfm.Name = "calfm"
        Me.calfm.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(215, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 15)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Gate Dt"
        '
        'txtto
        '
        Me.txtto.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtto.Location = New System.Drawing.Point(273, 121)
        Me.txtto.Name = "txtto"
        Me.txtto.Size = New System.Drawing.Size(116, 21)
        Me.txtto.TabIndex = 2
        '
        'btnfm
        '
        Me.btnfm.Location = New System.Drawing.Point(179, 120)
        Me.btnfm.Name = "btnfm"
        Me.btnfm.Size = New System.Drawing.Size(26, 24)
        Me.btnfm.TabIndex = 1
        Me.btnfm.Text = " "
        Me.btnfm.UseVisualStyleBackColor = True
        '
        'btnto
        '
        Me.btnto.Location = New System.Drawing.Point(388, 120)
        Me.btnto.Name = "btnto"
        Me.btnto.Size = New System.Drawing.Size(26, 24)
        Me.btnto.TabIndex = 1
        Me.btnto.Text = " "
        Me.btnto.UseVisualStyleBackColor = True
        '
        'btndaily
        '
        Me.btndaily.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndaily.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndaily.Location = New System.Drawing.Point(176, 22)
        Me.btndaily.Name = "btndaily"
        Me.btndaily.Size = New System.Drawing.Size(177, 26)
        Me.btndaily.TabIndex = 1
        Me.btndaily.Text = "Gate Entry Daily  Report"
        Me.btndaily.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btndaily.UseVisualStyleBackColor = True
        '
        'btncancel
        '
        Me.btncancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btncancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancel.Location = New System.Drawing.Point(7, 55)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(163, 26)
        Me.btncancel.TabIndex = 1
        Me.btncancel.Text = "Gate Cancel Report"
        Me.btncancel.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btncancel.UseVisualStyleBackColor = True
        '
        'btnrtv
        '
        Me.btnrtv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnrtv.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrtv.Location = New System.Drawing.Point(7, 90)
        Me.btnrtv.Name = "btnrtv"
        Me.btnrtv.Size = New System.Drawing.Size(163, 26)
        Me.btnrtv.TabIndex = 1
        Me.btnrtv.Text = "RTV Report"
        Me.btnrtv.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnrtv.UseVisualStyleBackColor = True
        '
        'btnpoamend
        '
        Me.btnpoamend.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnpoamend.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpoamend.Location = New System.Drawing.Point(176, 55)
        Me.btnpoamend.Name = "btnpoamend"
        Me.btnpoamend.Size = New System.Drawing.Size(177, 26)
        Me.btnpoamend.TabIndex = 1
        Me.btnpoamend.Text = "Invoice Amendment "
        Me.btnpoamend.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnpoamend.UseVisualStyleBackColor = True
        '
        'btninward
        '
        Me.btninward.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btninward.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btninward.Location = New System.Drawing.Point(176, 90)
        Me.btninward.Name = "btninward"
        Me.btninward.Size = New System.Drawing.Size(177, 26)
        Me.btninward.TabIndex = 1
        Me.btninward.Text = "Gate Entry Inward"
        Me.btninward.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btninward.UseVisualStyleBackColor = True
        '
        'btntime
        '
        Me.btntime.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btntime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntime.Location = New System.Drawing.Point(7, 126)
        Me.btntime.Name = "btntime"
        Me.btntime.Size = New System.Drawing.Size(163, 26)
        Me.btntime.TabIndex = 1
        Me.btntime.Text = "Time Study Report"
        Me.btntime.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btntime.UseVisualStyleBackColor = True
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(227, 367)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(74, 21)
        Me.txtrole.TabIndex = 4
        Me.txtrole.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(5, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Supplier"
        '
        'cmbsup
        '
        Me.cmbsup.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsup.FormattingEnabled = True
        Me.cmbsup.Location = New System.Drawing.Point(64, 36)
        Me.cmbsup.Name = "cmbsup"
        Me.cmbsup.Size = New System.Drawing.Size(252, 23)
        Me.cmbsup.TabIndex = 6
        '
        'btnadi
        '
        Me.btnadi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnadi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadi.Location = New System.Drawing.Point(176, 126)
        Me.btnadi.Name = "btnadi"
        Me.btnadi.Size = New System.Drawing.Size(177, 26)
        Me.btnadi.TabIndex = 7
        Me.btnadi.Text = "ADI Vendor Report"
        Me.btnadi.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnadi.UseVisualStyleBackColor = True
        '
        'btnurg
        '
        Me.btnurg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnurg.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnurg.Location = New System.Drawing.Point(7, 269)
        Me.btnurg.Name = "btnurg"
        Me.btnurg.Size = New System.Drawing.Size(163, 26)
        Me.btnurg.TabIndex = 7
        Me.btnurg.Text = "Urgent Inward List"
        Me.btnurg.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnurg.UseVisualStyleBackColor = True
        '
        'btnskip
        '
        Me.btnskip.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnskip.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnskip.Location = New System.Drawing.Point(176, 194)
        Me.btnskip.Name = "btnskip"
        Me.btnskip.Size = New System.Drawing.Size(177, 26)
        Me.btnskip.TabIndex = 8
        Me.btnskip.Text = "Non Accounting Gate"
        Me.btnskip.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnskip.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(21, 364)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 27)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'txt_miss
        '
        Me.txt_miss.Location = New System.Drawing.Point(117, 365)
        Me.txt_miss.Multiline = True
        Me.txt_miss.Name = "txt_miss"
        Me.txt_miss.Size = New System.Drawing.Size(97, 26)
        Me.txt_miss.TabIndex = 10
        Me.txt_miss.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(7, 67)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 15)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Gt No"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(217, 67)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 15)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Gt No"
        '
        'txtgfm
        '
        Me.txtgfm.Location = New System.Drawing.Point(64, 63)
        Me.txtgfm.Name = "txtgfm"
        Me.txtgfm.Size = New System.Drawing.Size(140, 21)
        Me.txtgfm.TabIndex = 11
        '
        'txtgto
        '
        Me.txtgto.Location = New System.Drawing.Point(275, 63)
        Me.txtgto.Name = "txtgto"
        Me.txtgto.Size = New System.Drawing.Size(140, 21)
        Me.txtgto.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(318, 40)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(27, 15)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Org"
        '
        'cmborg
        '
        Me.cmborg.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(349, 36)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(67, 23)
        Me.cmborg.TabIndex = 12
        '
        'btngt
        '
        Me.btngt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btngt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngt.Location = New System.Drawing.Point(7, 159)
        Me.btngt.Name = "btngt"
        Me.btngt.Size = New System.Drawing.Size(163, 26)
        Me.btngt.TabIndex = 13
        Me.btngt.Text = "Gate Entry Register"
        Me.btngt.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btngt.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnm2o)
        Me.GroupBox1.Controls.Add(Me.btnprep)
        Me.GroupBox1.Controls.Add(Me.adimanual)
        Me.GroupBox1.Controls.Add(Me.btnvallist)
        Me.GroupBox1.Controls.Add(Me.xerox)
        Me.GroupBox1.Controls.Add(Me.btnlong)
        Me.GroupBox1.Controls.Add(Me.btnconsolidate)
        Me.GroupBox1.Controls.Add(Me.btngt)
        Me.GroupBox1.Controls.Add(Me.btndaily)
        Me.GroupBox1.Controls.Add(Me.btncancel)
        Me.GroupBox1.Controls.Add(Me.btnrtv)
        Me.GroupBox1.Controls.Add(Me.btnpoamend)
        Me.GroupBox1.Controls.Add(Me.btninward)
        Me.GroupBox1.Controls.Add(Me.btntime)
        Me.GroupBox1.Controls.Add(Me.delayaccount)
        Me.GroupBox1.Controls.Add(Me.btnskip)
        Me.GroupBox1.Controls.Add(Me.btnadi)
        Me.GroupBox1.Controls.Add(Me.btninv)
        Me.GroupBox1.Controls.Add(Me.btnurg)
        Me.GroupBox1.Location = New System.Drawing.Point(427, -1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(362, 388)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        '
        'btnm2o
        '
        Me.btnm2o.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnm2o.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnm2o.Location = New System.Drawing.Point(176, 305)
        Me.btnm2o.Name = "btnm2o"
        Me.btnm2o.Size = New System.Drawing.Size(177, 26)
        Me.btnm2o.TabIndex = 16
        Me.btnm2o.Text = "M2O Inward Status Analysis"
        Me.btnm2o.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnm2o.UseVisualStyleBackColor = True
        '
        'btnprep
        '
        Me.btnprep.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnprep.Location = New System.Drawing.Point(7, 305)
        Me.btnprep.Name = "btnprep"
        Me.btnprep.Size = New System.Drawing.Size(163, 26)
        Me.btnprep.TabIndex = 15
        Me.btnprep.Text = "Gate Entry Prepared List"
        Me.btnprep.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnprep.UseVisualStyleBackColor = True
        '
        'adimanual
        '
        Me.adimanual.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.adimanual.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.adimanual.Location = New System.Drawing.Point(176, 159)
        Me.adimanual.Name = "adimanual"
        Me.adimanual.Size = New System.Drawing.Size(177, 26)
        Me.adimanual.TabIndex = 14
        Me.adimanual.Text = "ADI-Manual Entry Report"
        Me.adimanual.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.adimanual.UseVisualStyleBackColor = True
        '
        'btnvallist
        '
        Me.btnvallist.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnvallist.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnvallist.Location = New System.Drawing.Point(41, 346)
        Me.btnvallist.Name = "btnvallist"
        Me.btnvallist.Size = New System.Drawing.Size(278, 36)
        Me.btnvallist.TabIndex = 18
        Me.btnvallist.Text = "Not Validate List For supplier Debit"
        Me.btnvallist.UseVisualStyleBackColor = True
        '
        'xerox
        '
        Me.xerox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.xerox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.xerox.Location = New System.Drawing.Point(7, 233)
        Me.xerox.Name = "xerox"
        Me.xerox.Size = New System.Drawing.Size(163, 26)
        Me.xerox.TabIndex = 14
        Me.xerox.Text = "Xerox Invoice Bill  List"
        Me.xerox.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.xerox.UseVisualStyleBackColor = True
        '
        'btnlong
        '
        Me.btnlong.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnlong.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnlong.Location = New System.Drawing.Point(7, 194)
        Me.btnlong.Name = "btnlong"
        Me.btnlong.Size = New System.Drawing.Size(163, 26)
        Me.btnlong.TabIndex = 14
        Me.btnlong.Text = "Long Time Pending Invoice"
        Me.btnlong.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btnlong.UseVisualStyleBackColor = True
        '
        'delayaccount
        '
        Me.delayaccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.delayaccount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.delayaccount.Location = New System.Drawing.Point(176, 233)
        Me.delayaccount.Name = "delayaccount"
        Me.delayaccount.Size = New System.Drawing.Size(177, 26)
        Me.delayaccount.TabIndex = 8
        Me.delayaccount.Text = " Duplicate Copy Received"
        Me.delayaccount.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.delayaccount.UseVisualStyleBackColor = True
        '
        'btninv
        '
        Me.btninv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btninv.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btninv.Location = New System.Drawing.Point(176, 269)
        Me.btninv.Name = "btninv"
        Me.btninv.Size = New System.Drawing.Size(177, 26)
        Me.btninv.TabIndex = 7
        Me.btninv.Text = "Invoice Booking Details"
        Me.btninv.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btninv.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(7, 96)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 15)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Gt Type"
        '
        'rdpo
        '
        Me.rdpo.AutoSize = True
        Me.rdpo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdpo.Location = New System.Drawing.Point(97, 12)
        Me.rdpo.Name = "rdpo"
        Me.rdpo.Size = New System.Drawing.Size(42, 19)
        Me.rdpo.TabIndex = 15
        Me.rdpo.Text = "PO"
        Me.rdpo.UseVisualStyleBackColor = True
        '
        'rdosp
        '
        Me.rdosp.AutoSize = True
        Me.rdosp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdosp.Location = New System.Drawing.Point(192, 9)
        Me.rdosp.Name = "rdosp"
        Me.rdosp.Size = New System.Drawing.Size(50, 19)
        Me.rdosp.TabIndex = 15
        Me.rdosp.Text = "OSP"
        Me.rdosp.UseVisualStyleBackColor = True
        '
        'rdser
        '
        Me.rdser.AutoSize = True
        Me.rdser.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdser.Location = New System.Drawing.Point(275, 9)
        Me.rdser.Name = "rdser"
        Me.rdser.Size = New System.Drawing.Size(65, 19)
        Me.rdser.TabIndex = 15
        Me.rdser.Text = "Service"
        Me.rdser.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rdpo)
        Me.GroupBox2.Controls.Add(Me.rdser)
        Me.GroupBox2.Controls.Add(Me.RDALL)
        Me.GroupBox2.Controls.Add(Me.rdosp)
        Me.GroupBox2.Location = New System.Drawing.Point(64, 85)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(353, 32)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        '
        'RDALL
        '
        Me.RDALL.AutoSize = True
        Me.RDALL.Checked = True
        Me.RDALL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RDALL.Location = New System.Drawing.Point(7, 9)
        Me.RDALL.Name = "RDALL"
        Me.RDALL.Size = New System.Drawing.Size(38, 19)
        Me.RDALL.TabIndex = 15
        Me.RDALL.TabStop = True
        Me.RDALL.Text = "All"
        Me.RDALL.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(307, 364)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(38, 29)
        Me.TextBox1.TabIndex = 17
        Me.TextBox1.Visible = False
        '
        'btnper
        '
        Me.btnper.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnper.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnper.Location = New System.Drawing.Point(468, 393)
        Me.btnper.Name = "btnper"
        Me.btnper.Size = New System.Drawing.Size(278, 36)
        Me.btnper.TabIndex = 18
        Me.btnper.Text = "Gate Register Performance Report"
        Me.btnper.UseVisualStyleBackColor = True
        '
        'UNIT7
        '
        Me.UNIT7.AutoSize = True
        Me.UNIT7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UNIT7.Location = New System.Drawing.Point(3, 11)
        Me.UNIT7.Name = "UNIT7"
        Me.UNIT7.Size = New System.Drawing.Size(63, 19)
        Me.UNIT7.TabIndex = 15
        Me.UNIT7.Text = "UNIT 7"
        Me.UNIT7.UseVisualStyleBackColor = True
        '
        'UNIT2
        '
        Me.UNIT2.AutoSize = True
        Me.UNIT2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UNIT2.Location = New System.Drawing.Point(66, 11)
        Me.UNIT2.Name = "UNIT2"
        Me.UNIT2.Size = New System.Drawing.Size(63, 19)
        Me.UNIT2.TabIndex = 15
        Me.UNIT2.Text = "UNIT 2"
        Me.UNIT2.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(7, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 29)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Unit"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.UNIT7)
        Me.GroupBox3.Controls.Add(Me.RDSKY)
        Me.GroupBox3.Controls.Add(Me.RD3)
        Me.GroupBox3.Controls.Add(Me.UNIT2)
        Me.GroupBox3.Location = New System.Drawing.Point(60, -4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(340, 36)
        Me.GroupBox3.TabIndex = 19
        Me.GroupBox3.TabStop = False
        '
        'RDSKY
        '
        Me.RDSKY.AutoSize = True
        Me.RDSKY.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RDSKY.Location = New System.Drawing.Point(198, 11)
        Me.RDSKY.Name = "RDSKY"
        Me.RDSKY.Size = New System.Drawing.Size(77, 19)
        Me.RDSKY.TabIndex = 15
        Me.RDSKY.Text = "SKYFAST"
        Me.RDSKY.UseVisualStyleBackColor = True
        '
        'RD3
        '
        Me.RD3.AutoSize = True
        Me.RD3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RD3.Location = New System.Drawing.Point(131, 11)
        Me.RD3.Name = "RD3"
        Me.RD3.Size = New System.Drawing.Size(63, 19)
        Me.RD3.TabIndex = 15
        Me.RD3.Text = "UNIT 4"
        Me.RD3.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox4.Controls.Add(Me.calfm)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 148)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(198, 181)
        Me.GroupBox4.TabIndex = 20
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Visible = False
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox5.Controls.Add(Me.calto)
        Me.GroupBox5.Location = New System.Drawing.Point(218, 148)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(200, 181)
        Me.GroupBox5.TabIndex = 21
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Visible = False
        '
        'rdu1
        '
        Me.rdu1.AutoSize = True
        Me.rdu1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdu1.Location = New System.Drawing.Point(333, 8)
        Me.rdu1.Name = "rdu1"
        Me.rdu1.Size = New System.Drawing.Size(63, 19)
        Me.rdu1.TabIndex = 16
        Me.rdu1.Text = "UNIT 1"
        Me.rdu1.UseVisualStyleBackColor = True
        '
        'newreport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(791, 451)
        Me.Controls.Add(Me.rdu1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.btnper)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmborg)
        Me.Controls.Add(Me.txtgto)
        Me.Controls.Add(Me.txtgfm)
        Me.Controls.Add(Me.txt_miss)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.cmbsup)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.txtto)
        Me.Controls.Add(Me.txtfm)
        Me.Controls.Add(Me.btnto)
        Me.Controls.Add(Me.btnfm)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "newreport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gate Register-Reports"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnconsolidate As System.Windows.Forms.Button
    Friend WithEvents txtfm As System.Windows.Forms.TextBox
    Friend WithEvents calto As System.Windows.Forms.MonthCalendar
    Friend WithEvents calfm As System.Windows.Forms.MonthCalendar
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtto As System.Windows.Forms.TextBox
    Friend WithEvents btnfm As System.Windows.Forms.Button
    Friend WithEvents btnto As System.Windows.Forms.Button
    Friend WithEvents btndaily As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnrtv As System.Windows.Forms.Button
    Friend WithEvents btnpoamend As System.Windows.Forms.Button
    Friend WithEvents btninward As System.Windows.Forms.Button
    Friend WithEvents btntime As System.Windows.Forms.Button
    Friend WithEvents txtrole As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbsup As System.Windows.Forms.ComboBox
    Friend WithEvents btnadi As System.Windows.Forms.Button
    Friend WithEvents btnurg As System.Windows.Forms.Button
    Friend WithEvents btnskip As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txt_miss As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtgfm As System.Windows.Forms.TextBox
    Friend WithEvents txtgto As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents btngt As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents rdpo As System.Windows.Forms.RadioButton
    Friend WithEvents rdosp As System.Windows.Forms.RadioButton
    Friend WithEvents rdser As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents RDALL As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents btnlong As System.Windows.Forms.Button
    Friend WithEvents btnper As System.Windows.Forms.Button
    Friend WithEvents UNIT7 As System.Windows.Forms.RadioButton
    Friend WithEvents UNIT2 As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents xerox As System.Windows.Forms.Button
    Friend WithEvents delayaccount As System.Windows.Forms.Button
    Friend WithEvents adimanual As System.Windows.Forms.Button
    Friend WithEvents btninv As System.Windows.Forms.Button
    Friend WithEvents btnprep As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnm2o As System.Windows.Forms.Button
    Friend WithEvents RD3 As System.Windows.Forms.RadioButton
    Friend WithEvents RDSKY As System.Windows.Forms.RadioButton
    Friend WithEvents btnvallist As System.Windows.Forms.Button
    Friend WithEvents rdu1 As System.Windows.Forms.RadioButton
End Class
