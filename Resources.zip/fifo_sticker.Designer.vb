<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class fifo_sticker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnprint = New System.Windows.Forms.Button()
        Me.chkpend = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmborg = New System.Windows.Forms.ComboBox()
        Me.btnshow = New System.Windows.Forms.Button()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtitem = New System.Windows.Forms.TextBox()
        Me.txtgno = New System.Windows.Forms.TextBox()
        Me.dgv = New System.Windows.Forms.DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.chkptc = New System.Windows.Forms.CheckBox()
        Me.chkjpend = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btn_jstk = New System.Windows.Forms.Button()
        Me.dgvjob = New System.Windows.Forms.DataGridView()
        Me.cmbjorg = New System.Windows.Forms.ComboBox()
        Me.jto = New System.Windows.Forms.DateTimePicker()
        Me.jfm = New System.Windows.Forms.DateTimePicker()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtjob = New System.Windows.Forms.TextBox()
        Me.txtjitem = New System.Windows.Forms.TextBox()
        Me.bntjob = New System.Windows.Forms.Button()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.btncprint = New System.Windows.Forms.Button()
        Me.dgvcstk = New System.Windows.Forms.DataGridView()
        Me.cmbsub = New System.Windows.Forms.ComboBox()
        Me.cmbcorg = New System.Windows.Forms.ComboBox()
        Me.cto = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.cfm = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtcitem = New System.Windows.Forms.TextBox()
        Me.btncshow = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdsrc = New System.Windows.Forms.RadioButton()
        Me.rddes = New System.Windows.Forms.RadioButton()
        Me.btnslist = New System.Windows.Forms.Button()
        Me.chkspend = New System.Windows.Forms.CheckBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.cmbsorg = New System.Windows.Forms.ComboBox()
        Me.btnship = New System.Windows.Forms.Button()
        Me.dtsto = New System.Windows.Forms.DateTimePicker()
        Me.dtsfm = New System.Windows.Forms.DateTimePicker()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtsitem = New System.Windows.Forms.TextBox()
        Me.txtship = New System.Windows.Forms.TextBox()
        Me.dgvs = New System.Windows.Forms.DataGridView()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtto = New System.Windows.Forms.TextBox()
        Me.txtloc = New System.Windows.Forms.TextBox()
        Me.txtfrm = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgvjob, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.dgvcstk, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgvs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(9, 9)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1295, 618)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnprint)
        Me.TabPage1.Controls.Add(Me.chkpend)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.cmborg)
        Me.TabPage1.Controls.Add(Me.btnshow)
        Me.TabPage1.Controls.Add(Me.DateTimePicker2)
        Me.TabPage1.Controls.Add(Me.DateTimePicker1)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.txtitem)
        Me.TabPage1.Controls.Add(Me.txtgno)
        Me.TabPage1.Controls.Add(Me.dgv)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage1.Size = New System.Drawing.Size(1287, 592)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "PO"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnprint
        '
        Me.btnprint.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprint.Location = New System.Drawing.Point(663, 30)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(98, 31)
        Me.btnprint.TabIndex = 38
        Me.btnprint.Text = "Print Sticker"
        Me.btnprint.UseVisualStyleBackColor = True
        '
        'chkpend
        '
        Me.chkpend.AutoSize = True
        Me.chkpend.Checked = True
        Me.chkpend.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkpend.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkpend.Location = New System.Drawing.Point(767, 9)
        Me.chkpend.Name = "chkpend"
        Me.chkpend.Size = New System.Drawing.Size(115, 17)
        Me.chkpend.TabIndex = 37
        Me.chkpend.Text = "Sticker Pending"
        Me.chkpend.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.MediumVioletRed
        Me.Label2.ForeColor = System.Drawing.Color.Olive
        Me.Label2.Location = New System.Drawing.Point(512, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(25, 20)
        Me.Label2.TabIndex = 36
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(535, 39)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(128, 13)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Lot Sticker Printed"
        '
        'cmborg
        '
        Me.cmborg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(306, 7)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(60, 21)
        Me.cmborg.TabIndex = 33
        '
        'btnshow
        '
        Me.btnshow.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnshow.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshow.Location = New System.Drawing.Point(885, 6)
        Me.btnshow.Name = "btnshow"
        Me.btnshow.Size = New System.Drawing.Size(48, 23)
        Me.btnshow.TabIndex = 32
        Me.btnshow.Text = "Show"
        Me.btnshow.UseVisualStyleBackColor = True
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker2.Location = New System.Drawing.Point(180, 7)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(96, 21)
        Me.DateTimePicker2.TabIndex = 31
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(62, 7)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(96, 21)
        Me.DateTimePicker1.TabIndex = 30
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(276, 11)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 13)
        Me.Label8.TabIndex = 27
        Me.Label8.Text = "Org"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Gate Dt"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(157, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(20, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "To"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(592, 11)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 13)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Item No"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(376, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "Gate No"
        '
        'txtitem
        '
        Me.txtitem.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtitem.Location = New System.Drawing.Point(645, 7)
        Me.txtitem.Name = "txtitem"
        Me.txtitem.Size = New System.Drawing.Size(116, 21)
        Me.txtitem.TabIndex = 24
        '
        'txtgno
        '
        Me.txtgno.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgno.Location = New System.Drawing.Point(429, 7)
        Me.txtgno.Name = "txtgno"
        Me.txtgno.Size = New System.Drawing.Size(160, 21)
        Me.txtgno.TabIndex = 24
        '
        'dgv
        '
        Me.dgv.AllowUserToAddRows = False
        Me.dgv.BackgroundColor = System.Drawing.Color.White
        Me.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv.Location = New System.Drawing.Point(9, 67)
        Me.dgv.Name = "dgv"
        Me.dgv.RowHeadersWidth = 30
        Me.dgv.Size = New System.Drawing.Size(1179, 508)
        Me.dgv.TabIndex = 23
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.chkptc)
        Me.TabPage2.Controls.Add(Me.chkjpend)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.btn_jstk)
        Me.TabPage2.Controls.Add(Me.dgvjob)
        Me.TabPage2.Controls.Add(Me.cmbjorg)
        Me.TabPage2.Controls.Add(Me.jto)
        Me.TabPage2.Controls.Add(Me.jfm)
        Me.TabPage2.Controls.Add(Me.Label38)
        Me.TabPage2.Controls.Add(Me.Label41)
        Me.TabPage2.Controls.Add(Me.Label40)
        Me.TabPage2.Controls.Add(Me.Label36)
        Me.TabPage2.Controls.Add(Me.Label35)
        Me.TabPage2.Controls.Add(Me.txtjob)
        Me.TabPage2.Controls.Add(Me.txtjitem)
        Me.TabPage2.Controls.Add(Me.bntjob)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.TabPage2.Size = New System.Drawing.Size(1287, 592)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "JOB"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'chkptc
        '
        Me.chkptc.AutoSize = True
        Me.chkptc.Location = New System.Drawing.Point(942, 12)
        Me.chkptc.Name = "chkptc"
        Me.chkptc.Size = New System.Drawing.Size(188, 17)
        Me.chkptc.TabIndex = 43
        Me.chkptc.Text = "Create Lot no For PTC items"
        Me.chkptc.UseVisualStyleBackColor = True
        Me.chkptc.Visible = False
        '
        'chkjpend
        '
        Me.chkjpend.AutoSize = True
        Me.chkjpend.Checked = True
        Me.chkjpend.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkjpend.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkjpend.Location = New System.Drawing.Point(808, 12)
        Me.chkjpend.Name = "chkjpend"
        Me.chkjpend.Size = New System.Drawing.Size(115, 17)
        Me.chkjpend.TabIndex = 42
        Me.chkjpend.Text = "Sticker Pending"
        Me.chkjpend.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.MediumVioletRed
        Me.Label13.ForeColor = System.Drawing.Color.Olive
        Me.Label13.Location = New System.Drawing.Point(477, 41)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(25, 20)
        Me.Label13.TabIndex = 41
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(500, 45)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(128, 13)
        Me.Label14.TabIndex = 40
        Me.Label14.Text = "Lot Sticker Printed"
        '
        'btn_jstk
        '
        Me.btn_jstk.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_jstk.Location = New System.Drawing.Point(702, 36)
        Me.btn_jstk.Name = "btn_jstk"
        Me.btn_jstk.Size = New System.Drawing.Size(98, 31)
        Me.btn_jstk.TabIndex = 39
        Me.btn_jstk.Text = "Print Sticker"
        Me.btn_jstk.UseVisualStyleBackColor = True
        '
        'dgvjob
        '
        Me.dgvjob.AllowUserToAddRows = False
        Me.dgvjob.BackgroundColor = System.Drawing.Color.White
        Me.dgvjob.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvjob.Location = New System.Drawing.Point(7, 71)
        Me.dgvjob.Name = "dgvjob"
        Me.dgvjob.RowHeadersWidth = 30
        Me.dgvjob.Size = New System.Drawing.Size(1261, 507)
        Me.dgvjob.TabIndex = 35
        '
        'cmbjorg
        '
        Me.cmbjorg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbjorg.FormattingEnabled = True
        Me.cmbjorg.Location = New System.Drawing.Point(201, 9)
        Me.cmbjorg.Name = "cmbjorg"
        Me.cmbjorg.Size = New System.Drawing.Size(60, 21)
        Me.cmbjorg.TabIndex = 34
        '
        'jto
        '
        Me.jto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.jto.Location = New System.Drawing.Point(702, 9)
        Me.jto.Name = "jto"
        Me.jto.Size = New System.Drawing.Size(100, 21)
        Me.jto.TabIndex = 16
        '
        'jfm
        '
        Me.jfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.jfm.Location = New System.Drawing.Point(569, 9)
        Me.jfm.Name = "jfm"
        Me.jfm.Size = New System.Drawing.Size(100, 21)
        Me.jfm.TabIndex = 17
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(167, 13)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(28, 13)
        Me.Label38.TabIndex = 13
        Me.Label38.Text = "Org"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(674, 13)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(20, 13)
        Me.Label41.TabIndex = 14
        Me.Label41.Text = "To"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(530, 13)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(36, 13)
        Me.Label40.TabIndex = 15
        Me.Label40.Text = "From"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(271, 13)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(45, 13)
        Me.Label36.TabIndex = 12
        Me.Label36.Text = "Job No"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(7, 13)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(53, 13)
        Me.Label35.TabIndex = 11
        Me.Label35.Text = "Item No"
        '
        'txtjob
        '
        Me.txtjob.Location = New System.Drawing.Point(316, 9)
        Me.txtjob.Name = "txtjob"
        Me.txtjob.Size = New System.Drawing.Size(208, 21)
        Me.txtjob.TabIndex = 9
        '
        'txtjitem
        '
        Me.txtjitem.Location = New System.Drawing.Point(63, 9)
        Me.txtjitem.Name = "txtjitem"
        Me.txtjitem.Size = New System.Drawing.Size(100, 21)
        Me.txtjitem.TabIndex = 10
        '
        'bntjob
        '
        Me.bntjob.Location = New System.Drawing.Point(634, 36)
        Me.bntjob.Name = "bntjob"
        Me.bntjob.Size = New System.Drawing.Size(62, 31)
        Me.bntjob.TabIndex = 7
        Me.bntjob.Text = "Show"
        Me.bntjob.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.btncprint)
        Me.TabPage3.Controls.Add(Me.dgvcstk)
        Me.TabPage3.Controls.Add(Me.cmbsub)
        Me.TabPage3.Controls.Add(Me.cmbcorg)
        Me.TabPage3.Controls.Add(Me.cto)
        Me.TabPage3.Controls.Add(Me.Label10)
        Me.TabPage3.Controls.Add(Me.cfm)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.Label7)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.Label11)
        Me.TabPage3.Controls.Add(Me.txtcitem)
        Me.TabPage3.Controls.Add(Me.btncshow)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1287, 592)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Current Stock"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'btncprint
        '
        Me.btncprint.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncprint.Location = New System.Drawing.Point(794, 6)
        Me.btncprint.Name = "btncprint"
        Me.btncprint.Size = New System.Drawing.Size(98, 31)
        Me.btncprint.TabIndex = 47
        Me.btncprint.Text = "Print Sticker"
        Me.btncprint.UseVisualStyleBackColor = True
        '
        'dgvcstk
        '
        Me.dgvcstk.AllowUserToAddRows = False
        Me.dgvcstk.BackgroundColor = System.Drawing.Color.White
        Me.dgvcstk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvcstk.Location = New System.Drawing.Point(13, 46)
        Me.dgvcstk.Name = "dgvcstk"
        Me.dgvcstk.RowHeadersWidth = 30
        Me.dgvcstk.Size = New System.Drawing.Size(1261, 499)
        Me.dgvcstk.TabIndex = 46
        '
        'cmbsub
        '
        Me.cmbsub.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsub.FormattingEnabled = True
        Me.cmbsub.Items.AddRange(New Object() {"FC Store", "RM Store", "PPD", "SF Store", "FG Store"})
        Me.cmbsub.Location = New System.Drawing.Point(626, 11)
        Me.cmbsub.Name = "cmbsub"
        Me.cmbsub.Size = New System.Drawing.Size(95, 21)
        Me.cmbsub.TabIndex = 45
        '
        'cmbcorg
        '
        Me.cmbcorg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcorg.FormattingEnabled = True
        Me.cmbcorg.Location = New System.Drawing.Point(195, 11)
        Me.cmbcorg.Name = "cmbcorg"
        Me.cmbcorg.Size = New System.Drawing.Size(60, 21)
        Me.cmbcorg.TabIndex = 45
        '
        'cto
        '
        Me.cto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.cto.Location = New System.Drawing.Point(432, 11)
        Me.cto.Name = "cto"
        Me.cto.Size = New System.Drawing.Size(100, 21)
        Me.cto.TabIndex = 43
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(539, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(89, 13)
        Me.Label10.TabIndex = 40
        Me.Label10.Text = "Sub Inventory"
        '
        'cfm
        '
        Me.cfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.cfm.Location = New System.Drawing.Point(299, 11)
        Me.cfm.Name = "cfm"
        Me.cfm.Size = New System.Drawing.Size(100, 21)
        Me.cfm.TabIndex = 44
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(161, 15)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 40
        Me.Label6.Text = "Org"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(404, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(20, 13)
        Me.Label7.TabIndex = 41
        Me.Label7.Text = "To"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(260, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(36, 13)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "From"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 15)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(53, 13)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "Item No"
        '
        'txtcitem
        '
        Me.txtcitem.Location = New System.Drawing.Point(61, 11)
        Me.txtcitem.Name = "txtcitem"
        Me.txtcitem.Size = New System.Drawing.Size(100, 21)
        Me.txtcitem.TabIndex = 37
        '
        'btncshow
        '
        Me.btncshow.Location = New System.Drawing.Point(726, 6)
        Me.btncshow.Name = "btncshow"
        Me.btncshow.Size = New System.Drawing.Size(62, 31)
        Me.btncshow.TabIndex = 35
        Me.btncshow.Text = "Show"
        Me.btncshow.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1287, 592)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Other Transactions"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.GroupBox1)
        Me.TabPage5.Controls.Add(Me.btnslist)
        Me.TabPage5.Controls.Add(Me.chkspend)
        Me.TabPage5.Controls.Add(Me.Label15)
        Me.TabPage5.Controls.Add(Me.Label16)
        Me.TabPage5.Controls.Add(Me.cmbsorg)
        Me.TabPage5.Controls.Add(Me.btnship)
        Me.TabPage5.Controls.Add(Me.dtsto)
        Me.TabPage5.Controls.Add(Me.dtsfm)
        Me.TabPage5.Controls.Add(Me.Label17)
        Me.TabPage5.Controls.Add(Me.Label18)
        Me.TabPage5.Controls.Add(Me.Label19)
        Me.TabPage5.Controls.Add(Me.Label20)
        Me.TabPage5.Controls.Add(Me.Label21)
        Me.TabPage5.Controls.Add(Me.txtsitem)
        Me.TabPage5.Controls.Add(Me.txtship)
        Me.TabPage5.Controls.Add(Me.dgvs)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1287, 592)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Shipment"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdsrc)
        Me.GroupBox1.Controls.Add(Me.rddes)
        Me.GroupBox1.Location = New System.Drawing.Point(1042, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(143, 63)
        Me.GroupBox1.TabIndex = 55
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Visible = False
        '
        'rdsrc
        '
        Me.rdsrc.AutoSize = True
        Me.rdsrc.Location = New System.Drawing.Point(14, 39)
        Me.rdsrc.Name = "rdsrc"
        Me.rdsrc.Size = New System.Drawing.Size(105, 17)
        Me.rdsrc.TabIndex = 0
        Me.rdsrc.TabStop = True
        Me.rdsrc.Text = "Transfer From"
        Me.rdsrc.UseVisualStyleBackColor = True
        '
        'rddes
        '
        Me.rddes.AutoSize = True
        Me.rddes.Location = New System.Drawing.Point(14, 16)
        Me.rddes.Name = "rddes"
        Me.rddes.Size = New System.Drawing.Size(89, 17)
        Me.rddes.TabIndex = 0
        Me.rddes.TabStop = True
        Me.rddes.Text = "Transfer To"
        Me.rddes.UseVisualStyleBackColor = True
        '
        'btnslist
        '
        Me.btnslist.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnslist.Location = New System.Drawing.Point(657, 37)
        Me.btnslist.Name = "btnslist"
        Me.btnslist.Size = New System.Drawing.Size(98, 31)
        Me.btnslist.TabIndex = 54
        Me.btnslist.Text = "Print Sticker"
        Me.btnslist.UseVisualStyleBackColor = True
        '
        'chkspend
        '
        Me.chkspend.AutoSize = True
        Me.chkspend.Checked = True
        Me.chkspend.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkspend.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkspend.Location = New System.Drawing.Point(813, 12)
        Me.chkspend.Name = "chkspend"
        Me.chkspend.Size = New System.Drawing.Size(115, 17)
        Me.chkspend.TabIndex = 53
        Me.chkspend.Text = "Sticker Pending"
        Me.chkspend.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.MediumVioletRed
        Me.Label15.ForeColor = System.Drawing.Color.Olive
        Me.Label15.Location = New System.Drawing.Point(509, 38)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(25, 20)
        Me.Label15.TabIndex = 52
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(532, 42)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(128, 13)
        Me.Label16.TabIndex = 51
        Me.Label16.Text = "Lot Sticker Printed"
        '
        'cmbsorg
        '
        Me.cmbsorg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbsorg.FormattingEnabled = True
        Me.cmbsorg.Location = New System.Drawing.Point(322, 10)
        Me.cmbsorg.Name = "cmbsorg"
        Me.cmbsorg.Size = New System.Drawing.Size(60, 21)
        Me.cmbsorg.TabIndex = 50
        '
        'btnship
        '
        Me.btnship.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnship.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnship.Location = New System.Drawing.Point(928, 8)
        Me.btnship.Name = "btnship"
        Me.btnship.Size = New System.Drawing.Size(63, 45)
        Me.btnship.TabIndex = 49
        Me.btnship.Text = "Show"
        Me.btnship.UseVisualStyleBackColor = True
        '
        'dtsto
        '
        Me.dtsto.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtsto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtsto.Location = New System.Drawing.Point(196, 10)
        Me.dtsto.Name = "dtsto"
        Me.dtsto.Size = New System.Drawing.Size(96, 21)
        Me.dtsto.TabIndex = 48
        '
        'dtsfm
        '
        Me.dtsfm.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtsfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtsfm.Location = New System.Drawing.Point(59, 10)
        Me.dtsfm.Name = "dtsfm"
        Me.dtsfm.Size = New System.Drawing.Size(96, 21)
        Me.dtsfm.TabIndex = 47
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(292, 14)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(28, 13)
        Me.Label17.TabIndex = 44
        Me.Label17.Text = "Org"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(5, 14)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 13)
        Me.Label18.TabIndex = 46
        Me.Label18.Text = "From Dt"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(154, 14)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(37, 13)
        Me.Label19.TabIndex = 45
        Me.Label19.Text = "To Dt"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(638, 14)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(53, 13)
        Me.Label20.TabIndex = 42
        Me.Label20.Text = "Item No"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(392, 14)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(80, 13)
        Me.Label21.TabIndex = 43
        Me.Label21.Text = "Shipment No"
        '
        'txtsitem
        '
        Me.txtsitem.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsitem.Location = New System.Drawing.Point(691, 10)
        Me.txtsitem.Name = "txtsitem"
        Me.txtsitem.Size = New System.Drawing.Size(116, 21)
        Me.txtsitem.TabIndex = 40
        '
        'txtship
        '
        Me.txtship.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtship.Location = New System.Drawing.Point(475, 10)
        Me.txtship.Name = "txtship"
        Me.txtship.Size = New System.Drawing.Size(160, 21)
        Me.txtship.TabIndex = 41
        '
        'dgvs
        '
        Me.dgvs.AllowUserToAddRows = False
        Me.dgvs.BackgroundColor = System.Drawing.Color.White
        Me.dgvs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvs.Location = New System.Drawing.Point(6, 75)
        Me.dgvs.Name = "dgvs"
        Me.dgvs.RowHeadersWidth = 30
        Me.dgvs.Size = New System.Drawing.Size(1179, 504)
        Me.dgvs.TabIndex = 39
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.Label26)
        Me.TabPage6.Controls.Add(Me.txtto)
        Me.TabPage6.Controls.Add(Me.txtloc)
        Me.TabPage6.Controls.Add(Me.txtfrm)
        Me.TabPage6.Controls.Add(Me.DataGridView1)
        Me.TabPage6.Controls.Add(Me.Button1)
        Me.TabPage6.Controls.Add(Me.Label25)
        Me.TabPage6.Controls.Add(Me.Label24)
        Me.TabPage6.Controls.Add(Me.Label23)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(1287, 592)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Store Location"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Verdana", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(271, 12)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(467, 29)
        Me.Label26.TabIndex = 42
        Me.Label26.Text = "(Type till Location no   EG:C.6.17.D)"
        '
        'txtto
        '
        Me.txtto.Font = New System.Drawing.Font("Verdana", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtto.Location = New System.Drawing.Point(331, 67)
        Me.txtto.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtto.Multiline = True
        Me.txtto.Name = "txtto"
        Me.txtto.Size = New System.Drawing.Size(66, 36)
        Me.txtto.TabIndex = 41
        '
        'txtloc
        '
        Me.txtloc.Font = New System.Drawing.Font("Verdana", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtloc.Location = New System.Drawing.Point(130, 12)
        Me.txtloc.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtloc.Name = "txtloc"
        Me.txtloc.Size = New System.Drawing.Size(130, 33)
        Me.txtloc.TabIndex = 41
        '
        'txtfrm
        '
        Me.txtfrm.Font = New System.Drawing.Font("Verdana", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfrm.Location = New System.Drawing.Point(163, 66)
        Me.txtfrm.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtfrm.Multiline = True
        Me.txtfrm.Name = "txtfrm"
        Me.txtfrm.Size = New System.Drawing.Size(66, 36)
        Me.txtfrm.TabIndex = 41
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersHeight = 40
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
        Me.DataGridView1.Location = New System.Drawing.Point(767, 8)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.Size = New System.Drawing.Size(363, 268)
        Me.DataGridView1.TabIndex = 40
        Me.DataGridView1.Visible = False
        '
        'Column1
        '
        Me.Column1.HeaderText = "Location"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 200
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 16.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(169, 130)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(188, 55)
        Me.Button1.TabIndex = 39
        Me.Button1.Text = "Print Location"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Verdana", 16.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(5, 12)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(117, 30)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Location"
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(248, 78)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(77, 14)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "Location To"
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(73, 76)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(85, 15)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Location From"
        '
        'fifo_sticker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(913, 487)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "fifo_sticker"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.dgv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.dgvjob, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.dgvcstk, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgvs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dgv As System.Windows.Forms.DataGridView
    Friend WithEvents chkpend As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents btnshow As System.Windows.Forms.Button
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtgno As System.Windows.Forms.TextBox
    Friend WithEvents btnprint As System.Windows.Forms.Button
    Friend WithEvents cmbjorg As System.Windows.Forms.ComboBox
    Friend WithEvents jto As System.Windows.Forms.DateTimePicker
    Friend WithEvents jfm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtjob As System.Windows.Forms.TextBox
    Friend WithEvents txtjitem As System.Windows.Forms.TextBox
    Friend WithEvents bntjob As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents cmbsub As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcorg As System.Windows.Forms.ComboBox
    Friend WithEvents cto As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents cfm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtcitem As System.Windows.Forms.TextBox
    Friend WithEvents btncshow As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtitem As System.Windows.Forms.TextBox
    Friend WithEvents dgvjob As System.Windows.Forms.DataGridView
    Friend WithEvents btn_jstk As System.Windows.Forms.Button
    Friend WithEvents dgvcstk As System.Windows.Forms.DataGridView
    Friend WithEvents btncprint As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rdsrc As RadioButton
    Friend WithEvents rddes As RadioButton
    Friend WithEvents btnslist As Button
    Friend WithEvents chkspend As CheckBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents cmbsorg As ComboBox
    Friend WithEvents btnship As Button
    Friend WithEvents dtsto As DateTimePicker
    Friend WithEvents dtsfm As DateTimePicker
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents txtsitem As TextBox
    Friend WithEvents txtship As TextBox
    Friend WithEvents dgvs As DataGridView
    Friend WithEvents chkjpend As CheckBox
    Friend WithEvents chkptc As CheckBox
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Label26 As Label
    Friend WithEvents txtto As TextBox
    Friend WithEvents txtloc As TextBox
    Friend WithEvents txtfrm As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
End Class
