Imports System.Data.OracleClient
Public Class qc_block

    Dim T_INV, slashpos As Integer
    Dim ORG, username, GT, GT1, orgcode As String

    Private Sub qc_block_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If Not e.KeyCode = Keys.Alt Then
            e.Handled = True
        End If
    End Sub



    Private Sub qc_block_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        slashpos = My.User.Name.LastIndexOf("\")
        username = My.User.Name.Substring(slashpos + 1)

        sql = "SELECT * FROM JAN_PO_BLOCK_IP WHERE IP_ADDR=(select SYS_CONTEXT('USERENV', 'IP_ADDRESS') ipaddr from dual) AND UPPER(UNAME) ='" & username.ToUpper & "'  AND FLAG='Y'"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "result")
        If ds.Tables("RESULT").Rows.Count > 0 Then
            Label3.Text = ds.Tables("RESULT").Rows(0).Item("COUNT_DOWN")
            T_INV = ds.Tables("RESULT").Rows(0).Item("T_INTERVAL")
            ORG = ds.Tables("RESULT").Rows(0).Item("ORG")
            orgcode = ds.Tables("RESULT").Rows(0).Item("ORG_code")

            sql = "select COUNT(*) ITEM_COUNT FROM JAN_FP_bLOCK_LINES WHERE ORGANIZATION_ID IN (" & ORG & " )AND BLOCK_FORM_NAME='RCVTXERT' AND QC_RES_PERSON IS NOT NULL AND BLOCK_END_DATE IS NULL   "

            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds1 = New DataSet
            adap.Fill(ds1, "result")

            If ds1.Tables("RESULT").Rows(0).Item("ITEM_COUNT") > 0 Then

                Label1.Text = "Inspection Pending in " & orgcode & " For the Below Items"

                sql = "select   receipt_no,item_no,jan_itemdesc(item_no),(select quantity_received from jan_pur_listing_test where shipment_header_id=a.shipment_header_id and po_line_id=a.po_line_id and item_no=a.item_no)  from JAN_FP_BLOCK_LINES_v a WHERE ORGANIZATION_ID IN (" & ORG & ") AND BLOCK_FORM_NAME='RCVTXERT' AND BLOCK_END_DATE IS NULL AND QC_RES_PERSON IS NOT NULL "

                cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                DSGATE = New DataSet
                adap.Fill(DSGATE, "GT")

                With dgvlist
                    .DataSource = DSGATE.Tables("gt")
                    .Columns(0).HeaderText = "Receipt Num" : .Columns(0).Width = 200
                    .Columns(1).HeaderText = "Item No" : .Columns(1).Width = 200
                    .Columns(2).HeaderText = "Desc" : .Columns(2).Width = 200
                    .Columns(3).HeaderText = "Qty" : .Columns(3).Width = 70 : .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                End With

                '  Label1.Text = "Purchase Orders(M2O) yet to be released for " & ds1.Tables("result").Rows(0).Item("ITEM_COUNT") & " Items. " & vbNewLine & " Org:" & ds.Tables("RESULT").Rows(0).Item("org_code")
                Timer1.Start()
                tJolt.Start()
            Else
                End
            End If
        Else
            End
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Val(Label3.Text) > 0 Then Label3.Text = Val(Label3.Text) - 1
        If Val(Label3.Text) = 1 Then
            Label5.Text = "Second"
        Else
            Label5.Text = "Seconds"
        End If

        If Val(Label3.Text) = 0 Then
            Me.Hide()
            Timer1.Stop()
            tJolt.Start()
            Label6.Text = 0
        End If
    End Sub

    Private Sub tJolt_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tJolt.Tick
        Label6.Text = Val(Label6.Text) + 1
        If Val(Label6.Text) Mod T_INV = 0 Then


            sql = "SELECT * FROM JAN_PO_BLOCK_IP WHERE IP_ADDR=(select SYS_CONTEXT('USERENV', 'IP_ADDRESS') ipaddr from dual) AND UPPER(UNAME) ='" & username.ToUpper & "'  AND FLAG='Y'"
            cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "result")
            If ds.Tables("RESULT").Rows.Count > 0 Then
                Label3.Text = ds.Tables("RESULT").Rows(0).Item("COUNT_DOWN")
                T_INV = ds.Tables("RESULT").Rows(0).Item("T_INTERVAL")
                ORG = ds.Tables("RESULT").Rows(0).Item("ORG")
                orgcode = ds.Tables("RESULT").Rows(0).Item("ORG_code")
                sql = "select COUNT(*) ITEM_COUNT FROM JAN_FP_bLOCK_LINES WHERE ORGANIZATION_ID=" & ORG & " AND BLOCK_FORM_NAME='RCVTXERT' AND QC_RES_PERSON IS NOT NULL AND BLOCK_END_DATE IS NULL   "

                cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                ds1 = New DataSet
                adap.Fill(ds1, "result")
                If ds1.Tables("RESULT").Rows(0).Item("ITEM_COUNT") > 0 Then
                    Label1.Text = "Inspection Pending in " & orgcode & " For the Below Items"

                    sql = "select   receipt_no,item_no,jan_itemdesc(item_no),(select quantity_received from jan_pur_listing_test where shipment_header_id=a.shipment_header_id and po_line_id=a.po_line_id and item_no=a.item_no)  from JAN_FP_BLOCK_LINES_v a WHERE ORGANIZATION_ID=" & ORG & " AND BLOCK_FORM_NAME='RCVTXERT' AND BLOCK_END_DATE IS NULL AND QC_RES_PERSON IS NOT NULL "
                    cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
                    DSGATE = New DataSet
                    adap.Fill(DSGATE, "GT")

                    With dgvlist
                        .DataSource = DSGATE.Tables("gt")
                        .Columns(0).HeaderText = "Receipt Num" : .Columns(0).Width = 200
                        .Columns(1).HeaderText = "Item No" : .Columns(1).Width = 200
                        .Columns(2).HeaderText = "Desc" : .Columns(2).Width = 200
                        .Columns(3).HeaderText = "Qty" : .Columns(3).Width = 70 : .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    End With
                    Me.Show()
                    Timer1.Start()
                    Label6.Text = 0
                    tJolt.Stop()
                    '  Label1.Text = "Purchase Orders(M2O) yet to be released for " & ds1.Tables("result").Rows(0).Item("ITEM_COUNT") & " Items. " & vbNewLine & " Org:" & ds.Tables("RESULT").Rows(0).Item("org_code")

                Else
                    End
                End If
            Else
                End
            End If
        End If
    End Sub
End Class