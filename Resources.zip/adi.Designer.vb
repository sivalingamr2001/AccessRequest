﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class adi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.self_certified = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.opn_seq = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.wip_entity_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tariff = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LINE_TYPE = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RateCategory = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.asn_dt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.asn_no = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lineloc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.val = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pohead = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poline = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.type = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.txtrwt = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtpodwt = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtbox = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtpod = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.spot_inspection = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmbcr = New System.Windows.Forms.ComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.chkoadi = New System.Windows.Forms.CheckBox()
        Me.txtveh = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Txt_inv_val = New System.Windows.Forms.TextBox()
        Me.nval_cb = New System.Windows.Forms.CheckBox()
        Me.txtrole = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.scmcon2 = New System.Data.SqlClient.SqlConnection()
        Me.BUT_DWNLD_ASN = New System.Windows.Forms.Button()
        Me.TXT_ASN_NO = New System.Windows.Forms.TextBox()
        Me.asn_grid = New System.Windows.Forms.DataGrid()
        Me.job = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SCMCON = New System.Data.OleDb.OleDbConnection()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.operation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.pono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.podt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.org = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.rev = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.popend = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.uom = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dcqty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.remark = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.poqty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.osp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TXTUSER = New System.Windows.Forms.TextBox()
        Me.btnupdt = New System.Windows.Forms.Button()
        Me.txtorg = New System.Windows.Forms.TextBox()
        Me.btnmod = New System.Windows.Forms.Button()
        Me.txtgno = New System.Windows.Forms.TextBox()
        Me.cmbtype = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.dgv12 = New System.Windows.Forms.DataGridView()
        Me.dtdc = New System.Windows.Forms.DateTimePicker()
        Me.dtgdt = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtdcno = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txttype = New System.Windows.Forms.TextBox()
        Me.txtsite = New System.Windows.Forms.TextBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.cmbsup = New System.Windows.Forms.ComboBox()
        Me.cmbpo = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbitem = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        CType(Me.asn_grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'self_certified
        '
        Me.self_certified.HeaderText = "self_certified"
        Me.self_certified.Name = "self_certified"
        Me.self_certified.Visible = False
        '
        'opn_seq
        '
        Me.opn_seq.HeaderText = "H_opn_seq"
        Me.opn_seq.Name = "opn_seq"
        Me.opn_seq.Visible = False
        '
        'wip_entity_id
        '
        Me.wip_entity_id.HeaderText = "Hwip_entity_id"
        Me.wip_entity_id.Name = "wip_entity_id"
        Me.wip_entity_id.Visible = False
        '
        'Tariff
        '
        Me.Tariff.HeaderText = "Tariff"
        Me.Tariff.Name = "Tariff"
        Me.Tariff.Visible = False
        '
        'LINE_TYPE
        '
        Me.LINE_TYPE.HeaderText = "LINE_TYPE"
        Me.LINE_TYPE.Name = "LINE_TYPE"
        '
        'RateCategory
        '
        Me.RateCategory.HeaderText = "Rate Category"
        Me.RateCategory.Name = "RateCategory"
        '
        'asn_dt
        '
        Me.asn_dt.HeaderText = "ASN Date"
        Me.asn_dt.Name = "asn_dt"
        Me.asn_dt.Visible = False
        '
        'asn_no
        '
        Me.asn_no.HeaderText = "ASN No"
        Me.asn_no.Name = "asn_no"
        Me.asn_no.Visible = False
        '
        'lineloc
        '
        Me.lineloc.HeaderText = "LineLocation"
        Me.lineloc.Name = "lineloc"
        Me.lineloc.Visible = False
        '
        'price
        '
        Me.price.HeaderText = "Price"
        Me.price.Name = "price"
        Me.price.Visible = False
        '
        'val
        '
        Me.val.HeaderText = "Val"
        Me.val.Name = "val"
        Me.val.Visible = False
        '
        'pohead
        '
        Me.pohead.HeaderText = "PoHead"
        Me.pohead.Name = "pohead"
        Me.pohead.Visible = False
        '
        'poline
        '
        Me.poline.HeaderText = "PoLine"
        Me.poline.Name = "poline"
        Me.poline.Visible = False
        '
        'type
        '
        Me.type.HeaderText = "Type"
        Me.type.Name = "type"
        Me.type.Visible = False
        '
        'txtrwt
        '
        Me.txtrwt.Location = New System.Drawing.Point(517, 856)
        Me.txtrwt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtrwt.Name = "txtrwt"
        Me.txtrwt.Size = New System.Drawing.Size(228, 26)
        Me.txtrwt.TabIndex = 159
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(388, 863)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(62, 20)
        Me.Label23.TabIndex = 158
        Me.Label23.Text = "Rec Wt"
        '
        'txtpodwt
        '
        Me.txtpodwt.Location = New System.Drawing.Point(517, 820)
        Me.txtpodwt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtpodwt.Name = "txtpodwt"
        Me.txtpodwt.Size = New System.Drawing.Size(228, 26)
        Me.txtpodwt.TabIndex = 157
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(388, 827)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(116, 20)
        Me.Label24.TabIndex = 156
        Me.Label24.Text = "Actual POD Wt"
        '
        'txtbox
        '
        Me.txtbox.Location = New System.Drawing.Point(146, 856)
        Me.txtbox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtbox.Name = "txtbox"
        Me.txtbox.Size = New System.Drawing.Size(228, 26)
        Me.txtbox.TabIndex = 155
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(27, 863)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(78, 20)
        Me.Label22.TabIndex = 154
        Me.Label22.Text = "No of Box"
        '
        'txtpod
        '
        Me.txtpod.Location = New System.Drawing.Point(146, 820)
        Me.txtpod.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtpod.Name = "txtpod"
        Me.txtpod.Size = New System.Drawing.Size(228, 26)
        Me.txtpod.TabIndex = 153
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(27, 827)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(67, 20)
        Me.Label21.TabIndex = 152
        Me.Label21.Text = "POD No"
        '
        'spot_inspection
        '
        Me.spot_inspection.HeaderText = "spot_inspection"
        Me.spot_inspection.Name = "spot_inspection"
        Me.spot_inspection.Visible = False
        '
        'cmbcr
        '
        Me.cmbcr.FormattingEnabled = True
        Me.cmbcr.Items.AddRange(New Object() {"OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "INTER UNIT TRANSFERS ", "MAINTENANCE ITEMS", "CASH PURCHASE", "BINS", "SALES RETURN", "COURIER - POD"})
        Me.cmbcr.Location = New System.Drawing.Point(146, 781)
        Me.cmbcr.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbcr.Name = "cmbcr"
        Me.cmbcr.Size = New System.Drawing.Size(228, 28)
        Me.cmbcr.TabIndex = 150
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(27, 781)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(81, 28)
        Me.Label20.TabIndex = 151
        Me.Label20.Text = "Courier"
        '
        'chkoadi
        '
        Me.chkoadi.Location = New System.Drawing.Point(1103, 57)
        Me.chkoadi.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.chkoadi.Name = "chkoadi"
        Me.chkoadi.Size = New System.Drawing.Size(106, 46)
        Me.chkoadi.TabIndex = 149
        Me.chkoadi.Text = "Old Gate Ref"
        Me.chkoadi.UseVisualStyleBackColor = True
        Me.chkoadi.Visible = False
        '
        'txtveh
        '
        Me.txtveh.Location = New System.Drawing.Point(146, 722)
        Me.txtveh.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtveh.Multiline = True
        Me.txtveh.Name = "txtveh"
        Me.txtveh.Size = New System.Drawing.Size(416, 50)
        Me.txtveh.TabIndex = 147
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(27, 739)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(114, 20)
        Me.Label14.TabIndex = 148
        Me.Label14.Text = "Vehicle details"
        '
        'Txt_inv_val
        '
        Me.Txt_inv_val.Location = New System.Drawing.Point(1226, 714)
        Me.Txt_inv_val.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Txt_inv_val.Name = "Txt_inv_val"
        Me.Txt_inv_val.Size = New System.Drawing.Size(148, 26)
        Me.Txt_inv_val.TabIndex = 146
        '
        'nval_cb
        '
        Me.nval_cb.AutoSize = True
        Me.nval_cb.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nval_cb.ForeColor = System.Drawing.Color.Red
        Me.nval_cb.Location = New System.Drawing.Point(853, 766)
        Me.nval_cb.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.nval_cb.Name = "nval_cb"
        Me.nval_cb.Size = New System.Drawing.Size(401, 24)
        Me.nval_cb.TabIndex = 145
        Me.nval_cb.Text = "Auto Validate ( No Validate Required )"
        Me.nval_cb.UseVisualStyleBackColor = True
        Me.nval_cb.Visible = False
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(908, 717)
        Me.txtrole.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(148, 26)
        Me.txtrole.TabIndex = 142
        Me.txtrole.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(1109, 720)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(104, 20)
        Me.Label12.TabIndex = 131
        Me.Label12.Text = "Invoice Value"
        '
        'Column1
        '
        Me.Column1.HeaderText = "ASNTYPE"
        Me.Column1.Name = "Column1"
        Me.Column1.Visible = False
        '
        'scmcon2
        '
        Me.scmcon2.ConnectionString = "Data Source=13.235.195.146;Initial Catalog=scm;User ID=scm;Password=scm#$sql2007"
        Me.scmcon2.FireInfoMessageEventOnUserErrors = False
        '
        'BUT_DWNLD_ASN
        '
        Me.BUT_DWNLD_ASN.Location = New System.Drawing.Point(1341, 56)
        Me.BUT_DWNLD_ASN.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BUT_DWNLD_ASN.Name = "BUT_DWNLD_ASN"
        Me.BUT_DWNLD_ASN.Size = New System.Drawing.Size(100, 35)
        Me.BUT_DWNLD_ASN.TabIndex = 143
        Me.BUT_DWNLD_ASN.Text = "Download"
        Me.BUT_DWNLD_ASN.UseVisualStyleBackColor = True
        '
        'TXT_ASN_NO
        '
        Me.TXT_ASN_NO.Location = New System.Drawing.Point(1211, 57)
        Me.TXT_ASN_NO.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TXT_ASN_NO.Name = "TXT_ASN_NO"
        Me.TXT_ASN_NO.Size = New System.Drawing.Size(122, 26)
        Me.TXT_ASN_NO.TabIndex = 123
        '
        'asn_grid
        '
        Me.asn_grid.DataMember = ""
        Me.asn_grid.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.asn_grid.Location = New System.Drawing.Point(19, 406)
        Me.asn_grid.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.asn_grid.Name = "asn_grid"
        Me.asn_grid.Size = New System.Drawing.Size(1359, 297)
        Me.asn_grid.TabIndex = 144
        Me.asn_grid.Visible = False
        '
        'job
        '
        Me.job.HeaderText = "Job"
        Me.job.Name = "job"
        Me.job.Visible = False
        Me.job.Width = 80
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(1387, 114)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(69, 20)
        Me.Label11.TabIndex = 141
        Me.Label11.Text = "ADI No"
        Me.Label11.Visible = False
        '
        'Column3
        '
        Me.Column3.HeaderText = "lotno"
        Me.Column3.Name = "Column3"
        '
        'SCMCON
        '
        Me.SCMCON.ConnectionString = "Provider=SQLNCLI.1;Data Source=JANATICS.NET;Password=scm#$sql2007;User ID=scm;Ini" &
    "tial Catalog=SCM"
        '
        'Column2
        '
        Me.Column2.HeaderText = "weight"
        Me.Column2.Name = "Column2"
        '
        'operation
        '
        Me.operation.HeaderText = "Operation"
        Me.operation.Name = "operation"
        Me.operation.Visible = False
        '
        'btnclose
        '
        Me.btnclose.Location = New System.Drawing.Point(830, 713)
        Me.btnclose.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(99, 35)
        Me.btnclose.TabIndex = 126
        Me.btnclose.Text = "&Close"
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'dgv1
        '
        Me.dgv1.AllowUserToOrderColumns = True
        Me.dgv1.BackgroundColor = System.Drawing.Color.White
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.pono, Me.podt, Me.item, Me.description, Me.org, Me.rev, Me.popend, Me.uom, Me.dcqty, Me.remark, Me.poqty, Me.osp, Me.operation, Me.job, Me.type, Me.poline, Me.pohead, Me.val, Me.price, Me.lineloc, Me.asn_no, Me.asn_dt, Me.RateCategory, Me.LINE_TYPE, Me.Tariff, Me.wip_entity_id, Me.opn_seq, Me.spot_inspection, Me.self_certified, Me.Column1, Me.Column2, Me.Column3})
        Me.dgv1.Location = New System.Drawing.Point(20, 114)
        Me.dgv1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.Size = New System.Drawing.Size(1359, 577)
        Me.dgv1.TabIndex = 140
        '
        'pono
        '
        Me.pono.HeaderText = "Pono"
        Me.pono.Name = "pono"
        Me.pono.Width = 80
        '
        'podt
        '
        Me.podt.HeaderText = "PoDt"
        Me.podt.Name = "podt"
        Me.podt.Visible = False
        Me.podt.Width = 80
        '
        'item
        '
        Me.item.HeaderText = "Item"
        Me.item.Name = "item"
        '
        'description
        '
        Me.description.HeaderText = "Description"
        Me.description.Name = "description"
        '
        'org
        '
        Me.org.HeaderText = "Org"
        Me.org.Name = "org"
        Me.org.Width = 30
        '
        'rev
        '
        Me.rev.HeaderText = "Rev"
        Me.rev.Name = "rev"
        Me.rev.Width = 30
        '
        'popend
        '
        Me.popend.HeaderText = "PoPend"
        Me.popend.Name = "popend"
        Me.popend.Width = 50
        '
        'uom
        '
        Me.uom.HeaderText = "UOM"
        Me.uom.Name = "uom"
        Me.uom.Width = 70
        '
        'dcqty
        '
        Me.dcqty.HeaderText = "DcQty"
        Me.dcqty.Name = "dcqty"
        Me.dcqty.Width = 70
        '
        'remark
        '
        Me.remark.HeaderText = "Remark"
        Me.remark.Name = "remark"
        Me.remark.Visible = False
        Me.remark.Width = 80
        '
        'poqty
        '
        Me.poqty.HeaderText = "POQty"
        Me.poqty.Name = "poqty"
        Me.poqty.Width = 50
        '
        'osp
        '
        Me.osp.HeaderText = "OSP"
        Me.osp.Name = "osp"
        Me.osp.Visible = False
        Me.osp.Width = 50
        '
        'TXTUSER
        '
        Me.TXTUSER.Location = New System.Drawing.Point(908, 722)
        Me.TXTUSER.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TXTUSER.Name = "TXTUSER"
        Me.TXTUSER.Size = New System.Drawing.Size(148, 26)
        Me.TXTUSER.TabIndex = 139
        Me.TXTUSER.Visible = False
        '
        'btnupdt
        '
        Me.btnupdt.Location = New System.Drawing.Point(936, 713)
        Me.btnupdt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnupdt.Name = "btnupdt"
        Me.btnupdt.Size = New System.Drawing.Size(112, 35)
        Me.btnupdt.TabIndex = 138
        Me.btnupdt.Text = "&Update"
        Me.btnupdt.UseVisualStyleBackColor = True
        Me.btnupdt.Visible = False
        '
        'txtorg
        '
        Me.txtorg.Location = New System.Drawing.Point(1271, 766)
        Me.txtorg.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtorg.Name = "txtorg"
        Me.txtorg.Size = New System.Drawing.Size(121, 26)
        Me.txtorg.TabIndex = 116
        Me.txtorg.Visible = False
        '
        'btnmod
        '
        Me.btnmod.Location = New System.Drawing.Point(908, 714)
        Me.btnmod.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnmod.Name = "btnmod"
        Me.btnmod.Size = New System.Drawing.Size(99, 35)
        Me.btnmod.TabIndex = 125
        Me.btnmod.Text = "Modify"
        Me.btnmod.UseVisualStyleBackColor = True
        Me.btnmod.Visible = False
        '
        'txtgno
        '
        Me.txtgno.Location = New System.Drawing.Point(963, 60)
        Me.txtgno.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtgno.Name = "txtgno"
        Me.txtgno.Size = New System.Drawing.Size(127, 26)
        Me.txtgno.TabIndex = 122
        '
        'cmbtype
        '
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Items.AddRange(New Object() {"PO", "OSP"})
        Me.cmbtype.Location = New System.Drawing.Point(73, 14)
        Me.cmbtype.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(148, 28)
        Me.cmbtype.TabIndex = 110
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(8, 20)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 20)
        Me.Label8.TabIndex = 137
        Me.Label8.Text = "GType"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(290, 16)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(386, 26)
        Me.TextBox1.TabIndex = 113
        Me.TextBox1.Visible = False
        '
        'dgv12
        '
        Me.dgv12.BackgroundColor = System.Drawing.Color.White
        Me.dgv12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv12.Location = New System.Drawing.Point(19, 113)
        Me.dgv12.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dgv12.Name = "dgv12"
        Me.dgv12.Size = New System.Drawing.Size(1359, 271)
        Me.dgv12.TabIndex = 120
        Me.dgv12.Visible = False
        '
        'dtdc
        '
        Me.dtdc.Enabled = False
        Me.dtdc.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdc.Location = New System.Drawing.Point(743, 60)
        Me.dtdc.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dtdc.Name = "dtdc"
        Me.dtdc.Size = New System.Drawing.Size(146, 26)
        Me.dtdc.TabIndex = 121
        '
        'dtgdt
        '
        Me.dtgdt.Enabled = False
        Me.dtgdt.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtgdt.Location = New System.Drawing.Point(73, 60)
        Me.dtgdt.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.dtgdt.Name = "dtgdt"
        Me.dtgdt.Size = New System.Drawing.Size(148, 26)
        Me.dtgdt.TabIndex = 117
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(683, 66)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 20)
        Me.Label7.TabIndex = 136
        Me.Label7.Text = "DC DT"
        '
        'txtdcno
        '
        Me.txtdcno.Location = New System.Drawing.Point(537, 60)
        Me.txtdcno.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtdcno.Name = "txtdcno"
        Me.txtdcno.Size = New System.Drawing.Size(140, 26)
        Me.txtdcno.TabIndex = 119
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(446, 66)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 20)
        Me.Label6.TabIndex = 133
        Me.Label6.Text = "DC/Inv No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 66)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 20)
        Me.Label5.TabIndex = 134
        Me.Label5.Text = "GDate"
        '
        'txttype
        '
        Me.txttype.Location = New System.Drawing.Point(73, 14)
        Me.txttype.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txttype.Name = "txttype"
        Me.txttype.Size = New System.Drawing.Size(148, 26)
        Me.txttype.TabIndex = 111
        Me.txttype.Visible = False
        '
        'txtsite
        '
        Me.txtsite.Location = New System.Drawing.Point(289, 60)
        Me.txtsite.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtsite.Name = "txtsite"
        Me.txtsite.Size = New System.Drawing.Size(148, 26)
        Me.txtsite.TabIndex = 118
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(235, 66)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 20)
        Me.Label4.TabIndex = 135
        Me.Label4.Text = "Site"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(218, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 20)
        Me.Label1.TabIndex = 132
        Me.Label1.Text = "Supplier"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1129, 20)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 20)
        Me.Label2.TabIndex = 129
        Me.Label2.Text = "PO No"
        '
        'btnsave
        '
        Me.btnsave.Location = New System.Drawing.Point(724, 713)
        Me.btnsave.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(99, 35)
        Me.btnsave.TabIndex = 124
        Me.btnsave.Text = "&Save"
        Me.btnsave.UseVisualStyleBackColor = True
        '
        'cmbsup
        '
        Me.cmbsup.FormattingEnabled = True
        Me.cmbsup.Location = New System.Drawing.Point(290, 14)
        Me.cmbsup.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbsup.Name = "cmbsup"
        Me.cmbsup.Size = New System.Drawing.Size(388, 28)
        Me.cmbsup.TabIndex = 112
        '
        'cmbpo
        '
        Me.cmbpo.FormattingEnabled = True
        Me.cmbpo.Location = New System.Drawing.Point(1189, 14)
        Me.cmbpo.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbpo.Name = "cmbpo"
        Me.cmbpo.Size = New System.Drawing.Size(289, 28)
        Me.cmbpo.TabIndex = 115
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(895, 66)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 20)
        Me.Label9.TabIndex = 130
        Me.Label9.Text = "Gate No"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(685, 20)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 20)
        Me.Label3.TabIndex = 127
        Me.Label3.Text = "Item"
        '
        'cmbitem
        '
        Me.cmbitem.FormattingEnabled = True
        Me.cmbitem.Location = New System.Drawing.Point(723, 14)
        Me.cmbitem.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbitem.Name = "cmbitem"
        Me.cmbitem.Size = New System.Drawing.Size(402, 28)
        Me.cmbitem.TabIndex = 114
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(1421, 771)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 20)
        Me.Label10.TabIndex = 128
        Me.Label10.Text = "Org"
        Me.Label10.Visible = False
        '
        'adi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1486, 897)
        Me.Controls.Add(Me.txtrwt)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.txtpodwt)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.txtbox)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.txtpod)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.cmbcr)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.chkoadi)
        Me.Controls.Add(Me.txtveh)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Txt_inv_val)
        Me.Controls.Add(Me.nval_cb)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.BUT_DWNLD_ASN)
        Me.Controls.Add(Me.TXT_ASN_NO)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnclose)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.TXTUSER)
        Me.Controls.Add(Me.btnupdt)
        Me.Controls.Add(Me.txtorg)
        Me.Controls.Add(Me.btnmod)
        Me.Controls.Add(Me.txtgno)
        Me.Controls.Add(Me.cmbtype)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.dgv12)
        Me.Controls.Add(Me.dtdc)
        Me.Controls.Add(Me.dtgdt)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtdcno)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txttype)
        Me.Controls.Add(Me.txtsite)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.cmbsup)
        Me.Controls.Add(Me.cmbpo)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmbitem)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.asn_grid)
        Me.Name = "adi"
        Me.Text = "ADI"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.asn_grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents self_certified As DataGridViewTextBoxColumn
    Friend WithEvents opn_seq As DataGridViewTextBoxColumn
    Friend WithEvents wip_entity_id As DataGridViewTextBoxColumn
    Friend WithEvents Tariff As DataGridViewTextBoxColumn
    Friend WithEvents LINE_TYPE As DataGridViewTextBoxColumn
    Friend WithEvents RateCategory As DataGridViewTextBoxColumn
    Friend WithEvents asn_dt As DataGridViewTextBoxColumn
    Friend WithEvents asn_no As DataGridViewTextBoxColumn
    Friend WithEvents lineloc As DataGridViewTextBoxColumn
    Friend WithEvents price As DataGridViewTextBoxColumn
    Friend WithEvents val As DataGridViewTextBoxColumn
    Friend WithEvents pohead As DataGridViewTextBoxColumn
    Friend WithEvents poline As DataGridViewTextBoxColumn
    Friend WithEvents type As DataGridViewTextBoxColumn
    Friend WithEvents txtrwt As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents txtpodwt As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents txtbox As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents txtpod As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents spot_inspection As DataGridViewTextBoxColumn
    Friend WithEvents cmbcr As ComboBox
    Friend WithEvents Label20 As Label
    Friend WithEvents chkoadi As CheckBox
    Friend WithEvents txtveh As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Txt_inv_val As TextBox
    Friend WithEvents nval_cb As CheckBox
    Friend WithEvents txtrole As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents scmcon2 As SqlClient.SqlConnection
    Friend WithEvents BUT_DWNLD_ASN As Button
    Friend WithEvents TXT_ASN_NO As TextBox
    Friend WithEvents asn_grid As DataGrid
    Friend WithEvents job As DataGridViewTextBoxColumn
    Friend WithEvents Label11 As Label
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents SCMCON As OleDb.OleDbConnection
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents operation As DataGridViewTextBoxColumn
    Friend WithEvents btnclose As Button
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents pono As DataGridViewTextBoxColumn
    Friend WithEvents podt As DataGridViewTextBoxColumn
    Friend WithEvents item As DataGridViewTextBoxColumn
    Friend WithEvents description As DataGridViewTextBoxColumn
    Friend WithEvents org As DataGridViewTextBoxColumn
    Friend WithEvents rev As DataGridViewTextBoxColumn
    Friend WithEvents popend As DataGridViewTextBoxColumn
    Friend WithEvents uom As DataGridViewTextBoxColumn
    Friend WithEvents dcqty As DataGridViewTextBoxColumn
    Friend WithEvents remark As DataGridViewTextBoxColumn
    Friend WithEvents poqty As DataGridViewTextBoxColumn
    Friend WithEvents osp As DataGridViewTextBoxColumn
    Friend WithEvents TXTUSER As TextBox
    Friend WithEvents btnupdt As Button
    Friend WithEvents txtorg As TextBox
    Friend WithEvents btnmod As Button
    Friend WithEvents txtgno As TextBox
    Friend WithEvents cmbtype As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents dgv12 As DataGridView
    Friend WithEvents dtdc As DateTimePicker
    Friend WithEvents dtgdt As DateTimePicker
    Friend WithEvents Label7 As Label
    Friend WithEvents txtdcno As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txttype As TextBox
    Friend WithEvents txtsite As TextBox
    Friend WithEvents ErrorProvider1 As ErrorProvider
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnsave As Button
    Friend WithEvents cmbsup As ComboBox
    Friend WithEvents cmbpo As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cmbitem As ComboBox
    Friend WithEvents Label10 As Label
End Class
