Imports System.Data.OracleClient
Public Class rtvreason

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        sql = "insert into jan_gate_rtv values('" & txtgate.Text & "','" & txttrans.Text & "','" & txtdoc.Text & "','" & txtqty.Text & "','" & txtwt.Text & "','" & txtterm.Text & "','" & txtamt.Text & "','" & txtremark.Text & "','1')"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        MessageBox.Show("RTV Details saved for " & txtgate.Text & "", "Gate Register")
        clear()
    End Sub

    Public Sub clear()
        txtgate.Text = ""
        txttrans.Text = ""
        txtdoc.Text = ""
        txtqty.Text = ""
        txtwt.Text = ""
        txtterm.Text = ""
        txtamt.Text = ""
        txtremark.Text = ""
    End Sub
    Private Sub btncan_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdt.Click
        sql = "update jan_gate_rtv set transport='" & txttrans.Text & "',docno='" & txtdoc.Text & "',qty=" & txtqty.Text & ",wt='" & txtwt.Text & "',terms='" & txtterm.Text & "',amt=" & txtamt.Text & ",remark='" & txtremark.Text & "',flag='1' where gatE_no=" & txtgate.Text & ""
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        MessageBox.Show(" RTV Details for " & txtgate.Text & " Updated", "Gate Register")
        clear()
    End Sub

    Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click
        sql = "update jan_gate_rtv set flag='0' where gatE_no=" & txtgate.Text & ""
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        MessageBox.Show(" RTV Details for " & txtgate.Text & " Deleted", "Gate Register")
        clear()
    End Sub
End Class