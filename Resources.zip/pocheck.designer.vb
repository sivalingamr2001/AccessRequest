<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class pocheck
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtpo = New System.Windows.Forms.TextBox()
        Me.txtpodate = New System.Windows.Forms.TextBox()
        Me.txtvendor = New System.Windows.Forms.TextBox()
        Me.txtlocation = New System.Windows.Forms.TextBox()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.dgv2 = New System.Windows.Forms.DataGridView()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblval = New System.Windows.Forms.Label()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.dgv3 = New System.Windows.Forms.DataGridView()
        Me.BTLCALTAX = New System.Windows.Forms.Button()
        Me.TXTITEM = New System.Windows.Forms.TextBox()
        Me.TXTPQTY = New System.Windows.Forms.TextBox()
        Me.TXTPOOSP = New System.Windows.Forms.TextBox()
        Me.TXTGNO = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbldcval = New System.Windows.Forms.Label()
        Me.lbldctotval = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.btngo = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtdc = New System.Windows.Forms.TextBox()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtrate = New System.Windows.Forms.TextBox()
        Me.txtrole = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lbfreight = New System.Windows.Forms.Label()
        Me.lbrate = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtline = New System.Windows.Forms.TextBox()
        Me.dgvtax = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtvendorid = New System.Windows.Forms.TextBox()
        Me.dgvtaxdetails = New System.Windows.Forms.DataGridView()
        Me.richorder = New System.Windows.Forms.RichTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.richdc = New System.Windows.Forms.RichTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.dcoth = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.dctt = New System.Windows.Forms.Label()
        Me.dcvat = New System.Windows.Forms.Label()
        Me.dcstax = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.dcscess = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.dccess = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.dcbed = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.dcpf = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblcval = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblcdcval = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lbordertot = New System.Windows.Forms.Label()
        Me.txtcur = New System.Windows.Forms.TextBox()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvtax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.dgvtaxdetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(991, 308)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "PO No"
        Me.Label1.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(982, 282)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "PO Date"
        Me.Label2.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Vendor  Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(328, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Location"
        '
        'txtpo
        '
        Me.txtpo.BackColor = System.Drawing.Color.White
        Me.txtpo.Location = New System.Drawing.Point(1029, 304)
        Me.txtpo.Name = "txtpo"
        Me.txtpo.ReadOnly = True
        Me.txtpo.Size = New System.Drawing.Size(52, 20)
        Me.txtpo.TabIndex = 1
        Me.txtpo.Visible = False
        '
        'txtpodate
        '
        Me.txtpodate.BackColor = System.Drawing.Color.White
        Me.txtpodate.Location = New System.Drawing.Point(1029, 278)
        Me.txtpodate.Name = "txtpodate"
        Me.txtpodate.ReadOnly = True
        Me.txtpodate.Size = New System.Drawing.Size(78, 20)
        Me.txtpodate.TabIndex = 2
        Me.txtpodate.Visible = False
        '
        'txtvendor
        '
        Me.txtvendor.BackColor = System.Drawing.Color.White
        Me.txtvendor.Location = New System.Drawing.Point(81, 3)
        Me.txtvendor.Name = "txtvendor"
        Me.txtvendor.ReadOnly = True
        Me.txtvendor.Size = New System.Drawing.Size(246, 20)
        Me.txtvendor.TabIndex = 3
        '
        'txtlocation
        '
        Me.txtlocation.BackColor = System.Drawing.Color.White
        Me.txtlocation.Location = New System.Drawing.Point(373, 3)
        Me.txtlocation.Name = "txtlocation"
        Me.txtlocation.ReadOnly = True
        Me.txtlocation.Size = New System.Drawing.Size(158, 20)
        Me.txtlocation.TabIndex = 4
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.BackgroundColor = System.Drawing.Color.White
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(5, 29)
        Me.dgv1.Name = "dgv1"
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv1.RowHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgv1.RowHeadersWidth = 15
        Me.dgv1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgv1.Size = New System.Drawing.Size(1119, 165)
        Me.dgv1.TabIndex = 5
        '
        'dgv2
        '
        Me.dgv2.AllowUserToAddRows = False
        Me.dgv2.BackgroundColor = System.Drawing.Color.White
        Me.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv2.Location = New System.Drawing.Point(5, 226)
        Me.dgv2.Name = "dgv2"
        Me.dgv2.ReadOnly = True
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv2.RowHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgv2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgv2.Size = New System.Drawing.Size(148, 156)
        Me.dgv2.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(563, 202)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "ORDER  VALUE :"
        '
        'lblval
        '
        Me.lblval.BackColor = System.Drawing.Color.White
        Me.lblval.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblval.ForeColor = System.Drawing.Color.Crimson
        Me.lblval.Location = New System.Drawing.Point(655, 201)
        Me.lblval.Name = "lblval"
        Me.lblval.Size = New System.Drawing.Size(96, 14)
        Me.lblval.TabIndex = 6
        Me.lblval.Text = ":: "
        Me.lblval.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(1029, 279)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(70, 20)
        Me.txt1.TabIndex = 8
        Me.txt1.Visible = False
        '
        'dgv3
        '
        Me.dgv3.AllowUserToAddRows = False
        Me.dgv3.BackgroundColor = System.Drawing.Color.White
        Me.dgv3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv3.Location = New System.Drawing.Point(7, 389)
        Me.dgv3.Name = "dgv3"
        Me.dgv3.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgv3.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgv3.RowHeadersWidth = 35
        Me.dgv3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgv3.Size = New System.Drawing.Size(397, 165)
        Me.dgv3.TabIndex = 5
        '
        'BTLCALTAX
        '
        Me.BTLCALTAX.Location = New System.Drawing.Point(816, 362)
        Me.BTLCALTAX.Name = "BTLCALTAX"
        Me.BTLCALTAX.Size = New System.Drawing.Size(75, 23)
        Me.BTLCALTAX.TabIndex = 9
        Me.BTLCALTAX.Text = "Calc Tax"
        Me.BTLCALTAX.UseVisualStyleBackColor = True
        Me.BTLCALTAX.Visible = False
        '
        'TXTITEM
        '
        Me.TXTITEM.Location = New System.Drawing.Point(791, 4)
        Me.TXTITEM.Name = "TXTITEM"
        Me.TXTITEM.Size = New System.Drawing.Size(37, 20)
        Me.TXTITEM.TabIndex = 10
        Me.TXTITEM.Visible = False
        '
        'TXTPQTY
        '
        Me.TXTPQTY.Location = New System.Drawing.Point(825, 4)
        Me.TXTPQTY.Name = "TXTPQTY"
        Me.TXTPQTY.Size = New System.Drawing.Size(27, 20)
        Me.TXTPQTY.TabIndex = 11
        Me.TXTPQTY.Visible = False
        '
        'TXTPOOSP
        '
        Me.TXTPOOSP.Location = New System.Drawing.Point(1029, 278)
        Me.TXTPOOSP.Name = "TXTPOOSP"
        Me.TXTPOOSP.Size = New System.Drawing.Size(70, 20)
        Me.TXTPOOSP.TabIndex = 12
        Me.TXTPOOSP.Visible = False
        '
        'TXTGNO
        '
        Me.TXTGNO.Location = New System.Drawing.Point(1029, 276)
        Me.TXTGNO.Name = "TXTGNO"
        Me.TXTGNO.Size = New System.Drawing.Size(70, 20)
        Me.TXTGNO.TabIndex = 13
        Me.TXTGNO.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(757, 203)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(66, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "DC VALUE :"
        '
        'lbldcval
        '
        Me.lbldcval.BackColor = System.Drawing.Color.White
        Me.lbldcval.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldcval.ForeColor = System.Drawing.Color.Crimson
        Me.lbldcval.Location = New System.Drawing.Point(825, 202)
        Me.lbldcval.Name = "lbldcval"
        Me.lbldcval.Size = New System.Drawing.Size(96, 14)
        Me.lbldcval.TabIndex = 14
        Me.lbldcval.Text = "::"
        Me.lbldcval.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbldctotval
        '
        Me.lbldctotval.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lbldctotval.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldctotval.ForeColor = System.Drawing.Color.Crimson
        Me.lbldctotval.Location = New System.Drawing.Point(781, 595)
        Me.lbldctotval.Name = "lbldctotval"
        Me.lbldctotval.Size = New System.Drawing.Size(96, 14)
        Me.lbldctotval.TabIndex = 6
        Me.lbldctotval.Text = ":: "
        Me.lbldctotval.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label13.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(696, 595)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(79, 14)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "TOTAL VAL"
        '
        'btngo
        '
        Me.btngo.Image = Global.Manufacture.My.Resources.Resources.go
        Me.btngo.ImageAlign = System.Drawing.ContentAlignment.TopLeft
        Me.btngo.Location = New System.Drawing.Point(858, 0)
        Me.btngo.Name = "btngo"
        Me.btngo.Size = New System.Drawing.Size(29, 29)
        Me.btngo.TabIndex = 7
        Me.btngo.Text = "     Button1"
        Me.btngo.UseVisualStyleBackColor = True
        Me.btngo.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label17.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(6, 605)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(94, 13)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "Freight/Courier"
        Me.Label17.Visible = False
        '
        'txtdc
        '
        Me.txtdc.Location = New System.Drawing.Point(105, 601)
        Me.txtdc.Name = "txtdc"
        Me.txtdc.Size = New System.Drawing.Size(100, 20)
        Me.txtdc.TabIndex = 17
        Me.txtdc.Visible = False
        '
        'btnsave
        '
        Me.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnsave.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.Location = New System.Drawing.Point(213, 625)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(113, 23)
        Me.btnsave.TabIndex = 18
        Me.btnsave.Text = "Save Adj Value"
        Me.btnsave.UseVisualStyleBackColor = True
        Me.btnsave.Visible = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label23.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(216, 605)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(92, 13)
        Me.Label23.TabIndex = 6
        Me.Label23.Text = "Rate Adj Value"
        Me.Label23.Visible = False
        '
        'txtrate
        '
        Me.txtrate.Location = New System.Drawing.Point(315, 601)
        Me.txtrate.Name = "txtrate"
        Me.txtrate.Size = New System.Drawing.Size(100, 20)
        Me.txtrate.TabIndex = 17
        Me.txtrate.Visible = False
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(1125, 275)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(20, 20)
        Me.txtrole.TabIndex = 19
        Me.txtrole.Visible = False
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label26.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(696, 548)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(79, 14)
        Me.Label26.TabIndex = 6
        Me.Label26.Text = "FREIGHT"
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label28.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(696, 572)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(79, 14)
        Me.Label28.TabIndex = 6
        Me.Label28.Text = "RATE ADJ"
        '
        'lbfreight
        '
        Me.lbfreight.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lbfreight.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbfreight.ForeColor = System.Drawing.Color.Crimson
        Me.lbfreight.Location = New System.Drawing.Point(781, 548)
        Me.lbfreight.Name = "lbfreight"
        Me.lbfreight.Size = New System.Drawing.Size(96, 14)
        Me.lbfreight.TabIndex = 6
        Me.lbfreight.Text = ":: "
        Me.lbfreight.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbrate
        '
        Me.lbrate.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lbrate.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbrate.ForeColor = System.Drawing.Color.Crimson
        Me.lbrate.Location = New System.Drawing.Point(781, 572)
        Me.lbrate.Name = "lbrate"
        Me.lbrate.Size = New System.Drawing.Size(96, 14)
        Me.lbrate.TabIndex = 6
        Me.lbrate.Text = ":: "
        Me.lbrate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label29.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(7, 627)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(49, 13)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "Line No"
        Me.Label29.Visible = False
        '
        'txtline
        '
        Me.txtline.Location = New System.Drawing.Point(105, 627)
        Me.txtline.Name = "txtline"
        Me.txtline.Size = New System.Drawing.Size(100, 20)
        Me.txtline.TabIndex = 17
        Me.txtline.Visible = False
        '
        'dgvtax
        '
        Me.dgvtax.AllowUserToAddRows = False
        Me.dgvtax.BackgroundColor = System.Drawing.Color.White
        Me.dgvtax.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvtax.Location = New System.Drawing.Point(1, 26)
        Me.dgvtax.Name = "dgvtax"
        Me.dgvtax.RowHeadersWidth = 5
        Me.dgvtax.Size = New System.Drawing.Size(414, 115)
        Me.dgvtax.TabIndex = 20
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.dgvtax)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Location = New System.Drawing.Point(0, 450)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(417, 144)
        Me.Panel1.TabIndex = 21
        Me.Panel1.Visible = False
        '
        'Button3
        '
        Me.Button3.Image = Global.Manufacture.My.Resources.Resources.SI_Cancel
        Me.Button3.Location = New System.Drawing.Point(390, 0)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(25, 23)
        Me.Button3.TabIndex = 21
        Me.Button3.Text = " "
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Black
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.White
        Me.Label30.Location = New System.Drawing.Point(3, 5)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(207, 15)
        Me.Label30.TabIndex = 2
        Me.Label30.Text = "Tax Details for the Item booked"
        '
        'txtvendorid
        '
        Me.txtvendorid.Location = New System.Drawing.Point(576, 2)
        Me.txtvendorid.Name = "txtvendorid"
        Me.txtvendorid.Size = New System.Drawing.Size(108, 20)
        Me.txtvendorid.TabIndex = 22
        Me.txtvendorid.Visible = False
        '
        'dgvtaxdetails
        '
        Me.dgvtaxdetails.AllowUserToAddRows = False
        Me.dgvtaxdetails.BackgroundColor = System.Drawing.Color.White
        Me.dgvtaxdetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvtaxdetails.Location = New System.Drawing.Point(163, 228)
        Me.dgvtaxdetails.Name = "dgvtaxdetails"
        Me.dgvtaxdetails.Size = New System.Drawing.Size(798, 151)
        Me.dgvtaxdetails.TabIndex = 23
        '
        'richorder
        '
        Me.richorder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.richorder.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.richorder.Location = New System.Drawing.Point(408, 404)
        Me.richorder.Name = "richorder"
        Me.richorder.Size = New System.Drawing.Size(284, 134)
        Me.richorder.TabIndex = 24
        Me.richorder.Text = ""
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Crimson
        Me.Label7.Location = New System.Drawing.Point(801, 631)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(196, 18)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Read Sales Tax as VAT"
        '
        'richdc
        '
        Me.richdc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.richdc.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.richdc.Location = New System.Drawing.Point(696, 404)
        Me.richdc.Name = "richdc"
        Me.richdc.Size = New System.Drawing.Size(290, 134)
        Me.richdc.TabIndex = 24
        Me.richdc.Text = ""
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(474, 595)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(79, 14)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "TOTAL VAL"
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label27.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(12, 141)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(79, 14)
        Me.Label27.TabIndex = 6
        Me.Label27.Text = "OTHERS"
        '
        'dcoth
        '
        Me.dcoth.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dcoth.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dcoth.ForeColor = System.Drawing.Color.Crimson
        Me.dcoth.Location = New System.Drawing.Point(93, 141)
        Me.dcoth.Name = "dcoth"
        Me.dcoth.Size = New System.Drawing.Size(96, 14)
        Me.dcoth.TabIndex = 6
        Me.dcoth.Text = ":: "
        Me.dcoth.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label25.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(12, 161)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(79, 14)
        Me.Label25.TabIndex = 6
        Me.Label25.Text = "TOTAL TAX"
        '
        'dctt
        '
        Me.dctt.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dctt.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dctt.ForeColor = System.Drawing.Color.Crimson
        Me.dctt.Location = New System.Drawing.Point(93, 161)
        Me.dctt.Name = "dctt"
        Me.dctt.Size = New System.Drawing.Size(96, 14)
        Me.dctt.TabIndex = 6
        Me.dctt.Text = ":: "
        Me.dctt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dcvat
        '
        Me.dcvat.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dcvat.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dcvat.ForeColor = System.Drawing.Color.Crimson
        Me.dcvat.Location = New System.Drawing.Point(92, 100)
        Me.dcvat.Name = "dcvat"
        Me.dcvat.Size = New System.Drawing.Size(96, 14)
        Me.dcvat.TabIndex = 6
        Me.dcvat.Text = ":: "
        Me.dcvat.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.dcvat.UseMnemonic = False
        '
        'dcstax
        '
        Me.dcstax.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dcstax.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dcstax.ForeColor = System.Drawing.Color.Crimson
        Me.dcstax.Location = New System.Drawing.Point(93, 122)
        Me.dcstax.Name = "dcstax"
        Me.dcstax.Size = New System.Drawing.Size(96, 14)
        Me.dcstax.TabIndex = 6
        Me.dcstax.Text = ":: "
        Me.dcstax.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label22.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(12, 122)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(79, 14)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "CST"
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label24.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(11, 100)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(79, 14)
        Me.Label24.TabIndex = 6
        Me.Label24.Text = "VAT"
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label21.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(10, 78)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(79, 14)
        Me.Label21.TabIndex = 6
        Me.Label21.Text = "SCESS"
        '
        'dcscess
        '
        Me.dcscess.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dcscess.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dcscess.ForeColor = System.Drawing.Color.Crimson
        Me.dcscess.Location = New System.Drawing.Point(91, 78)
        Me.dcscess.Name = "dcscess"
        Me.dcscess.Size = New System.Drawing.Size(96, 14)
        Me.dcscess.TabIndex = 6
        Me.dcscess.Text = ":: "
        Me.dcscess.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label19.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(10, 58)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(79, 14)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "CESS"
        '
        'dccess
        '
        Me.dccess.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dccess.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dccess.ForeColor = System.Drawing.Color.Crimson
        Me.dccess.Location = New System.Drawing.Point(91, 58)
        Me.dccess.Name = "dccess"
        Me.dccess.Size = New System.Drawing.Size(96, 14)
        Me.dccess.TabIndex = 6
        Me.dccess.Text = ":: "
        Me.dccess.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label15.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(10, 37)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(79, 14)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "BED/Ser"
        '
        'dcbed
        '
        Me.dcbed.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dcbed.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dcbed.ForeColor = System.Drawing.Color.Crimson
        Me.dcbed.Location = New System.Drawing.Point(91, 37)
        Me.dcbed.Name = "dcbed"
        Me.dcbed.Size = New System.Drawing.Size(96, 14)
        Me.dcbed.TabIndex = 6
        Me.dcbed.Text = ":: "
        Me.dcbed.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label11.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(10, 17)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(79, 14)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "P_F"
        '
        'dcpf
        '
        Me.dcpf.BackColor = System.Drawing.Color.WhiteSmoke
        Me.dcpf.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dcpf.ForeColor = System.Drawing.Color.Crimson
        Me.dcpf.Location = New System.Drawing.Point(91, 17)
        Me.dcpf.Name = "dcpf"
        Me.dcpf.Size = New System.Drawing.Size(96, 14)
        Me.dcpf.TabIndex = 6
        Me.dcpf.Text = ":: "
        Me.dcpf.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.dcpf)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.dcbed)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.dccess)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.dcscess)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label24)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.dcstax)
        Me.GroupBox2.Controls.Add(Me.dcvat)
        Me.GroupBox2.Controls.Add(Me.dctt)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.dcoth)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Location = New System.Drawing.Point(721, 631)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 17)
        Me.GroupBox2.TabIndex = 16
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "DC Tax "
        Me.GroupBox2.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(9, 202)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(105, 13)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "ORDER  VALUE (I) :"
        Me.Label12.Visible = False
        '
        'lblcval
        '
        Me.lblcval.BackColor = System.Drawing.Color.White
        Me.lblcval.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcval.ForeColor = System.Drawing.Color.Purple
        Me.lblcval.Location = New System.Drawing.Point(111, 201)
        Me.lblcval.Name = "lblcval"
        Me.lblcval.Size = New System.Drawing.Size(96, 14)
        Me.lblcval.TabIndex = 6
        Me.lblcval.Text = ":: "
        Me.lblcval.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblcval.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(232, 201)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(75, 13)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "DC VALUE(I) :"
        Me.Label16.Visible = False
        '
        'lblcdcval
        '
        Me.lblcdcval.BackColor = System.Drawing.Color.White
        Me.lblcdcval.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcdcval.ForeColor = System.Drawing.Color.Purple
        Me.lblcdcval.Location = New System.Drawing.Point(303, 200)
        Me.lblcdcval.Name = "lblcdcval"
        Me.lblcdcval.Size = New System.Drawing.Size(96, 14)
        Me.lblcdcval.TabIndex = 14
        Me.lblcdcval.Text = "::"
        Me.lblcdcval.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblcdcval.Visible = False
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.White
        Me.Label9.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Crimson
        Me.Label9.Location = New System.Drawing.Point(410, 387)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(214, 14)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Order Qty Tax Details"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.White
        Me.Label10.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Crimson
        Me.Label10.Location = New System.Drawing.Point(696, 389)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(214, 14)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "DC Qty Tax Details"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbordertot
        '
        Me.lbordertot.BackColor = System.Drawing.Color.WhiteSmoke
        Me.lbordertot.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbordertot.ForeColor = System.Drawing.Color.Crimson
        Me.lbordertot.Location = New System.Drawing.Point(566, 595)
        Me.lbordertot.Name = "lbordertot"
        Me.lbordertot.Size = New System.Drawing.Size(96, 14)
        Me.lbordertot.TabIndex = 6
        Me.lbordertot.Text = ":: "
        Me.lbordertot.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtcur
        '
        Me.txtcur.BackColor = System.Drawing.Color.White
        Me.txtcur.Location = New System.Drawing.Point(1026, 330)
        Me.txtcur.Name = "txtcur"
        Me.txtcur.ReadOnly = True
        Me.txtcur.Size = New System.Drawing.Size(52, 20)
        Me.txtcur.TabIndex = 1
        Me.txtcur.Visible = False
        '
        'pocheck
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1127, 651)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.richdc)
        Me.Controls.Add(Me.dgvtaxdetails)
        Me.Controls.Add(Me.txtvendorid)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.txtrate)
        Me.Controls.Add(Me.txtline)
        Me.Controls.Add(Me.txtdc)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.lblcdcval)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.lbldcval)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TXTGNO)
        Me.Controls.Add(Me.TXTPOOSP)
        Me.Controls.Add(Me.TXTPQTY)
        Me.Controls.Add(Me.TXTITEM)
        Me.Controls.Add(Me.BTLCALTAX)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.lbrate)
        Me.Controls.Add(Me.lbfreight)
        Me.Controls.Add(Me.lbordertot)
        Me.Controls.Add(Me.lbldctotval)
        Me.Controls.Add(Me.btngo)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.lblcval)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblval)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.dgv3)
        Me.Controls.Add(Me.dgv2)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.txtlocation)
        Me.Controls.Add(Me.txtvendor)
        Me.Controls.Add(Me.txtpodate)
        Me.Controls.Add(Me.txtcur)
        Me.Controls.Add(Me.txtpo)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.richorder)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "pocheck"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PO PENDING VIEW"
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgv3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvtax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.dgvtaxdetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtpo As System.Windows.Forms.TextBox
    Friend WithEvents txtpodate As System.Windows.Forms.TextBox
    Friend WithEvents txtvendor As System.Windows.Forms.TextBox
    Friend WithEvents txtlocation As System.Windows.Forms.TextBox
    Friend WithEvents dgv1 As System.Windows.Forms.DataGridView
    Friend WithEvents dgv2 As System.Windows.Forms.DataGridView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblval As System.Windows.Forms.Label
    Friend WithEvents btngo As System.Windows.Forms.Button
    Friend WithEvents txt1 As System.Windows.Forms.TextBox
    Friend WithEvents dgv3 As System.Windows.Forms.DataGridView
    Friend WithEvents BTLCALTAX As System.Windows.Forms.Button
    Friend WithEvents TXTITEM As System.Windows.Forms.TextBox
    Friend WithEvents TXTPQTY As System.Windows.Forms.TextBox
    Friend WithEvents TXTPOOSP As System.Windows.Forms.TextBox
    Friend WithEvents TXTGNO As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lbldcval As System.Windows.Forms.Label
    Friend WithEvents lbldctotval As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtdc As System.Windows.Forms.TextBox
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtrate As System.Windows.Forms.TextBox
    Friend WithEvents txtrole As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents lbfreight As System.Windows.Forms.Label
    Friend WithEvents lbrate As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtline As System.Windows.Forms.TextBox
    Friend WithEvents dgvtax As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtvendorid As System.Windows.Forms.TextBox
    Friend WithEvents dgvtaxdetails As System.Windows.Forms.DataGridView
    Friend WithEvents richorder As System.Windows.Forms.RichTextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents richdc As System.Windows.Forms.RichTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label

    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents dcoth As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents dctt As System.Windows.Forms.Label
    Friend WithEvents dcvat As System.Windows.Forms.Label
    Friend WithEvents dcstax As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents dcscess As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents dccess As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents dcbed As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents dcpf As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As Label
    Friend WithEvents lblcval As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lblcdcval As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lbordertot As Label
    Friend WithEvents txtcur As TextBox
End Class
