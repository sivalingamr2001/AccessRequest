Imports System.Windows.Forms

Public Class WinControl

    ' This is the function used in order to block the keyboard and mouse:
    Declare Function BlockInput Lib "User32" _
           (ByVal fBlockIt As Boolean) As Boolean
    ' This function will block the keyboard and mouse untill a window with
    ' the specify caption will appear or the given time in seconds has 
    ' past ( 0 seconds - wait forever).
    ' If the window with the caption appears than the given key is send 
    ' to it and the input block is removed.
    Public Shared Function Wait2Send(ByVal caption As String, _
              ByVal keys As String, ByVal seconds As Integer)

        ' Indicates if the window with the given caption was found
        Dim success As Boolean = False

        ' Start time of the function
        Dim now As DateTime = DateTime.Now

        ' Begining of keyboard and mouse block
        BlockInput(True)

        While (success = False And (DateTime.Now.Subtract(now).Seconds _
                                               < seconds Or seconds = 0))
            Try
                ' Activating the window with desired function
                ' if the window is not found an exception is thrown.
                AppActivate(caption)

                ' Sending desired key stroke to the application window
                SendKeys.SendWait(keys)

                ' Indicates the window was found and keys sent
                success = True

            Catch
                ' Assuming window was not found and sleep for 100 miliseconds
                System.Threading.Thread.Sleep(100)
            End Try
        End While
        ' Release the keyboard block
        BlockInput(False)

    End Function

End Class