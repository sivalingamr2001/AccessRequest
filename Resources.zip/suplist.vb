Imports System.Data.OracleClient
Public Class suplist

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        If rdurg.Checked = True Then
            If cmbsup.SelectedItem <> "" And txtitem.Text <> "" And txtname.Text <> "" Then
                GoTo ins
            Else
                MessageBox.Show("Enter Supplier,Item no,follower name", "Gate Register")
                Exit Sub
            End If
        End If
ins:
        sql = "insert into jan_gate_supplier (supplier_name,type"
        If rdurg.Checked = True Then sql &= ",item,dt,dt1,FNAME,EDATE"
        sql &= ")"
        sql &= "values ('" & cmbsup.SelectedItem & "'"
        If rdadi.Checked = True And sealed.Checked = False Then sql &= ",'ADI'"
        If sealed.Checked = True And rdadi.Checked = False Then sql &= ",'ADINEW'"
        If rdurg.Checked = True Then sql &= " ,'URGENT','" & txtitem.Text & "','" & Format(dt.Value, "dd-MMM-yyyy") & "','" & Format(dt1.Value, "dd-MMM-yyyy") & "','" & txtname.Text & "',SYSDATE"
        sql &= ")"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        MessageBox.Show("Supplier Details added", "Gate Register")
        cmbsup.SelectedIndex = -1
        txtitem.Text = ""
        txtname.Text = ""
    End Sub

    Private Sub suplist_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        sql = "select vendor_name from po_vendors where vendor_type_lookup_code <>'EMPLOYEE' order by vendor_name asc"
        cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        ds = New DataSet()
        cl.oradap.Fill(ds, "resultab")
        For i = 0 To ds.Tables("resultab").Rows.Count - 1
            cmbsup.Items.Add(ds.Tables("resultab").Rows(i).Item("vendor_name").ToString.Replace("'", "''"))
        Next
    End Sub

    Private Sub btncan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncan.Click
        If txtitem.Text = "" Then
            sql = "delete  from jan_gate_supplier where  supplier_name='" & cmbsup.SelectedItem & "' and item is null"
        Else
            sql = "delete from jan_gatE_supplier where supplier_name='" & cmbsup.SelectedItem & "' and item='" & txtitem.Text & "' and dt>='" & Format(dt.Value, "dd-MMM-yyyy") & "' and dt1<='" & Format(dt1.Value, "dd-MMM-yyyy") & "'"
        End If
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        MessageBox.Show("Urgent List deleted", "Gate Register")
        cmbsup.SelectedIndex = -1
        txtitem.Text = ""
    End Sub

    Private Sub rdadi_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdadi.CheckedChanged
        If rdadi.Checked = True Then
            txtname.Enabled = False : txtitem.Enabled = False
        Else
            txtname.Enabled = True : txtitem.Enabled = True
        End If
    End Sub
End Class