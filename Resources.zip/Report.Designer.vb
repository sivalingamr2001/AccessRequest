<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Report
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtfm = New System.Windows.Forms.DateTimePicker
        Me.Button1 = New System.Windows.Forms.Button
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmbcat = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.btnnval = New System.Windows.Forms.Button
        Me.btngt = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rdser = New System.Windows.Forms.RadioButton
        Me.rdpo = New System.Windows.Forms.RadioButton
        Me.rdosp = New System.Windows.Forms.RadioButton
        Me.btnprintnew = New System.Windows.Forms.Button
        Me.cmborg = New System.Windows.Forms.ComboBox
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.po = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.cmbval = New System.Windows.Forms.ComboBox
        Me.dtto = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.txtrole = New System.Windows.Forms.TextBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtfm
        '
        Me.dtfm.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtfm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtfm.Location = New System.Drawing.Point(72, 20)
        Me.dtfm.Name = "dtfm"
        Me.dtfm.Size = New System.Drawing.Size(93, 21)
        Me.dtfm.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(-1, 109)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(51, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Print"
        Me.Button1.UseVisualStyleBackColor = True
        Me.Button1.Visible = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(183, 0)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(83, 17)
        Me.RadioButton1.TabIndex = 2
        Me.RadioButton1.Text = "Not Validate"
        Me.RadioButton1.UseVisualStyleBackColor = True
        Me.RadioButton1.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Gate Date"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmbcat)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.btnnval)
        Me.GroupBox1.Controls.Add(Me.btngt)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.btnprintnew)
        Me.GroupBox1.Controls.Add(Me.cmborg)
        Me.GroupBox1.Controls.Add(Me.RadioButton2)
        Me.GroupBox1.Controls.Add(Me.po)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.cmbval)
        Me.GroupBox1.Controls.Add(Me.dtto)
        Me.GroupBox1.Controls.Add(Me.dtfm)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 20)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(606, 134)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Report For"
        '
        'cmbcat
        '
        Me.cmbcat.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcat.FormattingEnabled = True
        Me.cmbcat.Items.AddRange(New Object() {"BINS", "CASH PURCHASE", "COURIER - POD", "INTER UNIT TRANSFERS", "MAINTENANCE ITEMS", "OPEN CHALLAN", "SCRAP", "S8 CHALLAN - TOOL & DIE", "S8 CHALLAN - GAUGES", "SAMPLES", "SALES RETURN", "TESTING"})
        Me.cmbcat.Location = New System.Drawing.Point(287, 50)
        Me.cmbcat.Name = "cmbcat"
        Me.cmbcat.Size = New System.Drawing.Size(237, 21)
        Me.cmbcat.TabIndex = 76
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(182, 53)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 20)
        Me.Label19.TabIndex = 77
        Me.Label19.Text = "Inward Category"
        '
        'btnnval
        '
        Me.btnnval.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnnval.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnnval.Location = New System.Drawing.Point(357, 87)
        Me.btnnval.Name = "btnnval"
        Me.btnnval.Size = New System.Drawing.Size(98, 23)
        Me.btnnval.TabIndex = 75
        Me.btnnval.Text = "Not Validate List"
        Me.btnnval.UseVisualStyleBackColor = True
        '
        'btngt
        '
        Me.btngt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btngt.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btngt.Location = New System.Drawing.Point(247, 87)
        Me.btngt.Name = "btngt"
        Me.btngt.Size = New System.Drawing.Size(104, 23)
        Me.btngt.TabIndex = 74
        Me.btngt.Text = "Gate+Receipt"
        Me.btngt.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rdser)
        Me.GroupBox2.Controls.Add(Me.rdpo)
        Me.GroupBox2.Controls.Add(Me.rdosp)
        Me.GroupBox2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(6, 40)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(169, 41)
        Me.GroupBox2.TabIndex = 73
        Me.GroupBox2.TabStop = False
        '
        'rdser
        '
        Me.rdser.AutoSize = True
        Me.rdser.Location = New System.Drawing.Point(95, 14)
        Me.rdser.Name = "rdser"
        Me.rdser.Size = New System.Drawing.Size(68, 17)
        Me.rdser.TabIndex = 76
        Me.rdser.TabStop = True
        Me.rdser.Text = "Service"
        Me.rdser.UseVisualStyleBackColor = True
        '
        'rdpo
        '
        Me.rdpo.AutoSize = True
        Me.rdpo.Checked = True
        Me.rdpo.Location = New System.Drawing.Point(7, 14)
        Me.rdpo.Name = "rdpo"
        Me.rdpo.Size = New System.Drawing.Size(41, 17)
        Me.rdpo.TabIndex = 72
        Me.rdpo.TabStop = True
        Me.rdpo.Text = "PO"
        Me.rdpo.UseVisualStyleBackColor = True
        '
        'rdosp
        '
        Me.rdosp.AutoSize = True
        Me.rdosp.Location = New System.Drawing.Point(49, 15)
        Me.rdosp.Name = "rdosp"
        Me.rdosp.Size = New System.Drawing.Size(49, 17)
        Me.rdosp.TabIndex = 72
        Me.rdosp.Text = "OSP"
        Me.rdosp.UseVisualStyleBackColor = True
        '
        'btnprintnew
        '
        Me.btnprintnew.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnprintnew.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprintnew.Location = New System.Drawing.Point(192, 87)
        Me.btnprintnew.Name = "btnprintnew"
        Me.btnprintnew.Size = New System.Drawing.Size(49, 23)
        Me.btnprintnew.TabIndex = 71
        Me.btnprintnew.Text = "Print"
        Me.btnprintnew.UseVisualStyleBackColor = True
        '
        'cmborg
        '
        Me.cmborg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmborg.FormattingEnabled = True
        Me.cmborg.Location = New System.Drawing.Point(524, 21)
        Me.cmborg.Name = "cmborg"
        Me.cmborg.Size = New System.Drawing.Size(50, 21)
        Me.cmborg.TabIndex = 70
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(51, 111)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(67, 17)
        Me.RadioButton2.TabIndex = 2
        Me.RadioButton2.Text = "Gate List"
        Me.RadioButton2.UseVisualStyleBackColor = True
        Me.RadioButton2.Visible = False
        '
        'po
        '
        Me.po.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.po.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.po.Location = New System.Drawing.Point(111, 87)
        Me.po.Name = "po"
        Me.po.Size = New System.Drawing.Size(77, 23)
        Me.po.TabIndex = 66
        Me.po.Text = "Gate+PO"
        Me.po.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(496, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 65
        Me.Label3.Text = "Org"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(286, 24)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(50, 13)
        Me.Label13.TabIndex = 65
        Me.Label13.Text = "Criteria"
        '
        'cmbval
        '
        Me.cmbval.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbval.FormattingEnabled = True
        Me.cmbval.Items.AddRange(New Object() {"All", "Gate", "Not Validated", "Action Taken", "Validated", "RTV", "No Reference"})
        Me.cmbval.Location = New System.Drawing.Point(340, 19)
        Me.cmbval.Name = "cmbval"
        Me.cmbval.Size = New System.Drawing.Size(150, 21)
        Me.cmbval.TabIndex = 64
        '
        'dtto
        '
        Me.dtto.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtto.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtto.Location = New System.Drawing.Point(190, 20)
        Me.dtto.Name = "dtto"
        Me.dtto.Size = New System.Drawing.Size(93, 21)
        Me.dtto.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(167, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(21, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "To"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(682, 44)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(89, 23)
        Me.Button4.TabIndex = 69
        Me.Button4.Text = "Gate Validate"
        Me.Button4.UseVisualStyleBackColor = True
        Me.Button4.Visible = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(438, 1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(59, 23)
        Me.Button3.TabIndex = 68
        Me.Button3.Text = "Validate"
        Me.Button3.UseVisualStyleBackColor = True
        Me.Button3.Visible = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(38, 0)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(109, 23)
        Me.Button2.TabIndex = 67
        Me.Button2.Text = "Not validate pend"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(222, 3)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.Visible = False
        '
        'txtrole
        '
        Me.txtrole.Location = New System.Drawing.Point(351, 3)
        Me.txtrole.Name = "txtrole"
        Me.txtrole.Size = New System.Drawing.Size(100, 20)
        Me.txtrole.TabIndex = 6
        Me.txtrole.Visible = False
        '
        'Report
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(810, 166)
        Me.Controls.Add(Me.txtrole)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.RadioButton1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Report"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Report"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dtfm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents dtto As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cmbval As System.Windows.Forms.ComboBox
    Friend WithEvents po As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents txtrole As System.Windows.Forms.TextBox
    Friend WithEvents cmborg As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rdpo As System.Windows.Forms.RadioButton
    Friend WithEvents rdosp As System.Windows.Forms.RadioButton
    Friend WithEvents btnprintnew As System.Windows.Forms.Button
    Friend WithEvents btngt As System.Windows.Forms.Button
    Friend WithEvents btnnval As System.Windows.Forms.Button
    Friend WithEvents rdser As System.Windows.Forms.RadioButton
    Friend WithEvents cmbcat As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
End Class
