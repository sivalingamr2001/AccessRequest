﻿Imports oracleclass
Imports System.Data
Imports System.Data.OracleClient

Public Class operation_eod_exception
    Dim cl As New oracleclass.Class1
    Private Sub operation_eod_exception_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '     Dim dt As DataTable = Me.GetData("select    major_process
        'from JAN_operations_process_master")

        '     Me.PopulateTreeView(dt, 0, Nothing)
        sql = "select PROC_ID,MAJOR_PROCESS,PROCESSNAME,PROCESS_DESCRIPTION,PHASE_OF_IMPLEMENTATION_OF_V2K_INITIATIVES,nvl(eod_id,exception_id )
from JAN_operations_process_master"
        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "val")
        With DataGridView1
            .DataSource = ds.Tables("val")
            .Columns(0).HeaderText = "Process ID" : .Columns(0).Width = 80
            .Columns(1).HeaderText = "Process Type" : .Columns(1).Width = 120
            .Columns(2).HeaderText = "Process Name" : .Columns(2).Width = 120
            .Columns(3).HeaderText = "Process Desc" : .Columns(3).Width = 250
            .Columns(4).HeaderText = "Category" : .Columns(4).Width = 50
            '.Columns(5).Visible = False
            '.Columns(6).Visible = False


        End With

        For k = 0 To DataGridView1.Rows.Count - 1
            If Not IsDBNull(DataGridView1.Rows(k).Cells(5).Value) Then
                DataGridView1.Rows(k).Cells(0).Style.BackColor = Color.Red
            End If

        Next


    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        sql = "select process_id,(select process_name from jan_eod_process_master where idno=a.process_id and rownum=1)process_name,count(*)cnt from jan_eod_transactions a where process_id in (" & DataGridView1.CurrentRow.Cells(5).Value & ") and operating_unit=103 and comp_flag=0  "

        sql &= "  and a.target_DAte>= TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.target_DAte<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "

        sql &= " group by process_id"

        sql &= " union all"

        sql &= " select exception_id,remarks, count  (*)cnt  from jan_outward_new_requirement a where exception_id in (" & DataGridView1.CurrentRow.Cells(5).Value & ") and org_id in (select organization_id from jan_organization_list_View where org_id=103 ) "

        sql &= "  and  a.created_dt>= TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.created_dt<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "

        sql &= " group by  exception_id,remarks"

        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "exp")
        With DataGridView3
            .DataSource = ds.Tables("exp")
            .Columns(0).HeaderText = "Process ID" : .Columns(0).Width = 60
            .Columns(1).HeaderText = "Process Name" : .Columns(1).Width = 150
            .Columns(2).HeaderText = "Total" : .Columns(2).Width = 60

        End With

    End Sub

    Private Sub DataGridView3_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView3.CellClick
        sql = "select  org,item_no,item_Desc,vendor_name,ref_id,ref_dt,target_date,responsible_person from jan_eod_excel_list a  where operating_unit=103  and process_id=" & DataGridView3.CurrentRow.Cells(0).Value & " and a.target_DAte>= TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.target_DAte<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "
        adap = New OracleDataAdapter(sql, cl.oracon)
        ds = New DataSet
        adap.Fill(ds, "expbrk")
        If ds.Tables("expbrk").Rows.Count > 0 Then
            With DataGridView2
                .DataSource = ds.Tables("expbrk")
                .Columns(0).HeaderText = "Org" : .Columns(0).Width = 30
                .Columns(1).HeaderText = "Item No" : .Columns(1).Width = 100
                .Columns(2).HeaderText = "Item Desc" : .Columns(2).Width = 150
                .Columns(3).HeaderText = "Vendor" : .Columns(3).Width = 150
                .Columns(4).HeaderText = "Ref ID" : .Columns(4).Width = 80
                .Columns(5).HeaderText = "Ref Dt" : .Columns(5).Width = 80
                .Columns(6).HeaderText = "Target Dt" : .Columns(6).Width = 80
                .Columns(7).HeaderText = "Responsible Person" : .Columns(7).Width = 200
            End With
        Else
            sql = " select jan_orgcode(org_id)org,jan_itemname(item_id)item_no,jan_itemdesc(jan_itemname(item_id))item_desc,job_qty  from jan_outward_new_requirement a where org_id in (select organization_id from jan_organization_list_View where org_id=103) and exception_id= " & DataGridView3.CurrentRow.Cells(0).Value & " and a.created_dt>= TO_DATE('" & Format(inwdtf.Value, "dd/MM/yyyy") & " 00:00:00','DD/MM/YYYY HH24:MI:SS') and  a.created_dt<=TO_DATE('" & Format(inwdtto.Value, "dd/MM/yyyy") & " 23:59:00','DD/MM/YYYY HH24:MI:SS') "
            adap = New OracleDataAdapter(sql, cl.oracon)
            ds = New DataSet
            adap.Fill(ds, "expbrk")
            If ds.Tables("expbrk").Rows.Count > 0 Then
                With DataGridView2
                    .DataSource = ds.Tables("expbrk")
                    .Columns(0).HeaderText = "Org" : .Columns(0).Width = 30
                    .Columns(1).HeaderText = "Item No" : .Columns(1).Width = 100
                    .Columns(2).HeaderText = "Item Desc" : .Columns(2).Width = 150
                    .Columns(3).HeaderText = "Qty" : .Columns(3).Width = 30
                End With
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub



    'Private Function GetData(query As String) As DataTable
    '    Dim dt As New DataTable

    '    dt = ds.Tables(0)
    '    Return dt
    'End Function


    'Private Sub PopulateTreeView(dtParent As DataTable, parentId As String, treeNode As TreeNode)
    '    For Each row As DataRow In dtParent.Rows
    '        Dim child As New TreeNode() With {
    '         .Text = row("major_process").ToString(),
    '         .Tag = row("major_process")
    '        }
    '        If parentId = 0 Then
    '            TreeView1.Nodes.Add(child)
    '            Dim dtChild As DataTable = Me.GetData("SELECT proc_Id, processname FROM JAN_operations_process_master WHERE major_process = '" & child.Tag & "'")
    '            PopulateTreeView(dtChild, Convert.ToString(child.Tag), child)
    '        Else
    '            treeNode.Nodes.Add(child)
    '        End If
    '    Next
    'End Sub
End Class