Imports System.Data.OracleClient
Imports oracleclass
Public Class pocheck

    Dim valt, pf1, pft, bed1, bedt, cess1, cesst, scess1, scesst, stax1, staxt, others1, otherst, ttax1, ttaxt, dc, dc1, value1, mpf, mbed, mcess, mscess, mtax, moth, moth1, mtotal, mt1, tax, tax1, mpf1, mbed1, mcess1, mscess1, mtax1, svat, svat1, mvat, mvat1, ser, sert, cvalt, dc2, value2 As Double
    Dim ospds, pods, dsadd, rejds, vds, dspo As New DataSet
    Dim dbind As New BindingSource
    Dim ltype, pur, irevision, desc, uom, oaqty, pendqty, SUPDC, uprice, value, dcval1, itemclass, tno, pfper, pf, bedpr, bed, cessper, cess, scessper, scess, staxper, stax, others, ttax, pono, podt, sh, ven, it, po, ap, apdt, ndt, apcst As DataGridViewTextBoxColumn
    Dim dctax, ordertax, dcval, orderval, dctot, ordertot As Decimal
    Dim total As Double
    Dim cl As New oracleclass.Class1
    Private Sub btngo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btngo.Click
        Try
            Me.Cursor = Cursors.WaitCursor

            ds.Clear() : ds.Dispose()
            ds1.Clear() : ds1.Dispose()
            pods.Clear() : pods.Dispose()

            txtpodate.Text = "" : txtvendor.Text = "" : txtlocation.Text = ""

            If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()

            cl.sql = "SELECT B.pono,B.po_date,B.vendor_name,B.sh_location,B.line_type,A.item"
            'If TXTPOOSP.Text = "PO" Then cl.sql &= "B.item item"
            'If TXTPOOSP.Text = "OSP" Then cl.sql &= "decode(partno,null,partno1,partno) item"

            cl.sql &= ",B.item_description,B.uom,B.line_qty,b.pend_qty,A.SUPDCQTY,b.unit_price,round((B.unit_price*B.line_qty),2)value,round((b.unit_price * a.supdcqty),2) DcVal,B.item_class,B.HSN_CODE,a.line_no,b.po_price,round((B.po_price*B.line_qty),2)cvalue,round((b.po_price * a.supdcqty),2) cDcVal,b.currency_code, (select  nvl(nvl(segment2,segment11),segment17) from gl_code_combinations where code_combination_id in (select code_combination_id from po_distributions_all where line_location_id=b.line_location_id)) ch,"

            cl.sql &= "(select description from FND_FLEX_VALUES_VL where rownum=1 and flex_value in (select nvl(nvl(segment2,segment11),segment17) from gl_code_combinations where code_combination_id in (select code_combination_id from po_distributions_all where line_location_id=b.line_location_id)))cod, "

            cl.sql &= "(select  nvl(nvl(segment3,segment12),segment18) from gl_code_combinations where code_combination_id in (select code_combination_id from po_distributions_all where line_location_id=b.line_location_id))ac,"

            cl.sql &= "  (select description from FND_FLEX_VALUES_VL where rownum=1 And flex_value in (select nvl(nvl(segment3,segment12),segment18) from gl_code_combinations where code_combination_id in (select code_combination_id from po_distributions_all where line_location_id=b.line_location_id)))acd "

            cl.sql &= " FROM JAN_GATE_LINES A,JAN_PURCHASE_2 B WHERE A.POHEAD=B.PO_HEADER_ID And a.flag =1 And A.POLINE=B.PO_LINE_ID  And a.location_id=b.line_location_id"

            'If TXTPOOSP.Text = "PO" Then cl.sql &= " And B.ITEM=A.ITEM "
            'If TXTPOOSP.Text = "OSP" Then cl.sql &= " And decode(partno,null,partno1,partno)=A.ITEM  "
            cl.sql &= " And A.GATE_NO='" & TXTGNO.Text & "'"
            If txt1.Text <> "" Then cl.sql &= " and B.pend_qty>0"
            cl.sql &= " order  by a.line_no"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds = New DataSet
            cl.oradap.Fill(ds, "resultab")

            If ds.Tables("resultab").Rows.Count <> 0 Then
                txtvendor.Text = ds.Tables("resultab").Rows(0).Item("vendor_name")
                txtlocation.Text = ds.Tables("resultab").Rows(0).Item("sh_location")
                txtpodate.Text = ds.Tables("resultab").Rows(0).Item("po_date")
                txtcur.Text = ds.Tables("resultab").Rows(0).Item("currency_code")
            End If

            '''''query for tax calculation
            ' TAXQUERY1()
            taxquery()
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            ds1 = New DataSet
            cl.oradap.Fill(ds1, "resultab")

            ''''''''''''''' grid2
            binddgv2()

            If TXTPOOSP.Text = "PO" Then
                cl.sql = "select b.pono,B.need_by_date,B.approved_flag ,to_char(B.approved_date,'dd/mm/yyyy') approved_date from jan_po_pending_bought_outs B,JAN_GATE_LINES A where B.po_HEADER_ID=A.POHEAD AND A.GATE_NO='" & TXTGNO.Text & "'   and a.flag = 1 AND A.POLINE=B.PO_LINE_ID and a.location_id=b.line_location_id"
            ElseIf TXTPOOSP.Text = "OSP" Then
                cl.sql = " select  b.pono,B.need_by_date,B.approved_flag ,to_char(B.approved_date,'dd/mm/yyyy') approved_date,B.PRICE from jan_po_pending_osp B,JAN_GATE_LINES A where B.po_HEADER_ID=A.POHEAD AND A.GATE_NO='" & TXTGNO.Text & "'  and a.flag = 1  AND A.POLINE=B.PO_LINE_ID and a.location_id=b.line_location_id"

            End If

            ',B.APPD_OSP_COST,ospcost_wef

            If txt1.Text <> "" Then cl.sql &= " and pend_qty>0"
            cl.sql &= " ORDER BY PONO"

            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            cl.oradap.Fill(dspo, "resultab")

            binddgv1()



            For Each orow As DataGridViewRow In dgv1.Rows
                Dim ostyle As New DataGridViewCellStyle()
                If Not IsDBNull(orow.Cells(14).Value) Then
                    If orow.Cells(14).Value = "OTIN" Or orow.Cells(14).Value = "FGIN" Then
                        ostyle.ForeColor = Color.Magenta
                        ostyle.Font = New Font("verdana", 8, FontStyle.Bold)
                        orow.Cells(14).Style = ostyle
                    End If

                    If orow.Cells(14).Value = "CCIN" Then
                        ostyle.ForeColor = Color.DarkGreen
                        ostyle.Font = New Font("verdana", 8, FontStyle.Bold)
                        orow.Cells(14).Style = ostyle
                    End If


                    If orow.Cells(14).Value = "CGIN" Then
                        ostyle.ForeColor = Color.Orchid
                        ostyle.Font = New Font("verdana", 8, FontStyle.Bold)
                        orow.Cells(14).Style = ostyle
                    End If
                End If


            Next
            valt = 0
            cvalt = 0
            lblval.Text = ""
            lbldcval.Text = ""

            lblcval.Text = ""
            lblcdcval.Text = ""


            dc1 = 0

            For i = 0 To ds.Tables("resultab").Rows.Count - 1
                valt = ds.Tables("resultab").Rows(i).Item("value") + valt
                dc = ds.Tables("resultab").Rows(i).Item("dcval")
                dc1 = dc + dc1

                '''''''' for import

                cvalt = ds.Tables("resultab").Rows(i).Item("cvalue") + cvalt
                dc = ds.Tables("resultab").Rows(i).Item("cdcval")
                dc2 = dc + dc2

            Next
            lblval.Text = valt
            lbldcval.Text = dc1
            If txtcur.Text <> "INR" Then
                lblcval.Visible = True
                lblcdcval.Visible = True
                Label12.Visible = True
                Label16.Visible = True

                lblcval.Text = cvalt
                lblcdcval.Text = dc2
            Else
                lblcval.Visible = False
                lblcdcval.Visible = False
                Label12.Visible = False
                Label16.Visible = False
            End If

            'lbcordertot.Text = lblcval.Text
            'lbldcctotval.Text = dc2
            order()
            dcorder()

            ''''''''grid3
            binddgv3()
            '  dccalc()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
            Me.Cursor = Cursors.Arrow
        End Try
        Me.Cursor = Cursors.Arrow
    End Sub

    Private Sub pocheck_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If txtrole.Text = "UNIT2VIEW" Or txtrole.Text = "USER" Then
            Label17.Visible = False : Label23.Visible = False : txtrate.Visible = False : txtdc.Visible = False : btnsave.Visible = False : Label29.Visible = False : txtline.Visible = False
            Label5.Visible = False : Label6.Visible = False : lblval.Visible = False : lbldcval.Visible = False : richorder.Visible = False : richdc.Visible = False : Label9.Visible = False : Label10.Visible = False : lblcval.Visible = False : lblcdcval.Visible = False

            lbfreight.Visible = False : lbrate.Visible = False : lbldctotval.Visible = False : lbordertot.Visible = False : Label8.Visible = False : Label26.Visible = False : Label28.Visible = False : Label13.Visible = False
        Else

            Label17.Visible = True : Label23.Visible = True : txtrate.Visible = True : txtdc.Visible = True : btnsave.Visible = True : Label29.Visible = True : txtline.Visible = True
        End If


        cl.sql = "select  SUM(NVL(freigHt,0))FREIGHT,SUM(NVL(rate,0))RATE from jan_gatE_lines where   gatE_no='" & TXTGNO.Text & "'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        Dim d As New DataSet
        cl.oradap.Fill(d, "resultab")
        If d.Tables("resultab").Rows.Count > 0 Then
            lbfreight.Text = d.Tables("resultab").Rows(0).Item("freight").ToString
            lbrate.Text = d.Tables("resultab").Rows(0).Item("rate").ToString
        Else
            lbfreight.Text = "0" : lbrate.Text = "0"
        End If
        btngo_Click(sender, e)
        '   BTNCALTAX_Click(sender, e)
        cl.sql = "update jan_gate_header set dcval='" & lbldctotval.Text & "' where gate_no=" & TXTGNO.Text & ""
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()

        'If txtvendor.Text = "X'MAS STEELS PRIVATE LIMITED" Then
        '    cl.sql = "UPDATE JAN_GATe_HEADER SET SUPPLIER_NAME=(SELECT VENDOR_NAME FROM PO_VENDORS WHERE VENDOR_ID=1565) WHERE VENDOR_ID=1565 and gate_no= " & TXTGNO.Text & ""

        '    If CON.State = ConnectionState.Closed Then CON.Open()
        '    cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
        '    (cl.orcmd).ExecuteNonQuery()
        'ElseIf txtvendor.Text = "READ 'n' REACH" Then
        '    cl.sql = "UPDATE JAN_GATe_HEADER SET SUPPLIER_NAME=(SELECT VENDOR_NAME FROM PO_VENDORS WHERE VENDOR_ID=696325) WHERE VENDOR_ID=696325 and gate_no= " & TXTGNO.Text & ""

        '    If CON.State = ConnectionState.Closed Then CON.Open()
        '    cl.or(cl.orcmd) = New oracleCommand(cl.sql,cl.oracon)
        '    (cl.orcmd).ExecuteNonQuery()
        'End If

    End Sub

    Private Sub BTNCALTAX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTLCALTAX.Click
        dcpf.Text = "" : dccess.Text = "" : dcscess.Text = "" : dcstax.Text = ""
        dcoth.Text = "" : dctt.Text = "" : dcbed.Text = ""
        mpf1 = 0 : mbed1 = 0 : mcess1 = 0 : mtax1 = 0 : moth1 = 0 : mvat1 = 0 : mt1 = 0 : tax1 = 0
        Try
            cl.sql = "SELECT b.*,a.supdcqty FROM JAN_GATE_LINES A,JAN_PURCHASE_2 B WHERE A.POHEAD=B.PO_HEADER_ID  and a.flag = '" & 1 & "' AND A.POLINE=B.PO_LINE_ID  and A.location_id=B.line_location_id"
            If TXTPOOSP.Text = "PO" Then cl.sql &= " AND B.ITEM=A.ITEM"
            If TXTPOOSP.Text = "OSP" Then cl.sql &= "  AND (B.PARTNO || B.PARTNO1 )=A.ITEM"
            cl.sql &= " AND A.GATE_NO='" & TXTGNO.Text & "'"
            If txt1.Text <> "" Then cl.sql &= " and B.pend_qty>0"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            Dim dstax As New DataSet
            cl.oradap.Fill(dstax, "resultab")
            For i = 0 To dstax.Tables("resultab").Rows.Count - 1

                value1 = 0 : mpf = 0 : mbed = 0 : mcess = 0
                mtax = 0 : tax = 0 : mvat = 0
                moth = 0 : mtotal = 0


                '    p_f(+bed + service + cess + srv_cess + scess + srv_scess + cst + vat + others + total_tax)

                With dstax.Tables("resultab").Rows(i)
                    tax = .Item("total_tax")
                    value1 = .Item("unit_price") * .Item("supdcqty")
                    value2 = .Item("po_price") * .Item("supdcqty")

                    mpf = ((.Item("p_f") / .Item("line_qty")) * .Item("supdcqty"))
                    mpf = Math.Round(mpf, 2)
                    mpf1 = mpf + mpf1
                    mbed = (((.Item("bed") + .Item("service")) / .Item("line_qty")) * .Item("supdcqty"))
                    mbed = Math.Round(mbed, 2)
                    mbed1 = mbed + mbed1
                    mcess = (((.Item("cess") + .Item("srv_cess")) / .Item("line_qty")) * .Item("supdcqty"))
                    mcess = Math.Round(mcess, 2)
                    mcess1 = mcess + mcess1
                    mscess = (((.Item("scess") + .Item("srv_scess")) / .Item("line_qty")) * .Item("supdcqty"))
                    mscess = Math.Round(mscess, 2)
                    mscess1 = mscess + mscess1
                    mtax = ((.Item("cst") / .Item("line_qty")) * .Item("supdcqty"))

                    mtax1 = mtax + mtax1
                    mtax1 = Math.Round(mtax1, 2)
                    mvat = ((.Item("vat") / .Item("line_qty")) * .Item("supdcqty"))
                    mvat1 = mvat + mvat1
                    mvat1 = Math.Round(mvat1, 2)
                    moth = ((.Item("others") / .Item("line_qty")) * .Item("supdcqty"))
                    moth1 = moth + moth1
                    mtotal = (mpf + mbed + mcess + mscess + mtax + mvat + moth)
                    mtotal = Math.Round(mtotal, 2)
                    mt1 = mtotal + mt1
                    tax1 = Math.Round((tax + tax1), 2)
                End With
            Next
            dcpf.Text = Math.Round(mpf1, 2) : dcbed.Text = Math.Round(mbed1, 2) : dccess.Text = Math.Round(mcess1, 2) : dcscess.Text = Math.Round(mscess1, 2) : dcstax.Text = Math.Round(mtax1, 2) : dcvat.Text = Math.Round(mvat1, 2) : dcoth.Text = Math.Round(moth1, 2) : dctt.Text = Math.Round(mt1, 2)


            orderval = lblval.Text
            dcval = lbldcval.Text
            ' ordertax = ttlbl.Text
            dctax = dctt.Text
            ordertot = orderval + ordertax
            dctot = dcval + dctax
            'lbldctotval.Text = Math.Round(dctot, 2)           

            lbldctotval.Text = Math.Round(dctot + lbfreight.Text + lbrate.Text, 2)
            'lblototval.Text = Math.Round(ordertot, 2)
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Gate Entry")
        End Try
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        ' cl.sql = "update jan_gate_header set dcval='" & lbldctotval.Text & "',rate='" & txtrate.Text & "',freight='" & txtdc.Text & "' where gate_no='" & TXTGNO.Text & "'"
        cl.sql = "update jan_gatE_lines set rate='" & txtrate.Text & "',freight='" & txtdc.Text & "' where gate_no='" & TXTGNO.Text & "' and line_no='" & txtline.Text & "'"
        If cl.oracon.State = ConnectionState.Closed Then cl.oracon.Open()
        cl.orcmd = New OracleCommand(cl.sql, cl.oracon)
        cl.orcmd.ExecuteNonQuery()
        MessageBox.Show("Rate Values added", "Gate Register")
        txtrate.Text = "" : txtdc.Text = "" : txtline.Text = ""
    End Sub

    Private Sub dgv1_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv1.CellClick
        Dim d As New DataSet
        If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "UNIT2" Or txtrole.Text = "ADD1" Then
            Panel1.Visible = True
            dgvtax.Columns.Clear()
            cl.sql = "SELECT distinct GATe_NO, bed,bed_per,cess,cess_per,scess,scess_per,service,srv_cess,stx_cess_per,srv_scess,stx_scess_per,vat,vat_per,cst,cst_per,(select tariff from jan_gate_lines where item=a.item and gate_no='" & TXTGNO.Text & "' and line_no='" & dgv1.Rows(dgv1.CurrentRow.Index).Cells(16).Value & "' and rownum=1) tariff FROM JAN_PURCHASE_2 a,jan_gate_lines b  WHERE "
            'If TXTPOOSP.Text = "PO" Then cl.sql &= "  a.ITEM='" & dgv1.Rows(dgv1.CurrentRow.Index).Cells(5).Value.ToString.Substring(0, dgv1.Rows(dgv1.CurrentRow.Index).Cells(5).Value.ToString.IndexOf("-")) & "' "

            'If TXTPOOSP.Text = "OSP" Then

            'End If
            cl.sql &= "  a.ITEM='" & dgv1.Rows(dgv1.CurrentRow.Index).Cells(5).Value & "' "
            cl.sql &= " and NVL(REF_DOC_TRX_ID,A.po_header_ID)=b.poHEAD and a.line_location_id=b.location_id and a.item=b.item and a.vendor_name='" & txtvendor.Text.Replace("'", " ") & "' and b.flag=1 AND ROWNUM<4 "
            If txtrole.Text = "UNIT1" Or txtrole.Text = "INWARD" Or txtrole.Text = "ADD" Or txtrole.Text = "ADD1" Then cl.sql &= " and b.ORG<>'I01'"
            If txtrole.Text = "UNIT2" Then cl.sql &= " and b.ORG='I01'"
            cl.sql &= "ORDER BY GATE_NO DESC"
            cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
            Dim dstax1 As New DataSet
            cl.oradap.Fill(dstax1, "resultab")
            dgvtax.DataSource = dstax1.Tables("resultab")
            If dgvtax.Rows.Count > 0 Then
                dgvtax.Columns(0).HeaderText = "GATE"
                dgvtax.Columns(0).Width = 50
                dgvtax.Columns(1).HeaderText = "Bed"
                dgvtax.Columns(1).Width = 50
                dgvtax.Columns(2).HeaderText = "Bed%"
                dgvtax.Columns(2).Width = 50
                dgvtax.Columns(3).HeaderText = "Cess"
                dgvtax.Columns(3).Width = 50
                dgvtax.Columns(4).HeaderText = "Cess%"
                dgvtax.Columns(4).Width = 55
                dgvtax.Columns(5).HeaderText = "Scess"
                dgvtax.Columns(5).Width = 55
                dgvtax.Columns(6).HeaderText = "Scess%"
                dgvtax.Columns(6).Width = 55
                dgvtax.Columns(7).HeaderText = "Serv"
                dgvtax.Columns(7).Width = 55
                dgvtax.Columns(8).HeaderText = "SrvCess"
                dgvtax.Columns(8).Width = 55
                dgvtax.Columns(9).HeaderText = "SrvSCess"
                dgvtax.Columns(9).Width = 55
                dgvtax.Columns(10).HeaderText = "StxCess"
                dgvtax.Columns(10).Width = 55
                dgvtax.Columns(11).HeaderText = "StxSCess"
                dgvtax.Columns(11).Width = 55
                dgvtax.Columns(12).HeaderText = "Vat"
                dgvtax.Columns(12).Width = 40
                dgvtax.Columns(13).HeaderText = "Vat%"
                dgvtax.Columns(13).Width = 40
                dgvtax.Columns(14).HeaderText = "Cst"
                dgvtax.Columns(14).Width = 40
                dgvtax.Columns(15).HeaderText = "Cst%"
                dgvtax.Columns(15).Width = 40
                dgvtax.Columns(16).HeaderText = "tariff"
                dgvtax.Columns(16).Visible = False

                Dim cc As New DataGridViewTextBoxColumn
                cc.HeaderText = "Tariff"
                cc.Width = 50
                Me.dgvtax.Columns.Add(cc)
                If Not IsDBNull(dgvtax.Rows(dgvtax.CurrentRow.Index).Cells(16).Value) Then
                    If dgvtax.Rows(dgvtax.CurrentRow.Index).Cells(16).Value.ToString <> dgv1.Rows(dgv1.CurrentRow.Index).Cells(15).Value.ToString Then
                        dgvtax.Rows(0).Cells(17).Value = "No"
                    Else
                        dgvtax.Rows(0).Cells(17).Value = "Yes"
                    End If
                Else
                    dgvtax.Rows(0).Cells(17).Value = "No Tariff"
                End If

            End If
        End If
        cl.sql = "select  SUM(NVL(freigHt,0))FREIGHT,SUM(NVL(rate,0))RATE from jan_gatE_lines where   gatE_no='" & TXTGNO.Text & "'"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)

        cl.oradap.Fill(d, "resultab")
        If d.Tables("resultab").Rows.Count > 0 Then
            lbfreight.Text = d.Tables("resultab").Rows(0).Item("freight").ToString
            lbrate.Text = d.Tables("resultab").Rows(0).Item("rate").ToString
        Else
            lbfreight.Text = "0" : lbrate.Text = "0"
        End If
        cl.sql = "SELECT NVL(FREIGHT,0) FREIGHT,NVL(RATE,0) RATE FROM JAN_GATE_LINES WHERE GATE_NO='" & TXTGNO.Text & "' AND LINE_NO= '" & dgv1.Rows(dgv1.CurrentRow.Index).Cells(16).Value & "'"

        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        d = New DataSet
        cl.oradap.Fill(d, "RESULTAB")
        If d.Tables("resultab").Rows.Count > 0 Then
            txtdc.Text = d.Tables("resultab").Rows(0).Item("freight").ToString
            txtrate.Text = d.Tables("resultab").Rows(0).Item("rate").ToString
        Else
            txtdc.Text = "0" : txtrate.Text = "0"
        End If
        lbldctotval.Text = total + Val(lbfreight.Text) + Val(lbrate.Text) + Val(lbldcval.Text)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Panel1.Visible = False
    End Sub

    ''''commented function dccalc
    Public Sub dccalc()
        dcpf.Text = "" : dccess.Text = "" : dcscess.Text = "" : dcstax.Text = ""
        dcoth.Text = "" : dctt.Text = "" : dcbed.Text = ""
        mpf1 = 0 : mbed1 = 0 : mcess1 = 0 : mtax1 = 0 : moth1 = 0 : mvat1 = 0 : mt1 = 0 : tax1 = 0

        'cl.sql = "SELECT b.*,a.supdcqty FROM JAN_GATE_LINES A,JAN_PURCHASE_2 B WHERE A.POHEAD=B.PO_HEADER_ID  and a.flag = '" & 1 & "' AND A.POLINE=B.PO_LINE_ID  and A.location_id=B.line_location_id"
        'If TXTPOOSP.Text = "PO" Then cl.sql &= " AND B.ITEM=A.ITEM"
        'If TXTPOOSP.Text = "OSP" Then cl.sql &= "  AND (B.PARTNO || B.PARTNO1 )=A.ITEM"
        'cl.sql &= " AND A.GATE_NO='" & TXTGNO.Text & "'"
        'If txt1.Text <> "" Then cl.sql &= " and B.pend_qty>0"
        'cl.oradap = New oracleDataAdapter(cl.sql,cl.oracon)
        'Dim dstax As New DataSet
        'cl.oradap.Fill(dstax, "resultab")
        For i = 0 To ds1.Tables("resultab").Rows.Count - 1

            value1 = 0 : mpf = 0 : mbed = 0 : mcess = 0
            mtax = 0 : tax = 0 : mvat = 0
            moth = 0 : mtotal = 0

            With ds1.Tables("resultab").Rows(i)
                tax = .Item("total_tax")
                value1 = .Item("unit_price") * .Item("supdcqty")
                mpf = ((.Item("p_f") / .Item("line_qty")) * .Item("supdcqty"))
                mpf = Math.Round(mpf, 2)
                mpf1 = mpf + mpf1
                mbed = (((.Item("bed") + .Item("service")) / .Item("line_qty")) * .Item("supdcqty"))
                mbed = Math.Round(mbed, 2)
                mbed1 = mbed + mbed1
                mcess = (((.Item("cess") + .Item("srv_cess")) / .Item("line_qty")) * .Item("supdcqty"))
                mcess = Math.Round(mcess, 2)
                mcess1 = mcess + mcess1
                mscess = (((.Item("scess") + .Item("srv_scess")) / .Item("line_qty")) * .Item("supdcqty"))
                mscess = Math.Round(mscess, 2)
                mscess1 = mscess + mscess1
                mtax = ((.Item("cst") / .Item("line_qty")) * .Item("supdcqty"))

                mtax1 = mtax + mtax1
                mtax1 = Math.Round(mtax1, 2)
                mvat = ((.Item("vat") / .Item("line_qty")) * .Item("supdcqty"))
                mvat1 = mvat + mvat1
                mvat1 = Math.Round(mvat1, 2)
                moth = ((.Item("others") / .Item("line_qty")) * .Item("supdcqty"))
                moth1 = moth + moth1
                mtotal = (mpf + mbed + mcess + mscess + mtax + mvat + moth)
                mtotal = Math.Round(mtotal, 2)
                mt1 = mtotal + mt1
                tax1 = Math.Round((tax + tax1), 2)
            End With
        Next
        dcpf.Text = Math.Round(mpf1, 2) : dcbed.Text = Math.Round(mbed1, 2) : dccess.Text = Math.Round(mcess1, 2) : dcscess.Text = Math.Round(mscess1, 2) : dcstax.Text = Math.Round(mtax1, 2) : dcvat.Text = Math.Round(mvat1, 2) : dcoth.Text = Math.Round(moth1, 2) : dctt.Text = Math.Round(mt1, 2)


        orderval = lblval.Text
        dcval = lbldcval.Text
        ' ordertax = ttlbl.Text
        dctax = dctt.Text
        ordertot = orderval + ordertax
        dctot = dcval + dctax
        'lbldctotval.Text = Math.Round(dctot, 2)           

        lbldctotval.Text = Math.Round(dctot + lbfreight.Text + lbrate.Text, 2)
        ' lblototval.Text = Math.Round(ordertot, 2)
    End Sub

#Region "binding grid"

    Public Sub binddgv2()
        it = New DataGridViewTextBoxColumn
        it.HeaderText = "Item"
        it.DataPropertyName = "item"
        it.Width = 90
        Me.dgv2.Columns.Add(it)
        ' dgv2.Columns(1).Visible = False : dgv2.Columns(2).Visible = False : dgv2.Columns(3).Visible = False

        pfper = New DataGridViewTextBoxColumn
        pfper.HeaderText = "P_F Per"
        pfper.DataPropertyName = "poline"
        pfper.Width = 50
        pfper.Visible = False
        Me.dgv2.Columns.Add(pfper)

        pf = New DataGridViewTextBoxColumn
        pf.HeaderText = "P_F"
        pf.DataPropertyName = "pohead"
        pf.Width = 50
        pf.Visible = False
        Me.dgv2.Columns.Add(pf)

        bedpr = New DataGridViewTextBoxColumn
        bedpr.HeaderText = "BED Per/Ser"
        bedpr.DataPropertyName = "location_id"
        bedpr.Width = 55
        bedpr.Visible = False
        Me.dgv2.Columns.Add(bedpr)

        bed = New DataGridViewTextBoxColumn
        bed.HeaderText = "BED/Ser"
        bed.DataPropertyName = "line_no"
        bed.Visible = False
        bed.Width = 55
        Me.dgv2.Columns.Add(bed)

        'cessper = New DataGridViewTextBoxColumn
        'cessper.HeaderText = "CESS Per"
        'cessper.DataPropertyName = "cess_per"
        'cessper.Width = 50
        'Me.dgv2.Columns.Add(cessper)

        'cess = New DataGridViewTextBoxColumn
        'cess.HeaderText = "CESS"
        'cess.DataPropertyName = "CESS"
        'cess.Width = 50
        'Me.dgv2.Columns.Add(cess)

        'scessper = New DataGridViewTextBoxColumn
        'scessper.HeaderText = "SCESS Per"
        'scessper.DataPropertyName = "scess_per"
        'scessper.Width = 50
        'Me.dgv2.Columns.Add(scessper)

        'scess = New DataGridViewTextBoxColumn
        'scess.HeaderText = "SCESS"
        'scess.DataPropertyName = "scess"
        'scess.Width = 50
        'Me.dgv2.Columns.Add(scess)

        'stax = New DataGridViewTextBoxColumn
        'stax.HeaderText = "VAT Per"
        'stax.DataPropertyName = "vat_per"
        'stax.Width = 50
        'Me.dgv2.Columns.Add(stax)

        'staxper = New DataGridViewTextBoxColumn
        'staxper.HeaderText = "VAT"
        'staxper.DataPropertyName = "vat"
        'staxper.Width = 50
        'Me.dgv2.Columns.Add(staxper)

        'stax = New DataGridViewTextBoxColumn
        'stax.HeaderText = "CST Per"
        'stax.DataPropertyName = "cst_per"
        'stax.Width = 50
        'Me.dgv2.Columns.Add(stax)

        'staxper = New DataGridViewTextBoxColumn
        'staxper.HeaderText = "CST"
        'staxper.DataPropertyName = "cst"
        'staxper.Width = 50
        'Me.dgv2.Columns.Add(staxper)

        'others = New DataGridViewTextBoxColumn
        'others.HeaderText = "Others"
        'others.DataPropertyName = "others"
        'others.Width = 50
        'Me.dgv2.Columns.Add(others)

        'ttax = New DataGridViewTextBoxColumn
        'ttax.HeaderText = "TotalTax"
        'ttax.DataPropertyName = "total_tax"
        'ttax.Width = 70
        'Me.dgv2.Columns.Add(ttax)

        'ttax = New DataGridViewTextBoxColumn
        'ttax.HeaderText = "line"
        'ttax.DataPropertyName = "line_no"
        'ttax.Visible = False
        'Me.dgv2.Columns.Add(ttax)
        'ttax = New DataGridViewTextBoxColumn
        'ttax.DataPropertyName = "service"
        'ttax.Visible = False
        'Me.dgv2.Columns.Add(ttax)
        'ttax = New DataGridViewTextBoxColumn
        'ttax.DataPropertyName = "srv_cess"
        'ttax.Visible = False
        'Me.dgv2.Columns.Add(ttax)
        'ttax = New DataGridViewTextBoxColumn
        'ttax.DataPropertyName = "line_qty"
        'ttax.Visible = False
        'Me.dgv2.Columns.Add(ttax)
        'ttax = New DataGridViewTextBoxColumn
        'ttax.DataPropertyName = "srv_scess"
        'ttax.Visible = False
        'Me.dgv2.Columns.Add(ttax)
        'ttax = New DataGridViewTextBoxColumn
        'ttax.DataPropertyName = "unit_price"
        'ttax.Visible = False
        'Me.dgv2.Columns.Add(ttax)
        'ttax = New DataGridViewTextBoxColumn
        'ttax.DataPropertyName = "supdcqty"
        'ttax.Visible = False
        'Me.dgv2.Columns.Add(ttax)
        dgv2.DataSource = ds1.Tables("resultab")
    End Sub

    Public Sub binddgv3()
        po = New DataGridViewTextBoxColumn
        po.HeaderText = "Po"
        po.DataPropertyName = "pono"
        po.Width = 70
        Me.dgv3.Columns.Add(po)

        ap = New DataGridViewTextBoxColumn
        ap.HeaderText = "App"
        ap.DataPropertyName = "approved_flag"
        ap.Width = 30
        Me.dgv3.Columns.Add(ap)

        apdt = New DataGridViewTextBoxColumn
        apdt.HeaderText = "AppDt"
        apdt.DataPropertyName = "approved_date"
        apdt.Width = 120
        Me.dgv3.Columns.Add(apdt)

        ndt = New DataGridViewTextBoxColumn
        ndt.HeaderText = "NeedDt"
        ndt.DataPropertyName = "need_by_date"
        ndt.Width = 120
        Me.dgv3.Columns.Add(ndt)

        If txtrole.Text = "UNIT2VIEW" Or txtrole.Text = "USER" Then
            apcst = New DataGridViewTextBoxColumn
            apcst.HeaderText = "Unit.Rt"
            If TXTPOOSP.Text = "OSP" Then apcst.DataPropertyName = "PRICE"
            apcst.Width = 50
            apcst.Visible = False
            Me.dgv3.Columns.Add(apcst)

        Else
            apcst = New DataGridViewTextBoxColumn
            apcst.HeaderText = "Unit.Rt"
            If TXTPOOSP.Text = "OSP" Then apcst.DataPropertyName = "PRICE"
            apcst.Width = 50
            Me.dgv3.Columns.Add(apcst)
        End If
        'apcst = New DataGridViewTextBoxColumn
        'apcst.HeaderText = "Rev.Rt"
        'If TXTPOOSP.Text = "OSP" Then apcst.DataPropertyName = "appd_osp_cost"
        'apcst.Width = 50
        'Me.dgv3.Columns.Add(apcst)

        'apcst = New DataGridViewTextBoxColumn
        'apcst.HeaderText = "OSP.Ref Date"
        'If TXTPOOSP.Text = "OSP" Then apcst.DataPropertyName = "ospcost_wef"
        'apcst.Width = 80
        'Me.dgv3.Columns.Add(apcst)
        dgv3.DataSource = dspo.Tables("resultab")
    End Sub

    Public Sub binddgv1()
        ltype = New DataGridViewTextBoxColumn
        ltype.HeaderText = "LineType"
        ltype.DataPropertyName = "line_type"
        ltype.Width = 55
        ltype.ReadOnly = True
        Me.dgv1.Columns.Add(ltype)

        pur = New DataGridViewTextBoxColumn
        pur.HeaderText = "PO"
        pur.DataPropertyName = "pono"
        pur.Width = 80
        pur.ReadOnly = True
        Me.dgv1.Columns.Add(pur)

        irevision = New DataGridViewTextBoxColumn
        irevision.HeaderText = "Item-Revision"
        irevision.DataPropertyName = "Item"
        irevision.Width = 75
        irevision.ReadOnly = True
        Me.dgv1.Columns.Add(irevision)

        desc = New DataGridViewTextBoxColumn
        desc.HeaderText = "Item Description"
        desc.DataPropertyName = "Item_Description"
        desc.Width = 100
        desc.ReadOnly = True
        Me.dgv1.Columns.Add(desc)

        uom = New DataGridViewTextBoxColumn
        uom.HeaderText = "UOM"
        uom.DataPropertyName = "UOM"
        uom.Width = 50
        uom.ReadOnly = True
        Me.dgv1.Columns.Add(uom)

        oaqty = New DataGridViewTextBoxColumn
        oaqty.HeaderText = "Order Qty"
        oaqty.DataPropertyName = "line_qty"
        oaqty.Width = 60
        oaqty.ReadOnly = True
        Me.dgv1.Columns.Add(oaqty)

        pendqty = New DataGridViewTextBoxColumn
        pendqty.HeaderText = "Pend Qty"
        pendqty.DataPropertyName = "pend_qty"
        pendqty.Width = 60
        pendqty.ReadOnly = False
        Me.dgv1.Columns.Add(pendqty)

        SUPDC = New DataGridViewTextBoxColumn
        SUPDC.HeaderText = "DCQty"
        SUPDC.DataPropertyName = "SUPDCQTY"
        SUPDC.Width = 60
        SUPDC.ReadOnly = False
        Me.dgv1.Columns.Add(SUPDC)

        If txtrole.Text = "UNIT2VIEW" Or txtrole.Text = "USER" Then
            uprice = New DataGridViewTextBoxColumn
            uprice.HeaderText = "Unit Price"
            uprice.DataPropertyName = "Unit_price"
            uprice.Width = 50
            uprice.ReadOnly = True
            uprice.Visible = False
            Me.dgv1.Columns.Add(uprice)

            value = New DataGridViewTextBoxColumn
            value.HeaderText = "Value"
            value.DataPropertyName = "value"
            value.Width = 70
            value.ReadOnly = True
            value.Visible = False
            Me.dgv1.Columns.Add(value)

            dcval1 = New DataGridViewTextBoxColumn
            dcval1.HeaderText = "DcVal"
            dcval1.DataPropertyName = "dcval"
            dcval1.Width = 70
            dcval1.ReadOnly = True
            dcval1.Visible = False
            Me.dgv1.Columns.Add(dcval1)
        Else
            uprice = New DataGridViewTextBoxColumn
            uprice.HeaderText = "Unit Price"
            uprice.DataPropertyName = "Unit_price"
            uprice.Width = 60
            uprice.ReadOnly = True
            Me.dgv1.Columns.Add(uprice)

            value = New DataGridViewTextBoxColumn
            value.HeaderText = "Value"
            value.DataPropertyName = "value"
            value.Width = 70
            value.ReadOnly = True
            Me.dgv1.Columns.Add(value)

            dcval1 = New DataGridViewTextBoxColumn
            dcval1.HeaderText = "DcVal"
            dcval1.DataPropertyName = "dcval"
            dcval1.Width = 70
            dcval1.ReadOnly = True
            Me.dgv1.Columns.Add(dcval1)
        End If


        itemclass = New DataGridViewTextBoxColumn
        itemclass.HeaderText = "Item Class"
        itemclass.DataPropertyName = "Item_class"
        itemclass.Width = 45
        itemclass.ReadOnly = True
        Me.dgv1.Columns.Add(itemclass)

        tno = New DataGridViewTextBoxColumn
        tno.HeaderText = "HSN Code"
        tno.DataPropertyName = "hsn_code"
        tno.Width = 60
        tno.ReadOnly = True
        Me.dgv1.Columns.Add(tno)

        podt = New DataGridViewTextBoxColumn
        podt.DataPropertyName = "po_date"
        Me.dgv1.Columns.Add(podt)
        podt.Visible = False

        pono = New DataGridViewTextBoxColumn
        pono.DataPropertyName = "pono"
        Me.dgv1.Columns.Add(pono)
        pono.Visible = False

        sh = New DataGridViewTextBoxColumn
        sh.DataPropertyName = "sh_location"
        Me.dgv1.Columns.Add(sh)
        sh.Visible = False

        sh = New DataGridViewTextBoxColumn
        sh.DataPropertyName = "line_no"
        Me.dgv1.Columns.Add(sh)
        sh.Visible = False

        ven = New DataGridViewTextBoxColumn
        ven.DataPropertyName = "vendor_name"
        Me.dgv1.Columns.Add(ven)
        ven.Visible = False

        If txtcur.Text <> "INR" Then
            uprice = New DataGridViewTextBoxColumn
            uprice.HeaderText = "I-Unit Price"
            uprice.DataPropertyName = "po_price"
            uprice.Width = 50
            uprice.ReadOnly = True
            Me.dgv1.Columns.Add(uprice)

            value = New DataGridViewTextBoxColumn
            value.HeaderText = "I-Value"
            value.DataPropertyName = "cvalue"
            value.Width = 70
            value.ReadOnly = True
            Me.dgv1.Columns.Add(value)

            dcval1 = New DataGridViewTextBoxColumn
            dcval1.HeaderText = "I-DcVal"
            dcval1.DataPropertyName = "cdcval"
            dcval1.Width = 70
            dcval1.ReadOnly = True
            Me.dgv1.Columns.Add(dcval1)

            dcval1 = New DataGridViewTextBoxColumn
            dcval1.HeaderText = "Currency"
            dcval1.DataPropertyName = "currency_code"
            dcval1.Width = 70
            dcval1.ReadOnly = True
            Me.dgv1.Columns.Add(dcval1)
        Else
            uprice = New DataGridViewTextBoxColumn
            uprice.HeaderText = "I-Unit Price"
            uprice.DataPropertyName = "po_price"
            uprice.Width = 50
            uprice.ReadOnly = True
            uprice.Visible = False

            Me.dgv1.Columns.Add(uprice)

            value = New DataGridViewTextBoxColumn
            value.HeaderText = "I-Value"
            value.DataPropertyName = "cvalue"
            value.Width = 70
            value.ReadOnly = True
            value.Visible = False
            Me.dgv1.Columns.Add(value)

            dcval1 = New DataGridViewTextBoxColumn
            dcval1.HeaderText = "I-DcVal"
            dcval1.DataPropertyName = "cdcval"
            dcval1.Width = 70
            dcval1.ReadOnly = True
            dcval1.Visible = False
            Me.dgv1.Columns.Add(dcval1)

            dcval1 = New DataGridViewTextBoxColumn
            dcval1.HeaderText = "Currency"
            dcval1.DataPropertyName = "currency_code"
            dcval1.Width = 70
            dcval1.ReadOnly = True
            dcval1.Visible = False
            Me.dgv1.Columns.Add(dcval1)

        End If

        dcval1 = New DataGridViewTextBoxColumn
        dcval1.HeaderText = "Cost Head"
        dcval1.DataPropertyName = "ch"
        dcval1.Width = 70
        dcval1.ReadOnly = True
        'dcval1.Visible = False
        Me.dgv1.Columns.Add(dcval1)

        dcval1 = New DataGridViewTextBoxColumn
        dcval1.HeaderText = "Cost Head Desc"
        dcval1.DataPropertyName = "cod"
        dcval1.Width = 70
        dcval1.ReadOnly = True
        'dcval1.Visible = False
        Me.dgv1.Columns.Add(dcval1)

        dcval1 = New DataGridViewTextBoxColumn
        dcval1.HeaderText = "A/C Head"
        dcval1.DataPropertyName = "ac"
        dcval1.Width = 70
        dcval1.ReadOnly = True
        'dcval1.Visible = False
        Me.dgv1.Columns.Add(dcval1)


        dcval1 = New DataGridViewTextBoxColumn
        dcval1.HeaderText = "A/C Head Desc"
        dcval1.DataPropertyName = "acd"
        dcval1.Width = 70
        dcval1.ReadOnly = True
        'dcval1.Visible = False
        Me.dgv1.Columns.Add(dcval1)
        dgv1.DataSource = ds.Tables("resultab")
    End Sub

#End Region

#Region "Tax query"

    Public Sub taxquery()

        cl.sql = "Select a.item ,a.poline,a.pohead,a.location_id,a.line_no from jan_gatE_lines a where "
        cl.sql &= "   A.GATE_NO='" & TXTGNO.Text & "' and A.flag=1  "
        cl.sql &= " order by A.line_no"
    End Sub


    Private Sub dgv2_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgv2.CellClick
        dgvtaxdetails.Columns.Clear()



        cl.sql = "  select y.tax_rate_CODE,''tax_type_name,y.tax_rate_percentage,y.UNROUND_TAX_AMT_FUN_CURR,y.LINE_AMT,c.supdcqty  from    apps.jai_tax_lines  y , jan_gatE_lines c where       (( ENTITY_CODE='RELEASE' and TRX_TYPE='BLANKET')or (ENTITY_CODE='PURCHASE_ORDER' and TRX_TYPE='STANDARD'))  AND    CASE WHEN TRX_TYPE='STANDARD' THEN   Y.TRX_ID WHEN TRX_TYPE='BLANKET'  THEN Y.ref_doc_TRX_id END=" & dgv2.Rows(dgv2.CurrentRow.Index).Cells(2).Value & " AND CASE WHEN TRX_TYPE='STANDARD' THEN   Y.trx_line_id WHEN TRX_TYPE='BLANKET'  THEN Y.ref_doc_line_id END   =  " & dgv2.Rows(dgv2.CurrentRow.Index).Cells(1).Value & " and c.gate_no=" & TXTGNO.Text & " and line_no=" & dgv2.Rows(dgv2.CurrentRow.Index).Cells(4).Value & " AND Y.ITEM_ID=C.ITEM_ID AND  TRX_LOC_LINE_ID=C.LOCATION_ID "

        ' cl.sql = "SELECT  b.tax_name, B.TAX_TYPE , B.TAX_RATE, a.tax_amount,A.TAX_LINE_NO  FROM ja_in_po_line_location_taxes A , ja_in_tax_codes  B ,jan_gatE_lines c  WHERE A.po_header_id =" & dgv2.Rows(dgv2.CurrentRow.Index).Cells(2).Value & "    AND A.TAX_ID=B.TAX_ID  AND po_line_id =  " & dgv2.Rows(dgv2.CurrentRow.Index).Cells(1).Value & "  AND line_location_id =" & dgv2.Rows(dgv2.CurrentRow.Index).Cells(3).Value & "  and c.flag=1 and c.gate_no=" & TXTGNO.Text & " and line_no=" & dgv2.Rows(dgv2.CurrentRow.Index).Cells(4).Value & "   ORDER BY A.TAX_LINE_NO"

        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds = New DataSet
        cl.oradap.Fill(ds, "resultab")



        With dgvtaxdetails
            .DataSource = ds.Tables("resultab")
            .Columns(0).HeaderText = "Tax Name" : .Columns(0).Width = 250
            .Columns(1).HeaderText = "Tax Type " : .Columns(1).Width = 150
            .Columns(2).HeaderText = "Tax Rate" : .Columns(2).Width = 90
            If txtrole.Text = "UNIT2VIEW" Or txtrole.Text = "USER" Then
                .Columns(3).Visible = False
            Else
                .Columns(3).HeaderText = "Tax Amount" : .Columns(3).Width = 90 : .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            End If

            .Columns(4).HeaderText = "Line Total" : .Columns(4).Width = 90 : .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            .Columns(5).HeaderText = "Qty" : .Columns(5).Width = 40 : .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        End With

    End Sub

    Public Sub order()

        cl.sql = "  select  y.tax_rate_CODE TAX_TYPE,NVL(SUM(y.UNROUND_TAX_AMT_FUN_CURR),0)tax_amount  from    apps.jai_tax_lines y , jan_gatE_lines c where  (( ENTITY_CODE='RELEASE' and TRX_TYPE='BLANKET')or (ENTITY_CODE='PURCHASE_ORDER' and TRX_TYPE='STANDARD'))    and c.gate_no=" & TXTGNO.Text & "  AND Y.ITEM_ID=C.ITEM_ID AND TRX_LOC_LINE_ID=C.LOCATION_ID    GROUP BY y.tax_rate_CODE"
        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds1 = New DataSet
        cl.oradap.Fill(ds1, "resultab")

        Dim a As String = ""
        Dim a1 As Double
        For i = 0 To ds1.Tables("resultab").Rows.Count - 1
            a1 = a1 + ds1.Tables("resultab").Rows(i).Item("tax_amount")
            a = String.Concat(a, vbNewLine, ds1.Tables("resultab").Rows(i).Item("tax_type") & " : " & ds1.Tables("resultab").Rows(i).Item("tax_amount"))

        Next
        richorder.Text = a
        lbordertot.Text = a1 + Val(lblval.Text)
    End Sub

    Public Sub dcorder()

        Dim ds3 As New DataSet

        cl.sql = "  select   Y.TAX_RATE_CODE tax_Type ,  NVL(round(SUM ((y.UNROUND_TAX_AMT_FUN_CURR / Y.TRX_LINE_QUANTITY) * c.supdcqty),3),0) tax_amount  from    apps.jai_tax_lines  y , jan_gatE_lines c where  (( ENTITY_CODE='RELEASE' and TRX_TYPE='BLANKET')or (ENTITY_CODE='PURCHASE_ORDER' and TRX_TYPE='STANDARD'))     and c.gate_no=" & TXTGNO.Text & " AND Y.ITEM_ID=C.ITEM_ID AND TRX_LOC_LINE_ID=C.LOCATION_ID and   TRX_LINE_QUANTITY > 0 GROUP BY y.tax_rate_CODE"

        cl.oradap = New OracleDataAdapter(cl.sql, cl.oracon)
        ds3 = New DataSet
        cl.oradap.Fill(ds3, "resultab")


        Dim a As String = ""
        For k = 0 To ds3.Tables("resultab").Rows.Count - 1
            total = total + ds3.Tables("resultab").Rows(k).Item("tax_amount")
            a = String.Concat(a, vbNewLine, ds3.Tables("resultab").Rows(k).Item("tax_type") & " : " & ds3.Tables("resultab").Rows(k).Item("tax_amount"))

        Next
        richdc.Text = a
        lbldctotval.Text = total + Val(lbfreight.Text) + Val(lbrate.Text) + Val(lbldcval.Text)
    End Sub

#End Region

End Class