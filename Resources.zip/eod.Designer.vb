﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class eod
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.dgv1 = New System.Windows.Forms.DataGridView()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmbprc = New System.Windows.Forms.ComboBox()
        Me.txtres = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbp = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbou = New System.Windows.Forms.ComboBox()
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(221, 209)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(161, 34)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "List Status"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'dgv1
        '
        Me.dgv1.AllowUserToAddRows = False
        Me.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv1.Location = New System.Drawing.Point(22, 294)
        Me.dgv1.Name = "dgv1"
        Me.dgv1.RowTemplate.Height = 28
        Me.dgv1.Size = New System.Drawing.Size(210, 28)
        Me.dgv1.TabIndex = 1
        Me.dgv1.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(17, 121)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(176, 18)
        Me.Label8.TabIndex = 50
        Me.Label8.Text = "Responsibility Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 78)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(149, 18)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "Process Category"
        '
        'cmbprc
        '
        Me.cmbprc.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbprc.FormattingEnabled = True
        Me.cmbprc.Items.AddRange(New Object() {"--Select--", "EOD", "Overall Status", "Person Wise Status", "Dept Wise Status"})
        Me.cmbprc.Location = New System.Drawing.Point(193, 74)
        Me.cmbprc.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbprc.Name = "cmbprc"
        Me.cmbprc.Size = New System.Drawing.Size(401, 26)
        Me.cmbprc.TabIndex = 49
        '
        'txtres
        '
        Me.txtres.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtres.FormattingEnabled = True
        Me.txtres.Location = New System.Drawing.Point(193, 117)
        Me.txtres.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtres.Name = "txtres"
        Me.txtres.Size = New System.Drawing.Size(401, 26)
        Me.txtres.TabIndex = 49
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(17, 166)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 18)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Process"
        '
        'cmbp
        '
        Me.cmbp.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbp.FormattingEnabled = True
        Me.cmbp.Location = New System.Drawing.Point(193, 162)
        Me.cmbp.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbp.Name = "cmbp"
        Me.cmbp.Size = New System.Drawing.Size(401, 26)
        Me.cmbp.TabIndex = 49
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(203, 339)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(161, 34)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "List Breakup"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(416, 389)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 20)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "Label3"
        Me.Label3.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(17, 31)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(129, 18)
        Me.Label4.TabIndex = 50
        Me.Label4.Text = "Operating Unit"
        '
        'cmbou
        '
        Me.cmbou.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbou.FormattingEnabled = True
        Me.cmbou.Location = New System.Drawing.Point(193, 27)
        Me.cmbou.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cmbou.Name = "cmbou"
        Me.cmbou.Size = New System.Drawing.Size(401, 26)
        Me.cmbou.TabIndex = 49
        '
        'eod
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(616, 265)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmbp)
        Me.Controls.Add(Me.txtres)
        Me.Controls.Add(Me.cmbou)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cmbprc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.dgv1)
        Me.Controls.Add(Me.Label2)
        Me.Name = "eod"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "List To Excel (Process Based)"
        CType(Me.dgv1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents dgv1 As DataGridView
    Friend WithEvents Label8 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents cmbprc As ComboBox
    Friend WithEvents txtres As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cmbp As ComboBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents cmbou As ComboBox
End Class
