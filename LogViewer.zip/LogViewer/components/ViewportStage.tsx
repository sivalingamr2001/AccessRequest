import type { Viewport } from "../types/viewport";
import { Terminal } from "./terminal/Terminal";

interface Props {
  viewport: Viewport;
  width: number;
  theme: "dark" | "light";
}

export function ViewportStage({ viewport, width, theme }: Props) {
  if (viewport === "desktop") {
    return <Terminal />;
  }

  const framedHeight = viewport === "mobile" ? 780 : 900;
  const src = `?embed=1&theme=${theme}`;

  return (
    <div className="flex justify-center">
      <div
        className="relative rounded-[28px] bg-[var(--card-muted)] ring-1 ring-[var(--border)] shadow-2xl shadow-black/20 dark:shadow-black/60 p-2 transition-all duration-300"
        style={{ width: width + 16 }}
      >
        <div className="absolute -top-6 left-1/2 -translate-x-1/2 font-mono text-[12px] uppercase tracking-[0.2em] text-[var(--text-muted)]">
          {width}px
        </div>
        <iframe
          key={`${viewport}-${theme}`}
          title={`Log terminal preview at ${width}px`}
          src={src}
          loading="lazy"
          className="block rounded-[22px] bg-[var(--page-bg)]"
          style={{ width, height: framedHeight, border: 0 }}
        />
      </div>
    </div>
  );
}
