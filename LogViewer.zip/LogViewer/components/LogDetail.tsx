import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import type { LogEntry } from "../types/log";
import { LevelBadge } from "./log-chips/LevelBadge";
import { SourceChip } from "./log-chips/SourceChip";
import { formatFull } from "../lib/time";

interface Props {
  log: LogEntry;
  onClose: () => void;
}

export function LogDetail({ log, onClose }: Props) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(
        `${formatFull(log.t)}  ${log.level.toUpperCase()}  ${log.source}  ${
          log.msg
        }${log.trace ? "\n" + log.trace : ""}`
      );
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      /* ignore */
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
      role="dialog"
      aria-modal="true"
      aria-label="Log details"
    >
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.15 }}
        className="absolute inset-0 bg-black/50 dark:bg-black/70"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 16, scale: 0.98 }}
        transition={{ duration: 0.18, ease: [0.2, 0.7, 0.2, 1] }}
        className="relative w-full sm:w-[520px] max-w-[640px] sm:rounded-2xl rounded-t-2xl bg-[var(--card-bg)] ring-1 ring-[var(--border)] shadow-2xl shadow-black/30 dark:shadow-black/70 max-h-[85vh] flex flex-col"
      >
        <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-[var(--border-soft)]">
          <div className="flex items-center gap-2 flex-wrap">
            <LevelBadge level={log.level} minWidth="" />
            <SourceChip source={log.source} short={false} minWidth="" />
            <time
              dateTime={new Date(log.t).toISOString()}
              className="font-mono text-[11px] text-[var(--text-muted)] tabular-nums"
            >
              {formatFull(log.t)}
            </time>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="shrink-0 inline-flex h-8 w-8 items-center justify-center rounded-md text-[var(--text-muted)] hover:bg-[var(--card-muted)] hover:text-[var(--text-primary)]"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 14 14"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M3 3l8 8M11 3l-8 8"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>

        <div className="px-4 py-4 overflow-y-auto log-scroll">
          <div className="font-mono text-[12.5px] text-[var(--text-primary)] whitespace-pre-wrap break-words leading-[20px]">
            {log.msg}
          </div>
          {log.trace && (
            <pre className="mt-3 font-mono text-[12px] text-rose-800 dark:text-rose-300 whitespace-pre-wrap break-words leading-[18px]">
              {log.trace}
            </pre>
          )}
          <div className="mt-4 grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-[11px] font-mono">
            <span className="text-[var(--text-muted)]">id</span>
            <span className="text-[var(--text-secondary)] tabular-nums">
              {log.id}
            </span>
            <span className="text-[var(--text-muted)]">source</span>
            <span className="text-[var(--text-secondary)]">{log.source}</span>
            <span className="text-[var(--text-muted)]">level</span>
            <span className="text-[var(--text-secondary)]">{log.level}</span>
            <span className="text-[var(--text-muted)]">timestamp</span>
            <span className="text-[var(--text-secondary)] tabular-nums">
              {log.t}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 px-4 py-3 border-t border-[var(--border-soft)] bg-[var(--card-muted)]/50 sm:rounded-b-2xl">
          <button
            type="button"
            onClick={copy}
            className="rounded-md px-3 py-1.5 text-[12px] font-semibold bg-[var(--card-bg)] text-[var(--text-primary)] ring-1 ring-inset ring-[var(--border)] hover:bg-[var(--card-muted)]"
          >
            {copied ? "✓ copied" : "copy"}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md px-3 py-1.5 text-[12px] font-semibold bg-emerald-700 text-white hover:bg-emerald-800 dark:bg-emerald-500/25 dark:text-emerald-50 dark:ring-1 dark:ring-inset dark:ring-emerald-400/40 dark:hover:bg-emerald-500/35"
          >
            close
          </button>
        </div>
      </motion.div>
    </div>
  );
}
