import { SunIcon } from "./icons/SunIcon";
import { MoonIcon } from "./icons/MoonIcon";

interface Props {
  theme: "dark" | "light";
  onToggle: () => void;
}

export function ThemeToggle({ theme, onToggle }: Props) {
  const next = theme === "dark" ? "light" : "dark";
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={`Switch to ${next} theme`}
      title={`Switch to ${next} theme`}
      className="inline-flex h-[38px] w-[38px] items-center justify-center rounded-xl bg-[var(--card-bg)] text-[var(--text-primary)] ring-1 ring-inset ring-[var(--border)] hover:bg-[var(--card-muted)]"
    >
      {theme === "dark" ? <SunIcon /> : <MoonIcon />}
    </button>
  );
}
