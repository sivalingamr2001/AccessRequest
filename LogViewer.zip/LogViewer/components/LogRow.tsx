import { memo } from "react";
import type { LogEntry } from "../types/log";
import { LevelBadge } from "./log-chips/LevelBadge";
import { SourceChip } from "./log-chips/SourceChip";
import { LEVEL_TEXT } from "./log-chips/styles";
import { formatTime, formatTimeShort } from "../lib/time";

interface RowProps {
  log: LogEntry;
  top: number;
  height: number;
  query: string;
  onSelect: (log: LogEntry) => void;
}

function highlight(text: string, query: string): React.ReactNode {
  if (!query) return text;
  const q = query.toLowerCase();
  const lower = text.toLowerCase();
  const parts: React.ReactNode[] = [];
  let i = 0;
  while (i < text.length) {
    const hit = lower.indexOf(q, i);
    if (hit === -1) {
      parts.push(text.slice(i));
      break;
    }
    if (hit > i) parts.push(text.slice(i, hit));
    parts.push(
      <mark
        key={hit}
        className="bg-emerald-200 text-emerald-900 dark:bg-emerald-400/30 dark:text-emerald-100 rounded-sm px-0.5"
      >
        {text.slice(hit, hit + q.length)}
      </mark>
    );
    i = hit + q.length;
  }
  return parts;
}

function Row({ log, top, height, query, onSelect }: RowProps) {
  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={`Open log ${log.id}`}
      onClick={() => onSelect(log)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect(log);
        }
      }}
      className="absolute left-0 right-0 font-mono cursor-pointer hover:bg-black/[3%] dark:hover:bg-white/[2.5%] focus:outline-none focus:bg-black/5 dark:focus:bg-white/[4%]"
      style={{ top, height }}
    >
      {/* Mobile: stacked — meta line above full-width message */}
      <div className="sm:hidden flex flex-col px-3 py-1 leading-tight">
        <div className="flex items-center gap-1.5">
          <SourceChip source={log.source} />
          <LevelBadge level={log.level} />
          <time
            dateTime={new Date(log.t).toISOString()}
            className="text-[10px] tabular-nums text-[var(--text-muted)]"
          >
            {formatTimeShort(log.t)}
          </time>
        </div>
        <div className={"truncate text-[12px] mt-0.5 " + LEVEL_TEXT[log.level]}>
          {highlight(log.msg, query)}
          {log.trace && (
            <span className="text-rose-800 dark:text-rose-300 pl-2">
              {log.trace}
            </span>
          )}
        </div>
      </div>

      {/* Tablet/Desktop: single row */}
      <div className="hidden sm:flex items-center gap-3 px-4 text-[12.5px] leading-[24px] h-full">
        <time
          dateTime={new Date(log.t).toISOString()}
          className="shrink-0 w-[92px] text-[var(--text-muted)] tabular-nums"
        >
          {formatTime(log.t)}
        </time>
        <LevelBadge level={log.level} />
        <SourceChip source={log.source} />
        <span className={"min-w-0 flex-1 truncate " + LEVEL_TEXT[log.level]}>
          {highlight(log.msg, query)}
          {log.trace && (
            <span className="text-rose-800 dark:text-rose-300 text-[12px] pl-2">
              {log.trace}
            </span>
          )}
        </span>
      </div>
    </div>
  );
}

export default memo(Row);
