export function Backdrop() {
  return (
    <>
      <div
        className="absolute inset-0 grid-bg pointer-events-none"
        aria-hidden="true"
      />
      <div
        className="absolute inset-0 backdrop-glow pointer-events-none"
        aria-hidden="true"
      />
    </>
  );
}
