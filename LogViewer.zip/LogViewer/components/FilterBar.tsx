import type { LogLevel, LogSource } from '../types/log';
import { LEVELS, SOURCES } from '../types/log';

const LEVEL_STYLES: Record<LogLevel, { on: string; off: string }> = {
  debug: {
    on: 'bg-zinc-700 text-white ring-zinc-600 dark:bg-zinc-500/25 dark:text-zinc-100 dark:ring-zinc-400/40',
    off: 'bg-zinc-100 text-zinc-700 ring-zinc-200 hover:bg-zinc-200 dark:bg-zinc-500/5 dark:text-zinc-400 dark:ring-zinc-500/10 dark:hover:text-zinc-200',
  },
  info: {
    on: 'bg-sky-700 text-white ring-sky-700 dark:bg-sky-500/25 dark:text-sky-100 dark:ring-sky-400/40',
    off: 'bg-sky-50 text-sky-800 ring-sky-200 hover:bg-sky-100 dark:bg-sky-500/5 dark:text-sky-400/80 dark:ring-sky-500/10 dark:hover:text-sky-200',
  },
  warn: {
    on: 'bg-amber-700 text-white ring-amber-700 dark:bg-amber-500/25 dark:text-amber-100 dark:ring-amber-400/40',
    off: 'bg-amber-50 text-amber-800 ring-amber-200 hover:bg-amber-100 dark:bg-amber-500/5 dark:text-amber-400/80 dark:ring-amber-500/10 dark:hover:text-amber-200',
  },
  error: {
    on: 'bg-rose-700 text-white ring-rose-700 dark:bg-rose-500/30 dark:text-rose-100 dark:ring-rose-400/50',
    off: 'bg-rose-50 text-rose-800 ring-rose-200 hover:bg-rose-100 dark:bg-rose-500/5 dark:text-rose-400/80 dark:ring-rose-500/10 dark:hover:text-rose-200',
  },
};

interface Props {
  activeLevels: Set<LogLevel>;
  activeSources: Set<LogSource>;
  onToggleLevel: (l: LogLevel) => void;
  onToggleSource: (s: LogSource) => void;
  counts: Record<LogLevel, number>;
}

export function FilterBar({
  activeLevels,
  activeSources,
  onToggleLevel,
  onToggleSource,
  counts,
}: Props) {
  return (
    <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Log filters">
      <div className="flex items-center gap-1.5" role="group" aria-label="Level filters">
        {LEVELS.map((l) => {
          const on = activeLevels.has(l);
          const style = LEVEL_STYLES[l][on ? 'on' : 'off'];
          return (
            <button
              key={l}
              type="button"
              aria-pressed={on}
              onClick={() => onToggleLevel(l)}
              className={
                'flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[12px] font-semibold uppercase tracking-wider ring-1 ring-inset transition ' +
                style
              }
            >
              <span>{l}</span>
              <span className="font-mono text-[12px] tabular-nums">{counts[l]}</span>
            </button>
          );
        })}
      </div>
      <div
        className="hidden sm:block h-5 w-px bg-[var(--border)] mx-1"
        aria-hidden="true"
      />
      <div
        className="flex flex-wrap items-center gap-1.5"
        role="group"
        aria-label="Source filters (empty = all)"
      >
        {SOURCES.map((s) => {
          const on = activeSources.has(s);
          return (
            <button
              key={s}
              type="button"
              aria-pressed={on}
              onClick={() => onToggleSource(s)}
              className={
                'rounded-md px-2 py-1 text-[12px] font-mono ring-1 ring-inset transition ' +
                (on
                  ? 'bg-[var(--text-primary)] text-[var(--card-bg)] ring-[var(--text-primary)]'
                  : 'bg-[var(--card-bg)] text-[var(--text-secondary)] ring-[var(--border)] hover:bg-[var(--card-muted)]')
              }
            >
              {s}
            </button>
          );
        })}
      </div>
    </div>
  );
}
