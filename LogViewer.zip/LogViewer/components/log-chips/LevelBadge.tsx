import type { LogLevel } from '../../types/log';
import { CHIP_BASE, LEVEL_BADGE } from './styles';

interface Props {
  level: LogLevel;
  minWidth?: string;
}

export function LevelBadge({ level, minWidth = 'min-w-[44px]' }: Props) {
  return <span className={CHIP_BASE + LEVEL_BADGE[level] + ' ' + minWidth}>{level}</span>;
}
