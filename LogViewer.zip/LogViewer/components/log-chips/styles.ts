import type { LogLevel } from "../../types/log";

export const CHIP_BASE =
  "shrink-0 inline-flex items-center justify-center rounded-sm px-1.5 py-[1px] text-[10px] font-semibold uppercase tracking-wider ring-1 ring-inset ";

export const LEVEL_BADGE: Record<LogLevel, string> = {
  debug:
    "bg-zinc-200 text-zinc-700 ring-zinc-300 dark:bg-zinc-500/15 dark:text-zinc-300 dark:ring-zinc-500/20",
  info: "bg-sky-100 text-sky-800 ring-sky-300 dark:bg-sky-500/15 dark:text-sky-200 dark:ring-sky-400/30",
  warn: "bg-amber-100 text-amber-800 ring-amber-300 dark:bg-amber-500/15 dark:text-amber-200 dark:ring-amber-400/30",
  error:
    "bg-rose-100 text-rose-800 ring-rose-400 dark:bg-rose-500/20 dark:text-rose-200 dark:ring-rose-400/40",
};

export const LEVEL_TEXT: Record<LogLevel, string> = {
  debug: "text-zinc-600 dark:text-zinc-400",
  info: "text-sky-800 dark:text-sky-300",
  warn: "text-amber-800 dark:text-amber-300",
  error: "text-rose-800 dark:text-rose-300",
};

export const SOURCE_CHIP_NEUTRAL =
  "bg-zinc-100 text-zinc-700 ring-zinc-300 dark:bg-zinc-500/15 dark:text-zinc-200 dark:ring-zinc-500/30";
