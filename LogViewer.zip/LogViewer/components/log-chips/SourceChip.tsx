import type { LogSource } from '../../types/log';
import { SOURCE_META } from '../../types/log';
import { CHIP_BASE, SOURCE_CHIP_NEUTRAL } from './styles';

interface Props {
  source: LogSource;
  short?: boolean;
  minWidth?: string;
}

export function SourceChip({ source, short = true, minWidth = 'min-w-[58px]' }: Props) {
  return (
    <span aria-label={source} className={CHIP_BASE + SOURCE_CHIP_NEUTRAL + ' ' + minWidth}>
      {short ? SOURCE_META[source].short : source}
    </span>
  );
}
