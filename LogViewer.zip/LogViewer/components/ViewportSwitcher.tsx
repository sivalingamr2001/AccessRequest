import type { Viewport } from '../types/viewport';
import { VIEWPORTS } from '../types/viewport';
import { ViewportIcon } from './icons/ViewportIcon';

interface Props {
  value: Viewport;
  onChange: (v: Viewport) => void;
}

export function ViewportSwitcher({ value, onChange }: Props) {
  return (
    <div
      role="radiogroup"
      aria-label="Preview viewport"
      className="inline-flex items-center gap-1 rounded-xl bg-[var(--card-bg)] p-1 ring-1 ring-inset ring-[var(--border)]"
    >
      {VIEWPORTS.map((v) => {
        const on = value === v.id;
        return (
          <button
            key={v.id}
            type="button"
            role="radio"
            aria-checked={on}
            onClick={() => onChange(v.id)}
            className={
              'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[13px] font-semibold transition ' +
              (on
                ? 'bg-emerald-700 text-white dark:bg-emerald-500/25 dark:text-emerald-50 dark:ring-1 dark:ring-inset dark:ring-emerald-400/50'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--card-muted)]')
            }
          >
            <ViewportIcon id={v.id} />
            <span>{v.label}</span>
            {v.width > 0 && (
              <span className="hidden md:inline font-mono text-[12px]">{v.width}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}
