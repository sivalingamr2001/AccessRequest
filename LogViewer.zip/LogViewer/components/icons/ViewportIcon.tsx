import type { Viewport } from "../../types/viewport";

export function ViewportIcon({ id }: { id: Viewport }) {
  if (id === "mobile") {
    return (
      <svg
        width="12"
        height="14"
        viewBox="0 0 12 14"
        fill="none"
        aria-hidden="true"
      >
        <rect
          x="1"
          y="1"
          width="10"
          height="12"
          rx="2"
          stroke="currentColor"
          strokeWidth="1.3"
        />
        <circle cx="6" cy="11" r="0.6" fill="currentColor" />
      </svg>
    );
  }
  if (id === "tablet") {
    return (
      <svg
        width="14"
        height="12"
        viewBox="0 0 14 12"
        fill="none"
        aria-hidden="true"
      >
        <rect
          x="1"
          y="1"
          width="12"
          height="10"
          rx="1.5"
          stroke="currentColor"
          strokeWidth="1.3"
        />
      </svg>
    );
  }
  return (
    <svg
      width="16"
      height="12"
      viewBox="0 0 16 12"
      fill="none"
      aria-hidden="true"
    >
      <rect
        x="1"
        y="1"
        width="14"
        height="8"
        rx="1"
        stroke="currentColor"
        strokeWidth="1.3"
      />
      <path
        d="M5 11h6"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
      />
    </svg>
  );
}
