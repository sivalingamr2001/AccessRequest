export function EmptyState() {
    return (
      <div className="absolute inset-0 grid place-items-center text-[var(--text-secondary)] text-[14px] font-mono">
        no logs match the current filters
      </div>
    );
  }
  