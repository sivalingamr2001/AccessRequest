import { RateSlider } from "./RateSlider";
import { SearchInput } from "./SearchInput";

interface Props {
  query: string;
  onQueryChange: (q: string) => void;
  rate: number;
  onRateChange: (r: number) => void;
  paused: boolean;
  onTogglePause: () => void;
  onClear: () => void;
}

export function TerminalHeader({
  query,
  onQueryChange,
  rate,
  onRateChange,
  paused,
  onTogglePause,
  onClear,
}: Props) {
  return (
    <div className="flex flex-col gap-3 px-3 sm:px-4 py-3 border-b border-[var(--border-soft)] bg-[var(--card-muted)]">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="flex gap-1.5 shrink-0" aria-hidden="true">
            <span className="h-2.5 w-2.5 rounded-full bg-rose-500/80" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber-400/90" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/90" />
          </div>
          <span className="ml-2 sm:ml-3 font-mono text-[12px] text-[var(--text-muted)] truncate">
            /var/log/services — streaming
          </span>
        </div>
        <div className="flex items-center gap-1.5 sm:gap-2 sm:justify-end sm:shrink-0">
          <RateSlider rate={rate} onChange={onRateChange} />
          <button
            type="button"
            onClick={onTogglePause}
            aria-pressed={paused}
            aria-label={paused ? "Resume log stream" : "Pause log stream"}
            className={
              "inline-flex items-center justify-center rounded-md h-8 w-10 sm:h-auto sm:w-auto sm:px-3 sm:py-1.5 text-[13px] font-semibold ring-1 ring-inset transition " +
              (paused
                ? "bg-emerald-100 text-emerald-800 ring-emerald-600/30 hover:bg-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-200 dark:ring-emerald-400/30 dark:hover:bg-emerald-500/25"
                : "bg-amber-100 text-amber-900 ring-amber-600/30 hover:bg-amber-200 dark:bg-amber-500/15 dark:text-amber-200 dark:ring-amber-400/30 dark:hover:bg-amber-500/25")
            }
          >
            <span className="sm:hidden" aria-hidden="true">
              {paused ? "▶" : "⏸"}
            </span>
            <span className="hidden sm:inline">
              {paused ? "▶ resume" : "⏸ pause"}
            </span>
          </button>
          <button
            type="button"
            onClick={onClear}
            aria-label="Clear logs"
            className="inline-flex items-center justify-center rounded-md h-8 w-10 sm:h-auto sm:w-auto sm:px-3 sm:py-1.5 text-[13px] font-semibold bg-[var(--card-muted)] text-[var(--text-primary)] ring-1 ring-inset ring-[var(--border)] hover:bg-[var(--card-bg)]"
          >
            <span className="sm:hidden" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path
                  d="M3 4.5h8M5.5 4.5V3a.8.8 0 01.8-.8h1.4a.8.8 0 01.8.8v1.5M4 4.5l.5 6.5a1 1 0 001 .9h3a1 1 0 001-.9l.5-6.5"
                  stroke="currentColor"
                  strokeWidth="1.3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
            <span className="hidden sm:inline">clear</span>
          </button>
        </div>
      </div>
      <SearchInput value={query} onChange={onQueryChange} />
    </div>
  );
}
