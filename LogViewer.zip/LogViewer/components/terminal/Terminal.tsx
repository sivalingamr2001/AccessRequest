import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { useLogStream } from '../../hooks/useLogStream';
import { useVirtualRows } from '../../hooks/useVirtualRows';
import { useIsMobile } from '../../hooks/useIsMobile';
import LogRow from '../LogRow';
import { FilterBar } from '../FilterBar';
import { StatusBar } from '../StatusBar';
import { LogDetail } from '../LogDetail';
import type { LogEntry, LogLevel, LogSource } from '../../types/log';
import { LEVELS } from '../../types/log';
import { TerminalHeader } from './TerminalHeader';
import { JumpToLatest } from './JumpToLatest';
import { EmptyState } from './EmptyState';

const ROW_HEIGHT_MOBILE = 40;
const ROW_HEIGHT_DESKTOP = 32;

export function Terminal() {
  const stream = useLogStream(10);
  const [query, setQuery] = useState('');
  const [activeLevels, setActiveLevels] = useState<Set<LogLevel>>(new Set(LEVELS));
  const [activeSources, setActiveSources] = useState<Set<LogSource>>(new Set());
  const [tailing, setTailing] = useState(true);
  const [newSinceLock, setNewSinceLock] = useState(0);
  const [selected, setSelected] = useState<LogEntry | null>(null);
  const isMobile = useIsMobile();
  const rowHeight = isMobile ? ROW_HEIGHT_MOBILE : ROW_HEIGHT_DESKTOP;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const srcFilter = activeSources.size > 0;
    const out: LogEntry[] = [];
    for (const log of stream.logs) {
      if (!activeLevels.has(log.level)) continue;
      if (srcFilter && !activeSources.has(log.source)) continue;
      if (q && !log.msg.toLowerCase().includes(q) && !log.source.includes(q)) continue;
      out.push(log);
    }
    return out;
  }, [stream.logs, query, activeLevels, activeSources]);

  const counts = useMemo(() => {
    const c: Record<LogLevel, number> = { debug: 0, info: 0, warn: 0, error: 0 };
    for (const l of stream.logs) c[l.level]++;
    return c;
  }, [stream.logs]);

  const { ref: scrollRef, start, end, totalHeight } = useVirtualRows({
    count: filtered.length,
    rowHeight,
    overscan: 10,
  });

  const prevLenRef = useRef(filtered.length);

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const grew = filtered.length - prevLenRef.current;
    prevLenRef.current = filtered.length;
    if (grew <= 0) return;
    if (tailing) {
      el.scrollTop = el.scrollHeight;
    } else {
      setNewSinceLock((n) => n + grew);
    }
  }, [filtered.length, tailing, scrollRef]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < rowHeight * 2;
      setTailing((prev) => {
        if (nearBottom && !prev) {
          setNewSinceLock(0);
          return true;
        }
        if (!nearBottom && prev) return false;
        return prev;
      });
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    return () => el.removeEventListener('scroll', onScroll);
  }, [scrollRef, rowHeight]);

  const jumpToLatest = () => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
    setTailing(true);
    setNewSinceLock(0);
  };

  const toggleLevel = (l: LogLevel) => {
    setActiveLevels((prev) => {
      const n = new Set(prev);
      if (n.has(l)) n.delete(l);
      else n.add(l);
      return n;
    });
  };

  const toggleSource = (s: LogSource) => {
    setActiveSources((prev) => {
      const n = new Set(prev);
      if (n.has(s)) n.delete(s);
      else n.add(s);
      return n;
    });
  };

  const visibleRows = filtered.slice(start, end);
  const trimmedQuery = query.trim();

  return (
    <section
      aria-label="Log stream"
      className="rounded-2xl bg-[var(--card-bg)] ring-1 ring-[var(--border)] shadow-xl shadow-black/20 dark:shadow-black/60 overflow-hidden"
    >
      <TerminalHeader
        query={query}
        onQueryChange={setQuery}
        rate={stream.rate}
        onRateChange={stream.setRate}
        paused={stream.paused}
        onTogglePause={() => stream.setPaused(!stream.paused)}
        onClear={stream.clear}
      />

      <div className="px-3 sm:px-4 py-3 border-b border-[var(--border-soft)] bg-[var(--card-muted)]/50">
        <FilterBar
          activeLevels={activeLevels}
          activeSources={activeSources}
          onToggleLevel={toggleLevel}
          onToggleSource={toggleSource}
          counts={counts}
        />
      </div>

      <div className="relative">
        <div
          ref={scrollRef}
          role="log"
          aria-live="polite"
          aria-relevant="additions"
          aria-label="Streaming logs"
          tabIndex={0}
          className="log-scroll relative h-[58vh] sm:h-[62vh] min-h-[360px] sm:min-h-[420px] overflow-y-auto scan-lines bg-[var(--card-bg)]"
        >
          {filtered.length === 0 && <EmptyState />}
          <div role="list" style={{ height: totalHeight, position: 'relative' }}>
            {visibleRows.map((log, i) => (
              <LogRow
                key={log.id}
                log={log}
                top={(start + i) * rowHeight}
                height={rowHeight}
                query={trimmedQuery}
                onSelect={setSelected}
              />
            ))}
          </div>
        </div>

        <JumpToLatest show={!tailing && newSinceLock > 0} count={newSinceLock} onClick={jumpToLatest} />
      </div>

      <StatusBar
        total={stream.total}
        shown={filtered.length}
        rate={stream.rate}
        paused={stream.paused}
        tailing={tailing}
      />

      <AnimatePresence>
        {selected && <LogDetail key={selected.id} log={selected} onClose={() => setSelected(null)} />}
      </AnimatePresence>
    </section>
  );
}
