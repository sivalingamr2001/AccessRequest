import { AnimatePresence, motion } from 'framer-motion';

interface Props {
  show: boolean;
  count: number;
  onClick: () => void;
}

export function JumpToLatest({ show, count, onClick }: Props) {
  return (
    <AnimatePresence>
      {show && (
        <motion.button
          key="jump"
          type="button"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 8 }}
          transition={{ duration: 0.18 }}
          onClick={onClick}
          className="absolute bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-emerald-700 text-white dark:bg-emerald-500 dark:text-black text-[13px] font-semibold px-4 py-1.5 shadow-lg shadow-emerald-700/30 dark:shadow-emerald-500/20 hover:bg-emerald-800 dark:hover:bg-emerald-400"
        >
          ↓ {count} new log{count === 1 ? '' : 's'}
        </motion.button>
      )}
    </AnimatePresence>
  );
}
