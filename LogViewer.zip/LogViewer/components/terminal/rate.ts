export const RATE_MIN = 1;
export const RATE_MAX = 60;
export const RATE_CURVE = 2.4;
export const SLIDER_STEPS = 100;

export function sliderToRate(v: number): number {
  const t = Math.min(1, Math.max(0, v / SLIDER_STEPS));
  return Math.round(RATE_MIN + Math.pow(t, RATE_CURVE) * (RATE_MAX - RATE_MIN));
}

export function rateToSlider(r: number): number {
  const t = (r - RATE_MIN) / (RATE_MAX - RATE_MIN);
  return Math.round(Math.pow(Math.min(1, Math.max(0, t)), 1 / RATE_CURVE) * SLIDER_STEPS);
}
