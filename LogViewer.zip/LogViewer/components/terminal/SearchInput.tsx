import { useId } from 'react';

interface Props {
  value: string;
  onChange: (v: string) => void;
}

export function SearchInput({ value, onChange }: Props) {
  const id = useId();
  return (
    <div className="relative w-full">
      <label htmlFor={id} className="sr-only">
        Search logs
      </label>
      <input
        id={id}
        type="search"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="search logs…"
        className="w-full rounded-md bg-[var(--card-bg)] text-[var(--text-primary)] text-[13px] font-mono px-3 py-1.5 ring-1 ring-[var(--border)] placeholder:text-[var(--text-dim)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
      />
      {value && (
        <button
          type="button"
          onClick={() => onChange('')}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-[var(--text-primary)] text-sm leading-none"
          aria-label="Clear search"
        >
          ×
        </button>
      )}
    </div>
  );
}
