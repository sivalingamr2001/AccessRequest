import { useId } from 'react';
import { SLIDER_STEPS, rateToSlider, sliderToRate } from './rate';

interface Props {
  rate: number;
  onChange: (r: number) => void;
}

export function RateSlider({ rate, onChange }: Props) {
  const id = useId();
  return (
    <div className="flex flex-1 sm:flex-none items-center gap-1.5 sm:gap-2 rounded-md bg-[var(--card-bg)] px-2 py-1 ring-1 ring-inset ring-[var(--border)]">
      <label
        htmlFor={id}
        className="text-[12px] font-mono uppercase tracking-widest text-[var(--text-muted)]"
      >
        rate
      </label>
      <input
        id={id}
        type="range"
        min={0}
        max={SLIDER_STEPS}
        value={rateToSlider(rate)}
        onChange={(e) => onChange(sliderToRate(parseInt(e.target.value, 10)))}
        aria-label="Log stream rate per second"
        aria-valuetext={`${rate} per second`}
        className="flex-1 min-w-0 sm:flex-none sm:w-20 lg:w-24 accent-[color:var(--accent)]"
      />
    </div>
  );
}
