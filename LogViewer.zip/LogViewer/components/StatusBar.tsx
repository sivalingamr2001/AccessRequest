interface Props {
  total: number;
  shown: number;
  rate: number;
  paused: boolean;
  tailing: boolean;
}

export function StatusBar({ total, shown, rate, paused, tailing }: Props) {
  return (
    <div
      role="status"
      aria-live="polite"
      className="flex items-center justify-between gap-3 px-3 sm:px-4 py-2 border-t border-[var(--border-soft)] bg-[var(--card-muted)] text-[12px] font-mono text-[var(--text-secondary)]"
    >
      <div className="flex items-center gap-2 sm:gap-4 min-w-0">
        <span className="flex items-center gap-1.5 shrink-0">
          <span
            aria-hidden="true"
            className={
              "inline-block h-1.5 w-1.5 rounded-full " +
              (paused
                ? "bg-amber-600 dark:bg-amber-400"
                : "bg-emerald-600 dark:bg-emerald-400 pulse-dot")
            }
          />
          <span
            className={
              paused
                ? "text-amber-800 dark:text-amber-300"
                : "text-emerald-800 dark:text-emerald-300"
            }
          >
            {paused ? "PAUSED" : "LIVE"}
          </span>
        </span>
        <span className="truncate">
          <span className="text-[var(--text-primary)]">
            {shown.toLocaleString()}
          </span>
          <span className="text-[var(--text-muted)]"> / </span>
          <span>{total.toLocaleString()}</span>
          <span className="hidden sm:inline"> logs</span>
        </span>
        <span className="hidden sm:inline">
          rate <span className="text-[var(--text-primary)]">{rate}</span>/s
        </span>
      </div>
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        <span
          className={
            tailing
              ? "text-emerald-800 dark:text-emerald-400"
              : "text-[var(--text-muted)]"
          }
        >
          {tailing ? "tailing ▼" : "locked"}
        </span>
        <span className="caret text-[var(--text-secondary)]" aria-hidden="true">
          ▌
        </span>
      </div>
    </div>
  );
}
