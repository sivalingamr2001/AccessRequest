export type ThemeName = "dark" | "light";

export const themes = {
  dark: {
    pageBg: "#07070b",
    cardBg: "#0a0a10",
    cardMuted: "#12121a",
    textPrimary: "#ffffff",
    textSecondary: "#d4d4d8",
    textMuted: "#a1a1aa",
    textDim: "#71717a",
    border: "#27272a",
    borderSoft: "#1a1a1f",
    accent: "#34d399",
    warn: "#fbbf24",
    infoFg: "#7dd3fc",
    warnFg: "#fcd34d",
    errorFg: "#fda4af",
    debugFg: "#a1a1aa",
  },
  light: {
    pageBg: "#f5f5f7",
    cardBg: "#ffffff",
    cardMuted: "#f4f4f5",
    textPrimary: "#18181b",
    textSecondary: "#3f3f46",
    textMuted: "#52525b",
    textDim: "#71717a",
    border: "#e4e4e7",
    borderSoft: "#ececef",
    accent: "#047857",
    warn: "#b45309",
    infoFg: "#075985",
    warnFg: "#92400e",
    errorFg: "#991b1b",
    debugFg: "#52525b",
  },
} as const;

export type ThemeTokens = (typeof themes)["dark"];

export function applyTheme(name: ThemeName): void {
  const root = document.documentElement;
  root.classList.toggle("dark", name === "dark");
  root.setAttribute("data-theme", name);
  root.style.colorScheme = name;
}
