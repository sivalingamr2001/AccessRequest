import { useCallback, useEffect, useRef, useState } from "react";
import type { LogEntry } from "../types/log";
import { makeBurst } from "../data/generators";

const MAX_BUFFER = 5000;

export interface StreamState {
  logs: LogEntry[];
  paused: boolean;
  rate: number;
  setPaused: (p: boolean) => void;
  setRate: (r: number) => void;
  clear: () => void;
  total: number;
}

export function useLogStream(initialRate = 8): StreamState {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [paused, setPaused] = useState(false);
  const [rate, setRate] = useState(initialRate);
  const [total, setTotal] = useState(0);

  const pausedRef = useRef(paused);
  const rateRef = useRef(rate);
  pausedRef.current = paused;
  rateRef.current = rate;

  useEffect(() => {
    let cancelled = false;
    let timer: number;

    const tick = () => {
      if (cancelled) return;
      if (!pausedRef.current) {
        const r = rateRef.current;
        const baseSize = Math.max(1, Math.round(r / 4));
        const burstChance = 0.08;
        const size = Math.random() < burstChance ? baseSize * 6 : baseSize;
        const now = Date.now();
        const batch = makeBurst(size, now);
        setLogs((prev) => {
          const next =
            prev.length + batch.length > MAX_BUFFER
              ? [
                  ...prev.slice(prev.length + batch.length - MAX_BUFFER),
                  ...batch,
                ]
              : [...prev, ...batch];
          return next;
        });
        setTotal((t) => t + batch.length);
      }
      const intervalMs = Math.max(40, 1000 / Math.max(1, rateRef.current));
      timer = window.setTimeout(tick, intervalMs);
    };

    timer = window.setTimeout(tick, 250);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, []);

  const clear = useCallback(() => setLogs([]), []);

  return { logs, paused, rate, setPaused, setRate, clear, total };
}
