import { useEffect, useRef, useState } from "react";

interface Args {
  count: number;
  rowHeight: number;
  overscan?: number;
}

export interface VirtualState {
  ref: React.RefObject<HTMLDivElement>;
  start: number;
  end: number;
  totalHeight: number;
  viewportHeight: number;
  scrollTop: number;
}

export function useVirtualRows({
  count,
  rowHeight,
  overscan = 8,
}: Args): VirtualState {
  const ref = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [viewportHeight, setViewportHeight] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        setScrollTop(el.scrollTop);
        raf = 0;
      });
    };
    el.addEventListener("scroll", onScroll, { passive: true });

    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setViewportHeight(entry.contentRect.height);
      }
    });
    ro.observe(el);

    return () => {
      el.removeEventListener("scroll", onScroll);
      ro.disconnect();
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const start = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
  const visibleCount = Math.ceil(viewportHeight / rowHeight) + overscan * 2;
  const end = Math.min(count, start + visibleCount);
  const totalHeight = count * rowHeight;

  return { ref, start, end, totalHeight, viewportHeight, scrollTop };
}
