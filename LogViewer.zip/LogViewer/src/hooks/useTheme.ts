import { useCallback, useEffect, useState } from "react";
import { ThemeName, applyTheme } from "../theme";

const KEY = "log-terminal-theme";

function initial(): ThemeName {
  if (typeof window === "undefined") return "dark";
  const qs = new URLSearchParams(window.location.search).get("theme");
  if (qs === "light" || qs === "dark") return qs;
  const stored = window.localStorage.getItem(KEY) as ThemeName | null;
  if (stored === "light" || stored === "dark") return stored;
  return window.matchMedia("(prefers-color-scheme: light)").matches
    ? "light"
    : "dark";
}

export function useTheme(): {
  theme: ThemeName;
  setTheme: (t: ThemeName) => void;
  toggle: () => void;
} {
  const [theme, setThemeState] = useState<ThemeName>(initial);

  useEffect(() => {
    applyTheme(theme);
    const hasOverride = new URLSearchParams(window.location.search).has(
      "theme"
    );
    if (hasOverride) return;
    try {
      window.localStorage.setItem(KEY, theme);
    } catch {
      /* quota or privacy mode — ignore */
    }
  }, [theme]);

  const setTheme = useCallback((t: ThemeName) => setThemeState(t), []);
  const toggle = useCallback(() => {
    setThemeState((t) => (t === "dark" ? "light" : "dark"));
  }, []);

  return { theme, setTheme, toggle };
}
