export function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function rnd(min: number, max: number): number {
  return Math.floor(min + Math.random() * (max - min + 1));
}

export function hex(len: number): string {
  let s = "";
  while (s.length < len) s += Math.random().toString(16).slice(2);
  return s.slice(0, len);
}
