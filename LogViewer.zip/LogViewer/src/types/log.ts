export type LogLevel = "debug" | "info" | "warn" | "error";

export type LogSource =
  | "api-gateway"
  | "auth-service"
  | "ingest-worker"
  | "scheduler"
  | "billing"
  | "edge-cdn";

export interface LogEntry {
  id: number;
  t: number;
  level: LogLevel;
  source: LogSource;
  msg: string;
  trace?: string;
}

export const LEVELS: LogLevel[] = ["debug", "info", "warn", "error"];

export const SOURCE_META: Record<LogSource, { short: string; weight: number }> =
  {
    "api-gateway": { short: "gateway", weight: 0.3 },
    "edge-cdn": { short: "cdn", weight: 0.22 },
    "ingest-worker": { short: "ingest", weight: 0.18 },
    "auth-service": { short: "auth", weight: 0.13 },
    scheduler: { short: "sched", weight: 0.1 },
    billing: { short: "billing", weight: 0.07 },
  };

export const SOURCES: LogSource[] = Object.keys(SOURCE_META) as LogSource[];
