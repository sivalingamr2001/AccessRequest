export type Viewport = 'mobile' | 'tablet' | 'desktop';

export interface ViewportSpec {
  id: Viewport;
  label: string;
  width: number;
}

export const VIEWPORTS: ViewportSpec[] = [
  { id: 'mobile', label: 'Mobile', width: 390 },
  { id: 'tablet', label: 'Tablet', width: 820 },
  { id: 'desktop', label: 'Desktop', width: 0 },
];
