import { useState } from "react";
import { Backdrop } from "./components/Backdrop";
import { ThemeToggle } from "./components/ThemeToggle";
import { ViewportSwitcher } from "./components/ViewportSwitcher";
import { ViewportStage } from "./components/ViewportStage";
import { useTheme } from "./hooks/useTheme";
import type { Viewport } from "./types/viewport";
import { VIEWPORTS } from "./types/viewport";
import { Terminal } from "./components/terminal/Terminal";

function isEmbed(): boolean {
  if (typeof window === "undefined") return false;
  return new URLSearchParams(window.location.search).has("embed");
}

function App() {
  const { theme, toggle } = useTheme();
  const [viewport, setViewport] = useState<Viewport>("desktop");

  if (isEmbed()) {
    return (
      <div className="relative min-h-screen overflow-hidden">
        <Backdrop />
        <main className="relative z-10 p-3 sm:p-6">
          <Terminal />
        </main>
      </div>
    );
  }

  const active = VIEWPORTS.find((v) => v.id === viewport)!;

  return (
    <div className="relative min-h-screen overflow-hidden">
      <Backdrop />

      <main className="relative z-10 mx-auto max-w-5xl px-3 sm:px-6 pt-10 sm:pt-16 pb-12 sm:pb-20">
        <header className="mb-5 sm:mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="font-sans text-2xl sm:text-3xl font-semibold tracking-tight text-[var(--text-primary)]">
              Log streaming terminal
            </h1>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <ViewportSwitcher value={viewport} onChange={setViewport} />
            <ThemeToggle theme={theme} onToggle={toggle} />
          </div>
        </header>

        <ViewportStage viewport={viewport} width={active.width} theme={theme} />
      </main>
    </div>
  );
}

export default App;
