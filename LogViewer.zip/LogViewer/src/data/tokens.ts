export const SVCS = [
  "auth-service",
  "billing",
  "ingest-worker",
  "pricing-svc",
  "feature-flags",
] as const;

export const PATHS = [
  "/v1/users/{id}",
  "/v1/orgs/{org}/members",
  "/v1/sessions",
  "/v2/events",
  "/v2/feeds/{id}",
  "/v1/billing/invoices",
  "/healthz",
  "/v1/assets/{id}",
] as const;

export const METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE"] as const;
export const STATUSES = [
  200, 200, 200, 201, 204, 301, 304, 400, 401, 404, 429,
] as const;
export const DOMAINS = [
  "acme.io",
  "app.acme.io",
  "api.acme.io",
  "cdn.acme.dev",
] as const;
export const POPS = [
  "fra1",
  "cdg1",
  "iad1",
  "sjc2",
  "nrt1",
  "gru1",
  "syd1",
  "lhr2",
] as const;
export const GEOS = [
  "DE-BE",
  "US-CA",
  "US-NY",
  "JP-13",
  "BR-SP",
  "GB-LDN",
  "AU-NSW",
] as const;
export const PLANS = ["starter", "pro", "team", "enterprise"] as const;
export const CRONS = [
  "*/5 * * * *",
  "0 * * * *",
  "0 0 * * *",
  "*/15 * * * *",
  "0 9 * * 1",
] as const;
export const QUEUES = [
  "emails",
  "webhooks",
  "thumbnails",
  "embeddings",
  "reindex",
] as const;
export const ACTIONS = [
  "orgs.read",
  "invoice.write",
  "users.delete",
  "feed.publish",
  "admin.impersonate",
] as const;
export const OAUTHS = ["google", "github", "okta", "azure-ad"] as const;
export const TABLES = [
  "events",
  "sessions",
  "orders",
  "feature_usage",
] as const;
export const COLS = [
  "email_verified_at",
  "plan_id",
  "archived_at",
  "region_code",
] as const;
export const TYPES = ["varchar", "timestamptz", "jsonb", "int4"] as const;
export const SKUS = [
  "seat-pro",
  "storage-tib",
  "requests-1m",
  "addon-sso",
] as const;
export const IDS = [
  "7fa12",
  "b93de",
  "0cc41",
  "d81a7",
  "4ee0b",
  "9ba5c",
  "a14f8",
  "6e22d",
] as const;
export const USERS = [
  "u_8f24a1",
  "u_b71c0d",
  "u_4ed218",
  "u_a09e3f",
  "u_15c8b2",
] as const;
export const TENANTS = [
  "t_acme",
  "t_globex",
  "t_initech",
  "t_umbrella",
  "t_hooli",
] as const;
export const MFAS = ["totp", "webauthn", "sms", "none"] as const;
export const CACHES = ["HIT", "MISS", "STALE", "BYPASS"] as const;
export const BUCKETS = ["events", "archive", "staging"] as const;
