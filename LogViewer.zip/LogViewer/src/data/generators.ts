import type { LogEntry, LogLevel, LogSource } from "../types/log";
import { SOURCES, SOURCE_META } from "../types/log";
import { pick, rnd } from "../lib/random";
import { POOLS } from "./templates";
import { fill } from "./fill";

function pickSource(): LogSource {
  const r = Math.random();
  let acc = 0;
  for (const s of SOURCES) {
    acc += SOURCE_META[s].weight;
    if (r < acc) return s;
  }
  return SOURCES[SOURCES.length - 1];
}

function weightedLevel(): LogLevel {
  const r = Math.random();
  if (r < 0.55) return "info";
  if (r < 0.8) return "debug";
  if (r < 0.95) return "warn";
  return "error";
}

let idSeq = 0;

export function makeLog(now = Date.now()): LogEntry {
  const source = pickSource();
  const level = weightedLevel();
  const tmpl = pick(POOLS[source][level]);
  const entry: LogEntry = {
    id: ++idSeq,
    t: now,
    level,
    source,
    msg: fill(tmpl),
  };
  if (level === "error" && Math.random() < 0.5) {
    entry.trace = `    at handler (${source}/index.ts:${rnd(10, 400)}:${rnd(
      1,
      80
    )})`;
  }
  return entry;
}

export function makeBurst(size: number, now = Date.now()): LogEntry[] {
  const out: LogEntry[] = new Array(size);
  for (let i = 0; i < size; i++) out[i] = makeLog(now);
  return out;
}
