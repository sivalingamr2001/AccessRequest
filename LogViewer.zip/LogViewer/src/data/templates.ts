import type { LogLevel, LogSource } from "../types/log";

export const POOLS: Record<LogSource, Record<LogLevel, readonly string[]>> = {
  "api-gateway": {
    info: [
      "{method} {path} {status} {ms}ms tenant={tenant} bytes={bytes}",
      "{method} {path} {status} {ms}ms cache={cache}",
      "route /v2/orgs/{org}/members served {status} in {ms}ms",
      "tls handshake ok sni={domain} cipher=TLS_AES_128_GCM",
      "edge=fra1 → origin=us-east-1 rtt={ms}ms",
      "cors preflight ok origin={domain}",
    ],
    debug: [
      "route matched {path} params.id={id}",
      "header sweep removed X-Internal-Trace from response",
      "h2 stream {n} window={n2} bytes",
      "circuit-breaker={cb} half-open trial allowed",
    ],
    warn: [
      "rate-limit 80% for tenant={tenant} window=60s",
      "slow upstream {svc} took {ms}ms (budget 250ms)",
      "{status} retry-after=2 from {svc}",
      "deprecated header X-Legacy-Auth from ip={ip}",
    ],
    error: [
      "upstream 502 from {svc} after {ms}ms request_id={req}",
      "tls handshake failed sni={domain} reason=unknown_ca",
      "route {path} panicked: nil pointer dereference",
      "request body exceeded 10MiB limit ip={ip}",
    ],
  },
  "auth-service": {
    info: [
      "login ok user={user} mfa={mfa} ip={ip}",
      "session refreshed sid={sid} user={user} ttl={ttl}s",
      "oauth callback ok provider={oauth} user={user}",
      "password rotation completed for user={user}",
      "token issued aud=api scope=read:org user={user}",
      "logout user={user} reason=user_initiated",
    ],
    debug: [
      "jwt verify ok kid={kid} alg=EdDSA",
      "argon2id verify took {ms}ms (target 200ms)",
      "rbac check user={user} action={action} → allow",
      "session store hit sid={sid} latency={ms}ms",
    ],
    warn: [
      "mfa challenge timed out user={user} method=totp",
      "suspicious login user={user} new_geo={geo} ip={ip}",
      "rate-limit /login 5/min from ip={ip}",
      "refresh token reused — rotating session for user={user}",
    ],
    error: [
      "jwt verification failed reason=signature_mismatch ip={ip}",
      "oauth state mismatch provider={oauth} ip={ip}",
      "argon2id timeout user={user} after {ms}ms",
      "lockout: 10 failed attempts user={user} ip={ip}",
    ],
  },
  "ingest-worker": {
    info: [
      "consumed batch={n} from kafka://ingest p={p} offset={o}",
      "flushed {n} rows to s3://{bucket}/dt={dt}/part-{p}.parquet",
      "compaction merged {n} segments → 1 ({mb}MB)",
      "lease renewed lock={job} ttl=30s",
      "worker={worker} claimed shard={shard} lag={ms}ms",
      "schema evolved table={table} added col={col}:{type}",
    ],
    debug: [
      "parsed payload keys=[ts, user_id, org_id, event]",
      "pool stats active={a} idle={i} waiting={w}",
      "codec=zstd level=3 ratio={ratio}x",
      "span op=parquet.write rows={n} duration={ms}ms",
    ],
    warn: [
      "consumer lag={ms}ms on partition={p} (threshold 5000ms)",
      'malformed event dropped: missing field "ts"',
      "rebalance triggered group=ingest-prod members={n}",
      "backpressure: writer queue {n}/1024",
    ],
    error: [
      "s3 PutObject failed bucket={bucket} key=dt={dt}/part-{p} status=503",
      "kafka commit failed group=ingest-prod p={p}: COORDINATOR_LOAD",
      "parquet writer panic: schema mismatch col={col}",
      "checksum mismatch expected={hash} got={hash2} batch={job}",
    ],
  },
  scheduler: {
    info: [
      'cron "{cron}" fired job={job} next={dt}T{time}Z',
      "job {job} succeeded in {ms}ms attempts=1",
      "queue={queue} drained {n} → 0 in {ms}ms",
      "leader election won node=node-{shard}",
      "job {job} dispatched to worker={worker}",
    ],
    debug: [
      "tick scheduler ts={dt}T{time}Z queues=[{queue},nightly,reports]",
      "next-run plan: 12 jobs in window 60s",
      "priority bump job={job} score={score}",
    ],
    warn: [
      "job {job} retry {n}/5 reason=timeout",
      "queue={queue} depth {n} (warn at 500)",
      "worker={worker} heartbeat stale {ms}ms",
      'cron drift detected: missed window for "{cron}" by {ms}ms',
    ],
    error: [
      "job {job} failed after 5 attempts: deadline exceeded",
      "lost leadership: lease expired for node-{shard}",
      "job {job} panicked: nil dependency graph",
    ],
  },
  billing: {
    info: [
      "invoice {inv} finalized total=${amount} tenant={tenant}",
      "charge succeeded ${amount} card=•••• {card4} user={user}",
      "usage roll-up tenant={tenant} period={dt} units={n}",
      "plan changed tenant={tenant} {plan} → {plan2} prorate=yes",
      "webhook stripe.invoice.paid id={inv} → 200",
    ],
    debug: [
      "tax calc tenant={tenant} jurisdiction={geo} rate={rate}%",
      "idempotency key {key} cache hit",
      "invoice line generated sku={sku} qty={n} unit=${amount}",
    ],
    warn: [
      "card expiring soon user={user} card=•••• {card4} exp={dt}",
      "usage approaching cap tenant={tenant} 92% of {plan}",
      "webhook retry {n}/4 stripe.charge.failed",
      "reconciliation drift ${amount} tenant={tenant}",
    ],
    error: [
      "charge declined ${amount} card=•••• {card4} reason=insufficient_funds",
      "stripe API 500 idempotency_key={key} after {ms}ms",
      "invoice {inv} finalize failed: tax_calc_unavailable",
      "dunning escalation tenant={tenant} 3rd attempt failed",
    ],
  },
  "edge-cdn": {
    info: [
      "cache HIT pop={pop} key={path} age={ttl}s",
      "cache MISS → origin pop={pop} key={path} {ms}ms",
      "purge ok pattern={path}* invalidated={n} keys",
      "http3 request pop={pop} {path} {ms}ms",
      "origin shield warmed pop={pop} {n} keys",
      "pop={pop} healthy: 99.9% 5m",
    ],
    debug: [
      "vary header normalized: Accept-Encoding=br",
      "h3 quic 0-rtt accepted pop={pop} ip={ip}",
      "tier-2 cache lookup pop={pop} latency={ms}ms",
    ],
    warn: [
      "origin slow pop={pop} {ms}ms (p95 800ms)",
      "cache fill stampede {path} (collapsed {n} requests)",
      "rate-limit ddos-shield triggered ip={ip} pop={pop}",
      "tls cert renewing in 7d for {domain}",
    ],
    error: [
      "origin unreachable {svc} pop={pop} after {ms}ms",
      "h3 quic version negotiation failed ip={ip}",
      "cert chain invalid for {domain} pop={pop}",
    ],
  },
};
